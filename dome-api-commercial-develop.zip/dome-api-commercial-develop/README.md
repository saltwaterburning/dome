## DOMEApi

This is the REST Service application for DOME. It utilizes Spring Security/JWT to secure endpoints as well as implements Actuator to monitoring and management.

###NOTE: These instructions were written after the fact and have not been thoroughly vetted. If you encounter an issue or incorrect step, please 

### Getting the Source Code
    * Clone the GIT repo at [DomeAPI Repo](https://github.com/dbdsct/DOMEApi) 
    
### Install Lombok    
    * Download https://projectlombok.org/downloads/lombok.jar version 1.18.8
    * java -jar lombok.jar
    * Point installer to your Eclipse installation
    * Restart Eclipse
    
### API Doc Installation  
You do not need to install APIDoc on your local machine if you do not want it. Jenkins will be generate the API Docs when it is building Dome. If you want it installed locally so you can validate your annotations and view the output, follow these steps.
   
    * Make sure you have node installed on your machine
    * run: npm install apidoc -g
    * add install directory (default is c:\Users\USERNAME\AppData\Roaming\npm\) to your path
    * Default output folder is c:/temp/DomeApiDocumentation but can be overridden via command line.
    * Validate install by running apidoc
