SELECT 
asset_id,
serial_number,
rating,
date_removed,
cycles,
hours,
sv_flag,
removal_reason,
date_removal_reported,
removal_event_id,
tso,
cso
FROM Hive.app_edata_view.rpt1_engines_waiting_induction WHERE serial_number in ('222007','733349','733815' )
