SELECT  
	   u.event_id,
       u.event_date_time,
       u.serial_number,
       u.engine_type,
       u.engine_family AS ENGINE_GROUP,
       u.engine_model,
       u.rating AS THRUST,
       u.tsn,
       u.csn,
       u.tso,
       u.cso,
       u.date_removed AS removed_date,
       u.date_inducted,
       u.sh_enddate,
       u.removal_reason,
       u.planned_sv_classification_type AS VISIT_TYPE
FROM (
		SELECT 
		   event_id,
	       event_date_time,
	       serial_number,
	       engine_type,
	       engine_family,
	       engine_model,
	       rating,
	       tsn,
	       csn,
	       tso,
	       cso,
	       date_removed,
	       date_inducted,
	       sh_enddate,
	       removal_reason,
	       planned_sv_classification_type

		from Hive.app_edata_view.rpt1_sv_aggregate
			
) as u

right join 
(
    SELECT serial_number, max( date_removed) as MaxRemove 
       from Hive.app_edata_view.rpt1_sv_aggregate
    group by serial_number
       
) as y on (u.date_removed = y.MaxRemove AND y.serial_number = u.serial_number)

UNION 

SELECT  
	   u.event_id,
       u.event_date_time,
       u.serial_number,
       u.engine_model as engine_type ,
       u.engine_model as engine_family,
       u.engine_model,
       u.rating AS THRUST,
       u.tsn,
       u.csn,
       u.tso,
       u.cso,
       u.date_removed AS removed_date,
       u.date_inducted,
       u.sh_enddate,
       u.removal_reason,
       u.planned_sv_classification_type AS VISIT_TYPE
FROM (
		SELECT 
		   event_id,
	       event_date_time,
	       serial_number,
		   engine_model as engine_type ,
           engine_model as engine_family,
	       engine_model,
	       rating,
	       tsn,
	       csn,
	       tso,
	       cso,
	       date_removed,
	       date_inducted,
	       sh_enddate,
	       removal_reason,
	       planned_sv_classification_type

		from Hive.app_vdata_view.rpt1_sv_aggregate
			
) as u

inner join 
(
    SELECT serial_number, max( date_removed) as MaxRemove 
       from Hive.app_vdata_view.rpt1_sv_aggregate
    group by serial_number
       
) as y on (u.date_removed = y.MaxRemove AND y.serial_number = u.serial_number)