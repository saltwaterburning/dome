SELECT
	value_description as EC_ID,
	allowable_value as EC_Description,
	attribute_value_id as EC_ID_Value
FROM
	(
	SELECT
	    value_description,
		allowable_value ,
		attribute_value_id
	from
		Hive.app_edata.attribute_values
	where
		(attribute_id = 27
		and value_description NOT IN (
			SELECT value_description
		FROM
			Hive.app_vdata.attribute_values
		where
			attribute_id = 27 ))
UNION
	SELECT
		value_description,
		allowable_value ,
		attribute_value_id
	from
		Hive.app_vdata.attribute_values
	where
		attribute_id = 27 ) as u
ORDER BY
	EC_ID