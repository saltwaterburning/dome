SELECT
	allowable_value as CUST_ID,
	value_description as CUST_Description,
	attribute_value_id as CUST_ID_Value
FROM
	(
	SELECT
		allowable_value ,
		value_description,
		attribute_value_id
	from
		Hive.app_edata.attribute_values
	where
		(attribute_id = 1
		and allowable_value NOT IN (
			SELECT allowable_value
		FROM
			Hive.app_vdata.attribute_values
		where
			attribute_id = 1 ))
UNION
	SELECT
		allowable_value ,
		value_description,
		attribute_value_id
	from
		Hive.app_vdata.attribute_values
	where
		attribute_id = 1 ) as u
ORDER BY
	CUST_ID