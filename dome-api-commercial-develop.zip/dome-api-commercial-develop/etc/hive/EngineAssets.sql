SELECT
	esn,
	asset_id,
	enginetype,
	enginegroup,
	enginemodel,
	fha_tm,
	thrustrating,
	operator,
	operator_desc,
	owner,
	owner_desc,
	tsn,
    csn,
    lifelimitingllpcycremaining,
    tso,
    cso,
	engine_disposition,
	MaxInstall,
	MaxRemove
FROM
	(
	SELECT
		x.esn,
		x.asset_id,
		x.enginetype,
		x.enginegroup,
		x.enginemodel,
		x.fha_tm,
		x.thrustrating,
		x.operator,
		x.operator_desc,
		x.owner,
		x.owner_desc,
		x.tsn,
	    x.csn,
	    x.lifelimitingllpcycremaining,
	    x.tso,
	    x.cso,
		x.engine_disposition,
		q.MaxInstall,
		q.MaxRemove
	FROM
		(
			SELECT esn,
			y.asset_id,
			'V2500' as enginetype,
			CONCAT('V2500-', model) as enginegroup,
			CONCAT('V25', SUBSTRING(thrustrating, 1, 2), '-', model) as enginemodel,
			fha_tm,
			thrustrating,
			operator,
			operator_desc,
			owner,
			owner_desc,
			tsn,
		    csn,
		    lifelimitingllpcycremaining,
		    tso,
		    cso,
			engine_disposition
		FROM
			Hive.app_vdata_view.rpt1_fleet_status_by_engine_fleet as vtest
		right join Hive.app_vdata_view.assets as y on
			vtest.esn = y.serial_number
			and asset_type_id = 2
		where
			engine_disposition in('Serviceable',
			'Unserviceable') ) as x
	inner join  (
		SELECT
			asset_id,
			max(A.date_installed) as MaxInstall,
			max(A.date_removed) as MaxRemove
		from
			Hive.app_vdata_view.assets_on_off as A
		INNER join Hive.app_vdata_view.assets_on_off as B on
			A.asset_id = B.asset_id
		group by
			a.asset_id ) as q on
		x.asset_id = q.asset_id
UNION
	SELECT
		ex.esn,
		ex.asset_id,
		ex.enginetype,
		ex.enginegroup,
		ex.enginemodel,
		ex.fha_tm,
		ex.thrustrating,
		ex.operator,
		ex.operator_desc,
		ex.owner,
		ex.owner_desc,
		ex.tsn,
	    ex.csn,
	    ex.lifelimitingllpcycremaining,
	    ex.tso,
	    ex.cso,
		ex.engine_disposition,
		eq.MaxInstall,
		eq.MaxRemove
	FROM
		(
			SELECT esn,
			ey.asset_id,
			etest.`engine type` as enginetype,
			etest.`engine family` as enginegroup,
			etest.`engine model` as enginemodel,
			etest.fha_tm,
			etest.thrustrating,
			etest.operator_code as operator ,
			etest.operator_desc,
			etest.owner_code as owner,
			etest.owner_desc,
			etest.tsn,
		    etest.csn,
		    etest.lifelimitingllpcycremaining,
		    etest.tso,
		    etest.cso,
			etest.engine_disposition
		FROM
			Hive.app_edata_view.rpt1_fleet_status_by_engine_fleet as etest
		right join Hive.app_edata_view.assets as ey on
			etest.esn = ey.serial_number
			and asset_type_id = 2
		where
			engine_disposition in('Serviceable',
			'Unserviceable') ) as ex
	INNER JOIN (
		SELECT
			asset_id,
			max(EA.date_installed) as MaxInstall,
			max(EA.date_removed) as MaxRemove
		from
			Hive.app_edata_view.assets_on_off as EA
		INNER join Hive.app_edata_view.assets_on_off as EB on
			EA.asset_id = EB.asset_id
		group by
			EA.asset_id ) as eq on
		ex.asset_id = eq.asset_id ) as u
	