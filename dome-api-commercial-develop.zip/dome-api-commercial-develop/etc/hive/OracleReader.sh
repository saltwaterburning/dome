sqoop eval -libjars  /cygdrive/d/sqoop/sqoop-1.4.7.bin__hadoop-2.6.0/lib/ojdbc6_g.jar --driver oracle.jdbc.OracleDriver --connect jdbc:oracle:thin:@10.196.1.215:1521:PRATDEVL --username pwebis --password pwebis --query 'SELECT * FROM PWEBIS.CUSTOMER'



sqoop import --connect jdbc:oracle:thin:@10.196.1.215:1521:PRATDEVL --table PWEBIS.CUSTOMER --username pwebis --password pwebis --hive-import --hive-database DatabaseName --create-hive-table --hive-table tableName -m 1 > text.text


//Working get connection from OracleDriver
sqoop list-tables --driver oracle.jdbc.driver.OracleDriver --connect jdbc:oracle:thin:@10.196.1.215:1521:PRATDEVL --username pwebis --password pwebis

//working getall from CUSTMER table
sqoop eval --connect jdbc:oracle:thin:@10.196.1.215:1521:PRATDEVL --username pwebis --password pwebis --query "SELECT * FROM PWEBIS.CUSTOMER"

sqoop import --connect jdbc:oracle:thin:@10.196.1.215:1521:PRATDEVL --username pwebis --password pwebis
--table EMPLOYEES \
--hive-import \
--create-hive-table \
--hive-table mydb.newtable


sqoop import --connect jdbc:oracle:thin:@10.196.1.215:1521:PRATDEVL --username pwebis --password pwebis --table "test" --target-dir "D:\sqoop\test" --delete-target-dir --hive-import --hs2-url "jdbc:hive2://knox.eh.pweh.com:443;transportMode=http;httpPath=/gateway/default/hive;AuthMech=3;SSL=1;SSLTrustStore=D:\dbeaver\truststore-entrust.jks;SSLTrustStorePwd=entrust" --hs2-user usernameX006776 --hs2-password Smile06119!

//get connection from HIVE Hadoop
sqoop list-tables --connect jdbc:hive2:@10.30.4.38:443 --username X006776 --password Smile06119!


sqoop --hive-import --hs2-url"jdbc:hive2://knox.eh.pweh.com:443;transportMode=http;httpPath=/gateway/default/hive;AuthMech=3;SSL=1;SSLTrustStore=D:\dbeaver\truststore-entrust.jks;SSLTrustStorePwd=entrust" --hs2-user usernameX006776 --hs2-password Smile06119!


jdbc:hive2://knox.eh.pweh.com:443;transportMode=http;httpPath=/gateway/default/hive;AuthMech=3;SSL=1;SSLTrustStore=D:\dbeaver\truststore-entrust.jks;SSLTrustStorePwd=entrust

knox.eh.pweh.com:443

sqoop import --driver oracle.jdbc.driver.OracleDriver --hive-import --connect jdbc:oracle:thin:@10.196.1.215:1521:PRATDEVL --username pwebis --password pwebis --verbose -m 1 --table PWEBIS.CUSTOMER

//partial working
sqoop import  --hive-import --connect jdbc:oracle:thin:@10.196.1.215:1521:PRATDEVL --username pwebis --password pwebis --verbose -m 1 --table PWEBIS.CUSTOMER

/*corrected
 <configuration>
   <property>
      <name>fs.default.name</name>
      <value>hdfs://127.0.0.1:9000</value>
   </property>
</configuration>


ERROR tool.ImportTool: Import failed: java.net.ConnectException: Call From AI21412
8/172.19.95.197 to 127.0.0.1:9000 failed on connection exception: java.net.ConnectException: Connection refused: no further information; For more details see:  http://wiki.apache.org/hadoop/Connection
Refused*/

# sqoop eval --connect "jdbc:hive2://sandbox.hortonworks.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2" --driver org.apache.hive.jdbc.HiveDriver --username hive -P
# sqoop list-tables --connect "jdbc:hive2://knox.eh.pweh.com:443;transportMode=http;httpPath=/gateway/default/hive;AuthMech=3;SSL=1;SSLTrustStore=D:\dbeaver\truststore-entrust.jks;SSLTrustStorePwd=entrust; UID=X006776; PWD=Smile06119!" --driver com.simba.hive.jdbc41.HS2Driver  --query "SELECT * FROM Hive.app_vdata_view.assets"

//working
sqoop eval --connect 
"jdbc:hive2://knox.eh.pweh.com:443;transportMode=http;httpPath=/gateway/default/hive;AuthMech=3;SSL=1;SSLTrustStore=D:\dbeaver\truststore-entrust.jks;SSLTrustStorePwd=entrust;UID=X006776;PWD=Smile06119!" --driver com.simba.hive.jdbc41.HS2Driver




sqoop import --connect jdbc:oracle:thin:@10.196.1.215:1521:PRATDEVL --username pwebis --password pwebis --table "CUSTOMER" --target-dir "D:\sqoop\test" --hive-import --hs2-url "jdbc:hive2://knox.eh.pweh.com:443;transportMode=http;httpPath=/gateway/default/hive;AuthMech=3;SSL=1;SSLTrustStore=D:\dbeaver\truststore-entrust.jks;SSLTrustStorePwd=entrust" --hs2-user username X006776 --hs2-password Smile06119!


//working   Hive.app_vdata_view.assets
SQOOP EXPORT --connect jdbc:oracle:thin:@10.196.1.215:1521:PRATDEVL --username pwebis --password pwebis --table PWEBIS.TEST --input-fields-terminated-by ',' --input-lines-terminated-by '\n' --export-dir "<<HDFS directory>>/<<file name>>" --input-null-string "\\\\N" --input-null-non-string "\\\\N" --verbose

sqoop --hive-import --hs2-url"jdbc:hive2://knox.eh.pweh.com:443;transportMode=http;httpPath=/gateway/default/hive;AuthMech=3;SSL=1;SSLTrustStore=D:\dbeaver\truststore-entrust.jks;SSLTrustStorePwd=entrust" --hs2-user usernameX006776 --hs2-password Smile06119!