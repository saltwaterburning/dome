SELECT c.esn ,  c.tsn, c.csn, c.tso, c.cso, c.lifelimitingllpcycremaining,
		c.removal_reason, c.date_removed
FROM (
		SELECT b.esn, b.tsn, b.csn, b.tso, b.cso,  b.lifelimitingllpcycremaining, 
			removal_reason, date_removed
			from Hive.app_edata_view.rpt1_fleet_status_by_engine_fleet b 
			inner join  Hive.app_edata_view.rpt1_engines_waiting_induction a  ON b.esn = a.serial_number
) as c

inner join 
(
    SELECT serial_number, max( date_removed) as MaxRemove 
       from Hive.app_edata_view.rpt1_engines_waiting_induction d 
    group by serial_number
       
) as y on (c.date_removed = y.MaxRemove AND y.serial_number = c.esn)
