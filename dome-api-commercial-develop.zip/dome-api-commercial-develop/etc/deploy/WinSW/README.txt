
A wrapper executable that can run any executable as an Windows service:
See https://github.com/kohsuke/winsw

Binaries:
See http://repo.jenkins-ci.org/releases/com/sun/winsw/winsw/
