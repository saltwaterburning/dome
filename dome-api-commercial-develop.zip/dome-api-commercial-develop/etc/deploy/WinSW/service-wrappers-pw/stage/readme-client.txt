Update Windows Service Wrapper

1) Double check the client directory structure:
   C:\usr\local\bin\dome\stage\client
   C:\usr\local\bin\dome\stage\client\conf
   C:\usr\local\bin\dome\stage\client\heap-dumps
   C:\usr\local\bin\dome\stage\client\logs

2) Copy contents of client directory to C:\usr\local\bin\dome\stage\client (3 files).

3) Stop DOME client service within Windows Services App.

4) In Admin command prompt:
   > cd C:\usr\local\bin\dome\stage\client
   > dome-client-stage.exe uninstall
   > dome-client-stage.exe install

5) Copy dome-client.jar file to the C:\usr\local\bin\dome\prod\client directory.

5) Start DOME client service within Windows Services App.


NOTE:  Any problems installing Services warppers see logs/dome-client-stage.wrapper.log file.
