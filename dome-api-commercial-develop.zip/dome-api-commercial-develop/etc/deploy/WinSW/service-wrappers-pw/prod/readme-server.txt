Update Windows Service Wrapper

1) Double check the server directory structure:
   C:\usr\local\bin\dome\prod\server
   C:\usr\local\bin\dome\prod\server\conf
   C:\usr\local\bin\dome\prod\server\heap-dumps
   C:\usr\local\bin\dome\prod\server\logs

2) Copy contents of server directory to C:\usr\local\bin\dome\prod\server (3 files).

3) Stop DOME server service within Windows Services App.

4) In Admin command prompt:
   > cd C:\usr\local\bin\dome\prod\server
   > dome-server.exe uninstall
   > dome-server.exe install

5) Copy dome-server.jar file to the C:\usr\local\bin\dome\prod\server directory.

6) Start DOME server service within Windows Services App.

NOTE:  Any problems installing Services warppers see logs/dome-server-prod.wrapper.log file.
