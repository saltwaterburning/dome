    Set-up required for MapStruct development.

1. Install the MapStruct plug-in from Eclipse Marketplace.
2. Install m2e-apt plug-in from Eclipse Marketplace.
3. Within Eclipse- navigate to Windows/Preferences/Maven/Annotation Processing.
  a. Select Automatically Configure JDT APT.
  b. Select Apply and Close.


Work-around for MapStruct/Lombok co-existence bus:
  Replace lombok.jar with lombok-1.18.12-AND-mapstruct-processor-1.3.1.Final.jar
