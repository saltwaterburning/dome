package com.pw.dome.engine.removed;

import com.pw.dome.aop.AfterMethodsAdvise;
import com.pw.dome.aop.jpa.CustomRepositoryFactory;

/**
 * Marker interface used to inject advise invoked after the matching JPA method(s).
 * Simply implement JpaRepository method(s) in a subclass by adding the return object as the methods first argument.
 * 
 * <p><code>
 * Example JPA Method:
 *   List<EngineEntity> getEnginesBySlotID(Integer slotID);
 * </code></p>
 * <p><code>
 * Example Implemented Return Advise:
 *   getEnginesBySlotID(List<EngineEntity>, Integer slotID);
 * </code></p>
 * 
 * @see CustomRepositoryFactory
 */
interface EngineRemovedRepositoryAfterMethods<T, ID> extends AfterMethodsAdvise<T, ID> {
	; // NOP
}
