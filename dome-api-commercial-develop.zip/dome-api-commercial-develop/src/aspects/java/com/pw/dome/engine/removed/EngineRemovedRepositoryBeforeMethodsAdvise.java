package com.pw.dome.engine.removed;

import org.springframework.stereotype.Component;

import com.pw.dome.aop.AbstractBeforeMethodsAdvise;

import lombok.extern.slf4j.Slf4j;

/**
 * Implementation JPA repository method(s) to execute before JPA method is invoked.
 * 
 * @see EngineRemovedRepository
 */
@Slf4j
@Component
public class EngineRemovedRepositoryBeforeMethodsAdvise extends AbstractBeforeMethodsAdvise<EngineRemovedEntity, Integer> implements EngineRemovedRepositoryBeforeMethods {

	public EngineRemovedEntity getEngineRemovedDetails(int removedEnginesId) {
		log.info("EngineRemovedRepositoryAfterAdvise.getEngineRemovedDetails({})", removedEnginesId);

		return null;
	}
}
