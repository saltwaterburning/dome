package com.pw.dome.engine;

import org.springframework.stereotype.Component;

import com.pw.dome.aop.AbstractAfterMethodsAdvise;

/**
 * Implementation of JPA repository methods to execute after JPA method is invoked.
 * 
 * @see EngineRepository
 */
@Component
public class EngineRepositoryAfterMethodsAdvise extends AbstractAfterMethodsAdvise<EngineEntity, Integer> implements EngineRepositoryAfterMethods<EngineEntity, Integer> {

	public void delete(EngineEntity engine) {
		; // NOP
	}
}
