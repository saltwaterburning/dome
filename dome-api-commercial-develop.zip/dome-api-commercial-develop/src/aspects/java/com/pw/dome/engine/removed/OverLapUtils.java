package com.pw.dome.engine.removed;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

final public class OverLapUtils {
    @SafeVarargs
    @SuppressWarnings("unused")
    public static List<String> union(Collection<String>... collections) {
        final List<String> overlap = new ArrayList<>();
        final Set<String> set = new HashSet<>();
        int cnt = 0;

        for (Collection<String> collection : collections) {
            cnt += collection.size();
            Iterator<String> iter = collection.iterator();

            while (iter.hasNext()) {
                String value = iter.next();

                if (!set.add(value)) {
                    overlap.add(value);
                }
            }
        }

//        System.err.println("Overlap: " + (cnt != set.size()));
        Collections.sort(overlap, Comparator.nullsFirst(Comparator.naturalOrder()));
        return overlap;
    }

    @SuppressWarnings("unused")
    @SafeVarargs
	public static List<Integer> union(List<Map<Integer, EngineRemovedDTO>>... maps) {
        final List<Integer> overlap = new ArrayList<>();
        final Set<Integer> set = new HashSet<>();
        int cnt = 0;

        for (List<Map<Integer, EngineRemovedDTO>> list : maps) {
        	int phase = 0;
        	for (Map<Integer, EngineRemovedDTO> map : list) {
        		cnt += map.size();
        		Iterator<Integer> iter = map.keySet().iterator();

        		while (iter.hasNext()) {
        			Integer key = iter.next();

        			if (!set.add(key)) {
        				overlap.add(key);
        			}
        		}
//            	System.out.println(EnginePhases.values()[phase] + ", result set cnt:" + map.size() + ", overlap size: " + overlap.size());
            	++phase;
        	}
        }

//        System.err.println("Overlap: " + (cnt != set.size()));
        Collections.sort(overlap, Comparator.nullsFirst(Comparator.naturalOrder()));
        return overlap;
    }
}
