package com.pw.dome.engine.removed;

import org.springframework.stereotype.Component;

import com.pw.dome.aop.AbstractAfterMethodsAdvise;

import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of JPA repository methods to execute after JPA method is invoked.
 * 
 * @see EngineRemovedRepository
 */
@Slf4j
@Component
public class EngineRemovedRepositoryAfterMethodsAdvise extends AbstractAfterMethodsAdvise<EngineRemovedEntity, Integer> implements EngineRemovedRepositoryAfterMethods<EngineRemovedEntity, Integer> {

	/**
	 * The actual after JPA method will have the return type as the first argument.
	 * 
	 * @param engineRemoved the result of the JPA repo method
	 * @param removedEnginesId the id passed to the JPA repo method
	 */
	public void getEngineRemovedDetails(EngineRemovedEntity engineRemoved, int removedEnginesId) {
		log.info("Hello world!, EngineRemoved={}, removedEnginesId={}", engineRemoved, removedEnginesId);
	}
}
