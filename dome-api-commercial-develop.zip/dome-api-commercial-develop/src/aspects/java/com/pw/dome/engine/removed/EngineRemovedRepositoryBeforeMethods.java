package com.pw.dome.engine.removed;

import com.pw.dome.aop.BeforeMethodsAdvise;
import com.pw.dome.aop.jpa.CustomRepositoryFactory;

/**
 * Marker interface used to inject advise invoked prior to the matching JPA method(s).
 * Simply implement JpaRepository method(s) in a subclass.
 * 
 * @see CustomRepositoryFactory
 */
interface EngineRemovedRepositoryBeforeMethods extends BeforeMethodsAdvise<EngineRemovedEntity, Integer> {
	; // NOP
}
