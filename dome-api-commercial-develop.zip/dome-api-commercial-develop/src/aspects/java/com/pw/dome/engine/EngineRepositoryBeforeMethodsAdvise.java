package com.pw.dome.engine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pw.dome.activity.ActivityEntity;
import com.pw.dome.activity.ActivityService;
import com.pw.dome.activity.DataUtils;
import com.pw.dome.aop.AbstractBeforeMethodsAdvise;

@Component
public class EngineRepositoryBeforeMethodsAdvise extends AbstractBeforeMethodsAdvise<EngineEntity, Integer> implements EngineRepositoryBeforeMethods<EngineEntity, Integer> {

	@Autowired
	private ActivityService activityService;

	public void delete(EngineEntity engine) {
		if(engine == null) return;
		// TODO The engine may not be properly "hydrated". Use a delegate to normalize: if SlotEntity is null then set using slotID. Log warning of such caases to help identify
		saveActivity(DataUtils.toActivityEntityDeleteEngine(engine, engine.getSlot()));
	}
	
	private void saveActivity(ActivityEntity request) {
		activityService.saveActivity(request);
    }
}
