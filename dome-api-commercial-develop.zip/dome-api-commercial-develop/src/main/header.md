Authentication
==============
    Dome uses JWT tokens to manage its security. Once the token is issued, all subsequent API 
	calls must have the token specified in the header as: 
	
			Authorization: Bearer 921b9c34-cf03-4b5d-beec-3cc20207b2XX
	
	Each token is valid for a period of time. When the token expires, a 401 will be returned on
	any API call made with it. A new token needs to be requested and used after the existing one
	expires.

Response Codes
==============
    Dome uses conventional HTTP response codes to indicate success or failure of 
	an API request. In general, codes in the 2xx range indicate success, codes in 
	the 4xx range indicate an error that resulted from the provided information 
	(e.g. a required parameter was missing, an unknown parameter, etc.), and codes 
	in the 5xx range indicate an error with the Dome servers.
        200: OK           - No errors, successful method operation.
        201: Created      - New POST was created successfully
        400: Bad Request  - Malformed request, missing parameters, validation failure. etc.
        401: Unauthorized - Invalid, expired, missing API token or creds. Check 
                             the response for a fine-grained indication.
        403: Forbidden    - User was authenticated, but does not have permission 
                              for the requested operation.
        404: Not Found    - The requested item was not found.
        409: Conflict     - A request to create an item that already exists was made.
        500: Server Error - A backend error occurred.

Error Response
==============
    Dome uses a standard JSON payload for all error reporting. All REST calls can 
	return this response. Within the payload, there are 4 error attributes:
        errorCode       : Optional alpha-numeric code that can be used If present 
                          will contain either the error message string code 
                          (see XXXXXX) or the string representation of the HTTP 
                          code. 
        errors          : A user safe message to indicate the error condition.

    A sample error response looks like:

		{
		  "errorCode": 403,
		  "errors": [
			"User does not have access to engineCenterID [EC412]"
		  ]
		}
		
