/**
 * @author John De Lello
 */
package com.pw.dome.engine.odin;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.pw.dome.jpa.AbstractEntityWithGeneratedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "DOME_ODIN")
@Builder(toBuilder = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OdinEntity extends AbstractEntityWithGeneratedId<Integer> {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOME_ODIN_SEQ")
	@SequenceGenerator(sequenceName = "DOME_ODIN_SEQ", allocationSize = 1, name = "DOME_ODIN_SEQ")
	@Column(name = "ODIN_ID")
	private Integer odinId;

	@Column(name = "ACCY_DELIVERY")
	private LocalDate accyDeliveryDate;

	@Column(name = "ACTUAL_REC_EBU")
	private LocalDate actualRecEbuDate;

	@Column(name = "AD_LIST_DATE")
	private LocalDate adListDate;

	@Column(name = "AIM_ALLOCATION_DATE")
	private LocalDate aimAllocationDate;

	@Column(name = "BER")
	private boolean ber;

	@Column(name = "CFD_FM")
	private String cfdFm;

	@Column(name = "COMMENTS")
	private String comments;

	@Column(name = "CONTRACTAL_REMOVAL")
	private boolean contractRemoval;

	@Column(name = "CURRENT_LOCATION")
	private String currentLocation;

	@Column(name = "CUST_APPROVAL")
	private LocalDate customerApprovalDate;

	@Column(name = "EBU_SHOP")
	private String ebuShop;

	@Column(name = "ENG_ID")
	private Integer engineId;

	@Column(name = "ESN")
	private String esn;
	
	@Column(name = "ESTIMATED_WORKSCOPE")
	private String estimatedWorkscope;

	@Column(name = "EVENT_ID")
	private Integer eventId;

	@Column(name = "FAN_BLADE_MAP_DATE")
	private LocalDate fanBladeMapDate;

	@Column(name = "FHA_ELIGIBLE")
	private boolean fhaEligible;

	@Column(name = "INVESTIGATION_ENGINE")
	private boolean investigationEngine;

	@Column(name = "INVEST_CATEGORY")
	private String investigationCategory;

	@Column(name = "LLP_DELIVERY")
	private LocalDate llpDeliveryDate;

	@Column(name = "LLP_REPLACE_TYPE")
	private String llpReplaceType;

	@Column(name = "MAINT_CENTER")
	private String maintenanceCenter;

	@Column(name = "NIS_DELIVERY")
	private LocalDate nisDeliveryDate;

	@Column(name = "ON_HOLD")
	private boolean onHold;

	@Column(name = "POWER_ENGINEER")
	private String powerEngineer;

	@Column(name = "PROJ_REC_EBU")
	private LocalDate projRecEbuDate;

	@Column(name = "PWEL_ASSET")
	private boolean pwelAsset;

	@Column(name = "RSL_PO")
	private String rslPO;

	// @Column(name="SCHEDULED_INDUCTION")
//	private LocalDate scheduledInductionDate;

	@Column(name = "SMI_NEED_DATE")
	private LocalDate smiNeedDate;

	@Column(name = "SPEID_PO")
	private String speidPO;

	@Column(name = "SV_CLASS")
	private String svClass;

	@Column(name = "TAR_CHECKBOX")
	private boolean tarCheckbox;

	@Column(name = "TEST_AT_RECEIPT")
	private LocalDate testAtReceipt;

	@Column(name = "UPGRADE_ELIGIBLE")
	private String upgradeEligible;

	@Column(name = "WARRANTY")
	private boolean warranty;

	@Column(name = "WS_COMPLETE_ACCY")
	private LocalDate wsDraftCompleteAccyDate;

	@Column(name = "WS_COMPLETE_ENG")
	private LocalDate wsDraftCompleteEngDate;

	@Column(name = "WS_INITIATION")
	private LocalDate wsInitiationDate;

	@Column(name = "WS_ORIG_RELEASE")
	private LocalDate wsOrigReleaseDate;

	@Override
	public Integer getId() {
		return odinId;
	}
}
