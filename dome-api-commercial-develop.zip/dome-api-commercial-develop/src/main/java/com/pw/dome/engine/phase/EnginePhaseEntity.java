package com.pw.dome.engine.phase;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.NaturalId;

import com.pw.dome.jpa.AbstractEntityWithNaturalId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author John De Lello
 */
@Entity
@Table(name="DOME_ENGINE_PHASE")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Immutable
public class EnginePhaseEntity extends AbstractEntityWithNaturalId<String>{
	@Id
	@NaturalId
	@Column(name="PHASE_CODE")
	private String enginePhaseID;
	
	@Column(name = "PHASE_NAME")
	private String name;
	
	@Column(name = "PHASE_DISPLAY_RANK")
	private Integer displayRank;

	@Override
	public String getId() {
		return enginePhaseID;
	}
}
