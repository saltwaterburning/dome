package com.pw.dome.external.mro.collab.services.pacingitems;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MroPacingItemNew {

	private Integer pacingId;
	private String category;
	private LocalDate closeDate;
	private LocalDate commitDate;
	private LocalDate datReceivedDate;
	private LocalDate datShipOutDate;
	private String description;
	private Integer dollarsSaved;
	private Integer engineId;
	private String engineSN;
	private boolean escItem;
	private String esn;
	private Integer eventId;
	private Integer holdDaysApproved;
	// 01/01/2021 12:00 AM
	private LocalDateTime logDateTime;
	private String mroShopCode;
	private String mroWorkOrder;
	private LocalDate needDate;
	private String notes;
	private String partId;
	private String purchaseOrder;
	private LocalDate startDate;
	private String subCategory;
	private String uniqueId;
	private LocalDate vendorInDate;
	private String vendorName;
	private LocalDate vendorOutDate;
	private String wsInd;
}
