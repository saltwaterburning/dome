package com.pw.dome.admin;

import static com.pw.dome.admin.ProfileStatus.APPROVED;
import static com.pw.dome.admin.ProfileStatus.DISAPPROVE;

import jakarta.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class Emailer {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	private SimpleJdbcCall simpleJdbcCall;

	@PostConstruct
	void init() {
		jdbcTemplate.setResultsMapCaseInsensitive(true);

		simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("DOME_SEND_MAIL");

	}

	public void sendEmail(String email, ProfileStatus status, String comments) {
		try {
			String subject = "";
			if (APPROVED == status) {
				subject = "Please be advised that your request for the DOME application has been approved.";
			} else if (DISAPPROVE == status) {
				subject = "Please be advised that your request for the DOME application has been reviewed and rejected for the following reason";
			} else {
				log.info("Email not sent to {} for status : {}", email, status);
				return;
			}

			SqlParameterSource in = new MapSqlParameterSource().addValue("SBJCT", subject).addValue("EMAILID", email)
					.addValue("COMMENTS", comments);
			simpleJdbcCall.execute(in);
			log.info("Email successfully sent to {}", email);
		} catch (Exception e) {
			log.warn("Error sending email to {}. Exception : {}", email, e);
		}
	}
}
