package com.pw.dome.mml.le;

import static com.pw.dome.mml.le.Consts.SQL.MONTHLY_LATEST_ESTIMATE_INDUCTION_DATA;
import static com.pw.dome.mml.le.Consts.SQL.MONTHLY_LATEST_ESTIMATE_PLAN_INDUCTION_DATA;
import static com.pw.dome.mml.le.Consts.SQL.MONTHLY_LATEST_ESTIMATE_PLAN_REVENUE_DATA;
import static com.pw.dome.mml.le.Consts.SQL.MONTHLY_LATEST_ESTIMATE_PLAN_SHIPMENT_DATA;
import static com.pw.dome.mml.le.Consts.SQL.MONTHLY_LATEST_ESTIMATE_REVENUE_DATA;
import static com.pw.dome.mml.le.Consts.SQL.MONTHLY_LATEST_ESTIMATE_SHIPMENT_DATA;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pw.dome.mml.PlanMarket;
import com.pw.dome.mml.PlanType;

@Repository
interface LeMonthlyRepository extends JpaRepository<LeMonthlyEntity, Integer> {
    int deleteByIdIn(List<Integer> ids);

    @Modifying
    @Query(value = "DELETE from LeMonthlyEntity leMonthlyEntity where leMonthlyEntity.engineId = ?1")
    public Integer deleteByEngineId(Integer engineId);

    @Modifying
    @Query(value = "DELETE from LeMonthlyEntity leMonthlyEntity where leMonthlyEntity.engineId in ?1")
    public Integer deleteByEngineIds(List<Integer> engineId);

    @Query(MONTHLY_LATEST_ESTIMATE_INDUCTION_DATA)
    List<DetailsDTO> getLeMonthlyInductionData(@Param("engCenterId") final String engineCenterId,
                                               @Param("engGroupIds") final List<String> engineGroups,
                                               @Param("month") final int leMonth,
                                               @Param("year") final int leYear,
                                               @Param("planMarket") final PlanMarket planMarket,
                                               @Param("planType") final PlanType planType);

    @Query(MONTHLY_LATEST_ESTIMATE_PLAN_INDUCTION_DATA)
    List<DetailsDTO> getLeMonthlyPlanInductionData(@Param("engCenterId") final String engineCenterId,
                                                   @Param("engGroupIds") final List<String> engineGroups,
                                                   @Param("month") final int leMonth,
                                                   @Param("year") final int leYear,
                                                   @Param("planMarket") final PlanMarket planMarket,
                                                   @Param("planType") final PlanType planType);

    @Query(MONTHLY_LATEST_ESTIMATE_PLAN_REVENUE_DATA) // xxyy
    List<DetailsDTO> getLeMonthlyPlanRevenueData(@Param("engCenterId") final String engineCenterId,
    		                                     @Param("engGroupIds") final List<String> engineGroups,
    		                                     @Param("month") final int leMonth,
    		                                     @Param("year") final int leYear,
    		                                     @Param("planMarket") final PlanMarket planMarket,
    		                                     @Param("planType") final PlanType planType);

    @Query(MONTHLY_LATEST_ESTIMATE_PLAN_SHIPMENT_DATA)
    List<DetailsDTO> getLeMonthlyPlanShipmentData(@Param("engCenterId") final String engineCenterId,
                                                  @Param("engGroupIds") final List<String> engineGroups,
                                                  @Param("month") final int leMonth,
                                                  @Param("year") final int leYear,
                                                  @Param("planMarket") final PlanMarket planMarket,
                                                  @Param("planType") final PlanType planType);

    @Query(MONTHLY_LATEST_ESTIMATE_REVENUE_DATA)
    List<DetailsDTO> getLeMonthlyRevenueData(@Param("engCenterId") final String engineCenterId,
                                             @Param("engGroupIds") final List<String> engineGroups,
                                             @Param("month") final int leMonth,
                                             @Param("year") final int leYear,
                                             @Param("planMarket") final PlanMarket planMarket,
                                             @Param("planType") final PlanType planType);

    @Query(MONTHLY_LATEST_ESTIMATE_SHIPMENT_DATA)
    List<DetailsDTO> getLeMonthlyShipmentData(@Param("engCenterId") final String engineCenterId,
                                              @Param("engGroupIds") final List<String> engineGroups,
                                              @Param("month") final int leMonth,
                                              @Param("year") final int leYear,
                                              @Param("planMarket") final PlanMarket planMarket,
                                              @Param("planType") final PlanType planType);

    @Modifying
    @Query("update EngineTrackingEntity engineTrackingEntity set engineTrackingEntity.engtrackIsopportunity = :opportunity where engineTrackingEntity.engtrackId = :engineId")
    int updateOpportunityByEngineId(@Param("opportunity") Integer opportunity, @Param("engineId") Integer engineId);

    @Modifying
    @Query("update LeMonthlyEntity leMonthlyEntity set leMonthlyEntity.risk = :risk where leMonthlyEntity.engineId = :engineId")
    int updateRiskByEngineId(@Param("risk") boolean risk, @Param("engineId") Integer engineId);
}
