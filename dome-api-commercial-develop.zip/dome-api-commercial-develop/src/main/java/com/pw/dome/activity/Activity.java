package com.pw.dome.activity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Activity {

    private Long activityId;
    private String item;
    private String activityDate;
    private String engineCenterId;
    private String engineType;
    private String engineGroup;
    private String engineModel;
    private String engineModule;
    private String engineSerialNumber;
    private String customerID;
    private String userEmail;
    private String type;
    private String description;
    
}
