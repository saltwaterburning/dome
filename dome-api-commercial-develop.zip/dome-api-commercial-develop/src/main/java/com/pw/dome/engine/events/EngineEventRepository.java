package com.pw.dome.engine.events;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface EngineEventRepository extends JpaRepository<EngineEventEntity, EngineEventEntityPK> {

    /**
     * Sets {@code slotID} to null and shipped to true for matching ESN and eventId.
     * 
     * @param esn
     * @param eventId
     * @return number of rows updated
     */
    @Modifying
    @Query(value = "UPDATE EngineEventEntity x set x.shipped = TRUE, x.slotId = NULL where UPPER(x.pk.esn) = UPPER(?1) AND x.pk.eventId = ?2")
    int dropSlotId(final String esn, final int eventId);

    EngineEventEntity findByPkEsnAndPkEventId(final String esn, final Integer eventId);

    List<EngineEventEntity> findByPkEsnInOrderByPkEsn(List<String> esns);
}
