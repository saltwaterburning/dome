package com.pw.dome.calendar.inductionplanning;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Getter 
@Setter 
@NoArgsConstructor 
@AllArgsConstructor 
@ToString
@Builder
public class InductionPlanningCalendarEngine{
	private String category;
	private String categoryCode;
	private Integer engineID;
	private String esn;
}
