package com.pw.dome.external.workscope.services;

import static com.pw.dome.external.workscope.services.Consts.SQL.GET_ODIN;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pw.dome.engine.odin.OdinEntity;

@Repository
interface WorkscopeToolRepository extends JpaRepository<OdinEntity, Integer> {

	@Query(GET_ODIN)
	Optional<OdinEntity> findOdin(
			@Param("esn") String esn, //
			@Param("eventId") Integer eventId, //
			@Param("smiNumber") String smiNumber);
}
