package com.pw.dome.engine.induction;

import lombok.Builder;

@Builder
public record AvailableDTO(
  Integer engineId,
  Integer engineAssetId,
  String esn,
  Integer eventId,
  String operator,
  String salesOrdeerType,
  Integer slotId) {
}
