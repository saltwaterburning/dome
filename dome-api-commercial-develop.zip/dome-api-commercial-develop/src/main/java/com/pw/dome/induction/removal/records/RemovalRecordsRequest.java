package com.pw.dome.induction.removal.records;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

record RemovalRecordsRequest(@NotBlank String esn, @NotNull Integer eventId) {

}
