package com.pw.dome.engine.odin.reports;

import static com.pw.dome.report.excel.ReportConstants.DATE_FORMAT;
import static com.pw.dome.util.excel.Border.BorderStyles.THIN;
import static com.pw.dome.util.excel.CellStyle.AlignH.CENTER;
import static com.pw.dome.util.excel.CellStyle.AlignH.LEFT;
import static com.pw.dome.util.excel.Colors.DARK_BLUE;
import static com.pw.dome.util.excel.Colors.DARK_RED;
import static com.pw.dome.util.excel.Colors.WHITE;

import java.time.LocalDate;
import java.util.Arrays;

import com.pw.dome.engine.odin.OdinBaseDTO;
import com.pw.dome.util.excel.Border;
import com.pw.dome.util.excel.CellStyle;
import com.pw.dome.util.excel.CellStyle.AlignH;
import com.pw.dome.util.excel.CellStyle.AlignV;
import com.pw.dome.util.excel.CellStyle.FillPattern;
import com.pw.dome.util.excel.CellValues;
import com.pw.dome.util.excel.CellValues.Builder;
import com.pw.dome.util.excel.Colors;
import com.pw.dome.util.excel.FontStyle;

import lombok.Getter;

class ReportHelper {
    @Getter
    private static final CellStyle centeredWrappedHeader = getStyle(true,
                                                                    true,
                                                                    false,
                                                                    true,
                                                                    0,
                                                                    WHITE,
                                                                    CENTER,
                                                                    null);
    @Getter
    private static final CellStyle redTextStyle = getStyle(false,
                                                           false,
                                                           false,
                                                           false,
                                                           null,
                                                           DARK_RED,
                                                           LEFT,
                                                           null);

    @Getter
    private static final CellStyle blueBorderStyle = getStyle(false,
                                                              true,
                                                              false,
                                                              false,
                                                              null,
                                                              DARK_BLUE,
                                                              CENTER,
                                                              AlignV.CENTER);
    @Getter
    private static final CellStyle blueTextStyle = getStyle(false,
                                                           false,
                                                           false,
                                                           false,
                                                           null,
                                                           DARK_BLUE,
                                                           LEFT,
                                                           null);
    private ReportHelper() {
        throw new IllegalAccessError();
    }

    static CellValues getHeaderCells(String[] headers) {
        Builder builder = CellValues.builder();
        Arrays.stream(headers)
            .forEach(s -> builder.add(getCenteredWrappedHeader(),
                                      s));
        return builder.build();
    }

    private static CellStyle getStyle(boolean bold,
        boolean border,
        boolean date,
        boolean wrapText,
        Integer bgColor,
        Colors textColor,
        AlignH horizontalAlignment,
        AlignV verticalAlignment) {
        final CellStyle.CellStyleBuilder cb = CellStyle.builder();
        final FontStyle.FontStyleBuilder fb = FontStyle.builder();

        fb.bold(bold);

        if (textColor != null) {
            fb.color(textColor);
        }

        if (border) {
            cb.border(Border.of(THIN));
        }

        if (date) {
            cb.dataFormat(DATE_FORMAT);
        }
        cb.wrapText(wrapText);

        if (bgColor != null) {
            cb.fillForegroundColorColor(bgColor)
                .fillPattern(FillPattern.SOLID_FOREGROUND);
        }
        cb.fontStyle(fb.build());

        if (horizontalAlignment != null) {
            cb.alignH(horizontalAlignment);
        }

        if (verticalAlignment != null) {
            cb.alignV(verticalAlignment);
        }
        return cb.build();
    }

    static String yOrN(boolean value) {
    	return value ? "Y" : "N";
    }
    static CellValues getRow(final OdinBaseDTO dto, final LocalDate lastPreliminaryIndutionDate) {
        CellStyle dateStyle = getStyle(false, false, true, false, null, null, null, null);

        Builder b = CellValues.builder();
        String eventId = dto.getEventId() == null ? "" : String.valueOf(dto.getEventId());
        b.add(eventId)
            .add(dto.getContractType())
            .add(dto.getOperatorName())
            .add(dto.getEsn())
            .add(dto.getThrust())
            .add(dto.getEngineModelName())
            .add(dto.getTsn())
            .add(dto.getCsn())
            .add(dto.getTso())
            .add(dto.getCso())
            .add(dto.getLlpCycRemain())
            .add(dto.getRemovalReason())
            .add(dto.getMaintenanceCenterName())
            .add(dto.getSvClassification())
            .add(dto.getLlpReplacementType())
            .add(dto.getUpgradeEligibility())
            .add(dateStyle, dto.getRemovalActualDate())
            .add(dateStyle, dto.getEngineActualReceiptDate())
//            .add(dateStyle, dto.getRemovalRecordedDate())
            .add(dateStyle, dto.getAimAllocationDate())
            .add(dateStyle, dto.getCustomerApprovalDate())
            .add(dateStyle, dto.getLlpDeliveryDate())
            .add(dateStyle, dto.getAccyDeliveryDate())
            .add(dateStyle, dto.getNisDeliveryDate())
            .add(dateStyle, dto.getWsInitiationDate())
            .add(dateStyle, dto.getWsDraftCompleteEngDate())
            .add(dateStyle, dto.getWsDraftCompleteAccyDate())
            .add(dateStyle, dto.getCustomerApprovalDate())
            .add(dateStyle, dto.getWsOrigReleaseDate()) // WS\nActual\nRelease
            .add(dateStyle, (LocalDate)null) // WS\nPlanned\nRelease -- N/A (Andy)
            .add(dateStyle, dto.getTestAtReceipt()) // TAR\nDate
            .add(dateStyle, dto.getProjRecEcDate()) // Planned\nEngine\nDelivery\nDate
            .add(dateStyle, dto.getActualRecEcDate()) // Actual\nEngine\nDelivery\nDate -- N/A (Andy)
            .add(dateStyle, (LocalDate)null) // S1\nKit\nOrdered\nDate -- N/A (Andy)
            .add(dateStyle, lastPreliminaryIndutionDate) // Prelim\nInduct
            .add(dateStyle, dto.getSlotDate()) // Scheduled\nInduct
            .add(dateStyle, dto.getCommittedInductionDate()) // Act\nInduct
            .add(dateStyle, (LocalDate)null) // Rec\nInduct -- N/A or same as previous field (Andy)
            .add(dto.getContractType())
            .add(yOrN(dto.isInvestigationEngine()))
            .add(yOrN(dto.isFhaEligible()))
            .add(dto.getComments());
//            .add("") // TODO Status
//            .add("") // TODO Scheduled\nInduct\nDate
//            .add("") // TODO Scheduled\nInduction\nDate\nRsn 1
//            .add("") // TODO Scheduled\nInduction\nDate\nRsn 2
//            .add("") // TODO Scheduled\nInduction\nDate\nRsn 3
//            .add("") // TODO Scheduled\nInduct\nDate 1
//            .add("") // TODO Scheduled\nInduct\nDate 2
//            .add("") // TODO Scheduled\nInduction\nDate 2\nRsn 1
//            .add("") // TODO Scheduled\nInduction\nDate 2\nRsn 2
//            .add("") // TODO Scheduled\nInduction\nDate 2\nRsn 3
//            .add("") // TODO Scheduled\nInduct\nDate 3
//            .add("") // TODO Scheduled\nInduction\nDate 3\nRsn 1
//            .add("") // TODO Scheduled\nInduction\nDate 3\nRsn 2
//            .add(""); // TODO Scheduled\nInduction\nDate 3\nRsn 3
            return b.build();
    }
}
