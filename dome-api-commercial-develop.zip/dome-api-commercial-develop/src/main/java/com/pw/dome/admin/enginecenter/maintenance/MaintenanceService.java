package com.pw.dome.admin.enginecenter.maintenance;

import static com.pw.dome.admin.enginecenter.maintenance.Consts.EC_ID_PREFIX;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.EG_ID_PREFIX;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.EM_ID_PREFIX;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.ET_ID_PREFIX;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.INACTIVE;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.engine.group.EngineGroupEntity;
import com.pw.dome.engine.group.EngineGroupRepository;
import com.pw.dome.engine.model.EngineModelEntity;
import com.pw.dome.engine.model.EngineModelRepository;
import com.pw.dome.engine.type.EngineTypeEntity;
import com.pw.dome.engine.type.EngineTypeRepository;
import com.pw.dome.enginecenter.EngineCenterEntity;
import com.pw.dome.enginecenter.EngineCenterRepository;
import com.pw.dome.exception.BadRequestException;
import com.pw.dome.external.workscope.WstWebClientAsyncService;
import com.pw.dome.user.UserRepository;
import com.pw.dome.util.SecurityUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MaintenanceService {
	@Autowired
	private EngineCenterRepository ecRepo;
	@Autowired
	private EngineGroupRepository egRepo;
	@Autowired
	private EngineModelRepository emRepo;
	@Autowired
	private EngineTypeRepository etRepo;
	@Autowired
	private BasicMaintenanceRepository repo;
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private WstWebClientAsyncService wstSvc;

	@Transactional
	public void deleteEngineGroupFromEngineType(String ecId, String typeId, String groupId) {
		int cnt = egRepo.setAction(INACTIVE, typeId, groupId);
		log.debug("Set eng_group_action inactive for {} rows in dome_eng_group_mst table; ecId={}, typeId={}, groupId={}", cnt, ecId, typeId, groupId);

		cnt = repo.deleteEngGroupFromEngSecurityCenter(ecId, typeId, groupId);
		log.debug("Deleted {} rows in dome_security_engine_center table; ecId={}, typeId={}, groupId={}", cnt, ecId, typeId, groupId);
	}

	@Transactional
	public void deleteEngineModelFromEngineGroup(String ecId, String typeId, String groupId, String modelId) {
		int cnt = emRepo.setAction(INACTIVE, groupId, modelId);
		log.debug("Set eng_mod_action inactive for {} rows in dome_eng_mod_mst table; ecId={}, typeId={}, groupId={}, modelId={}", cnt, ecId, typeId, groupId, modelId);
	}

	@Transactional
	public void deleteEngineTypeFromEngineCenter(String ecId, String typeId) {
		int cnt = repo.deleteEngTypeFromEngTypeCenterMap(ecId, typeId);
		log.debug("Deleted {} rows from dome_eng_type_center_map table; ecId={}, typeId={}", cnt, ecId, typeId);

		cnt = repo.deleteEngTypeFromEngCenterTypeGroup(ecId, typeId, null);
		log.debug("Deleted {} rows in dome_center_type_group table; ecId={}, typeId={}", cnt, ecId, typeId);

		cnt = repo.deleteEngTypeFromEngSecurityCenter(ecId, typeId);
		log.debug("Deleted {} rows in dome_security_engine_center table; ecId={}, typeId={}", cnt, ecId, typeId);

		cnt = userRepo.dropDefaultEngineType(ecId, typeId);
		log.debug("Nulled dome_login.log_deflt_eng_type_id for {} rows; ecId={}, typeId={}", cnt, ecId, typeId);
	}

	@Transactional(readOnly = true)
	public EngineCentersResponse getAllEngineCenters() {
		List<EngineCenterEntity> engineCenters = ecRepo.getAllEngineCenters();
		return EngineCentersResponse.builder().engineCenters(DataUtils.toBasicEngineCenter(engineCenters)).build();
	}

	@Transactional(readOnly = true)
	public EngineGroupsResponse getAllEngineGroups(String ecId, String typeId) {
		List<EngineGroupEntity> engineGroups = egRepo.getAllEngineGroups(typeId);
		return EngineGroupsResponse.builder().engineGroups(DataUtils.toBasicEngineGroup(engineGroups)).build();
	}

	@Transactional(readOnly = true)
	public EngineModelsResponse getAllEngineModels(String ecId, String typeId, String groupId) {
		List<EngineModelEntity> engineModels = emRepo.getAllEngineModels(groupId);
		return EngineModelsResponse.builder().engineModels(DataUtils.toBasicEngineModel(engineModels)).build();
	}

	@Transactional(readOnly = true)
	public EngineTypesResponse getAllEngineTypes(String ecId) {
		List<EngineTypeEntity> engineTypes = etRepo.getAllEngineTypes();
		Set<String> etSet = repo.getEngineTypeByCenter(ecId);
		return EngineTypesResponse.builder().engineTypes(DataUtils.toBasicEngineType(engineTypes, etSet)).build();
	}
	
	@Transactional(readOnly = true)
	public EngineTypesResponse getAllEngineTypesByCustomerId(String customerId) {
		List<EngineTypeEntity> engineTypes = etRepo.getAllEngineTypes();
		engineTypes = engineTypes.stream().filter(e -> e.isActive()).collect(Collectors.toList());
		Set<String> etSet = repo.getEngineTypeByCutomer(customerId);
		return EngineTypesResponse.builder().engineTypes(DataUtils.toBasicEngineTypeForCustomer(engineTypes, etSet)).build();
	}

	@Transactional
	public EngineCentersResponse save(EngineCentersResponse request) {
		List<BasicEngineCenter> engineCenters = new ArrayList<>();
		List<BasicEngineCenter> addedEngineCenters = new ArrayList<>();
		List<BasicEngineCenter> deletedEngineCenters = new ArrayList<>();

		String userEmail = SecurityUtils.getUserEmailAddress();

		for (BasicEngineCenter ecRequest: request.getEngineCenters()) {
			EngineCenterEntity entity;
			String centerId = ecRequest.getCenterId();

			// New engine center creation isn't currently needed by the UI.
			// Null BasicEngineCenter.centerId isn't yet allowed.
			if (StringUtils.isBlank(centerId)) {
				centerId = EC_ID_PREFIX + ecRepo.getNextSeqVal();
				entity = EngineCenterEntity.builder()
                                     .active(ecRequest.isActive())
                                     .id(centerId)
                                     .name(ecRequest.getCenterName())
                                     .build();

				addedEngineCenters.add(DataUtils.toBasicEngineCenter(entity));
			} else {
				entity = ecRepo.findById(centerId).get();
				if (entity.isActive() && !ecRequest.isActive()) {
					String ecId = entity.getId();
					int cnt = userRepo.dropDefaultEngineCenter(ecId, userEmail);
					log.debug("Nulled log_deflt_eng_type_id for {} rows in dome_login table; ecId={}", cnt, ecId);
					deletedEngineCenters.add(DataUtils.toBasicEngineCenter(entity));
				}

				entity.setActive(ecRequest.isActive());
				entity.setName(ecRequest.getCenterName());
			}

			log.debug("EngineCenterRepository.save(entity); {}", entity);
			entity = ecRepo.save(entity);
			log.debug("EngineCenterRepository saved entity; {}", entity);
			engineCenters.add(DataUtils.toBasicEngineCenter(entity));
		}

		egRepo.flush();
		request.setEngineCenters(engineCenters);

		if (!addedEngineCenters.isEmpty()) {
			wstSvc.pushProviders(addedEngineCenters);
		}
		if (!deletedEngineCenters.isEmpty()) {
			wstSvc.deleteProviders(deletedEngineCenters);
		}

		return request;
	}

	@Transactional
	public EngineTypesResponse save(String ecId, EngineTypesResponse request) {
		int cnt;
		List<BasicEngineType> response = new ArrayList<BasicEngineType>(request.getEngineTypes().size());
		Set<String> existingEngineTypes = repo.getEngineTypeByCenter(ecId);

		for (BasicEngineType engineType : request.getEngineTypes()) {
			final boolean isEagleData = engineType.isEagleData();
			boolean isNew = false;
			EngineTypeEntity entity;

			String typeId = engineType.getTypeId();
			// The Id is null for new ET and will be added to the current EC.
			if (StringUtils.isBlank(typeId)) {
				if (isEagleData) {
					String msg = String.format("New EngineType (%s) can't be EagleData.", engineType.getTypeName());
					throw new BadRequestException(msg);
				}

				isNew = true;
				engineType.setInEngineCenter(true);
				engineType.setTypeId(typeId = ET_ID_PREFIX + etRepo.getNextSeqVal());
			}

			// Sync dome_eng_type_center_map table.
			if (engineType.isInEngineCenter()) {
				existingEngineTypes.add(typeId);
				cnt = repo.insertIntoEngTypeCenterMap(ecId, typeId);
				log.debug("Inserted {} rows into dome_eng_type_center_map table; ecId={}, typeId={}", cnt, ecId, typeId);
			} else if (existingEngineTypes.contains(typeId)) {
				existingEngineTypes.remove(typeId);
				cnt = repo.deleteEngTypeFromEngTypeCenterMap(ecId, typeId);
				log.debug("Deleted {} rows from dome_eng_type_center_map table; ecId={}, typeId={}", cnt, ecId, typeId);
			}

			// Sync entity with UI data.
			if (isNew) {
				entity = DataUtils.toEngineType(engineType);
			} else if ((entity = etRepo.findById(typeId).orElse(null)) == null) {
				throw new BadRequestException("The EngineType Id doesn't exist: " + typeId);
			} else if (!isEagleData) { // Eagle Data names are immutable.
				entity.setName(engineType.getTypeName());
			}

			// Sync changes, if any, with DB.
			entity = etRepo.save(entity);
			response.add(DataUtils.toBasicEngineType(entity, existingEngineTypes));
		}

		etRepo.flush();
		repo.flush();
		
		request.setEngineTypes(response);
		return request;
	}

	@Transactional
	public EngineTypesResponse saveCustomerEngineTypes(String customerId, EngineTypesResponse request) {
		int cnt;
		List<BasicEngineType> response = new ArrayList<>(request.getEngineTypes().size());
		Set<String> existingEngineTypes = repo.getEngineTypeByCutomer(customerId);

		for (BasicEngineType engineType : request.getEngineTypes()) {
			EngineTypeEntity entity;

			String typeId = engineType.getTypeId();
			if (StringUtils.isBlank(typeId)) {
				throw new BadRequestException("The EngineType Id cannot be empty");
			}
			
			entity = etRepo.findById(typeId).orElse(null);
			if (entity == null) {
				throw new BadRequestException("The EngineType Id doesn't exist: " + typeId);
			}

			// Sync dome_eng_type_center_map table.
			if (engineType.isAssignedToCustomer()) {
				existingEngineTypes.add(typeId);
				cnt = repo.insertIntoCustomerEngineTypeMap(customerId, typeId);
				log.debug("Inserted {} rows into DOME_CUSTOMER_TYPE_MAP table; custId={}, typeId={}", cnt, customerId, typeId);
			} else if (existingEngineTypes.contains(typeId)) {
				existingEngineTypes.remove(typeId);
				cnt = repo.deleteEngTypeFromCustomerTypeMap(customerId, typeId);
				log.debug("Deleted {} rows from DOME_CUSTOMER_TYPE_MAP table; custId={}, typeId={}", cnt, customerId, typeId);
			}

			response.add(DataUtils.toBasicEngineTypeForCustomer(entity, existingEngineTypes));
		}

		repo.flush();
		
		request.setEngineTypes(response);
		return request;
	}
	
	@Transactional
	public EngineGroupsResponse save(String ecId, String typeId, EngineGroupsResponse request) {
		List<BasicEngineGroup> engineGroups = new ArrayList<>();

		for (BasicEngineGroup eg : request.getEngineGroups()) {
			EngineGroupEntity entity;
			String groupId = eg.getGroupId();

			if (StringUtils.isBlank(groupId)) {
				groupId = EG_ID_PREFIX + egRepo.getNextSeqVal();
				entity = EngineGroupEntity.builder()
			            .active(Boolean.TRUE)
			            .engineGroupID(groupId)
			            .engineTypeID(typeId)
			            .name(eg.getGroupName())
			            .build();
			} else {
				entity = egRepo.findById(groupId).get();
				entity.setActive(Boolean.TRUE);
				entity.setEngineGroupID(groupId);
				entity.setEngineTypeID(typeId);
				entity.setName(eg.getGroupName());
			}

			log.debug("EngineGroupRepository.save(entity); {}", entity);
			entity = egRepo.save(entity);
			log.debug("EngineGroupRepository saved entity; {}", entity);
			engineGroups.add(DataUtils.toBasicEngineGroup(entity));
		}

		egRepo.flush();
		request.setEngineGroups(engineGroups);
		return request;
	}

	@Transactional
	public EngineModelsResponse save(String ecId, String typeId, String groupId, EngineModelsResponse request) {
		List<BasicEngineModel> engineModels = new ArrayList<>();

		for (BasicEngineModel em : request.getEngineModels()) {
			EngineModelEntity entity;
			String modelId = em.getModelId();

			if (StringUtils.isBlank(modelId)) {
				modelId = EM_ID_PREFIX + emRepo.getNextSeqVal();
				entity = EngineModelEntity.builder()
                                    .active(Boolean.TRUE)
                                    .engineGroupID(groupId)
                                    .engineModelID(modelId)
                                    .name(em.getModelName())
                                    .build();
			} else {
				entity = emRepo.findById(modelId).get();
				entity.setActive(Boolean.TRUE);
				entity.setEngineGroupID(groupId);
				entity.setEngineModelID(em.getModelId());
				entity.setName(em.getModelName());
			}

			log.debug("EngineModelRepository.save(entity); {}", entity);
			entity = emRepo.save(entity);
			log.debug("EngineModelRepository saved entity; {}", entity);

			engineModels.add(DataUtils.toBasicEngineModel(entity));
		}

		emRepo.flush();
		request.setEngineModels(engineModels);
		return request;
	}
}
