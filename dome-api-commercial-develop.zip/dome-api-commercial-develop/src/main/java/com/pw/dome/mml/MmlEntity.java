package com.pw.dome.mml;

import java.time.LocalDate;

public interface MmlEntity {

    LocalDate getActualReceipentDate();

    String getCustomerName();

    String getEngineCategory();

    String getEngineCenterName();

    String getEngineGroupId();

    String getEngineGroupName();

    Integer getEngineId();

    String getEngineSerialNumber();

    Integer getMonth();

    LocalDate getPlanInductionDate();
}
