package com.pw.dome.admin.customer.maintenance;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.admin.enginecenter.maintenance.EngineTypesResponse;
import com.pw.dome.admin.enginecenter.maintenance.MaintenanceService;
import com.pw.dome.customer.CustomerDTO;
import com.pw.dome.customer.CustomerListResponse;

@RestController()
@RequestMapping("/v1/admin/customers")
public class CustomerMaintenanceController {

	@Autowired
    private CustomerMaintenanceService customerMaintenanceService;
	@Autowired
	private MaintenanceService maintenanceService;
	
	/**
	 * @api {put} /v1/admin/customers Add/Update Customer(s) 
     * @apiExample {curl} Example usage: 
     *      curl --request PUT
     *           --url http://localhost:8080/v1/admin/customers
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName updateCustomer
     * @apiGroup Customer Maintenance
     * @apiDescription Updates the Customer objects
     * @apiUse Error
     * @apiUse Error500
     **/
	@PutMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<CustomerDTO>> updateCustomerStatus(@RequestBody final CustomerListResponse customersList) {
		List<CustomerDTO> response = customerMaintenanceService.updateCustomers(customersList.getCustomers());
        return ResponseEntity.ok(response);
    }
	
	/**
	 * @api {get} /v1/admin/customers/engineTypes/:customerId Get engineTypes for a given customer 
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/admin/customers/engineTypes/:customerId
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName getEngineTypesForCustomer
     * @apiGroup Customer Maintenance
     * @apiDescription Returns the engineTypes for a customer
     * @apiUse Error
     * @apiUse Error500
     **/  
	@GetMapping(path = "/engineTypes/{customerId}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineTypesResponse> getEngineTypes(
    		@PathVariable(name = "customerId")
    		final String customerId) {
		
		return ResponseEntity.ok(maintenanceService.getAllEngineTypesByCustomerId(customerId));
	}
	
	/**
	 * @api {put} /v1/admin/customers/engineTypes/:customerId Update engineTypes for a given customer 
     * @apiExample {curl} Example usage: 
     *      curl --request PUT
     *           --url http://localhost:8080/v1/admin/customers/engineTypes/:customerId
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName updateEngineTypesForCustomer
     * @apiGroup Customer Maintenance
     * @apiDescription Updates the engineType objects for a customer
     * @apiUse Error
     * @apiUse Error500
     **/
	@PutMapping(path = "/engineTypes/{customerId}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineTypesResponse> save(
    		@PathVariable(name = "customerId")
    		final String customerId,
			@Valid
			@RequestBody
			EngineTypesResponse request) {
		
		return ResponseEntity.ok(maintenanceService.saveCustomerEngineTypes(customerId, request));
	}
}
