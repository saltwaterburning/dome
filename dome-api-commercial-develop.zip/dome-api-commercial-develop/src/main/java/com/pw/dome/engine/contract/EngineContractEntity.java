/**
 * @author John De Lello
 */
package com.pw.dome.engine.contract;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.NaturalId;

import com.pw.dome.jpa.AbstractEntityWithNaturalId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_SPEID")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Immutable
public class EngineContractEntity extends AbstractEntityWithNaturalId<String> {
	@Id
	@NaturalId
	@Column(name="ESN")
	private String esn;

    @Column(name="CONTRACT_DESC")
    private String description;
	
	@Column(name="CONTRACT_SUB_FLEET")
	private String subFleet;
	
	@Column(name="CONTRACT_TYPE")
	private String type;
	
	@Column(name="CONTRACT_YRS")
	private String years;

	@Column(name="CONTRACT_SVS")
	private String svs;

	@Column(name="CONTRACT_END_DATE")
	private LocalDate endDate;

	@Column(name="CONTRACT_LEASE_RETURN_DATE")
	private LocalDate leaseReturnDate;

	@Column(name="CONTRACT_REFURB_PAY_STRUCTURE")
	private String refurbPayStructure;

	@Column(name="CONTRACT_LLP_COVERAGE")
	private String llpCoverage;

	@Column(name="CONTRACT_S1_RETROFIT_COVERAGE")
	private String s1RetrofitCoverage;

	@Column(name="CONTRACT_LEASE_RETURN_COVERAGE")
	private String leaseReturnCoverage;

	@Column(name="CONTRACT_ACCESSORY_COVERAGE")
	private String accessoryCoverage;

	@Column(name="CONTRACT_SHIPPING_COVERAGE")
	private String shippingCoverage;

	@Override
	public String getId() {
		return esn;
	}
}
