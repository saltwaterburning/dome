package com.pw.dome.admin;

import static com.pw.dome.admin.Consts.DELIM;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.pw.dome.enginecenter.SecurityEngineCenterEntity;

public final class DataUtils {
    private DataUtils() {}

    public static Map<String, SecurityEngineCenterEntity> getMapByUniqueKey(final List<SecurityEngineCenterEntity> engineCenters) {
        Map<String, SecurityEngineCenterEntity> map = new HashMap<>();
        engineCenters.stream()
            .forEach(s -> map.put(getUniqueKey(s), s));
        return map;
    }

    public static String getUniqueKey(final SecurityEngineCenterEntity sec) {
        return sec.getEmailAddress() + DELIM +
        sec.getEngineCenterId() + DELIM +
        sec.getEngineGroupId() + DELIM +
        sec.getEngineTypeId();
    }
}
