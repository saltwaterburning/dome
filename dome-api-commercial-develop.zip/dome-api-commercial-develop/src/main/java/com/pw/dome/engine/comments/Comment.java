package com.pw.dome.engine.comments;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Comment {
	private Integer commentId;
	/**
	 * Date created actually.
	 */
	private LocalDateTime dateUpdated;
	@NotNull(message = "{NotNull.required}")
	private Boolean external;
	private String logEmail;
	@NotNull(message = "{NotNull.required}")
	@Size(min = 0, max = 2000)
	private String notes;
	private String firstName;
	private String lastName;
}
