package com.pw.dome.external.mro.collab.services.workorder;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "Delete work order schema.")
class MroWorkOrderDeleteRequest {
  @Size(min = 1, max = 20)
  @NotBlank(message = "{NotBlank.required}")
  @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
  private String esn;

  @Min(1)
  @NotNull
  @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
  private Integer eventId;

  @Size(min = 1, max = 10)
  @NotBlank(message = "{NotBlank.required}")
  @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
  private String mroShopCode;
}
