package com.pw.dome.mml.le;

import java.util.List;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.pw.dome.mml.PlanMarket;
import com.pw.dome.mml.PlanType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Builder
public class LeUpdateRequest {

    @NotNull(message = "{NotNull.required}")
    private String engineCenterId;

    @NotNull(message = "{NotNull.required}")
    private String engineGroupId;

    private List<DetailsDTO> leDetails;

    @NotNull(message = "{NotNull.required}")
    private PlanMarket leMarket;

    private List<DetailsDTO> lePlanDetails;

    @NotNull(message = "{NotNull.required}")
    private PlanType leType;

    @NotNull(message = "{NotNull.required}")
    @Max(value = 12, message = "month cannot be greater than 12")
    private Integer month;

    @NotBlank(message = "{NotBlank.required}")
    @Pattern(message = "{Pattern.required}", regexp = "monthly|quarterly")
    private String period;

    @NotNull(message = "{NotNull.required}")
    private Integer year;
}
