package com.pw.dome.engine.model;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import com.pw.dome.user.UserProfile;
import com.pw.dome.web.authorization.SecurityService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author John De Lello
 */
@Slf4j
@Service
public class EngineModelServiceImpl implements EngineModelService {
	@Autowired
	private SecurityService securityService; 
	
	@Autowired
	EngineModelRepository engineModelRepo;

	@Override
	public List<EngineModelEntity> getEngineModels(final UserProfile userProfile, final String engineCenterID, final String engineGroupID) {
		if(userProfile == null) {
			throw new IllegalArgumentException("No valid user profile was specified. Unable to get engine models list.");
		}
		
		if(StringUtils.isEmpty(engineCenterID)) {
			throw new IllegalArgumentException("No valid Engine Center ID was specified. Unable to get engine models list.");
		}
		
		if(StringUtils.isEmpty(engineGroupID)) {
			throw new IllegalArgumentException("No valid Engine Group ID was specified. Unable to get engine models list.");
		}
		
    	boolean isAllowable = securityService.isAllowableEngineCenter(userProfile, engineCenterID);
		
    	if(!isAllowable) {
			log.error("User does not have access to engineCenterID [{}]", engineCenterID);
			throw new AccessDeniedException("User does not have access to engineCenterID [" + engineCenterID + "]. Unable to get engine models list.");
    	}
		
		return engineModelRepo.getEngineModels(userProfile.getEmailAddress(), engineCenterID, engineGroupID);
	}

	@Override
	public List<EngineModelEntity> getEngineModels(final UserProfile userProfile, final String engineCenterID) {
		if(userProfile == null) {
			throw new IllegalArgumentException("No valid user profile was specified. Unable to get engine models list.");
		}
		
		return engineModelRepo.getEngineModels(userProfile.getEmailAddress(), engineCenterID);
	}
}
