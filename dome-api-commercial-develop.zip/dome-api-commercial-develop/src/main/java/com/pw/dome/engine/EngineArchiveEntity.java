package com.pw.dome.engine;

import static java.util.Objects.isNull;
import static org.hibernate.annotations.NotFoundAction.IGNORE;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import org.hibernate.annotations.NotFound;

import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.customer.CustomerEntity;
import com.pw.dome.engine.tracking.EngineTrackingEntity;
import com.pw.dome.jpa.AbstractEntityWithGeneratedId;
import com.pw.dome.module.ModuleEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_ENGINE_ARCHIVE")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EngineArchiveEntity extends AbstractEntityWithGeneratedId<Long> {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOME_ENG_ARCHIVE_ID_SEQ")
	@SequenceGenerator(sequenceName = "DOME_ENG_ARCHIVE_ID_SEQ", allocationSize = 1, name = "DOME_ENG_ARCHIVE_ID_SEQ")
	@Column(name = "ARCHIVE_ID")
	private Long archiveID;
	
	@Column(name = "FORECAST_DATE")
	private LocalDate forecastDate;
	
    @Column(name = "ASSET_ID")
	private Integer assetID;

    @Column(name = "ENG_CATEGORY")
	private String category;
	
    @OneToOne
	@NotFound(action = IGNORE)
	@JoinColumn(name = "ENG_CUST_ID", insertable = false, updatable = false)
	private CustomerEntity customer;

    @Column(name = "ENG_CUST_ID")
	private String customerID;

	@Column(name="ENG_ID")
    private Integer engineID;

    @OneToOne
	@NotFound(action = IGNORE)
    @JoinColumn(name = "ENG_ID", insertable = false, updatable = false)
    private EngineTrackingEntity engineTrackingEntity;

	@Column(name="ENG_SN")
	private String esn;

    @Column(name = "EVENT_ID")
    private Integer eventId;

    // engineActualReceiptDate
	@Column(name = "GATE1")
	private LocalDate gate1;

	// enginePlanReceiptDate
	@Column(name = "GATE1_PLAN")
	private LocalDate gate1Plan;
	
	@Column(name = "ENG_GROUP")
	private String groupID;

	@Column(name = "LOG_EMAIL")
	private String logEmail; 
	
	@Column(name = "ISMANUAL")
	private Boolean manualEngine;
	
	@Column(name = "ENG_MODEL")
	private String modelID;
	
    @OneToOne
	@NotFound(action = IGNORE)
	@JoinColumn(name = "ENG_MODULE", insertable = false, updatable = false)
	private ModuleEntity module;

	@Column(name="ENG_MODULE")
	private Integer moduleID;

    @Column(name = "NOTIFY_NUMBER")
	private String notifyNum;

	@Column(name = "PARENT_ESN")
	private String parentEsn;

	@Column(name = "ENG_PROBABILITY")
	private Integer priority;

	@Column(name = "ENG_REVENUE")
    private Boolean revenue;

	@Column(name = "SALES_ORDER_NO")
	private String salesOrderNum;

	@Column(name = "ENG_ORDER_TYPE")
	private String salesOrderType;
	
	@Column(name = "SHIPMENT_TYPE")
	private String shipmentType;
	
    @Column(name = "ENG_SHOP_VISIT_NO")
    private Integer shopVisitNum;
    
    @OneToOne
	@NotFound(action = IGNORE)
	@JoinColumn(name = "SLOT_ID", insertable = false, updatable = false)
	private SlotEntity slot;
	
	@Column(name = "SLOT_ID")
	private Integer slotID;

	@Column(name = "SLOT_UPDATE_DATE")
	private LocalDateTime updateDate;
	
	@Column(name = "ENG_WRNTY")
    private Boolean warranty;
	
	@PrePersist
	void preInsert() {
		updateDate = LocalDateTime.now();
				
	   if (isNull(this.manualEngine))
	       this.manualEngine = false;
	}
	
	@PreUpdate
	void preUpdate() {
		updateDate = LocalDateTime.now();

	   if (isNull(this.manualEngine))
	       this.manualEngine = false;
	}

    @Override
    public Long getId() {
        return archiveID;
    }
}
