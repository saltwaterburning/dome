package com.pw.dome.engine.induction;

import org.apache.commons.lang3.BooleanUtils;

import com.pw.dome.engine.asset.EngineAssetEntity;

import lombok.Builder;

@Builder
public record AvailableEngine (
	 int engineAssetID,
	 String esn,
     Integer eventId,
	 boolean installed,
	 String operatorId,
     String operatorName,
     Boolean planned,
     Boolean removed,
     Integer slotID) {

    /**
     * Returns the status description.
     * 
     * See {@link EngineAssetEntity}.
     * 
     * @return the status description
     */
    public String getStatus() {
    	if (BooleanUtils.isTrue(planned)) {
    		return "Planned";
    	} else if (BooleanUtils.isTrue(installed)) {
    		return "On-Wing";
    	} else if (BooleanUtils.isTrue(removed)) {
    		return "Removed";
    	} else {
    		return "Available";
    	}
    }
}
