package com.pw.dome.engine.induction.planning;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import org.hibernate.annotations.Immutable;

import com.pw.dome.jpa.AbstractEntityWithEmbeddedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the DOME_MISC database table.
 * 
 */
@Entity
@Table(name="DOME_MISC")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Immutable
class InductionMiscellaneousEntity extends AbstractEntityWithEmbeddedId<InductionMiscellaneousEntityPK>  {
	@EmbeddedId
	private InductionMiscellaneousEntityPK id;

	@Column(name="VALUE_FIELD")
	private String value;

	@Column(name="SHORT_FIELD")
	private String shorValue;

	@Override
	public InductionMiscellaneousEntityPK getId() {
		return id;
	}
}