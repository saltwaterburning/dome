package com.pw.dome.admin.misc;

import static com.pw.dome.admin.misc.Consts.SQL.GET_ADMINS;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowCountCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 * @see RowCallbackHandler
 * @see RowCountCallbackHandler
 */
@Repository
class AdminMiscRepository {
	@Autowired
	private JdbcTemplate template;

	List<AdminUser> getAdminUsers() {
		return template.query(GET_ADMINS, new RowMapper<AdminUser>() {
			public AdminUser mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new AdminUser(rs.getString("name"), rs.getString("email"), rs.getString("organization"));
			}
		});
	}
}
