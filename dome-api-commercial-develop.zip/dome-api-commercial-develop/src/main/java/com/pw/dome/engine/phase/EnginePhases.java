package com.pw.dome.engine.phase;

import java.util.stream.Stream;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.pw.dome.exception.RestExceptionHandler;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Enumeration of recognized engine phases.
 * This enum has annotations to direct JSON processing.
 * 
 * @see JsonCreator
 * @see JsonValue
 * @see RestExceptionHandler
 */
@Schema(enumAsRef = true)
public enum EnginePhases {
    /** Any phase searched by ESN. Code is ALL. */
    ALL,
    /** Engine Completed. Code is COMPLETE. */
    COMPLETE,
    /** Inactive engine. Code is INACTIVE. */
    INACTIVE,
    /** Removed Engine. Code is REMOVEDENG. */
    REMOVED_ENG,
    /** A planned engine that doesn't have an Actual Induction Date. Code is SCHEDULED. */
    SCHEDULED,
    /** Work In Progress. CODE is WIP. */
    WIP;

	private EnginePhases() {
	}

	/**
     * Returns the engine phase code as in the DOME_ENGINE_PHASE table.
     * @return the engine phase code
     * 
     * @see JsonValue
     */
    @JsonValue
    public String getCode() {
        return name().replace("_", "");
    }

    /**
     * Indicates if an ESN is required.
     * 
     * @return true if an ESN is required
     */
    public boolean searchRequiresEsn() {
    	return this == ALL || this == COMPLETE;
    }

    /**
     * Creates a {@code EnginePhases} instance from a phase code or enum name.
     * 
     * @param phaseCode code as in DOME_ENGINE_PHASE table or enum name
     * @return a {@code EnginePhases} instance
     * @throws IllegalArgumentException if unable to convert to a {@code EnginePhases}
     * 
     * @see JsonCreator
     */
    @JsonCreator
    public static EnginePhases of(final String phaseCode) {
    	return Stream.of(EnginePhases.values())
    			     .filter(s -> s.getCode().equalsIgnoreCase(phaseCode) || s.name().equalsIgnoreCase(phaseCode))
    			     .findFirst()
                     // IllegalArgumentException maps to HttpStatus.BAD_REQUEST request status.
    			     .orElseThrow(()-> new IllegalArgumentException("Invalid EnginePhases code: " + phaseCode));
    }

    @Component
    public static class EnginePhasesConverter implements Converter<String, EnginePhases> {

        @Override
        public EnginePhases convert(String value) {
            return EnginePhases.of(value);
        }
    }
}
