package com.pw.dome.engine.networkmanagement.excel;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.pw.dome.util.hibernate.ValidatingTupleTransformer;

/**
 * Allow for use of {@link ValidatingTupleTransformer} to provide query validation.
 */
interface CustomRepository {
	List<NetworkManagement> getNetworkManagementData(
			@Param("engCenters")
			List<String> engCenter, 
			@Param("engTypes")
			List<String> engType, 
			@Param("ignoreCustId")
			boolean ignoreCustId,
			@Param("custIds")
			List<String> custId,
			@Param("ignoreContractType")
			boolean ignoreContractType,
			@Param("contractTypes")
			List<String> contractType);

	List<NetworkManagement> getRemovedNetworkManagementData(
			@Param("engTypes")
			final List<String> engType);

}
