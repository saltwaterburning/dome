package com.pw.dome.calendar.slots;

import jakarta.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class UpdateSlotRequest {
  @NotNull
  private ShopVisitType shopVisitType;
  @Range(min = 0, max = 9)
  private Integer slotCount;
}
