package com.pw.dome.audit.listeners;

import static com.pw.dome.audit.AUDIT_TYPES.UPDATE;

import jakarta.persistence.PrePersist;
import jakarta.persistence.PreRemove;
import jakarta.persistence.PreUpdate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pw.dome.audit.AuditEntity;
import com.pw.dome.audit.AuditItem;
import com.pw.dome.audit.AuditService;
import com.pw.dome.wip.pacing.PacingItemEntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PacingItemEntityListener implements AuditableEntityListener<PacingItemEntity> {

  public static AuditItem ITEM = new AuditItem("Pacing Item");

  private static AuditService svc;

  @Autowired
  public void inject(AuditService svc) {
    PacingItemEntityListener.svc = svc;
  }

  @PrePersist
  @Override
  public void onPrePersist(PacingItemEntity entity) {
    log.debug("onPrePersist()");
  }

  @PreUpdate
  @Override
  public void onPreUpdate(PacingItemEntity entity) {
    log.debug("onPreUpdate()");

    AuditEntity audit = AuditEntity.builder()
        .customerID("CustABC")
        .description("Test only")
        .engineCenterId("EC1")
        .engineModel("EM1")
        .engineSerialNumber("SN123")
        .engineType("ET1")
        .item(getAuditItem())
        .type(UPDATE)
        .build();

    svc.saveAudit(audit);
  }

  @PreRemove
  @Override
  public void onPreRemove(PacingItemEntity entity) {
    log.debug("onPreRemove()");
  }

  @Override
  public AuditItem getAuditItem() {
    return ITEM;
  }
}
