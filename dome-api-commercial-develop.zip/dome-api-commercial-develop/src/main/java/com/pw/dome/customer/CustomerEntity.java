package com.pw.dome.customer;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.NaturalId;

import com.pw.dome.jpa.AbstractEntityWithNaturalId;
import com.pw.dome.util.hibernate.BooleanToActiveOrInactiveConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author John De Lello
 */
@Entity
@Table(name="DOME_CUSTOMER")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CustomerEntity extends AbstractEntityWithNaturalId<String> {
	@Id
	@NaturalId
	@Column(name="CUST_ID")
	private String customerID;

	@Column(name="CUST_STATUS")
	@Convert(converter = BooleanToActiveOrInactiveConverter.class)
	private boolean active;

	@Column(name="CUST_ID_VALUE")
	private Long customerIdValue;

	@Column(name="CUST_NAME")
	private String name;
	
	@Column(name="REGION")
	private String region;

	@Column(name="CUST_SNAME")
	private String shortName;

	@Override
	public String getId() {
		return customerID;
	}

	@Override
	public boolean isNew() {
		return StringUtils.isBlank(getId());
	}
}
