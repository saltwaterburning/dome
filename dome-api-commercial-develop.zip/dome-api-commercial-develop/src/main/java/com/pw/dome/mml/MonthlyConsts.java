package com.pw.dome.mml;

import static com.pw.dome.mml.Consts.SHIPPED_DAYS;

interface MonthlyConsts {

	interface SQL {
		String AND_NOT_DISABLED = " AND cast(nvl(engineAsset.disabled, 0) as int) = 0 ";

		String SELECT_BASE = "SELECT DISTINCT engine.engineID as engineId, "
												+ "engineCenter.name as engineCenterName,  "
												+ "engineGroup.name as engineGroupName, "
												+ "engineGroup.engineGroupID as engineGroupId, "
												+ "engine.category as engineCategory, "
												+ "engine.esn as engineSerialNumber, "
												+ "customer.name as customerName, ";
		String SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH = "SELECT mmlMonthlyEntity.engineId "
				+ "FROM MmlMonthlyEntity mmlMonthlyEntity "
				+ "WHERE mmlMonthlyEntity.planType = :planType AND "
				+ "mmlMonthlyEntity.planMarket = :planMarket  AND "
				+ "(mmlMonthlyEntity.planYear > year(local_date) "
				+ "   OR (mmlMonthlyEntity.planYear = :planYear AND mmlMonthlyEntity.planMonth >= month(local_date))) ";

		String SELECT_INDUCTION = SELECT_BASE + "engTrack.engtrackPlanIndDate as planInductionDate, "
												+ "engTrack.engtrackRecDate as actualReceipentDate ";
		
		String SELECT_REVENUE = SELECT_BASE + "engTrack.gate3Plan as planInductionDate, "
				+ "engTrack.enginePlanCoreAssemblyDate as actualReceipentDate ";
		
		String SELECT_SHIPMENT = SELECT_BASE + "engTrack.engtrackPlanEngComplete as planInductionDate, "
									+ "engTrack.enginePlanCoreAssemblyDate as actualReceipentDate ";
		
		String BASE_FROM =  "FROM EngineEntity engine, "
												+ "EngineTrackingEntity engTrack, "
												+ "SlotEntity slot, "
												+ "EngineCenterEntity engineCenter, "
												+ "EngineGroupEntity engineGroup, CustomerEntity customer ";
		String BASE_FROM2 =
"""
				FROM
				CustomerEntity customer,
				EngineEntity engine,
				EngineCenterEntity engineCenter,
				EngineGroupEntity engineGroup,
				EngineTrackingEntity engTrack,
				SlotEntity slot
""";

				String FROM_MONTHLY = BASE_FROM + ", MmlMonthlyEntity mmlMonthlyEntity ";
		
		String SELECT_ENGINE_ID = "SELECT mmlMonthlyEntity.engineId "
												+ "FROM MmlMonthlyEntity mmlMonthlyEntity "
												+ "WHERE mmlMonthlyEntity.planMonth = :planMonth AND "
												+ "mmlMonthlyEntity.planYear = :planYear AND "
												+ "mmlMonthlyEntity.planType = :planType AND "
												+ "mmlMonthlyEntity.planMarket = :planMarket ";
		
		
		String ORDER_BY_SHIP = "ORDER BY engTrack.engtrackPlanEngComplete, engTrack.enginePlanCoreAssemblyDate ";
		
		String ORDER_BY_REV = "ORDER BY engTrack.gate3Plan, engTrack.enginePlanCoreAssemblyDate ";
		
		String ORDER_BY_PLANIND_ENGTRACK = "ORDER BY engTrack.engtrackPlanIndDate, engTrack.engtrackRecDate ";
		
		String BASE_WHERE = "WHERE engine.engineID = engTrack.engtrackId AND "
												+ " engine.slotID = slot.slotID AND "
												+ "  UPPER(engine.esn) NOT IN ('CLOSED', 'FREE', 'LOST', 'RESV', 'XXXXXX') AND "
												+ "slot.engineCenterID = engineCenter.id AND "
												+ "engineCenter.id = :ecid AND "
												+ "engine.groupID = engineGroup.engineGroupID AND "
												+ "engine.customerID = customer.customerID AND "
												+ "engine.groupID in (:engineGroupIds) ";

		String BASE_NOT_WHERE = "WHERE engine.engineID = engTrack.engtrackId AND "
				+ " engine.slotID = slot.slotID AND "
				+  " engine.engineID NOT IN (" + SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH + ") AND"
				+ " UPPER(engine.esn) NOT IN ('CLOSED', 'FREE', 'LOST', 'RESV', 'XXXXXX') AND "
				+ " slot.engineCenterID = engineCenter.id AND "
				+ "engineCenter.id = :ecid AND "
				+ "engine.groupID = engineGroup.engineGroupID AND "
				+ "engine.customerID = customer.customerID AND "
				+ "engine.groupID in (:engineGroupIds) ";
		
		String ENGINES_SHIPPED_WHERE = "AND (engTrack.engtrackShipmentDate is null OR "
									+ "engTrack.engtrackShipmentDate > (local_date - " + SHIPPED_DAYS + " day)) ";
		
		String AND_WHERE = "AND engine.engineID = mmlMonthlyEntity.engineId AND "
												+ "mmlMonthlyEntity.planMonth = :planMonth AND "
												+ "mmlMonthlyEntity.planYear = :planYear ";

		String MONTHLY_MML_INDUCTION_DATA = SELECT_INDUCTION +  FROM_MONTHLY + BASE_WHERE + AND_WHERE + " AND engine.engineID IN ( " + SELECT_ENGINE_ID + ")" + ORDER_BY_PLANIND_ENGTRACK;

		String MONTHLY_MML_REVENUE_DATA = SELECT_REVENUE + FROM_MONTHLY + BASE_WHERE + AND_WHERE + " AND engine.engineID IN ( " + SELECT_ENGINE_ID + ")" + ORDER_BY_REV;

		String MONTHLY_MML_SHIPMENT = SELECT_SHIPMENT + FROM_MONTHLY + BASE_WHERE + AND_WHERE + " AND engine.engineID IN ( " + SELECT_ENGINE_ID + ")" + ORDER_BY_SHIP;

		String MONTHLY_MML_PLAN_INDUCTION_DATA =
				SELECT_INDUCTION +
				BASE_FROM2 +
				BASE_NOT_WHERE +
				ENGINES_SHIPPED_WHERE +
				ORDER_BY_PLANIND_ENGTRACK;

		String MONTHLY_MML_PLAN_REVENUE_DATA = SELECT_REVENUE + BASE_FROM + BASE_WHERE + ENGINES_SHIPPED_WHERE + " AND engine.engineID NOT IN ( " + SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH + ")" + ORDER_BY_REV;

		String MONTHLY_MML_PLAN_SHIPMENT_DATA = SELECT_SHIPMENT + BASE_FROM + BASE_WHERE + ENGINES_SHIPPED_WHERE +  " AND engine.engineID NOT IN ( " + SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH + ")" + ORDER_BY_SHIP;
	 }
	
}