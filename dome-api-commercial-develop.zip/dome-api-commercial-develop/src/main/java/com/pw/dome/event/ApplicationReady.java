package com.pw.dome.event;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootVersion;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.ApplicationListener;
import org.springframework.core.SpringVersion;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ApplicationReady implements ApplicationListener<ApplicationReadyEvent> {
	/**
	 * @see createBuildInfo task in build-tasks.gradle file.
	 */
	@Autowired
	private BuildProperties buildProperties;

	@Override
	public void onApplicationEvent(final ApplicationReadyEvent event) {
		final String separator = StringUtils.repeat("=", 80);
		final StringBuilder buffy = new StringBuilder("\nApplicationReadyEvent\n");

		buffy.append(separator).append("\n");
		String msg = String.format("Running with Spring Boot v%s, Spring v%s\n\n", SpringBootVersion.getVersion(),
				SpringVersion.getVersion());
		buffy.append(msg);
		buffy.append(buildProperties.getName()).append(" is ready to service requests.\n");
		buffy.append(separator);
		log.info(buffy.toString());
	}
}