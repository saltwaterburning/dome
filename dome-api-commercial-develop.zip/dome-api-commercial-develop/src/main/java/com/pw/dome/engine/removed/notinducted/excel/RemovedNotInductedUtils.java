package com.pw.dome.engine.removed.notinducted.excel;

import static com.pw.dome.report.excel.ReportConstants.DATE_FORMAT;
import static com.pw.dome.util.excel.Border.BorderStyles.THIN;
import static com.pw.dome.util.excel.CellStyle.AlignH.LEFT;

import java.util.Arrays;

import com.pw.dome.util.excel.Border;
import com.pw.dome.util.excel.CellStyle;
import com.pw.dome.util.excel.CellStyle.AlignH;
import com.pw.dome.util.excel.CellStyle.AlignV;
import com.pw.dome.util.excel.CellStyle.FillPattern;
import com.pw.dome.util.excel.CellValues;
import com.pw.dome.util.excel.CellValues.Builder;
import com.pw.dome.util.excel.Colors;
import com.pw.dome.util.excel.FontStyle;

import lombok.Getter;

class RemovedNotInductedUtils {

	@Getter
    private static final CellStyle boldLeftBlueWrapperHeader = getStyle(true, true, false, true, Colors.SKY_BLUE, null, LEFT, null);
	@Getter
	private static final CellStyle plainLeft = getStyle(false, false, false, false, null, null, LEFT, null);
	@Getter
	private static final CellStyle leftPlainDate = getStyle(false, false, true, false, null, null, LEFT, null);
	
	private static CellStyle getStyle(boolean bold, boolean border, boolean date, boolean wrapText, Colors bgColor, Colors textColor, AlignH horizontalAlignment, AlignV verticalAlignment) {
		final CellStyle.CellStyleBuilder cb = CellStyle.builder();
		final FontStyle.FontStyleBuilder fb = FontStyle.builder();

		fb.bold(bold);
		if (textColor != null) {
			fb.color(textColor);
		}
		if (border) {
			cb.border(Border.of(THIN));
		}
		if (date) {
			cb.dataFormat(DATE_FORMAT);
		}
		cb.wrapText(wrapText);
		if (bgColor != null) {
			cb.fillForegroundColor(bgColor)
			  .fillPattern(FillPattern.SOLID_FOREGROUND);
		}
		cb.fontStyle(fb.build());
		if (horizontalAlignment != null) {
			cb.alignH(horizontalAlignment);
		}
		if (verticalAlignment != null) {
			cb.alignV(verticalAlignment);
		}
		return cb.build();
	}
	
	public static CellValues getEnginesRemovedNotInductedReportHeaders() {
		String[] hdrs = { "ESN", "Event ID", "Engine Type", "Operator/Customer", "Operator",
				"Removal Date\n(Actual)", "Unserviceable\nDate", "Planned\nInduction",
				"Maintenance Center", "Current location", "SV Classification", "Investigation\nLevel",
				"Disabled", "Comment"};
		CellStyle style = getBoldLeftBlueWrapperHeader();
		Builder b = CellValues.builder();
		Arrays.stream(hdrs).forEach(h->b.add(style, h));
		return b.build();
	}
	
	public static CellValues getData(EngineRemovedNotInducted engine) {
        CellStyle style = getPlainLeft();
        CellStyle dateStyle = getLeftPlainDate();
		Builder b = CellValues.builder();
		
		b.add(style, engine.getEsn());
		b.add(style, engine.getEventId());
		b.add(style, engine.getEngineType());
		b.add(style, engine.getCustomerName());
		b.add(style, engine.getOperator());
		b.add(dateStyle, engine.getActualRemovalDate());
		b.add(dateStyle, engine.getRecordedRemovalDate());
		b.add(dateStyle, engine.getPlanInductionDate());
		b.add(style, engine.getMaintenanceCenter());
		b.add(style, engine.getCurrentLocation());
		b.add(style, engine.getSvClass());
		b.add(style, engine.getInvestigationLevel());
		b.add(style, engine.getDisabled(), "No", "Yes");
		b.add(style, engine.getComments());
		
		return b.build();
	}
}
