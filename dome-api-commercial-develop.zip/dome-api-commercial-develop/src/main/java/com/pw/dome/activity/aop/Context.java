package com.pw.dome.activity.aop;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Context {
    String activityItem;
    String activityType;
    String userEmail;
}
