package com.pw.dome.external.workscope;

import java.util.List;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.pw.dome.admin.enginecenter.maintenance.BasicEngineCenter;
import com.pw.dome.external.RemoteServicesWebClient;
import com.pw.dome.external.workscope.provider.Provider;
import com.pw.dome.external.workscope.provider.ProviderRequest;
import com.pw.dome.wip.WorkInProgress;

import lombok.extern.slf4j.Slf4j;

/**
 * Handles all requests to WST and guards against exceptions to prevent failures in calling service.
 * All methods are invoked asynchronously.
 * 
 * @see RemoteServicesWebClient
 */
@Service
@Slf4j
public class WstWebClientAsyncService extends WstWebClientAbstractService {

	@Async
	public void deleteProviders(List<BasicEngineCenter> newEngineCenters) {
		try {
			List<Provider> providers = DataMapper.INSTANCE.toProvider(newEngineCenters);
			ProviderRequest request = new ProviderRequest(providers);
			doDeleteProviders(request);
		} catch (Exception e) {
			log.error("deleteProviders() failed.", e);
		}
	}

	@Async
	public void pushProviders(List<BasicEngineCenter> newEngineCenters) {
		try {
			List<Provider> providers = DataMapper.INSTANCE.toProvider(newEngineCenters);
			ProviderRequest request = new ProviderRequest(providers);
			doPushProviders(request);
		} catch (Exception e) {
			log.error("pushProviders() failed.", e);
		}
	}

	@Async
	public void pushShopVisitDetails(WorkInProgress request) {
		try {
			doPushShopVisitDetails(request);
		} catch (Exception e) {
			log.error("pushShopVisitDetails() failed.", e);
		}
	}
}
