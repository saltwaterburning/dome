package com.pw.dome.engine.type;

import static com.pw.dome.engine.type.Consts.SQL.GET_ENGINE_TYPE_BY_ENGINE_GROUP;
import static com.pw.dome.engine.type.Consts.SQL.GET_ENGINE_TYPE_BY_ENGINE_TYPE_ID;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * @author John De Lello
 */
@Repository
public interface EngineTypeRepository extends JpaRepository<EngineTypeEntity, String> {

	@Query(GET_ENGINE_TYPE_BY_ENGINE_GROUP)
	EngineTypeEntity getEngineType(@Param("engGroupId")String engineGroupId);

	@Query(GET_ENGINE_TYPE_BY_ENGINE_TYPE_ID)
	EngineTypeEntity getByEngineTypeId(@Param("engineTypeId")String engineTypeId);

//	@Query(GET_ENGINE_TYPE_BY_ENGINE_GROUP)
//	List<EngineTypeEntity> getEngineType(@Param("userId")String emailAddress, @Param("engCenterId")String engineCenterID, @Param("engGroupId")String engineGroupId);

	@Query(value = "SELECT e FROM EngineTypeEntity e WHERE e.engineTypeID IN(SELECT engineTypeId FROM SecurityEngineCenterEntity s where lower(s.emailAddress) = lower(?1) AND s.engineCenterId =?2) AND e.active = true ORDER BY e.name")
	List<EngineTypeEntity> getEngineTypes(final String emailAddress, final String engineCenterID);

	@Query(value = "SELECT e FROM EngineTypeEntity e WHERE e.engineTypeID IN(SELECT engineTypeId FROM SecurityEngineCenterEntity s where lower(s.emailAddress) = lower(?1)) AND e.active = true ORDER BY e.name")
	List<EngineTypeEntity> getActiveEngineTypes(final String emailAddress);

	@Query(value = "SELECT e FROM EngineTypeEntity e WHERE e.engineTypeID IN(SELECT engineTypeId FROM SecurityEngineCenterEntity s where lower(s.emailAddress) = lower(?1) AND s.engineCenterId =?2 AND s.engineGroupId = ?3) AND e.active = true  ORDER BY e.name")
	List<EngineTypeEntity> getEngineTypes(String emailAddress, String engineCenterID, String engineGroupID);

	@Query(value = "SELECT dome_eng_type_id_seq.nextval FROM dual", nativeQuery = true)
	Long getNextSeqVal();

	@Query("SELECT e FROM EngineTypeEntity e WHERE e.active = true ORDER BY e.name")
    List<EngineTypeEntity> getActiveEngineTypes();

	@Query(value = "SELECT * FROM dome_eng_type_mst ORDER BY eng_type_name", nativeQuery = true)
    List<EngineTypeEntity> getAllEngineTypes();

	@Query(value = "SELECT e.name FROM EngineTypeEntity e WHERE e.engineTypeID IN (?1)")
	List<String> getEngineNames(List<String> engineTypes);
}
