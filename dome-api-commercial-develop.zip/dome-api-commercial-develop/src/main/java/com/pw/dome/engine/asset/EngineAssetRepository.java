/**
 * 
 */
package com.pw.dome.engine.asset;

import static com.pw.dome.engine.asset.Consts.SQL.ENGINES_AVAILABLE;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * The DOME_ENGINE_ASSETS table is unique on ESN and also unique on engine_asset_id.
 */
@Repository
public interface EngineAssetRepository extends JpaRepository<EngineAssetEntity, Integer>			 
{
    /**
     * Sets the specified {@code engineTypeId} to null. Used when an
     * engine type is deleted via the engine maintenance page.
     * 
     * @param engineTypeId the Id to make null
     */
    @Modifying
    @Query(value = "UPDATE EngineAssetEntity ea set ea.engineTypeID = NULL where ea.disabled = false AND ea.engineTypeID = ?1")
    int dropEngineType(final String engineTypeId);

    List<EngineAssetEntity> findByAssetID(final int assetID);

    EngineAssetEntity findByEsnIgnoreCase(final String esn);

    /**
     * Finds engine assets matching engineType and LIKE ESN (esn%).
     * 
     * @param engineType
     * @param esn
     * @return
     */
    @Query(value = ENGINES_AVAILABLE)
	List<EngineAssetEntity> getAvailableEngineAssetList(final String engineType, final String esn);
}
