package com.pw.dome.module;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Embeddable
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ModuleAssetEntityPK implements Serializable {
	private static final long serialVersionUID = -6731932541022406011L;

	@Column(name="ENG_MODULE_ID", insertable = false, updatable = false)
	private Integer moduleID;
	
	@Column(name="SN", insertable = false, updatable = false)
	private String sn;

	@Override
	public int hashCode() {
		return Objects.hash(moduleID, sn);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof ModuleAssetEntityPK))
			return false;
		ModuleAssetEntityPK other = (ModuleAssetEntityPK) obj;
		return Objects.equals(moduleID, other.moduleID) && Objects.equals(sn, other.sn);
	}

}
