package com.pw.dome.engine.asset;

import static com.pw.dome.util.Messages.engAssetNotFoundUsingEngAssetId;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.calendar.slots.SlotService;
import com.pw.dome.exception.NotFoundException;
import com.pw.dome.user.UserProfile;

/**
 * @author John De Lello
 */
@Service
public class EngineAssetService {
	@Autowired
	private EngineAssetRepository engineAssetRepository;
	@Autowired
	private SlotService slotService;

	@Transactional(readOnly = true)
	public List<EngineAssetResponse> findAvailableEnginesBySlotIDAndEsn(final UserProfile userProfile, final Integer slotID,
			final String esn) {
		DataMapper mapper = DataMapper.INSTANCE;

		SlotEntity slot = slotService.getSlotByID(userProfile, slotID);

		List<EngineAssetEntity> engineAssets = engineAssetRepository.getAvailableEngineAssetList(slot.getEngineTypeID(),
				esn + "%");

		List<EngineAssetResponse> response = new ArrayList<>();
		engineAssets.stream().forEach(s -> response.add(mapper.toResponse(s, slot)));

		return response;
	}

	@Transactional(readOnly = true)
	public EngineAssetEntity getEngineAssetByID(final int engineAssetID) {
		return engineAssetRepository.findById(engineAssetID)
				.orElseThrow(() -> new NotFoundException(engAssetNotFoundUsingEngAssetId(engineAssetID)));
	}

	@Transactional
	public EngineAssetEntity save(final EngineAssetEntity engineAsset) {
		return engineAssetRepository.saveAndFlush(engineAsset);
	}
}
