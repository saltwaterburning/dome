package com.pw.dome.example;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import jakarta.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pw.dome.common.oas.BaseRESTfulResource;
import com.pw.dome.exception.ErrorResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Example controller with comprehensive API annotations.
 * 
 * Note annotation on methods, request parameters and response DTO.
 *
 * See MRO controller(s) for example with array of DTOs.
 */
//@RestController
@RequestMapping("/v1/example")
// ONLY import BaseRESTfulResource not any of it's other classes.
@Tag(name = BaseRESTfulResource.Tags.EXAMPLE)
// Prefer class scope @Validated instead of @Valid
@Validated
class ExampleController extends BaseRESTfulResource {

	@Autowired
	private ExampleService exampleService;

	/**
	 * Example with no parameters and array response.
	 * Note @ArraySchema.
	 * No errors documented since the service doesn't throw any application errors.
	 * 
	 * All possible exceptions in com.pw.dome.example.
	 *
	 * Add method JavaDocs as needed.
	 * 
	 * @return
	 */
	@Operation(description = "Fetches Example matching suppied critera.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = OK,
					content = {@Content(array = @ArraySchema(schema = @Schema(implementation = String.class)))})
	})
	@GetMapping(path = "/no-parms", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<ExampleArrayResponse> getAllExample() {
		List<String> array = exampleService.getItAll();
		return ResponseEntity.ok(new ExampleArrayResponse(array));
	}

	/**
	 * Typical example with return DTO, validation and possible NOT_FOUND.
	 * Note annotation on API, request parameters and Response DTO.
	 * 
	 * Add method JavaDocs as needed.
	 * 
	 * See MRO controllers and DTO also.
	 * 
	 * @param esn
	 * @param workOrder
	 * @return
	 */
	@Operation(description = "Fetches Example matching suppied critera.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = OK,
					content = {@Content(schema = @Schema(implementation = ExampleRequestAndResponse.class))}),
			// When using validation...
			@ApiResponse(responseCode = BAD_REQUEST, description = Descriptions.BAD_REQUEST,
			content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
			// When throwing NotFoundException
			@ApiResponse(responseCode = NOT_FOUND, description = Descriptions.NOT_FOUND,
			content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})
	})
	@GetMapping(path = "typical-errors/{esn}/{work-order}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<ExampleRequestAndResponse> getExampleTypicalWithResponseDTO (
			@NotBlank(message = "{NotBlank.required}")
			@Parameter(description = "Engine Serial Number",
			required = true) @PathVariable(name = "esn") String esn,
			@NotBlank(message = "{NotBlank.required}")
			@Parameter(description = "Work Order",
			required = true) @PathVariable(name = "work-order") String workOrder) {
		return ResponseEntity.ok(exampleService.getIt(esn, workOrder));
	}

	/**
	 * Example to show every possible DOME exception.
	 * 
	 * All possible exceptions in com.pw.dome.example.
	 * 
	 * @param esn
	 * @param workOrder
	 * @return
	 */
	@Operation(description = "Fetches Example matching suppied critera.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = OK,
					content = {@Content(schema = @Schema(implementation = ExampleRequestAndResponse.class))}),
			// When using validation...
			@ApiResponse(responseCode = BAD_REQUEST, description = Descriptions.BAD_REQUEST,
			content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
			// When there is a data conflict as engine already slotted.
			@ApiResponse(responseCode = CONFLICT, description = Descriptions.CONFLICT,
			content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
			// When throwing NotFoundException
			@ApiResponse(responseCode = NOT_FOUND, description = Descriptions.NOT_FOUND,
			content = {@Content(schema = @Schema(implementation = ErrorResponse.class))}),
			// When user doesn't have security privilege.
			@ApiResponse(responseCode = UNAUTHORIZED, description = Descriptions.UNAUTHORIZED,
			content = {@Content(schema = @Schema(implementation = ErrorResponse.class))})
	})
	@GetMapping(path = "/all-errors/{esn}/{work-order}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<ExampleRequestAndResponse> getExampleWithResponseDTOAndAllPossibleErrors (
			@NotBlank(message = "{NotBlank.required}")
			@Parameter(description = "Engine Serial Number",
			required = true) @PathVariable(name = "esn") String esn,
			@NotBlank(message = "{NotBlank.required}")
			@Parameter(description = "Work Order",
			required = true) @PathVariable(name = "work-order") String workOrder) {
		return ResponseEntity.ok(exampleService.getIt(esn, workOrder));
	}
}
