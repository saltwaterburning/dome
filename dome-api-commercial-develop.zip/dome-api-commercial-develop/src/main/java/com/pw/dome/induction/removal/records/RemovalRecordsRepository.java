package com.pw.dome.induction.removal.records;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

interface RemovalRecordsRepository extends JpaRepository<RemovalRecordsEntity, Long> {

	List<RemovalRecordsEntity> findByEsnAndEventIdOrderByEventIdAscRemovalIdAsc(@Param("esn") String esn,
			@Param("eventId") Integer eventId);
}
