package com.pw.dome.engine.comments;

import static org.hibernate.annotations.NotFoundAction.IGNORE;

import java.time.LocalDateTime;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PostLoad;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

import com.pw.dome.jpa.AbstractEntityWithGeneratedId;
import com.pw.dome.user.UserProfile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * JPA entity. Spring Data provides converters for Java 8 (java.time.*) classes.
 * 
 * @see Jsr310JpaConverters
 */
@Entity
@Table(name="DOME_ENGINE_COMMENTS")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CommentEntity extends AbstractEntityWithGeneratedId<Integer> {
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOME_ENG_COMMENTS_SEQ")
    @SequenceGenerator(sequenceName = "DOME_ENG_COMMENTS_SEQ", allocationSize = 1, name = "DOME_ENG_COMMENTS_SEQ")
	@Column(name="ENG_COMMENTS_ID")
	private Integer commentId;

	@Column(name="DATE_UPDATED")
	private LocalDateTime dateUpdated;

	@Column(name="ENG_ID")
	private Integer engineId;

	@Column(name="IS_EXTERNAL")
	private boolean isExternal;
	
	@Column(name="LOG_EMAIL")
	private String logEmail;

	@OneToOne
	@NotFound(action = IGNORE)
	@JoinColumn(name = "LOG_EMAIL", insertable = false, updatable = false)
	private UserProfile user;

	@Column(name="NOTES")
	private String notes;

	@Override
	public Integer getId() {
		return commentId;
	}

	@PostLoad
	void postLoad() {
		if (Objects.isNull(notes)) {
			notes = "";
		}
	}
}
