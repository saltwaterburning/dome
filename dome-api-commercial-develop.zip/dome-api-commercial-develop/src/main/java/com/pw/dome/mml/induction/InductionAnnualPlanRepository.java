package com.pw.dome.mml.induction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pw.dome.mml.PlanMarket;
import com.pw.dome.mml.PlanType;


interface InductionAnnualPlanRepository extends JpaRepository<InductionAnnualPlanEntity, Integer> {

    @Query(value = Consts.SQL.ANNUAL_PLANS)
    List<InductionAnnualPlanEntity> getAnnualPlan(@Param("engCenterId")String engCenterId,
                                                  @Param("engGroupId")String engGroupId,
                                                  @Param("planMarket")PlanMarket planMarket,
                                                  @Param("planType")PlanType planType,
                                                  @Param("year")Integer year);
}