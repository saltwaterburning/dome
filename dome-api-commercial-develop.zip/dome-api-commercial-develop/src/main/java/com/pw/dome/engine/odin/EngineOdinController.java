package com.pw.dome.engine.odin;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.common.oas.BaseRESTfulResource;
import com.pw.dome.engine.induction.planning.InductionMiscKeys;
import com.pw.dome.exception.ErrorResponse;
import com.pw.dome.user.UserProfile;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

/**
 * @author John De Lello
 */
@RestController()
@RequestMapping("/v1/engines/odin")
public class EngineOdinController extends BaseRESTfulResource {
	@Autowired
	private EngineOdinService engineOdinSvc;

    /**
     * Fetches the ODIN details.
     * 
     * <pre>
     * OAS example documentation using path parameters and returning a POJO.
     * 
     * Notes:
     * 1) This API is multi-tagged. Meaning that it'll appear within several API sections (left-side).
     * 2) The API response POJO is defined within the {@code @Schema} annotation.
     * 3) The POJO is annotated to provide description using {@code @Schema}.
     * 4) The parameter type, name and required indication are derived from the {@code @PathVariable} annotations.
     * 
     * </pre>
     * 
     * @param userProfile injected value
     * @param assetId the asset identifier
     * @param esn the engine serial number
     * @return the ODIN details
     *
     * @see InductionMiscKeys
     * @see <a href="http://dbdsdev/api/doc.html#operation/getEngineOdinDetails" target="_blank">This Method API Doc</a>
     */
    @Operation(tags = { Tags.INDUCTION_PLANNING, Tags.ENG_ODIN }, // For multi-tagging
               description = "Returns the ODIN details.",
               responses = {
                   @ApiResponse(content = @Content(schema = @Schema(implementation = OdinDTO.class),
                                                   mediaType = MediaType.APPLICATION_JSON_VALUE),
                                responseCode = OK),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = BAD_REQUEST,
                                description = Descriptions.BAD_REQUEST),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = UNAUTHORIZED,
                                description = Descriptions.UNAUTHORIZED),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = NOT_FOUND,
                                description = Descriptions.NOT_FOUND),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = INTERNAL_SERVER_ERROR,
                                description = Descriptions.INTERNAL_SERVER_ERROR)
               })
//    @GetMapping(path = "/values/{key}",
//                produces = APPLICATION_JSON_VALUE)
//    @RequestMapping(value = "/{assetId}/{esn}", method = RequestMethod.GET)
//	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
//    public ResponseEntity<OdinDTO> getEngineOdinDetails(@AuthenticationPrincipal
//    		                                             UserProfile userProfile, 
//    		                                             @PathVariable
//    		                                             int assetId,
//    		                                             @PathVariable
//    		                                             String esn){
//    	OdinDTO removedEngineDetail = engineOdinSvc.getEngineRemovedDetails(assetId, esn);
//    	return new ResponseEntity<OdinDTO>(removedEngineDetail, HttpStatus.OK);
//    }

    @PostMapping(path = "/details", produces = APPLICATION_JSON_VALUE)
    @Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<OdinDTO> getEngineOdinDetails(@AuthenticationPrincipal
                                                         UserProfile userProfile, 
                                                         @Valid
                                                         @RequestBody
                                                         OdinDetailsRequest request){
        OdinDTO removedEngineDetail = engineOdinSvc.getEngineRemovedDetails(request, userProfile);
        return new ResponseEntity<OdinDTO>(removedEngineDetail, HttpStatus.OK);
    }

    /**
     * Updates the ODIN details.
     * 
     * <pre>
     * OAS example documentation using path parameters and returning a POJO.
     * 
     * Notes:
     * 1) This API is multi-tagged. Meaning that it'll appear within several API sections (left-side).
     * 2) The API request/response POJO is defined within the {@code @Schema} annotation.
     * 3) The POJO is annotated to provide description using {@code @Schema}.
     * 4) The parameter type, name and required indication are derived from the {@code @RequestBody} annotations.
     * 
     * </pre>
     * 
     * @param userProfile injected value
     * @param odinRequestDTO the JSON request body
     * @return the ODIN details
     *
     * @see InductionMiscKeys
     * @see <a href="http://dbdsdev/api/doc.html#operation/saveEngineOdinDetails" target="_blank">This Method API Doc</a>
     */
    @Operation(tags = { Tags.INDUCTION_PLANNING, Tags.ENG_ODIN }, // For multi-tagging
               description = "Updates the ODIN details.",
               responses = {
                   @ApiResponse(content = @Content(schema = @Schema(implementation = OdinDTO.class),
                                                   mediaType = MediaType.APPLICATION_JSON_VALUE),
                                responseCode = OK),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = BAD_REQUEST,
                                description = Descriptions.BAD_REQUEST),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = UNAUTHORIZED,
                                description = Descriptions.UNAUTHORIZED),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = NOT_FOUND,
                                description = Descriptions.NOT_FOUND),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = INTERNAL_SERVER_ERROR,
                                description = Descriptions.INTERNAL_SERVER_ERROR)
               })
    @PostMapping(produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE"})
    public ResponseEntity<OdinDTO> saveEngineOdinDetails(@AuthenticationPrincipal
                                                         UserProfile userProfile,
                                                         @Valid
                                                         @RequestBody
                                                         OdinDTO odinRequestDTO){
    	OdinDTO odinReplyDTO = engineOdinSvc.saveEngineOdinDetails(odinRequestDTO, userProfile);
    	return new ResponseEntity<OdinDTO>(odinReplyDTO, HttpStatus.OK);
    }     
}
