package com.pw.dome.event;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.pw.dome.util.TimeUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ApplicationStarted implements ApplicationListener<ApplicationStartedEvent> {
	/**
	 * @see createBuildInfo task in build-tasks.gradle file.
	 */
	@Autowired
	private BuildProperties buildProperties;

	@Override
	public void onApplicationEvent(final ApplicationStartedEvent event) {
	    final String separator = StringUtils.repeat("-", 80);
		final StringBuilder buffy = new StringBuilder("\nApplicationStartedEvent\n");
		buffy.append(separator).append("\n");

		sort(buildProperties).entrySet()
		                     .iterator()
		                     .forEachRemaining(e->buffy.append(StringUtils.rightPad(e.getKey(), 24)).append(": \"").append(getValue(e)).append("\"\n"));

		buffy.append(separator);
		log.info(buffy.toString());
	}

	private String getValue(final Map.Entry<String, String> e) {
	    String key = e.getKey();
	    String value = e.getValue();

	    if ("time".equals(key)) {
	        try {
	            Instant i = Instant.ofEpochMilli(Long.parseLong(value));
	            value = TimeUtils.toLocalDateTime(i).format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
	        } catch (Exception ignore) {
	            ;
	        }
	    }

	    return value;
	}

	private Map<String, String> sort(final BuildProperties properties) {
	    TreeMap<String, String> treeMap = new TreeMap<>();
	    properties.iterator().forEachRemaining(e->treeMap.put(e.getKey(), e.getValue()));
	    return treeMap;
	}
}