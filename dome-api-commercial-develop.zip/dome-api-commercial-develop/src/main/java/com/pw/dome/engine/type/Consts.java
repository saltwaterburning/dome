package com.pw.dome.engine.type;

interface Consts {

	interface SQL {
		String GET_ENGINE_TYPE_BY_ENGINE_GROUP =
"""
SELECT e
FROM EngineTypeEntity e,
     EngineGroupEntity eg
WHERE e.active = true
  AND e.engineTypeID = eg.engineTypeID
  AND eg.active = true
  AND eg.engineGroupID = :engGroupId
ORDER BY e.name
		""";

		String GET_ENGINE_TYPE_BY_ENGINE_TYPE_ID =
"""
SELECT e
FROM EngineTypeEntity e,
     EngineGroupEntity eg
WHERE e.active = true
  AND e.engineTypeID = eg.engineTypeID
  AND eg.active = true
  AND e.engineTypeID = :engineTypeId
ORDER BY e.name
		""";

	}

}
