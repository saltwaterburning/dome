package com.pw.dome.mml.induction;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.pw.dome.mml.PlanMarket;
import com.pw.dome.mml.PlanType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InductionAnnualPlan {
    private String category;
    private String engCenterId;
    private String engCenterName;
    private String engGroupId;
    private String engGroupName;

    private List<InductionAnnualPlanEntity> monthlyPlan;

    @JsonIgnore
    private int planCounter;
    @JsonIgnore
    private Integer planId;
    @JsonIgnore
    private PlanMarket planMarket;
    @JsonIgnore
    private int planMonth;
    @JsonIgnore
    private PlanType planType;
    @JsonIgnore
    private int planYear;
    private String salesOrderType;
}
