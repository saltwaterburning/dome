package com.pw.dome.external.mro;

import static java.util.Objects.nonNull;

import java.util.Collection;
import java.util.Comparator;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validator;

import org.apache.commons.lang3.Validate;

public class ValidationUtil {

	public static ConstraintViolationException invokeValidator(Boolean throwException, Validator validator, Object entity) {
		ConstraintViolationException exception = null;
		Objects.requireNonNull(entity);
		if (entity instanceof Collection<?>) {
			Validate.notEmpty((Collection<?>)entity);
			Validate.noNullElements((Collection<?>)entity);
		}

		Set<ConstraintViolation<Object>> constraintViolations = validator.validate(entity);
		if (!constraintViolations.isEmpty()) {
			exception = new ConstraintViolationException(constraintViolations);
		}

		if (throwException && nonNull(exception)) {
			throw exception;
		}

		return exception;
	}

	public static String toOrderedString(ConstraintViolationException ex) {
		Comparator<? super ConstraintViolation<?>> comparator = new Comparator<ConstraintViolation<?>>() {

			@Override
			public int compare(ConstraintViolation<?> o1, ConstraintViolation<?> o2) {
				return o1.getPropertyPath().toString().compareTo(o2.getPropertyPath().toString());
			}
		};

		TreeSet<ConstraintViolation<?>> orderedSet = new TreeSet<>(comparator);
		orderedSet.addAll(ex.getConstraintViolations());

		return orderedSet.stream()
				.map( cv -> cv == null ? "null" : cv.getPropertyPath() + ": " + cv.getMessage() )
				.collect( Collectors.joining( ", " ) );
	}

	public static ConstraintViolationException invokeValidator(Validator validator, Object entity) {
		return invokeValidator(false, validator, entity);
	}

	public static void validate(Validator validator, Object entity) {
		invokeValidator(true, validator, entity);
	}
}
