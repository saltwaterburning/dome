package com.pw.dome.enginecenter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import org.springframework.data.domain.Persistable;
import org.springframework.lang.Nullable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "DOME_SECURITY_ENGINE_CENTER")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SecurityEngineCenterEntity implements Persistable<Long> {

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEC_SEQ")
    @SequenceGenerator(sequenceName = "SEC_SEQ", allocationSize = 1, name = "SEC_SEQ")
	@Column(name = "SEC_ID")
	private Long id;

	@Column(name = "LOG_EMAIL")
	private String emailAddress;

	@Column(name = "EC_ID")
	private String engineCenterId;

	@Column(name = "ENG_TYPE_ID")
	private String engineTypeId;

	@Column(name = "ENG_GROUP_ID")
	private String engineGroupId;

	@Override
	public boolean isNew() {
		return id == null ;
	}

	@Nullable
	@Override
	public Long getId() {
		return id;
	}
}
