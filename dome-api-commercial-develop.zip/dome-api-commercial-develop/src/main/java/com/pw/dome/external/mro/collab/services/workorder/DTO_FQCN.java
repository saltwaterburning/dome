package com.pw.dome.external.mro.collab.services.workorder;

interface DTO_FQCN {
	/**
	 * Handles need for annotation constant expression.
	 * Used by test case to validate that DTO remains consistent with JPQL expression.
	 */
	String DTO_NAME = "com.pw.dome.external.mro.collab.services.workorder.SlottedShopCodesDTO";
}
