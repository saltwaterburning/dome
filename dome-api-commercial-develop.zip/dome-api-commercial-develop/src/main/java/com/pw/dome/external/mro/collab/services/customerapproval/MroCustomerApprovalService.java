package com.pw.dome.external.mro.collab.services.customerapproval;

import static java.util.Objects.nonNull;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pw.dome.engine.odin.OdinEntity;
import com.pw.dome.exception.ConflictException;
import com.pw.dome.exception.NotFoundException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
class MroCustomerApprovalService {
	@Autowired
	private MroOdinRepository repo;

	public void updateCustomerApprovalDate(@Valid
			           MroCustomerApprovalRequest request) {
		Optional<OdinEntity> option = repo.findOdin(request.getEsn(),
				                                       request.getEventId(),
				                                       request.getMroShopCode(),
				                                       request.getMroWorkOrder());

		if (option.isPresent()) {
			LocalDate date;
			OdinEntity odin = option.get();
			if (nonNull(date = odin.getCustomerApprovalDate())) {
				log.info("Customer approval date is already set. Date: {}, Request: {}", date.toString(), request);
				String msg = String.format("Customer approval date is already set.");
				throw new ConflictException(msg);
			}

			LocalDateTime dateTime = request.getCustomerApprovalDateTime();
			odin.setCustomerApprovalDate(dateTime.toLocalDate());
			repo.save(odin);
		} else {
			log.error("Unable to find matching ODIN record. Request: {}", request);
			throw new NotFoundException("Unable to find matching ODIN record.");
		}
	}
}
