package com.pw.dome.admin;

import static com.pw.dome.admin.ProfileStatus.UNKNOWN;
import static java.util.Objects.isNull;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import lombok.extern.slf4j.Slf4j;

@Converter(autoApply = true)
@Slf4j
public final class ProfileStatusConverter implements AttributeConverter<ProfileStatus, String> {

	@Override
	public String convertToDatabaseColumn(ProfileStatus attribute) {
		if (isNull(attribute)) {
			log.error("Saving ProfileStatus of null to DB.");
		} else if (UNKNOWN == attribute) {
			log.error("Saving ProfileStatus of UNKNOWN to DB.");
		}

		return isNull(attribute) ? null : attribute.name();
	}

	@Override
	public ProfileStatus convertToEntityAttribute(String dbData) {
		ProfileStatus profileStatus = ProfileStatus.of(dbData);
		if (isNull(profileStatus)) {
			log.error("Unknown user status code: {}", dbData);
		}

		return isNull(profileStatus) ? ProfileStatus.UNKNOWN : profileStatus;
	}
}
