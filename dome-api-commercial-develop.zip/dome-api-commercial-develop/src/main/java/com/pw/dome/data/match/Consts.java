package com.pw.dome.data.match;

/**
 * Package private constants.
 */
interface Consts {
	/** DB column size. */
	int NOTIFY_NUMBER_COLUMN_SIZE = 12;
	/** DB column size. */
	int SALES_ORDER_NO_COLUMN_SIZE = 10;
	/** Regex used to capture the alias names. */
	String ALIAS_REGEX = "(?i)\\s+AS\\s+(\\w+)";

	interface SQL {
		/** Base get SQL statement. */
	/*	String GET =
		"SELECT" +
		"    ea.cust_name            AS engineOperator," +
		"    ea.notify_number        AS notifyNum," +
		"    ea.eng_activity         AS engActivity," +
		"    ea.eng_act_seq_number   AS engActivitySequenceNum," +
		"    ea.eng_activ_completed  AS engActivityDate," +
		"    ea.sales_doc_number     AS salesOrderNum," +
		"    ec.ec_name              AS engineCenterName," +
		"    eng.eng_id              AS engineIdSeq," +
		"    eng.eng_sn              AS engineSN," +
		"    engmodel.eng_mod_name   AS engineModel" +
		" FROM" +
		"    estore_activity     ea," +
		"    dome_engine_center  ec," +
		"    dome_engine         eng," +
		"    dome_eng_mod_mst    engmodel" +
		" WHERE" +
		"    eng.eng_model = engmodel.eng_mod_id" +
		"    AND ea.eng_activ_completed != '00000000'" +
		// Andy Stewart : APU required to use longer ESN. Match on last 6.
		"    AND (( substr(rtrim(ea.eng_sn, ' '), - 6, 6) = eng.eng_sn )" +
		// Andy Stewart : If Estore ESN is null, try to match on Sales Doc 2-7
		"          OR (( substr(rtrim(ea.eng_sn, ' '), - 6, 6) is null )" +
		"               AND ( substr(ea.sales_doc_number, 2, 6)) = eng.eng_sn ))" +
		// Less than 366 days.
		"    AND ( local_date - ( to_date(ea.eng_activ_completed, 'yyyymmdd')) < (" +
		"        SELECT" +
		"            short_field" +
		"        FROM" +
		"            pwebis.eibs_misc" +
		"        WHERE" +
		"            key_field = 'AUTOM'" +
		"            AND value_field = 'EstoreActivityLookBack'" +
		"    ))" +
		"    AND ea.notify_number NOT IN (" +
		"        SELECT" +
		"            eng1.notify_number" +
		"        FROM" +
		"            pwebis.dome_engine eng1" +
		"        WHERE" +
		"            eng1.notify_number = ea.notify_number" +
		"    )";
		*/
String GET =
		"SELECT distinct" +
		"    ea.cust_name            AS engineOperator," +
		"    ea.notify_number        AS notifyNum," +
		//"    ea.eng_activity         AS engActivity," +
		//"    ea.eng_act_seq_number   AS engActivitySequenceNum," +
		//"    ea.eng_activ_completed  AS engActivityDate," +
		"    ea.sales_doc_number     AS salesOrderNum," +
		"    ec.ec_name              AS engineCenterName," +
		"    ec.ec_id              AS engineCenterId," +		
		"    eng.eng_id              AS engineIdSeq," +
		"    eng.eng_sn              AS engineSN," +
		"    engmodel.eng_mod_name   AS engineModel, " +
		"    eng.eng_group           AS engineGroupId, " +
		"    cust.cust_name          AS customerName," +
		"    et.engtrack_rec_date   AS engineReceiveDate, " +
		"    et.engtrack_ind_date   AS engineInductDate, " +
		"    et.engtrack_ship_date   AS engineShipDate, " +
		"    slot.sp_date            AS slotDate " +
		" FROM" +
		"    estore_activity     ea," +
		"    dome_engine_center  ec," +
		"    dome_engine         eng," +
		"    dome_eng_mod_mst    engmodel," +
		"    dome_engine_tracking   et," + 
		"    dome_customer          cust, "+
		"   dome_slotting          slot "+
		" WHERE" +
		"    eng.eng_model = engmodel.eng_mod_id" +
		"    AND eng.eng_id = et.engtrack_id (+) " +
		"    AND eng.eng_cust_id = cust.cust_id "+
		//"    AND eng.eng_centre = ec.ec_id " +
		"    AND eng.slot_id = slot.slot_id "+
		"    AND slot.sp_ec_id = ec.ec_id "+
		//"    AND ea.eng_activ_completed != '00000000'" +
	    "     And (   (RTRIM(ea.ENG_ACTIVITY, ' ')   	    = 	'RECEIVED' And ea.eng_activ_completed != '00000000') "+
	    "	    Or   (RTRIM(ea.ENG_ACTIVITY, ' ')       = 	'INDUCTED' And ea.eng_activ_completed != '00000000')) "+
		// Andy Stewart : APU required to use longer ESN. Match on last 6.
		"    AND (( substr(rtrim(ea.eng_sn, ' '), - 6, 6) = eng.eng_sn )" +
		// Andy Stewart : If Estore ESN is null, try to match on Sales Doc 2-7
		"          OR (( substr(rtrim(ea.eng_sn, ' '), - 6, 6) is null )" +
		"               AND ( substr(ea.sales_doc_number, 2, 6)) = eng.eng_sn ))" +
		// Less than 366 days.
		"    AND ( local_date - ( to_date(ea.eng_activ_completed, 'yyyymmdd')) < (" +
		"        SELECT" +
		"            short_field" +
		"        FROM" +
		"            pwebis.eibs_misc" +
		"        WHERE" +
		"            key_field = 'AUTOM'" +
		"            AND value_field = 'EstoreActivityLookBack' ))"+
		"     AND ec.ec_plant_code(+)  = ea.plant "  ;
	/*	"    AND ea.notify_number NOT IN (" +
		"        SELECT" +
		"            eng1.notify_number" +
		"        FROM" +
		"            pwebis.dome_engine eng1" +
		"        WHERE" +
		"            eng1.notify_number = ea.notify_number" +
		"    )";*/	//commented this section because once matched, it wont show up otherwise, if this condition is removed, they can be shown again in matched list.	

		/** The sorting SQL clause. */
		String ORDER_BY =
		" ORDER BY" +
		"    ea.notify_number" ;
		//"    eng_act_seq_number";

		/** EngineSN SQL clause. */
		String WHERE_ESN =
		"    AND eng.eng_sn = :engineSN";

		/** The engineCenterId and engineTypeId SQL clause. */
		String WHERE_IDS =
		"    AND ec.ec_id = :engineCenterId";
	//	"    AND eng.eng_group =:engineGroupId ";

		/** The engine matched SQL clause. */
		String WHERE_MATCHED =
		"    AND eng.notify_number is not null" +
		"    AND eng.sales_order_no is not null"+
	    "    AND eng.sales_order_no != ea.sales_doc_number";

		/** The engine unmatched SQL clause. */
		String WHERE_UNMATCHED =
		"    AND eng.notify_number is null" +
		"    AND eng.sales_order_no is null";
	}
}
