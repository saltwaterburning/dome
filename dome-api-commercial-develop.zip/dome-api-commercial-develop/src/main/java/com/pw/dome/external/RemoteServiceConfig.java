package com.pw.dome.external;

public interface RemoteServiceConfig {
	Boolean getAsynchronous();
	String getBaseUrl();
	Boolean getEnabled();
	String getJsonWebToken();
	Integer getResponseTimeoutSecs();
	Integer getRetryMaxAttempts();
	Integer getRetryMinBackoffSecs();
	Integer getWebClientThreadCap();
}
