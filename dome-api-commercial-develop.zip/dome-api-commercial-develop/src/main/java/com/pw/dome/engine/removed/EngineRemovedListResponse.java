 /**
 * 
 */
package com.pw.dome.engine.removed;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class EngineRemovedListResponse {
	private List<EngineRemovedDTO> engines;
}

