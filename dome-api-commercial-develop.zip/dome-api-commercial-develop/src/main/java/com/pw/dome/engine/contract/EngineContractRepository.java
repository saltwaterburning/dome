/**
 * 
 */
package com.pw.dome.engine.contract;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EngineContractRepository extends JpaRepository<EngineContractEntity, String >			 
{
	List<EngineContractEntity> findByEsnIgnoreCase(final String esn);
}
