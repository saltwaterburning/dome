package com.pw.dome.mml;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;

final class DataUtils {

    static List<MmlDetails> toMmlDetails(final List<MmlEntity> mmlEntities) {
        return mmlEntities.stream().map(mmlEntity -> MmlDetails.builder()
                                     .engineId(mmlEntity.getEngineId())
                                     .engineCenterName(mmlEntity.getEngineCenterName())
                                     .engineGroupId(mmlEntity.getEngineGroupId())
                                     .engineGroupName(mmlEntity.getEngineGroupName())
                                     .engineCategory(mmlEntity.getEngineCategory())
                                     .engineSerialNumber(mmlEntity.getEngineSerialNumber())
                                     .customerName(mmlEntity.getCustomerName())
                                     .month(mmlEntity.getMonth())
                                     .planInductionDate(mmlEntity.getPlanInductionDate())
                                     .actualReceipentDate(mmlEntity.getActualReceipentDate())
                                     .build()).collect(Collectors.toList());
     
    }
 
    static MmlMonthlyEntity toMmlMonthlyEntity(MmlUpdateRequest mmlUpdateRequest) {
        
        return MmlMonthlyEntity.builder()
             .planMarket(mmlUpdateRequest.getPlanMarket())
             .planMonth(mmlUpdateRequest.getMonth())
             .planType(mmlUpdateRequest.getPlanType())
             .planYear(mmlUpdateRequest.getYear())
             .build(); 
     }
    
    static List<MmlMonthlyEntity> toMmlMonthlyEntitiesToAdd(MmlUpdateRequest mmlUpdateRequest, List<MmlEntity> existingEntities) {
        
        Set<Integer> existingEngineIds = existingEntities.stream().map(MmlEntity :: getEngineId).collect(Collectors.toSet());
        
        List<Integer> updatedEngineIds = mmlUpdateRequest.getMmlDetails().stream().map(mml -> mml.getEngineId()).collect(Collectors.toList());
        
        List<Integer> engineIdsToAdd = updatedEngineIds.stream().filter(e -> !existingEngineIds.contains(e)).collect(Collectors.toList());
        
        return engineIdsToAdd.stream().map(engineId -> MmlMonthlyEntity.builder()
                                                                .planMarket(mmlUpdateRequest.getPlanMarket())
                                                                .planMonth(mmlUpdateRequest.getMonth())
                                                                .planType(mmlUpdateRequest.getPlanType())
                                                                .planYear(mmlUpdateRequest.getYear())
                                                                .engineId(engineId)
                                                                .build())
                                                                .collect(Collectors.toList());
        
     }
    
    static List<Integer> toMmlEntitiesToDelete(MmlUpdateRequest mmlUpdateRequest, List<MmlEntity> existingEntities) {
        
        Set<Integer> existingEngineIds = existingEntities.stream().map(MmlEntity :: getEngineId).collect(Collectors.toSet());
        
        List<Integer> updatedEngineIds = mmlUpdateRequest.getMmlDetails().stream().map(mml -> mml.getEngineId()).collect(Collectors.toList());
        
        List<Integer> engineIdsToDelete = existingEngineIds.stream().filter(e -> !updatedEngineIds.contains(e)).collect(Collectors.toList());
        
        return engineIdsToDelete;
     }

    static List<MmlQuarterlyEntity> toMmlQuarterlyEntitiesToAdd(MmlUpdateRequest mmlUpdateRequest, List<MmlEntity> existingEntities) {
        
        Set<Integer> existingEngineIds = existingEntities.stream().map(MmlEntity :: getEngineId).collect(Collectors.toSet());
        
        List<Integer> updatedEngineIds = mmlUpdateRequest.getMmlDetails().stream().map(mml -> mml.getEngineId()).collect(Collectors.toList());
        
        List<Integer> engineIdsToAdd = updatedEngineIds.stream().filter(e -> !existingEngineIds.contains(e)).collect(Collectors.toList());
        
        return engineIdsToAdd.stream().map(engineId -> MmlQuarterlyEntity.builder()
                                                                .planMarket(mmlUpdateRequest.getPlanMarket())
                                                                .month(mmlUpdateRequest.getMonth())
                                                                .planType(mmlUpdateRequest.getPlanType())
                                                                .planYear(mmlUpdateRequest.getYear())
                                                                .engineId(engineId)
                                                                .build())
                                                                .collect(Collectors.toList());
        
     }
    
    
    static MmlQuarterlyEntity toMmlQuarterlyEntity(MmlUpdateRequest mmlUpdateRequest) {
        return MmlQuarterlyEntity.builder()
             .planMarket(mmlUpdateRequest.getPlanMarket())
             .month(mmlUpdateRequest.getMonth())
             .planType(mmlUpdateRequest.getPlanType())
             .planYear(mmlUpdateRequest.getYear())
             .build();
     }
    
}
