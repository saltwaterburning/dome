package com.pw.dome.engine.networkmanagement.excel;

import static com.pw.dome.report.excel.ReportConstants.CLASSIFICATION;
import static com.pw.dome.report.excel.ReportConstants.DISCLAIMER;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.io.FileUtils.ONE_MB;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pw.dome.customer.CustomerRepository;
import com.pw.dome.customer.CustomerRepository.CustomerEsn;
import com.pw.dome.engine.EngineRepository;
import com.pw.dome.engine.EngineRepository.EngineInfo;
import com.pw.dome.engine.events.EngineEventEntity;
import com.pw.dome.engine.events.EngineEventRepository;
import com.pw.dome.engine.networkmanagement.excel.NetWorkManagementRequest.NetWorkManagementRequestBuilder;
import com.pw.dome.user.UserProfile;
import com.pw.dome.util.QueryHelper;
import com.pw.dome.util.excel.CellValues;
import com.pw.dome.util.excel.ExcelSheet;
import com.pw.dome.util.excel.ExcelWorkbook;
import com.pw.dome.wip.reports.tracking.TrackingUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
class NetworkManagementExcelService {

	private static final boolean DEBUG = false;

	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private EngineEventRepository eventRepo;
	@Autowired
	private EngineRepository engineRepo;
	@Autowired
	private NetworkManagementRepository networkManagementRepo;
	@Autowired
	private QueryHelper queryHelper;

	public ByteArrayInputStream getNetworkManagementData(UserProfile userProfile, NetWorkManagementRequest request)
			throws IOException {
		boolean ignoreContractType = QueryHelper.isAllOrAny(request.contractTypes());
		boolean ignoreCustId = QueryHelper.isAllOrAny(request.customers());

		NetWorkManagementRequestBuilder b = request.toBuilder();
		List<String> engTypes = queryHelper.getUserEngineTypes(request.engineTypes());
		b.engineTypes(engTypes);
		List<String> engCenters = queryHelper.getUserEngineCenters(request.engineCenters());
		b.engineCenters(engCenters);
		request = b.build();

		List<NetworkManagement> networkManagementData = networkManagementRepo.getNetworkManagementData(
				request.engineCenters(), request.engineTypes(), ignoreCustId, request.customers(), ignoreContractType,
				request.contractTypes());

		// Causing multiple customers and eventId
//		correctEngineEvents(networkManagementData);
//		correctOperatorInfo(networkManagementData);

		List<NetworkManagement> removedNetworkManagementData = networkManagementRepo
				.getRemovedNetworkManagementData(request.engineTypes());
		correctOperatorInfo(removedNetworkManagementData);

		final ExcelWorkbook workbook = new ExcelWorkbook(true);
		workbook.getSheets().stream().forEach(s -> s.withAutoSizedColumns());
		final ExcelSheet classification = workbook.getUniqueExcelSheet(CLASSIFICATION);
		classification.withCells(TrackingUtil.getRedTextStyle(), CellValues.builder().add(DISCLAIMER).build());

		final ExcelSheet sheet = workbook.getExcelSheet("Network Management Data").withFreezePane(4, 1);

		sheet.withCells(NetworkManagmentUtils.getNetworkDataReportHeaders());

		int size = networkManagementData.size() + removedNetworkManagementData.size();
		List<NetworkManagement> allNetworkManagementData = new ArrayList<>(size);
		allNetworkManagementData.addAll(networkManagementData);
		allNetworkManagementData.addAll(removedNetworkManagementData);
		allNetworkManagementData.sort(Comparator
				.comparing(NetworkManagement::getEsn, Comparator.nullsFirst(Comparator.naturalOrder()))
				.thenComparing(NetworkManagement::getEventId, Comparator.nullsFirst(Comparator.naturalOrder())));

		for (NetworkManagement data : allNetworkManagementData) {
			sheet.withNextRow().withCells(NetworkManagmentUtils.getData(data));
		}

		sheet.withAutoSizedColumns();

		return writeWorkbook(workbook, "Network Management Data");

	}

	// 1. Save ESN if eventId is null & save NetworkManagement to engId map.
	// 2. Get all engId, esn, eventId from engines order by 2, 1;
	// 3. Get all esn, eventId from events order by 1, 2 to list;
	// Matching index of 2 into 3.
	private void correctEngineEvents(List<NetworkManagement> networkManagementData) {
		Map<Integer, NetworkManagement> engIdToRowMap = new HashMap<>();
		Set<String> uniqueEsns = new TreeSet<>();

		for (int i = 0; i < networkManagementData.size(); ++i) {
			NetworkManagement row = networkManagementData.get(i);
			if (isNull(row.getEventId())) {
				Integer engId = row.getEngineId();
				engIdToRowMap.put(engId, row);
				String esn = row.getEsn();
				uniqueEsns.add(esn);
			}
		}

		if (!uniqueEsns.isEmpty()) {
			Set<String> updatedEsns = new TreeSet<>();
			List<EngineInfo> engines = engineRepo.getEnginesByEsnIn(new ArrayList<String>(uniqueEsns));
			Map<String, List<EngineInfo>> groupedEngines = engines.stream()
					.collect(Collectors.groupingBy(s -> s.getEsn(), LinkedHashMap::new,
							toSortedList((o1, o2) -> o1.getEngineId().compareTo(o2.getEngineId()))));
			List<EngineEventEntity> events = eventRepo.findByPkEsnInOrderByPkEsn(new ArrayList<String>(uniqueEsns));
			Map<String, List<EngineEventEntity>> groupedEvents = events.stream()
					.collect(Collectors.groupingBy(s -> s.getPk().getEsn(), LinkedHashMap::new,
							toSortedList((o1, o2) -> o1.getPk().getEventId().compareTo(o2.getPk().getEventId()))));

			if (log.isDebugEnabled()) {
				for (List<EngineInfo> engine : groupedEngines.values()) {
					int row = 0;
					for (EngineInfo info : engine) {
						log.debug("EngId={}, ESN={}, EventId={}, row={}",
								info.getEngineId(), info.getEsn(), info.getEventId(), ++row);
					}
				}
				for (List<EngineEventEntity> event : groupedEvents.values()) {
					int row = 0;
					for (EngineEventEntity info : event) {
						log.debug("ESN={}, EventId={}, row={}",
								info.getPk().getEsn(), info.getPk().getEventId(), ++row);
					}
				}
			}

			for (String esn : uniqueEsns) {
				List<EngineInfo> enginesForEsn = groupedEngines.get(esn);
				List<EngineEventEntity> eventsForEsn = groupedEvents.get(esn);
				if (nonNull(enginesForEsn) && nonNull(eventsForEsn)
						&& Objects.equals(enginesForEsn.size(), eventsForEsn.size())) {

					for (int i = 0; i < enginesForEsn.size(); ++i) {
						EngineInfo engine = enginesForEsn.get(i);
						Integer engId = engine.getEngineId();
						EngineEventEntity event = eventsForEsn.get(i);
						NetworkManagement row = engIdToRowMap.get(engId);
						if (nonNull(row) && isNull(row.getEventId()) && nonNull(event)) {
							Integer eventId = event.getPk().getEventId();
							log.debug("Updating EngineId {}, ESN {} with eventId {}", row.getEngineId(), row.getEsn(),
									eventId);
							row.setEventId(eventId);
							updatedEsns.add(row.getEsn());
						}
					}
				}
			}

			log.debug("ESNs To Update:{} ESNs: {}", uniqueEsns.size(), uniqueEsns);
			log.debug("Updated Events: {} ESNs: {}", updatedEsns.size(), updatedEsns);
		}
	}

	// Add rowNum.
	// 1. find all missing cutomer/operator (sname) and save ESns + save list index.
	// 2. Get all operator code for ESN.
	// 3. Update operator info.
	private void correctOperatorInfo(List<NetworkManagement> removedNetworkManagementData) {
		Map<String, List<Integer>> esnToRowMap = new HashMap<>();
		Set<String> uniqueEsns = new TreeSet<>();

		for (int i = 0; i < removedNetworkManagementData.size(); ++i) {
			NetworkManagement row = removedNetworkManagementData.get(i);
			if (isNull(row.getCustomerName()) || isNull(row.getOperator())) {
				String esn = row.getEsn();
				uniqueEsns.add(esn);

				List<Integer> list;
				if ((list = esnToRowMap.get(esn)) != null) {
					list.add(i);
				} else {
					list = new ArrayList<Integer>();
					list.add(i);
					esnToRowMap.put(esn, list);
				}
			}
		}

		if (!uniqueEsns.isEmpty()) {
			Set<String> updatedEsns = new TreeSet<>();
			ArrayList<String> allEsns = new ArrayList<String>(uniqueEsns);
			ArrayList<String> allEsns1 = new ArrayList<String>();
			ArrayList<String> allEsns2 = new ArrayList<String>();
			if (uniqueEsns.size() > 1000) { // TODO- make tuple
				allEsns1.addAll(allEsns.subList(0, 999));
				allEsns2.addAll(allEsns.subList(1000, allEsns.size() - 1));
			} else {
				allEsns1.addAll(allEsns);
			}

			List<CustomerEsn> customers = customerRepo.findByEsnIn(allEsns1, allEsns2);
			for (CustomerEsn customer : customers) {
				String esn = customer.getEsn();
				List<Integer> indexes = esnToRowMap.get(esn);
				if (Objects.nonNull(indexes)) {
					for (Integer i : indexes) {
						NetworkManagement row = removedNetworkManagementData.get(i);
						log.debug("Updating EngineId {}, ESN {} with customer {}", row.getEngineId(), row.getEsn(),
								customer.getName());
						row.setCustomerName(customer.getName());
						row.setOperator(customer.getShortName());
						updatedEsns.add(row.getEsn());
					}
				}
			}

			log.debug("ESNs To Update: {} ESNs: {}", uniqueEsns.size(), uniqueEsns);
			log.debug("Updated Operators: {} ESNs: {}", updatedEsns.size(), updatedEsns);
		}
	}

	<T> Collector<T, ?, List<T>> toSortedList(Comparator<? super T> c) {
		return Collectors.collectingAndThen(Collectors.toCollection(ArrayList::new), l -> {
			l.sort(c);
			return l;
		});
	}

	/**
	 * Returns the Excel workbook as a {@code ByteArrayInputStream}. Optionally
	 * writes the workbook into local PDF and XLSX files for debugging.
	 * 
	 * @param workbook Excel spreadsheet
	 * @param baseName used as the local filename
	 * @return the Excel workbook as a {@code ByteArrayInputStream}
	 * @throws IOException upon an error
	 */
	private ByteArrayInputStream writeWorkbook(ExcelWorkbook workbook, String baseName) throws IOException {
		ByteArrayInputStream inputByteArray;

		if (DEBUG) {
			try {
				String pathName = "/tmp/" + baseName;
				workbook.saveAsXlsx(pathName + ".xlsx");
			} catch (IOException cause) {
				throw new RuntimeException(cause);
			}
		}

		try (ByteArrayOutputStream outputByteArray = new ByteArrayOutputStream((int) ONE_MB)) {
			workbook.saveAsXlsx(outputByteArray);
			inputByteArray = new ByteArrayInputStream(outputByteArray.toByteArray());
		}

		return inputByteArray;
	}
}
