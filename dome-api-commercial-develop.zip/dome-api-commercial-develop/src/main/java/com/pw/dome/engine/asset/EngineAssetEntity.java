/**
 * @author John De Lello
 */
package com.pw.dome.engine.asset;

import static org.hibernate.annotations.NotFoundAction.IGNORE;

import java.io.Serializable;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import org.hibernate.annotations.NaturalId;
import org.hibernate.annotations.NotFound;

import com.pw.dome.customer.CustomerEntity;
import com.pw.dome.jpa.AbstractEntityWithNaturalId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "DOME_ENGINE_ASSETS")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EngineAssetEntity extends AbstractEntityWithNaturalId<Integer> implements Serializable {
	private static final long serialVersionUID = 81929262016895691L;

	@Id
	@NaturalId
    @Column(name = "ENGINE_ASSET_ID")
    private Integer engineAssetID;

    @Column(name = "ASSET_ID")
    private int assetID;

    @Column(name = "CONTRACT_TYPE")
    private String contractType;

 // Moved to EngineEntity
//    @Column(name = "CSN")
//    private Integer csn;

 // Moved to EngineEntity
//    @Column(name = "CSO")
//    private Integer cso;

    @Column(name = "ISDISABLED")
    private boolean disabled;

    @Column(name = "ENG_GROUP_ID")
    private String engineGroupID;

    @Column(name = "ENGINE_GROUP")
    private String engineGroupName;

    @Column(name = "ENG_MOD_ID")
    private String engineModelID;

    @Column(name = "ENGINE_MODEL")
    private String engineModelName;

    @Column(name = "ENG_TYPE_ID")
    private String engineTypeID;

    @Column(name = "ENGINE_TYPE")
    private String engineTypeName;

    @Column(name = "ESN", insertable = false, updatable = false)
    private String esn;

    @Column(name = "INSTALL_DATE")
    private LocalDate installDate;

    @Column(name = "ISINSTALLED")
    private boolean installed;

// Now on DOME_ENGINE_EVENTS table.
// See EngineEventEntity
    @Column(name = "EVENT_ID")
    private Integer eventId;

// Moved to EngineEntity
//    @Column(name = "LLPCYCREMAIN")
//    private Integer llpCycRemain;

    @OneToOne
	@NotFound(action = IGNORE)
    @JoinColumn(name = "OPER_ID", insertable = false, updatable = false)
    private CustomerEntity operator;

    @Column(name = "OPER_ID")
    private String operatorID;

    @Column(name = "OPERATOR_CODE")
    private String operatorShortName;

    @Column(name = "OWNER_ID")
    private String ownerID;

    @Column(name = "OWNER_CODE")
    private String ownerName;
    
    @Column(name = "PWEL_MANAGED")
    private boolean pwelManaged;

    @Column(name = "ISPLANNED")
    private boolean planned;

    @Column(name = "REMOVAL_DATE")
    private LocalDate removalDate;

    @Column(name = "ISREMOVED")
    private boolean removed;

    @Column(name = "SLOT_ID")
    private Integer slotId;

    @Column(name = "THRUST")
    private String thrust;

	@Override
	public Integer getId() {
		return engineAssetID;
	}

// Moved to EngineEntity
//    @Column(name = "TSN")
//    private Integer tsn;

 // Moved to EngineEntity
//    @Column(name = "TSO")
//    private Integer tso;
}
