package com.pw.dome.mml;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Enumeration of plan types.
 * This enum has annotations to direct JSON processing
 * and a nested class to handle JPA conversions.
 * 
 * @see PlanTypeJpaConverter
 */
// This enum could of been implemented without using an associated
// value by using ordinal offsets. This approach adheres to KISS principal!
public enum PlanType {
    INDUCTION(0),
    SHIPMENT(1),
    REVENUE(2);

    private final int value;
    /**
     * Instantiate enum with corresponding value.
     * @param value corresponding DB value
     */
    private PlanType(int value) {
        this.value = value;
    }

    /**
     * Returns the plan type integer value.
     * @return the plan type integer value
     * 
     * @see JsonValue
     */
    // JsonValue annotation indicates how to marshall this enum instance into a JSON String for client requests.
    // The name() will otherwise be used by default for marshalling.
    @JsonValue
    public int getValue() {
        return value;
    }

    /**
     * Creates a {@code PlanType} instance from an integer value.
     * No validation is performed. A null is returned if the value is not in range.
     * Use {@code jakarta.validation.constraints.NotNull} annotation on DTOs for client request validation.
     * 
     * @param value PlanType integer
     * @return a {@code PlanType} instance
     * 
     * @see JsonCreator
     */
    // JsonCreator annotation indicates how to unmarshall a JSON String into this enum instance for client requests.
    // Otherwise PlanType.values()[value] be used by default for unmarshalling.
    // Use jakarta.validation.constraints.NotNull annotation on DTOs for client request validation.
    @JsonCreator
    public static PlanType of(int value) {
        switch (value) {
        case 0:
            return INDUCTION;
        case 1:
            return SHIPMENT;
        case 2:
            return REVENUE;
        default:
            return null;
        }
    }

    @Component
    public static class PlanTypeConverter implements Converter<String, PlanType> {

        @Override
        public PlanType convert(String value) {
            return PlanType.of(Integer.valueOf(value));
        }
    }
}
