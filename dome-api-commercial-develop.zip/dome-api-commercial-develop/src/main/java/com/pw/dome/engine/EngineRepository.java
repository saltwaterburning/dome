package com.pw.dome.engine;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * @author John De Lello
 */
@Repository
public interface EngineRepository extends JpaRepository<EngineEntity, Integer> {
	public static interface EngineInfo {
		String getEsn();
		Integer getEngineId();
		Integer getEventId();
	}

	EngineEntity findByEngineIDAndEventIdNotNull(final Integer engineId);

	@Query("select id from #{#entityName}")
	List<Integer> getAllIds();

	@Query(value = "SELECT e FROM EngineEntity e LEFT JOIN FETCH e.customer CustomerEntity LEFT JOIN FETCH e.module ModuleEntity LEFT JOIN FETCH e.slot SlotEntity LEFT JOIN FETCH SlotEntity.engineType EngineTypeEntity WHERE SlotEntity.engineCenterID = ?1 AND SlotEntity.month =?2 AND SlotEntity.year =?3")
	List<EngineEntity> findByEngineCenterIdAndMonthAndYear(String engineCenterID, int month, int year);

	int countBySlotID(final Integer slotID);

	List<EngineEntity> getEnginesBySlotID(Integer slotID);

	@Modifying
	@Query(value = "UPDATE dome_engine set notify_number = ?2, sales_order_no = ?3 where eng_id = ?1 AND notify_number is null AND sales_order_no is null", nativeQuery = true)
	int setMatched(Integer engId, String notifyNumber, String salesOrderNum);

	@Query(value = "SELECT e FROM EngineEntity e WHERE e.assetID = ?1 AND UPPER(e.esn) = ?2")
	EngineEntity getEngine(final Integer assetID, final String esn);

	@Query(value = "SELECT e FROM EngineEntity e WHERE UPPER(e.esn) = ?1 AND e.eventId = ?2 order by e.engineID")
//	@Query(value = "SELECT e FROM EngineEntity e, EngineTrackingEntity t WHERE UPPER(e.esn) = ?1 AND e.eventId = ?2 AND t.engtrackShipmentDate is null ORDER by e.engineID")
	List<EngineEntity> getEngineByEsnAndEventId(final String esn, final Integer eventId);

	@Query(value = "SELECT e.engineID as engineId, e.esn as esn, e.eventId as eventId FROM EngineEntity e WHERE esn in (?1) order by esn")
	List<EngineInfo> getEnginesByEsnIn(List<String> esns);

	@Modifying
	@Query(value = "UPDATE dome_engine set notify_number = NULL, sales_order_no = NULL where eng_id = ?1 AND notify_number is not null AND sales_order_no is not null", nativeQuery = true)
	int setUnmatched(Integer engId);

	@Query(value = "SELECT e FROM EngineEntity e WHERE e.esn = ?1 and e.engineTrackingEntity.engtrackWorkOrder = ?2")
	EngineEntity getEngineByEsnAndWorkOrder(String esn, String engtrackWorkOrder);

}
