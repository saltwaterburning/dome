package com.pw.dome.engine;


import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class EngineAssetResponse {
	private int assetID;
	private int engineAssetID;
	private String esn;
	
	private LocalDate removalDate;
	private String status;
	private String thrust;
	private Integer visitType;
	
	private String engineModelID;
	private String engineModelName;
	private String engineTypeID;
	private String engineTypeName;
	private String engineGroupID;
	private String engineGroupName;
	private String operatorID;
	private String operatorName;
	private String operatorShortName;
}
