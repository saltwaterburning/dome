package com.pw.dome.mml;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Builder
class MmlRequest {

    @NotBlank(message = "{NotBlank.required}")
    @Pattern(message = "{Pattern.required}", regexp = "monthly|quarterly")
    private String period;
    
    @NotNull(message = "{NotNull.required}")
    private Integer year;
    
    @NotNull(message = "{NotNull.required}")
    @Max(value = 12, message = "month cannot be greater than 12")
    private Integer month;
    
    @NotNull(message = "{NotNull.required}")
    private String engineCenterId;
    
    @NotNull(message = "{NotNull.required}")
    private String engineGroupId;

    @NotNull(message = "{NotNull.required}")
    private PlanMarket planMarket;
    
    @NotNull(message = "{NotNull.required}")
    private PlanType planType;
}
