package com.pw.dome.admin;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;

/**
 * Defines system security roles. There are three types of roles: security, additional
 * and service account. Additional and service account roles are indicated by the 
 * {@code additionalRole} boolean and {@code serviceAccountRole} boolean respectively.
 */
@Getter
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum SecurityRoles {
    /**
     * Administrator security role.
     */
    ADMINISTRATOR("Administrator", "Administrative access."),

    /**
     * Read only security role.
     */
    READ("Read", "Read only access."),
    /**
     * Read and Write security role.
     */
    READ_WRITE("ReadWrite", "Read and Write access."),
    /**
     * Network Management additional role.
     */
    NETWORK_MANAGEMENT("NETMANAGEMENT", "Network Management", true),
    /**
     * Resident Center Manager additional role.
     */
    RESIDENT_CENTER_MANAGER("RCM", "Resident Center Manager", true),
    /**
     * MRO Collab API access role.
     */
    MROCOLLAB("MROCOLLAB", "MRO API access.", false, true),
    /**
     * Workscope Tool access role.
     */
    WORKSCOPE("WORKSCOPE", "WST API access.", false, true);

    @JsonIgnore
    private final boolean additionalRole;
    private final String roleId;
    private final String roleDescription;
    @JsonIgnore
    private final boolean serviceAccountRole;

    private SecurityRoles(String roleId, String roleDescription) {
        this.roleId = roleId;
        this.roleDescription = roleDescription;
        this.additionalRole = false;
        this.serviceAccountRole = false;
    }

    private SecurityRoles(String roleId, String roleDescription, boolean additionalRole) {
        this.roleId = roleId;
        this.roleDescription = roleDescription;
        this.additionalRole = additionalRole;
        this.serviceAccountRole = false;
    }
    

    private SecurityRoles(String roleId, String roleDescription, boolean additionalRole, boolean serviceAccountRole) {
        this.roleId = roleId;
        this.roleDescription = roleDescription;
        this.additionalRole = additionalRole;
        this.serviceAccountRole = serviceAccountRole;
    }

    /**
     * Returns the security roles with {@code additionalRole} of {@code true}.
     * 
     * @return the security roles with {@code additionalRole} of {@code true}
     */
    public static List<SecurityRoles> getAdditionalSecurityRoles() {
        return Stream.of(values())
            .filter((s) -> s.additionalRole)
            .collect(Collectors.toList());
    }
    
    /**
     * Returns the security roles with {@code serviceAccountRole} of {@code true}.
     * 
     * @return the security roles with {@code serviceAccountRole} of {@code true}
     */
    public static List<SecurityRoles> getServiceAccountRoles() {
        return Stream.of(values())
            .filter((s) -> s.serviceAccountRole)
            .collect(Collectors.toList());
    }

    /**
     * Returns the security roles with {@code additionalRole} of {@code false} and {@code serviceAccountRole} of {@code false} 
     * 
     * @return the security roles with {@code additionalRole} of {@code false} and {@code serviceAccountRole} of {@code false}
     */
    public static List<SecurityRoles> getSecurityRoles() {
        return Stream.of(values())
            .filter((s) -> !s.additionalRole && !s.serviceAccountRole)
            .collect(Collectors.toList());
    }

    /**
     * {}
     */
    public String roleId() {
    	return roleId.toUpperCase();
    }

    /**
     * Returns the enum matching the supplied name ignoring case.
     * 
     * @param enumName the enum name
     * @return the enum matching the supplied name ignoring case
     */
    public static SecurityRoles valueOfIgnoreCase(String enumName) {
        return Enum.valueOf(SecurityRoles.class,
                            enumName.toUpperCase());
    }

    /**
     * Returns the enum matching the supplied roleId ignoring case.
     * 
     * @param roleId the security role identifier
     * @return the enum matching the supplied roleId ignoring case
     */
    @JsonCreator
    public static SecurityRoles valueOfRoleCodeIgnoreCase(
        @JsonProperty("roleId")
        String roleId) {
        return Stream.of(SecurityRoles.values())
            .filter(e -> e.roleId.equalsIgnoreCase(roleId))
            .findFirst()
            .orElseThrow(() -> new IllegalArgumentException(String.format("Unsupported roleCode: %s.",
                                                                          roleId)));
    }
}
