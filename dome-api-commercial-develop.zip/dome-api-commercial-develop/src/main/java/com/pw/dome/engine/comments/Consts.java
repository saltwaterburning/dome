package com.pw.dome.engine.comments;

interface Consts {

	interface SQL {
		String GET_MRO_COMMENTS =
		"SELECT c "
		+ "FROM CommentEntity c,"
		+ "     EngineEntity e,"
		+ "     EngineTrackingEntity et "
		+ "WHERE c.engineId = e.engineID"
		+ "  AND c.engineId = et.engtrackId"
		+ "  AND e.eventId is not null"
		+ "  AND et.mroShopCode is not null"
		+ "  AND et.engtrackWorkOrder is not null";
	}
}
