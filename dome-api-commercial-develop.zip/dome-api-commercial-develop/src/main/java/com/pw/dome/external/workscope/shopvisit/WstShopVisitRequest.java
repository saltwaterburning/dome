package com.pw.dome.external.workscope.shopvisit;

import java.time.LocalDate;

import jakarta.annotation.Nullable;
import jakarta.validation.constraints.NotBlank;

import lombok.Builder;


@Builder(toBuilder = true)
public record WstShopVisitRequest(
		@NotBlank
		String esn,
		@NotBlank
		String operator,
		@NotBlank
		String provider,
//		@NotBlank
		String svClassification,
		@Nullable
		Integer eventId,
		@Nullable
		String smiNumber,
		@Nullable
		LocalDate actualAssetCompleteDate,
		@Nullable
		LocalDate actualCoreAssemblyDate,
		@Nullable
		LocalDate actualGate1CloseDate,
		@Nullable
		LocalDate actualGate3CloseDate,
		@Nullable
		LocalDate actualGate3CompleteDate,
		@Nullable
		LocalDate actualGate3StartDate,
		@Nullable
		LocalDate actualInductDate,
		@Nullable
		LocalDate actualKitCompleteDate,
		@Nullable
		LocalDate actualReceiptDate,
		@Nullable
		LocalDate actualReceiveDate,
		@Nullable
		LocalDate actualRemovalDate,
		@Nullable
		LocalDate actualShipDate,
		@Nullable
		LocalDate actualShipToCustDate,
		@Nullable
		LocalDate actualTestCompleteDate,
		@Nullable
		LocalDate actualTestStartDate,
		@Nullable
		LocalDate contractDate,
		@Nullable
		LocalDate externalAssetCompleteDate,
		@Nullable
		LocalDate externalContractDate,
		@Nullable
		LocalDate externalCoreAssemblyDate,
		@Nullable
		LocalDate externalGate1CloseDate,
		@Nullable
		LocalDate externalGate3CloseDate,
		@Nullable
		LocalDate externalGate3StartDate,
		@Nullable
		LocalDate externalInductDate,
		@Nullable
		LocalDate externalKitCompleteDate,
		@Nullable
		LocalDate externalReceiptDate,
		@Nullable
		LocalDate externalReceiveDate,
		@Nullable
		LocalDate externalShipDate,
		@Nullable
		LocalDate externalShipToCustDate,
		@Nullable
		LocalDate externalTestCompleteDate,
		@Nullable
		LocalDate externalTestStartDate,
		@Nullable
		LocalDate planAssetCompleteDate,
		@Nullable
		LocalDate planCoreAssemblyDate,
		@Nullable
		LocalDate planGate1CloseDate,
		@Nullable
		LocalDate planGate3CloseDate,
		@Nullable
		LocalDate planGate3StartDate,
		@Nullable
		LocalDate planInductDate,
		@Nullable
		LocalDate planKitCompleteDate,
		@Nullable
		LocalDate planReceiptDate,
		@Nullable
		LocalDate planReceiveDate,
		@Nullable
		LocalDate planRemovalDate,
		@Nullable
		LocalDate planShipDate,
		@Nullable
		LocalDate planShipToCustDate,
		@Nullable
		LocalDate planTestCompleteDate,
		@Nullable
		LocalDate planTestStartDate) {

}
