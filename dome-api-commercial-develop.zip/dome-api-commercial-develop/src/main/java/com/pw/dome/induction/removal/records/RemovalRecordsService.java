package com.pw.dome.induction.removal.records;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
class RemovalRecordsService {
	@Autowired
	private RemovalRecordsRepository rrRepo;

	@Transactional(readOnly = true)
	public RemovalRecordsResponse findRemovalRecords(RemovalRecordsRequest request) {
		List<RemovalRecordsEntity> list = rrRepo.findByEsnAndEventIdOrderByEventIdAscRemovalIdAsc(request.esn(), request.eventId());
		
		List<RemovalRecordsDTO> removalRecords = DataMapper.INSTANCE.toDTO(list);

		return new RemovalRecordsResponse(removalRecords);
	}
}
