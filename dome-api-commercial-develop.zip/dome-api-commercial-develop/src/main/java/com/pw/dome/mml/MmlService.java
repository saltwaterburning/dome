package com.pw.dome.mml;

import static java.time.temporal.IsoFields.QUARTER_OF_YEAR;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.text.CaseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.activity.ActivityEntity;
import com.pw.dome.activity.ActivityService;
import com.pw.dome.exception.NotFoundException;
import com.pw.dome.util.QueryHelper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
class MmlService {

    @Autowired
    private ActivityService activityService;
    @Autowired
    private MmlMonthlyRepository mmlMonthlyRepository;
    @Autowired
    private MmlQuarterlyRepository mmlQuarterlyRepository;
    @Autowired
    private QueryHelper qryHelper;

    /**
     * Get MML Details
     * @param mmlPlanRequest
     * @return MMLResponse
     */
    @Transactional(readOnly = true)
    public MmlResponse getMmlInfo(final MmlRequest mmlRequest) {
        
        log.debug("Invoking DB to get mml details");
        final String ecid = mmlRequest.getEngineCenterId();
        List<String> engGroups = qryHelper.getUserEngineGroups(Arrays.asList(mmlRequest.getEngineGroupId()));
        
        List<MmlEntity> mmlEntities = getMmlEntities(mmlRequest.getPlanType(), mmlRequest.getPlanMarket(), mmlRequest.getPeriod(), mmlRequest.getMonth(), mmlRequest.getYear(), ecid, engGroups);
        List<MmlDetails> mmlDetailsList = DataUtils.toMmlDetails(mmlEntities);
       
        log.debug("DB returned {} Mml detail records", mmlDetailsList.size());
        
        return MmlResponse.builder().mmlDetails(mmlDetailsList).build();
    }
    
    private List<MmlEntity> getMmlEntities(final PlanType planType, final PlanMarket planMarket, final String period, final Integer monthQtr, final Integer year, final String ecid, final List<String> engineGroups){
        
        return isMonthly(period) ? getMmlMonthlyEntities(planType, planMarket, monthQtr, year, ecid, engineGroups) : getMmlQuarterlyEntities(planType, planMarket, monthQtr, year, ecid, engineGroups);
        
    }
    
    private List<MmlEntity> getMmlMonthlyEntities(final PlanType planType, final PlanMarket planMarket, final Integer month, final Integer year, final String ecid, final List<String> engineGroups){
        if(planType.equals(PlanType.INDUCTION)) {
        	return mmlMonthlyRepository.getMmlMonthlyInductionData(month, year, ecid, engineGroups, planType, planMarket);
        }else if(planType.equals(PlanType.REVENUE)){
        	return mmlMonthlyRepository.getMmlMonthlyRevenueData(month, year, ecid, engineGroups, planType, planMarket);
        }else{
        	return mmlMonthlyRepository.getMmlMonthlyShipmentData(month, year, ecid, engineGroups, planType, planMarket);
        }
    }
    
    private List<MmlEntity> getMmlQuarterlyEntities(final PlanType planType, final PlanMarket planMarket, final Integer quarter, final Integer year, final String ecid, final List<String> engineGroups){
    	if(planType.equals(PlanType.INDUCTION)) {
    		return mmlQuarterlyRepository.getMmlQuarterlyInductionData(quarter, year, ecid, engineGroups, planType, planMarket);
    	}else if(planType.equals(PlanType.REVENUE)){
    		return mmlQuarterlyRepository.getMmlQuarterlyRevenueData(quarter, year, ecid, engineGroups, planType, planMarket);
    	}else {
    		return mmlQuarterlyRepository.getMmlQuarterlyShipmentData(quarter, year, ecid, engineGroups, planType, planMarket);
    	}
    }
    
    /**
     * Get MML Plan Details
     * @param mmlPlanRequest
     * @return MMLResponse
     */
    @Transactional(readOnly = true)
    public MmlResponse getMmlPlanInfo(final MmlPlanRequest mmlPlanRequest) {
        
        final String engineCenterId = mmlPlanRequest.getEngineCenterId();
        List<String> engGroups = qryHelper.getUserEngineGroups(Arrays.asList(mmlPlanRequest.getEngineGroupId()));
        final PlanType planType = mmlPlanRequest.getPlanType();
        final PlanMarket planMarket = mmlPlanRequest.getPlanMarket();
        final String period = mmlPlanRequest.getPeriod();
        final Integer month =  mmlPlanRequest.getMonth();
        final Integer year =  mmlPlanRequest.getYear();
       
        log.debug("Invoking DB to get {} mml plan details", period);
        
        List<MmlEntity> mmlEntities = getMmlPlanEntities(engineCenterId, engGroups, planType, planMarket, period, month, year);
        
        if (mmlEntities.isEmpty()) {
            throw new NotFoundException("No mml plan data found in the database");
        }
        
        List<MmlDetails> mmlDetailsList = DataUtils.toMmlDetails(mmlEntities);
        log.debug("DB returned {} Mml plan detail records", mmlDetailsList.size());
        
        return MmlResponse.builder().mmlPlanDetails(mmlDetailsList).build();
    }
    
    private List<MmlEntity> getMmlPlanEntities(final String engineCenterId, final List<String> engineGroups, final PlanType planType, final PlanMarket planMarket, final String period, final Integer monthQtr, final Integer year){
        
        return isMonthly(period) ? getMmlMonthlyPlanEntities(engineCenterId, engineGroups, planType, planMarket, monthQtr, year) : getMmlQuarterlyPlanEntities(engineCenterId, engineGroups, planType, planMarket, monthQtr, year);

    }
    
    private List<MmlEntity> getMmlMonthlyPlanEntities(final String engineCenterId, final List<String> engineGroups, final PlanType planType, final PlanMarket planMarket, final Integer month, final Integer year){
        if (planType.equals(PlanType.INDUCTION)){
        	return mmlMonthlyRepository.getMmlMonthlyPlanInductionData(engineCenterId, engineGroups, planType, planMarket, year);
        }else if(planType.equals(PlanType.REVENUE)){
        	return mmlMonthlyRepository.getMmlMonthlyPlanRevenueData(engineCenterId, engineGroups, planType, planMarket, year);
        }else {
        	return mmlMonthlyRepository.getMmlMonthlyPlanShipmentData(engineCenterId, engineGroups, planType, planMarket, year);
        }
    }
    
    private List<MmlEntity> getMmlQuarterlyPlanEntities(final String engineCenterId, final List<String> engineGroups, final PlanType planType, final PlanMarket planMarket, final Integer month, final Integer year) {
        if (planType.equals(PlanType.INDUCTION)) {
            return mmlQuarterlyRepository.getMmlQuarterlyPlanInductionData(engineCenterId, engineGroups, planType, planMarket, month, year);
       } if (planType.equals(PlanType.REVENUE)) {
           return mmlQuarterlyRepository.getMmlQuarterlyPlanRevenueData(engineCenterId, engineGroups, planType, planMarket, month, year);
      } else {
           return mmlQuarterlyRepository.getMmlQuarterlyPlanShipmentData(engineCenterId, engineGroups, planType, planMarket, month, year);
       }
    }

    /**
     * Update MMl Details
     * @param mmlUpdateRequest
     */
    @Transactional(readOnly = false)
    public void update(final MmlUpdateRequest mmlUpdateRequest, boolean copyToMonthly) {
        final String ecid = mmlUpdateRequest.getEngineCenterId();
        List<String> engGroups = qryHelper.getUserEngineGroups(Arrays.asList(mmlUpdateRequest.getEngineGroupId()));
        List<MmlEntity> existingMmlEntities = getMmlEntities(mmlUpdateRequest.getPlanType(), mmlUpdateRequest.getPlanMarket(), mmlUpdateRequest.getPeriod(), mmlUpdateRequest.getMonth(), mmlUpdateRequest.getYear(), ecid, engGroups);
        
        if(isMonthly(mmlUpdateRequest.getPeriod()))
        {
            addMmlMonthly(mmlUpdateRequest, existingMmlEntities);
            deleteMmlMonthly(mmlUpdateRequest, existingMmlEntities);
        } else {
        	if(copyToMonthly) {
                existingMmlEntities = getMmlEntities(mmlUpdateRequest.getPlanType(), mmlUpdateRequest.getPlanMarket(), "monthly", mmlUpdateRequest.getMonth(), mmlUpdateRequest.getYear(), ecid, engGroups);
                addMmlMonthly(mmlUpdateRequest, existingMmlEntities);
	            deleteMmlMonthly(mmlUpdateRequest, existingMmlEntities);
        	}
            addMmlQuarterly(mmlUpdateRequest, existingMmlEntities);
            deleteMmlQuarterly(mmlUpdateRequest, existingMmlEntities);
        }
        
    }

	private void deleteMmlQuarterly(final MmlUpdateRequest mmlUpdateRequest, List<MmlEntity> existingMmlEntities) {
		List<Integer> mmlEngineIdsToDelete = DataUtils.toMmlEntitiesToDelete(mmlUpdateRequest, existingMmlEntities);
		if(!CollectionUtils.isEmpty(mmlEngineIdsToDelete)) {
		    log.debug("Deleting data to MmlQuarterlyEntity table");
		    final int deletedRecords = mmlQuarterlyRepository.deleteByEngineIds(mmlUpdateRequest.getPlanMarket(), mmlUpdateRequest.getPlanType(), mmlEngineIdsToDelete);
		    log.debug("Deleted {} records from MmlQuarterlyEntity table : ", deletedRecords);
		    for(Integer engineId : mmlEngineIdsToDelete) {
		    	saveActivity(com.pw.dome.activity.DataUtils.toActivityEntityDeleteQuarterlyMml(mmlUpdateRequest, existingMmlEntities, engineId));
		    }
		}
	}

	private void addMmlQuarterly(final MmlUpdateRequest mmlUpdateRequest, List<MmlEntity> existingMmlEntities) {
		List<MmlQuarterlyEntity> mmlNewEntities = DataUtils.toMmlQuarterlyEntitiesToAdd(mmlUpdateRequest, existingMmlEntities);
		if(!CollectionUtils.isEmpty(mmlNewEntities)) {
		    log.debug("Saving data to MmlQuarterlyEntity table");
		    mmlQuarterlyRepository.saveAll(mmlNewEntities);
		    for(MmlQuarterlyEntity mml : mmlNewEntities) {
		    	saveActivity(com.pw.dome.activity.DataUtils.toActivityEntitySaveQuarterlylyMml(mmlUpdateRequest, mml));
		    }
		}
	}

	private void deleteMmlMonthly(final MmlUpdateRequest mmlUpdateRequest, List<MmlEntity> existingMmlEntities) {
		List<Integer> mmlEngineIdsToDelete = DataUtils.toMmlEntitiesToDelete(mmlUpdateRequest, existingMmlEntities);
		if(!CollectionUtils.isEmpty(mmlEngineIdsToDelete)) {
		    log.debug("Deleting data to MmlMonthlyEntity table");
		    final int deletedRecords = mmlMonthlyRepository.deleteByEngineIds(mmlUpdateRequest.getPlanMarket(), mmlUpdateRequest.getPlanType(), mmlEngineIdsToDelete);
		    log.debug("Deleted {} records from MmlMonthlyEntity table : ", deletedRecords);
		    for(Integer engineId : mmlEngineIdsToDelete) {
		    	saveActivity(com.pw.dome.activity.DataUtils.toActivityEntityDeleteMonthlyMml(mmlUpdateRequest, existingMmlEntities, engineId));
		    }
		}
	}

	private void addMmlMonthly(final MmlUpdateRequest mmlUpdateRequest, List<MmlEntity> existingMmlEntities) {
		List<MmlMonthlyEntity> mmlNewEntities = DataUtils.toMmlMonthlyEntitiesToAdd(mmlUpdateRequest, existingMmlEntities);
		if(!CollectionUtils.isEmpty(mmlNewEntities)) {
		    log.debug("Saving data to MmlMonthlyEntity table");
		    mmlMonthlyRepository.saveAll(mmlNewEntities);
		    for(MmlMonthlyEntity mml : mmlNewEntities) {
		    	saveActivity(com.pw.dome.activity.DataUtils.toActivityEntitySaveMonthlyMml(mmlUpdateRequest, mml));
		    }
		}
	}
    
    /**
     * Add MMl Details
     * @param mmlUpdateRequest
     * @return MmlResponse
     */
    @Transactional(readOnly = false)
    public MmlResponse save(final MmlUpdateRequest mmlUpdateRequest) {
        
        if(isMonthly(mmlUpdateRequest.getPeriod()))
        {
            MmlMonthlyEntity mmlNewEntity = DataUtils.toMmlMonthlyEntity(mmlUpdateRequest);
            log.debug("Saving EngineId : {} to MmlMonthlyEntity table : ", mmlNewEntity.getEngineId());
            mmlMonthlyRepository.save(mmlNewEntity);
        }else {
            MmlQuarterlyEntity mmlNewEntity = DataUtils.toMmlQuarterlyEntity(mmlUpdateRequest);
            log.debug("Saving EngineId : {} to MmlQuarterlyEntity table : ", mmlNewEntity.getEngineId());
            mmlQuarterlyRepository.save(mmlNewEntity);
        }
        
        return getMmlResponse(mmlUpdateRequest);
        
    }
    
    /**
     * Remove MML Details
     * @param mmlUpdateRequest
     * @return MmlResponse
     */
    @Transactional(readOnly = false)
    public MmlResponse remove(final MmlUpdateRequest mmlUpdateRequest) {
        
        if(isMonthly(mmlUpdateRequest.getPeriod())) {
            MmlMonthlyEntity mmlNewEntity = DataUtils.toMmlMonthlyEntity(mmlUpdateRequest);
            log.debug("Removing EngineId : {} to MmlMonthlyEntity table : ", mmlNewEntity.getEngineId());
            final int deletedRecords = mmlMonthlyRepository.deleteByEngineId(mmlNewEntity.getEngineId());
            log.debug("Deleted {} records from MmlMonthlyEntity table : ", deletedRecords);
        }else {
            MmlQuarterlyEntity mmlNewEntity = DataUtils.toMmlQuarterlyEntity(mmlUpdateRequest);
            log.debug("Removing EngineId : {} to MmlQuarterlyEntity table : ", mmlNewEntity.getEngineId());
            final int deletedRecords = mmlQuarterlyRepository.deleteByEngineId(mmlNewEntity.getEngineId());
            log.debug("Deleted {} records from MmlQuarterlyEntity table : ", deletedRecords);
        }
        
        return getMmlResponse(mmlUpdateRequest);
    }
    
    /**
     * Retrieve MML Response when a record is added or removed
     * @param mmlUpdateRequest
     * @return MmlResponse
     */
    private MmlResponse getMmlResponse(MmlUpdateRequest mmlUpdateRequest) {
        final String engineCenterId = mmlUpdateRequest.getEngineCenterId();
        List<String> engineGroups = qryHelper.getUserEngineGroups(Arrays.asList(mmlUpdateRequest.getEngineGroupId()));
        final PlanType planType = mmlUpdateRequest.getPlanType();
        final PlanMarket planMarket = mmlUpdateRequest.getPlanMarket();
        final String period = mmlUpdateRequest.getPeriod();
        final Integer month =  mmlUpdateRequest.getMonth();
        final Integer year =  mmlUpdateRequest.getYear();
        
        log.debug("Retrieve MML data");
        List<MmlEntity> mmlEntities = getMmlEntities(planType, planMarket, period, month, year, engineCenterId, engineGroups);
        List<MmlDetails> mmlDetailsList = DataUtils.toMmlDetails(mmlEntities);
        log.debug("DB returned {} Mml detail records", mmlDetailsList.size());
        
        log.debug("Retrieve MML Plan data");
        List<MmlEntity> mmlPlanEntities = getMmlPlanEntities(engineCenterId, engineGroups, planType, planMarket, period, month, year);
        List<MmlDetails> mmlPlanDetailsList = DataUtils.toMmlDetails(mmlPlanEntities);
        log.debug("DB returned {} Mml plan detail records", mmlPlanDetailsList.size());
        
        return MmlResponse.builder().mmlDetails(mmlDetailsList).mmlPlanDetails(mmlPlanDetailsList).build();
    }
    
    /**
     * Get months from last 14 months in past to 14 months in future
     * @return list of MonthlyDatesResponse
     */
    public List<MonthlyDatesResponse> getMonthlyDates() {
        return getMonthlyDates(false);
    }

    List<MonthlyDatesResponse> getMonthlyDates(boolean quarterBoundry) {
        List<MonthlyDatesResponse> months = new ArrayList<>();
        final LocalDate now = LocalDate.now();
        LocalDate start = LocalDate.of(now.getYear(), now.getMonth(), 1).minusMonths(14);
        LocalDate end = LocalDate.of(now.getYear(), now.getMonth(), 1).plusMonths(14);
        
        if (quarterBoundry) { // Ensure months fall at beginning/end of a quarter.
            int qtr = start.get(QUARTER_OF_YEAR);
            LocalDate newDate = start;
            for (int monthsToSubtract = 1; newDate.minusMonths(monthsToSubtract).get(QUARTER_OF_YEAR) == qtr; ++monthsToSubtract) {
                start = newDate.minusMonths(monthsToSubtract);
            }
            qtr = end.get(QUARTER_OF_YEAR);
            newDate = end;
            for (int monthsToAdd = 1; newDate.plusMonths(monthsToAdd).get(QUARTER_OF_YEAR) == qtr; ++monthsToAdd) {
                end = newDate.plusMonths(monthsToAdd);
            }
        }

        for (LocalDate date = start; date.isBefore(end) || date.isEqual(end); date = date.plusMonths(1)) {
            String monthName = CaseUtils.toCamelCase(date.getMonth().name(), true);
            MonthlyDatesResponse response = MonthlyDatesResponse.builder()
                                                                .month(date.getMonthValue())
                                                                .year(date.getYear())
                                                                .monthName(monthName).build();
            months.add(response);
        }
        
        return months;
    }

    public List<QuarterlyDatesResponse> getQuarterlyDates() {
        List<QuarterlyDatesResponse> quaters = new ArrayList<>();
        List<MonthlyDatesResponse> months = getMonthlyDates(true);
        int currentQtr = -1;
        QuarterlyDatesResponse quarter = null;
        for (MonthlyDatesResponse month : months) {
            LocalDate dt = LocalDate.of(month.getYear(), month.getMonth(), 1);
            int qtrOfMonth = dt.get(QUARTER_OF_YEAR);
            if (currentQtr != qtrOfMonth) {
                currentQtr = qtrOfMonth;
                String quarterName = "Q" + currentQtr;
                quarter = QuarterlyDatesResponse.builder()
                                                .months(new ArrayList<>())
                                                .quarter(currentQtr)
                                                .quarterName(quarterName)
                                                .year(month.getYear()).build();
                quaters.add(quarter);
            }

            quarter.getMonths().add(month);
        }
        
        return quaters;
    }

    /**
     * Check if the request is monthly or quarterly
     * @param period
     * @return true for monthly
     */
    private boolean isMonthly(String period) {
        return period.equalsIgnoreCase("monthly");
    }
    
    private void saveActivity(ActivityEntity request) {
        try {
            log.debug("Saving data to acitivity table");
            activityService.saveActivity(request);
        }catch(Exception e) {
            //Swallow the exception so it won't cause any service failure
            log.error("Error occured while saving data to acitvity table. Exception : " + e);
        }
    }
}
