package com.pw.dome.engine.removed.notinducted.excel;

interface Consts {
	String AND_NOT_DISABLED = " AND cast(nvl(engineAsset.disabled, 0) as int) = 0 ";

	String CLASSIFICATION = "Classification";
	String DISCLAIMER = "This document does not contain any export regulated technical data.";
	
	interface SQL {
		String REMOVED_NOT_INDUCTED =
"""
SELECT cast(nvl(engineAsset.disabled, 0) as java.lang.Boolean) as disabled,
       engineAsset.engineTypeName as engineType,
       engineEvent.pk.esn as esn,
       engineEvent.pk.eventId as eventId,
       customer.name as customerName,
       customer.shortName as operator,
       ec.name as maintenanceCenter,
       CAST(NULL AS java.lang.Boolean) as unserviceable,
       engineEvent.removalDate as actualRemovalDate,
       engineEvent.removalDateRecorded as recordedRemovalDate,
       engineTrack.engtrackActualReceivingDate as receivedDate,
       engineTrack.engtrackPlanIndDate as planInductionDate,
       o.odinId AS odinId,
       o.comments AS comments,
       o.currentLocation AS currentLocation,
       o.investigationCategory AS investigationLevel,
       o.svClass AS svClass
FROM EngineEventEntity engineEvent
LEFT OUTER JOIN CustomerEntity customer ON engineEvent.operatorCode = customer.shortName
LEFT OUTER JOIN EngineEntity engine ON engineEvent.pk.esn = engine.esn
AND engineEvent.pk.eventId = engine.eventId
LEFT OUTER JOIN EngineAssetEntity engineAsset ON engineAsset.esn = engineEvent.pk.esn
LEFT OUTER JOIN EngineTrackingEntity engineTrack ON engine.engineID = engineTrack.engtrackId
LEFT OUTER JOIN OdinEntity o ON o.esn = engineAsset.esn
AND o.engineId = engine.engineID
LEFT OUTER JOIN EngineCenterEntity ec ON ec.id = o.maintenanceCenter
WHERE engineEvent.shipped = false
  AND engineTrack.engtrackIndDate is null
  AND (:ignoreCustId = true
       OR customer.customerID IN :custId)
  AND (:ignoreEngType = true
       OR engineAsset.engineTypeID IN :engType)
""" + AND_NOT_DISABLED +
"""
ORDER BY 3,
         4,
         1
""";
    }
}
