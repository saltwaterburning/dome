package com.pw.dome.external.workscope.services;

interface Consts {
	interface SQL {
		String GET_ODIN =
"""
SELECT e
FROM OdinEntity e
WHERE e.odinId =
    (SELECT o.odinId
     FROM EngineEntity e,
          EngineTrackingEntity t,
          OdinEntity o
     WHERE e.engineID = t.engtrackId
       AND e.esn = :esn
       AND e.eventId = :eventId
       AND o.engineId = e.engineID
       AND o.esn = e.esn
       AND o.eventId = e.eventId
       AND t.engtrackWorkOrder = :smiNumber)
""";
	}
}
