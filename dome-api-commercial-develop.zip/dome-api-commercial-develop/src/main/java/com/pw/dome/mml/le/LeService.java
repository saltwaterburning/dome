package com.pw.dome.mml.le;

import static com.pw.dome.mml.PlanType.INDUCTION;
import static com.pw.dome.mml.PlanType.REVENUE;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.activity.ActivityEntity;
import com.pw.dome.activity.ActivityService;
import com.pw.dome.exception.NotFoundException;
import com.pw.dome.mml.PlanMarket;
import com.pw.dome.mml.PlanType;
import com.pw.dome.util.QueryHelper;

import lombok.extern.slf4j.Slf4j;

/**
 * TODO Eliminate unneeded queries. Only LE monthly/quarterly and planned monthly/quarterly are needed.
 */
@Service
@Slf4j
class LeService {

    @Autowired
    private ActivityService activityService;
    @Autowired
    private LeMonthlyOpportunityRepository leOppMonthlyRepository;
    @Autowired
    private LeMonthlyRepository leMonthlyRepository;
    @Autowired
    private LeQuarterlyOpportunityRepository leOppQuarterlyRepository;
    @Autowired
    private LeQuarterlyRepository leQuarterlyRepository;
    @Autowired
    private QueryHelper qryHelper;
    
    /**
     * Get LE Details
     * 
     * @param lePlanRequest
     * @return LeResponse
     */
    @Transactional(readOnly = true)
    public LeResponse getLeInfo(final LeRequest leRequest) {
        final List<String> engineGroups = qryHelper.getUserEngineGroups(Arrays.asList(leRequest.getEngineGroupId()));

        List<DetailsDTO> leEntities = getLeEntities(leRequest.getLeType(), leRequest.getLeMarket(), leRequest.getPeriod(),
                leRequest.getMonth(), leRequest.getYear(), leRequest.getEngineCenterId(), engineGroups);

        return LeResponse.builder().leDetails(leEntities).build();
    }

    /**
     * Get LE Plan Details
     * 
     * @param lePlanRequest
     * @return LeResponse
     */
    @Transactional(readOnly = true)
    public LeResponse getLePlanInfo(final LePlanRequest lePlanRequest) {

        final String engineCenterId = lePlanRequest.getEngineCenterId();
        final List<String> engineGroups = qryHelper.getUserEngineGroups(Arrays.asList(lePlanRequest.getEngineGroupId()));
        final PlanType leType = lePlanRequest.getLeType();
        final PlanMarket leMarket = lePlanRequest.getLeMarket();
        final String period = lePlanRequest.getPeriod();
        final Integer monthQtr = lePlanRequest.getMonth();
        final Integer year = lePlanRequest.getYear();

        List<DetailsDTO> leEntities = getLePlanEntities(engineCenterId, engineGroups, leType, leMarket, period, monthQtr,
                year);

        if (leEntities.isEmpty()) {
            throw new NotFoundException(String.format("No LE plan data found in the database"));
        }

        return LeResponse.builder().lePlanDetails(leEntities).build();
    }

    @Transactional(readOnly = false)
    public void save(final LeUpdateRequest leUpdateRequest) {
        validateRequest(leUpdateRequest);
        updateRiskRecords(leUpdateRequest); // Left list in UI.
        updateOpportunityRecords(leUpdateRequest); // Right list in UI.
    }

    private List<DetailsDTO> getLeEntities(final PlanType leType, final PlanMarket leMarket, final String period,
            final Integer monthQtr, final Integer year, final String ecid, final List<String> engineGroups) {

        if (isMonthly(period)) {
            return getLeMonthlyEntities(leType, leMarket, monthQtr, year, ecid, engineGroups);
        } else {
            return getLeQuarterlyEntities(leType, leMarket, monthQtr, year, ecid, engineGroups);
        }

    }

    private List<DetailsDTO> getLeMonthlyEntities(final PlanType leType, final PlanMarket leMarket, final Integer month,
            final Integer year, final String ecid, final List<String> engineGroups) {
        if (leType.equals(INDUCTION)) {
            log.debug("{}.getLeMonthlyInductionData()", LeMonthlyRepository.class.getSimpleName());
            return leMonthlyRepository.getLeMonthlyInductionData(ecid, engineGroups, month, year, leMarket, leType);
        } else if(leType.equals(REVENUE)){
            log.debug("{}.getLeMonthlyRevenueData()", LeMonthlyRepository.class.getSimpleName());
            return leMonthlyRepository.getLeMonthlyRevenueData(ecid, engineGroups, month, year, leMarket, leType);
        }else {
            log.debug("{}.getLeMonthlyShipment()", LeMonthlyRepository.class.getSimpleName());
            return leMonthlyRepository.getLeMonthlyShipmentData(ecid, engineGroups, month, year, leMarket, leType);
        }
    }

    private List<DetailsDTO> getLeMonthlyPlanEntities(final String engineCenterId, final List<String> engineGroups,
            final PlanType leType, final PlanMarket leMarket, final Integer month, final Integer year) {
        if (leType.equals(INDUCTION)) {
            log.debug("{}.getLeMonthlyPlanInductionData", LeMonthlyRepository.class.getSimpleName());
            return leMonthlyRepository.getLeMonthlyPlanInductionData(engineCenterId, engineGroups, month, year,
                        leMarket, leType);
        } else if(leType.equals(REVENUE)){
            log.debug("{}.getLeMonthlyPlanRevenueData", LeMonthlyRepository.class.getSimpleName());
            return leMonthlyRepository.getLeMonthlyPlanRevenueData(engineCenterId, engineGroups, month,
                        year, leMarket, leType);
        } else {
            log.debug("{}.getLeMonthlyPlanShipmentData", LeMonthlyRepository.class.getSimpleName());
            return leMonthlyRepository.getLeMonthlyPlanShipmentData(engineCenterId, engineGroups, month,
                        year, leMarket, leType);
        }
    }

    private List<DetailsDTO> getLePlanEntities(final String engineCenterId, final List<String> engineGroups,
            final PlanType planType, final PlanMarket planMarket, final String period, final Integer monthQtr,
            final Integer year) {

        return isMonthly(period)
                ? getLeMonthlyPlanEntities(engineCenterId, engineGroups, planType, planMarket, monthQtr, year)
                : getLeQuarterlyPlanEntities(engineCenterId, engineGroups, planType, planMarket, monthQtr, year);

    }

    private List<DetailsDTO> getLeQuarterlyEntities(final PlanType leType, final PlanMarket leMarket,
            final Integer quarter, final Integer year, final String ecid, final List<String> engineGroups) {
        if (leType.equals(INDUCTION)) {
            log.debug("{}.getLeQuarterlyInductionData()", LeQuarterlyRepository.class.getSimpleName());
            return leQuarterlyRepository.getLeQuarterlyInductionData(ecid, engineGroups, quarter, year, leMarket, leType);
        } else if(leType.equals(REVENUE)){
            log.debug("{}.getLeQuarterlyRevenueData()", LeQuarterlyRepository.class.getSimpleName());
            return leQuarterlyRepository.getLeQuarterlyRevenueData(ecid, engineGroups, quarter, year, leMarket, leType);
        } else {
            log.debug("{}.getLeQuarterlyShipmentData()", LeQuarterlyRepository.class.getSimpleName());
            return leQuarterlyRepository.getLeQuarterlyShipmentData(ecid, engineGroups, quarter, year, leMarket, leType);
        }
    }

    private List<DetailsDTO> getLeQuarterlyPlanEntities(final String engineCenterId, final List<String> engineGroups,
            final PlanType leType, final PlanMarket planMarket, final Integer month, final Integer year) {
        if (leType.equals(INDUCTION)) {
            log.debug("{}.getLeQuarterlyPlanInductionData()", LeQuarterlyRepository.class.getSimpleName());
            return leQuarterlyRepository.getLeQuarterlyPlanInductionData(engineCenterId, engineGroups, month,
                        year, planMarket, leType);
        } else if(leType.equals(REVENUE)){
            log.debug("{}.getLeQuarterlyPlanRevenueData()", LeQuarterlyRepository.class.getSimpleName());
            return leQuarterlyRepository.getLeQuarterlyPlanRevenueData(engineCenterId, engineGroups, month,
                        year, planMarket, leType);
        } else {
            log.debug("{}.getLeQuarterlyPlanShipment()", LeQuarterlyRepository.class.getSimpleName());
            return leQuarterlyRepository.getLeQuarterlyPlanShipmentData(engineCenterId, engineGroups, month,
                        year, planMarket, leType);
        }
    }

    private boolean isMonthly(String period) {
        return period.equalsIgnoreCase("monthly");
    }

    /**
     * Save only Opportunity records which are true and delete all others.
     * @param request
     */
    private void updateOpportunityRecords(final LeUpdateRequest request) {
        boolean isMonthly = isMonthly(request.getPeriod());
        List<DetailsDTO> details = request.getLePlanDetails();

        if (CollectionUtils.isNotEmpty(details)) {
            // validateRequest checks for null Opportunity when OpportunityId is not null.
            // Delete Opportunity records previously saved as true.
            List<Integer> deleteIds = details.stream()
                                       .filter(d->d.getOpportunityId() != null && FALSE.equals(d.getOpportunity()))
                                       .map(d->d.getOpportunityId())
                                       .collect(Collectors.toList());
            if (!deleteIds.isEmpty()) {
                if (isMonthly) {
                    int cnt = leOppMonthlyRepository.deleteByIdIn(deleteIds);
                    log.debug("Deleted {} records from {}, IDs:{}", cnt, LeMonthlyOpportunityEntity.class.getSimpleName(), deleteIds);
                } else {
                    int cnt = leOppQuarterlyRepository.deleteByIdIn(deleteIds);
                    log.debug("Deleted {} records from {}, IDs:{}", cnt, LeQuarterlyOpportunityEntity.class.getSimpleName(), deleteIds);
                }
            }

            List<DetailsDTO> newDTOs =
                details.stream()
                       .filter(d->d.getOpportunityId() == null && TRUE.equals(d.getOpportunity()))
                       .collect(Collectors.toList());

            if (!newDTOs.isEmpty()) {
                if (isMonthly) {
                    List<LeMonthlyOpportunityEntity> list = DataUtils.toLeMonthlyOpportunityEntity(request, newDTOs);
                    leOppMonthlyRepository.saveAll(list);
                } else {
                    List<LeQuarterlyOpportunityEntity> list = DataUtils.toLeQuarterlyOpportunityEntity(request, newDTOs);
                    leOppQuarterlyRepository.saveAll(list);
                }
            }
        }
    }

    /**
     * Always save LE records (left side of UI).
     * Delete when LE records moved to planed list (right side of UI).
     * @param request
     */
    private void updateRiskRecords(final LeUpdateRequest request) {
        boolean isMonthly = isMonthly(request.getPeriod());
        List<DetailsDTO> leDetails = request.getLeDetails();
        List<DetailsDTO> lePlanDetails = request.getLePlanDetails();

        // Delete LE records which were moved to planned list.
        // validateRequest() checks for null risk when riskId is not null.
        List<Integer> ids = lePlanDetails.stream()
                                         .filter(dto->dto.getRiskId() != null)
                                         .map(dto->dto.getRiskId())
                                         .collect(Collectors.toList());

        if (CollectionUtils.isNotEmpty(ids)) {
            if (isMonthly) {
                int cnt = leMonthlyRepository.deleteByIdIn(ids);
                log.debug("Deleted {} records from {}, IDs:{}", cnt, LeMonthlyEntity.class.getSimpleName(), ids);
                for(Integer id : ids) {
                	saveActivity(com.pw.dome.activity.DataUtils.toActivityEntityDeleteMonthlyLe(request, lePlanDetails, id));
                }
            } else {
                int cnt = leQuarterlyRepository.deleteByIdIn(ids);
                log.debug("Deleted {} records from {}, IDs:{}", cnt, LeQuarterlyEntity.class.getSimpleName(), ids);
                for(Integer id : ids) {
                	saveActivity(com.pw.dome.activity.DataUtils.toActivityEntityDeleteQuarterlyLe(request, lePlanDetails, id));
                }
            }
        }

        // Save/Update all LE records...
        //   New record if DetailsDTO.riskId == null.
        //   Otherwise DetailsDTO.risk may have changed. 
        if (CollectionUtils.isNotEmpty(leDetails)) {
            if (isMonthly) {
                List<LeMonthlyEntity> list = DataUtils.toLeMonthlyEntity(request, leDetails);
                leMonthlyRepository.saveAll(list);
                for(DetailsDTO detail : leDetails) {
                	saveActivity(com.pw.dome.activity.DataUtils.toActivityEntitySaveMonthlyLe(request, detail));
                }
                
            } else {
                List<LeQuarterlyEntity> list = DataUtils.LeQuarterlyEntity(request, leDetails);
                leQuarterlyRepository.saveAll(list);
                for(DetailsDTO detail : leDetails) {
                	saveActivity(com.pw.dome.activity.DataUtils.toActivityEntitySaveQuarterlylyLe(request, detail));
                }
            }
        }
    }

    private void validateRequest(LeUpdateRequest request) {
        List<DetailsDTO> leDetails = request.getLeDetails();
        if (CollectionUtils.isNotEmpty(leDetails)) {
            leDetails.stream()
                     .forEach(dto->Validate.isTrue(dto.getOpportunityId() == null || (dto.getOpportunityId() != null && dto.getOpportunity() != null),
                                                   "Invalid request: opportunity is null. ESN: %s", dto.getEngineSerialNumber()));
        }

        List<DetailsDTO> lePlanDetails = request.getLePlanDetails();
        if (CollectionUtils.isNotEmpty(lePlanDetails)) {
            lePlanDetails.stream()
                         .forEach(dto->Validate.isTrue(dto.getRiskId() == null || (dto.getRiskId() != null && dto.getRisk() != null),
                                                       "Invalid request: risk is null. ESN: %s", dto.getEngineSerialNumber()));
        }
    }
    
    private void saveActivity(ActivityEntity request) {
        try {
            log.debug("Saving data to acitivity table");
            activityService.saveActivity(request);
        }catch(Exception e) {
            //Swallow the exception so it won't cause any service failure
            log.error("Error occured while saving data to acitvity table. Exception : " + e);
        }
    }
}
