package com.pw.dome.audit;

import org.hibernate.exception.GenericJDBCException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuditService {

  @Autowired
  private AuditRepository repo;

  @Transactional(propagation = Propagation.REQUIRES_NEW, noRollbackFor = GenericJDBCException.class)
  public AuditEvent saveAudit(AuditEvent audit) {
    AuditMapper mapper = AuditMapper.INSTANCE;
    AuditEntity entity = mapper.toEntity(audit);
    entity = repo.save(entity);

    return mapper.toAuditEvent(entity);
  }

  @Transactional(propagation = Propagation.REQUIRES_NEW, noRollbackFor = GenericJDBCException.class)
  public AuditEvent saveAudit(AuditEntity entity) {
    AuditMapper mapper = AuditMapper.INSTANCE;
    AuditEntity newEntity = repo.save(entity);

    return mapper.toAuditEvent(newEntity);
  }
}
