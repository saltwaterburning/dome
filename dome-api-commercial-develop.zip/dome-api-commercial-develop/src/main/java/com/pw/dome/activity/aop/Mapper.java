package com.pw.dome.activity.aop;

import java.time.LocalDateTime;

import org.springframework.data.domain.Persistable;

import com.pw.dome.activity.ActivityEntity;
import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.engine.EngineEntity;

class Mapper {

    static ActivityEntity of(final Persistable<?> from, final Context ctx) {
        if (from instanceof EngineEntity) {
            return toEntity((EngineEntity)from, ctx);
        } else if (from instanceof SlotEntity) {
            return toEntity((SlotEntity)from, ctx);
        }

        throw new IllegalArgumentException();
    }

    static ActivityEntity toEntity(final EngineEntity engine, final Context ctx) {
        return  ActivityEntity.builder()
        .item(ctx.getActivityItem())
        .activityDate(LocalDateTime.now())
        .engineType(engine.getCategory())
        .engineGroup(engine.getGroupID())
        .engineModel(engine.getModelID())
        .engineModule(engine.getModule() == null ? null : engine.getModule().getModuleName())
        .engineSerialNumber(engine.getEsn())
        .customerID(engine.getCustomerID())
        .userEmail(ctx.getUserEmail())
        .type(ctx.getActivityType())
        .description("foo")
//        .description(String.format("Engine %s removed from Shop Visit for date : %s, type : %s", (engine == null ? null : engine.getEngineID()), dateStr, type))
        .build();
    }

    static ActivityEntity toEntity(final SlotEntity from, final Context ctx) {
        return  ActivityEntity.builder()
                              .item(ctx.getActivityItem())
                              .activityDate(LocalDateTime.now())
                              .engineCenterId(from.getEngineCenterID())
                              .engineType(from.getEngineType() !=null ? from.getEngineType().getName() : null)
                              .userEmail(ctx.getUserEmail())
                              .type(ctx.getActivityType())
                              .description(String.format("Add Shop Visit for date : %s/%s/%s, type : %s", from.getMonth(), from.getDay(), from.getYear(), from.getShopVisitType()))
                              .build();
    }
}
