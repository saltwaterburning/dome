package com.pw.dome.admin;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

import com.pw.dome.user.UserProfileEngineCenter;
import com.pw.dome.user.UserProfileEngineGroup;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountManagementResponse {
    @NotEmpty(message = "{NotEmpty.required}")
    private List<SecurityRoles> additionalRoles;

    @NotEmpty(message = "{NotEmpty.required}")
    @Valid
    private List<UserProfileEngineCenter> engineCenterGroups;

    // No engineGroups set.
    //    @NotEmpty(message = "{NotEmpty.required}")
    //    @Valid
    private List<UserProfileEngineCenter> engineCenters;

    @NotEmpty(message = "{NotEmpty.required}")
    @Valid
    private List<UserProfileEngineGroup> engineGroups;

    @NotEmpty(message = "{NotEmpty.required}")
    private List<SecurityRoles> securityRoles;
}
