package com.pw.dome.external.mro.collab;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import com.pw.dome.external.RemoteServiceConfig;

import lombok.Data;

@Configuration
@ConfigurationProperties(prefix = "dome.mro-collab")
@Data
@Validated
public class ConfigMroCollab implements RemoteServiceConfig {
	@NotNull
	private Boolean asynchronous;

	@NotNull
	private String baseUrl;

	@NotNull
	private String deleteCommentUri;

	@NotNull
	private String deleteEngineEsnUri;

	@NotNull
	private String deletePacingItemUri;

	/**
	 * Disabled for development environment.
	 */
	@NotNull
	private Boolean enabled;
	/**
	 * JWT required to access MRO service.
	 */
	@NotNull
	private String jsonWebToken;

	@NotNull
	private String pushCommentUri;

	@NotNull
	private String pushEngineGateInfoUri;

	@NotNull
	private String pushPacingItemUri;

	@Min(1)
	@NotNull
	private Integer responseTimeoutSecs;

	@Min(1)
	@NotNull
	private Integer retryMaxAttempts;

	@Min(1)
	@NotNull
	private Integer retryMinBackoffSecs;

	@Min(-1)
	@NotNull
	private Integer webClientThreadCap;
}
