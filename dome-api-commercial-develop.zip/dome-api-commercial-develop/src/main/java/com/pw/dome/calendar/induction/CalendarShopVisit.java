package com.pw.dome.calendar.induction;

import java.util.Collection;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.pw.dome.calendar.slots.ShopVisitType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Builder
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CalendarShopVisit {
	@JsonIgnore
	private int dayOfMonth;
	private Collection<CalendarEngine> engines;
	private String engineTypeID;
	private String engineTypeName;
	private ShopVisitType shopVisitType;
	private int slotCount;
	private int slotID;
}
