package com.pw.dome.engine.events;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Embeddable
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EngineEventEntityPK implements Serializable {

	private static final long serialVersionUID = -1398758536987095255L;

	@Column(name = "ESN", insertable = false, updatable = false)
	private String esn;

	@Column(name = "EVENT_ID", insertable = false, updatable = false)
	private Integer eventId;

	@Override
	public int hashCode() {
		return Objects.hash(esn, eventId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof EngineEventEntityPK))
			return false;
		EngineEventEntityPK other = (EngineEventEntityPK) obj;
		return Objects.equals(esn, other.esn) && Objects.equals(eventId, other.eventId);
	}

}
