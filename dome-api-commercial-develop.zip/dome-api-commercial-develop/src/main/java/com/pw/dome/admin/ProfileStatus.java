package com.pw.dome.admin;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Enumeration of 
 * 
 * 
 * @author ARijos
 * When user enter in DOME Application first time, the user has status NEW.
2.	
3.	After user first time request Engine Centers the status change to REQUEST.(As per previous documents and you also confirm couple of days ago).
4.	

5.	After approved from admin the user status will change to APPROVED.
6.	

7.	User visit DOME application and if ask engine center from User Profile page, the status will change to UPDATE.
8.	
9.	After Approved from Admin status again change to APPROVED.


 */
/**
 * @author ARijos
 *
 */
public enum ProfileStatus {
	/**
	 * After administrator approval of {@code REQUEST} status profile.
	 */
	APPROVED,
	/**
	 * After administrator disapproval of {@code REQUEST} status profile.
	 */
	DISAPPROVE,
	/**
	 * User enters DOME Application first time.
	 */
	NEW,
	/**
	 * After user initial Engine Centers.
	 */
	REQUEST,
	/**
	 * Spurious status string.
	 */
	UNKNOWN,
	/**
	 * User visit DOME application and if ask engine center from User Profile page, the status will change to UPDATE.
	 */
	UPDATE;

	/**
	 * @param statusName
	 * @return
	 */
    @JsonCreator
	public static ProfileStatus of(String statusName) {
		return Stream.of(ProfileStatus.values()).filter(s -> s.name().equalsIgnoreCase(statusName))
				                                .findFirst()
				                                .orElse(null);
	}

	/**
	 * @param profileStatus
	 * @return
	 */
	public static List<String> asList(ProfileStatus... profileStatus) {
		return Stream.of(profileStatus).map(s->s.name()).collect(Collectors.toList());
	}
}
