package com.pw.dome.calendar.slots;

interface Consts {
	interface SQL {
		String GET_IP_CALENDAR_VISITS =
		"""
SELECT e.eng_category AS category,
   e.eng_id AS engineID,
   e.eng_sn AS esn,
   engcent.ec_edata_id eData,
   engcent.ec_vdata_id vData,
   slots.sp_eng_type AS engineTypeId,
   slots.slot_id AS slotID,
   slots.sp_day AS dayOfMonth,
   slots.sp_ec_id AS engineCenterID,
   engcent.ec_name AS engineCenterName,
   slots.sp_slot_type AS shopVisitType,
   slots.sp_slot_count AS slotCount
FROM dome_slotting slots
LEFT OUTER JOIN dome_engine e
   ON e.slot_id = slots.slot_id
   AND e.eng_type_id IN (:engineTypeIds)
LEFT OUTER JOIN dome_engine_center engcent
   ON engcent.ec_id = slots.sp_ec_id
WHERE slots.sp_ec_id IN (
      SELECT ec_id
      FROM dome_security_engine_center
      WHERE log_email = :userEmailAddress
      )
   AND (
      slots.sp_slot_type = """ + ShopVisitType.HOLIDAY.getValue()
      +
      """
      OR slots.sp_eng_type IN (:engineTypeIds)
      )
   AND slots.sp_month = :month
   AND slots.sp_year = :year
		""";
	}
}
