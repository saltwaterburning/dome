package com.pw.dome.engine.group;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * @author John De Lello
 */
@Repository
public interface EngineGroupRepository extends JpaRepository<EngineGroupEntity, String> {

	@Query(value = "SELECT e FROM EngineGroupEntity e WHERE e.engineGroupID IN(SELECT engineGroupId FROM SecurityEngineCenterEntity s where lower(s.emailAddress) = lower(?1) AND s.engineCenterId =?2) AND e.engineTypeID = ?3 AND e.active = true  ORDER BY e.name")
	List<EngineGroupEntity> getEngineGroups(final String userEmailID, final String engineCenterID, final String engineTypeID);

	@Query(value = "SELECT e FROM EngineGroupEntity e WHERE e.engineGroupID IN(SELECT engineGroupId FROM SecurityEngineCenterEntity s where lower(s.emailAddress) = lower(?1) AND s.engineCenterId =?2) AND e.active = true ORDER BY e.name")
	List<EngineGroupEntity> getEngineGroups(final String userEmailID, final String engineCenterID);

	@Query(value = "SELECT e FROM EngineGroupEntity e WHERE e.engineGroupID IN(SELECT engineGroupId FROM SecurityEngineCenterEntity s where lower(s.emailAddress) = lower(?1)) AND e.active = true ORDER BY e.name")
	List<EngineGroupEntity> getEngineGroups(final String userEmailID);

	@Query(value = "SELECT dome_eng_group_id_seq.nextval FROM dual", nativeQuery = true)
	Long getNextSeqVal();

	@Query(value = "SELECT * FROM dome_eng_group_mst WHERE eng_group_action = 'A' AND eng_type_id = ?1 ORDER BY eng_group_name", nativeQuery = true)
    List<EngineGroupEntity> getActiveEngineGroups(final String typeId);

	@Query(value = "SELECT * FROM dome_eng_group_mst WHERE eng_type_id = ?1 ORDER BY eng_group_name", nativeQuery = true)
    List<EngineGroupEntity> getAllEngineGroups(final String typeId);

	@Query(value = "SELECT e FROM EngineGroupEntity e WHERE e.active = true ORDER BY e.name")
    List<EngineGroupEntity> getEngineGroups();

	@Modifying
	@Query(value = "UPDATE EngineGroupEntity x SET x.active = ?1 WHERE x.active != ?1 AND x.engineTypeID = ?2 AND x.engineGroupID = ?3")
	int setAction(final boolean active, final String typeId, final String groupId);
}
