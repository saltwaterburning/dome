package com.pw.dome;

import static com.pw.dome.common.oas.ApiOperations.Tags.MRO;

import io.swagger.v3.oas.annotations.ExternalDocumentation;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.annotations.servers.Server;
import io.swagger.v3.oas.annotations.tags.Tag;

@OpenAPIDefinition(externalDocs = @ExternalDocumentation(description = "Project SharePoint",
                                                         url = ""),
                   info = @Info(title = "Digital Overhaul Management of Engines",
                                version = "2023-03-20",
                                description = "DOME Application RESTful API for use by MRO Application.",
                                contact = @Contact(email = "chuck.marco@prattwhitney.com",
                                                   name = "Chuck Marco",
                                                   url = "https://www.dbds.com")),
                   security = {
                       @SecurityRequirement(name = "bearerAuth",
                                            scopes = {})
                   },
                   servers = {
                       @Server(description = "DBDS Devlelopment",
                               url = "http://192.168.3.171:81/dome"),
                       @Server(description = "DBDS Stage",
                               url = "http://192.168.3.171:82/dome"),
                       @Server(description = "P&W Stage",
                               url = "https://dome-ui-test.prattwhitney.com/dome")
                   }, tags = {@Tag(name = MRO, description = "MRO (maintenance, repair and operations) Collaboration API.")})
@SecurityScheme(description = "JWT Bearer Authorization.", name = "bearerAuth",
                bearerFormat = "jwt",
                type = SecuritySchemeType.HTTP,
                scheme = "bearer")
public class OpenApiConfig {}
// https://stackoverflow.com/questions/59357205/springdoc-openapi-apply-default-global-securityscheme-possible
