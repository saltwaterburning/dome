package com.pw.dome.engine.induction;

import com.pw.dome.engine.phase.EnginePhases;

import lombok.Builder;

@Builder
record PhaseQuery(EnginePhases phase, String query) {

}
