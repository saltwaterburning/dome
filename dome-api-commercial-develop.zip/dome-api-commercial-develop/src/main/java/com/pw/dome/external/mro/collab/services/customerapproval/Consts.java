package com.pw.dome.external.mro.collab.services.customerapproval;

interface Consts {

	interface SQL {
		String GET_ODIN =
"""
SELECT e
FROM OdinEntity e
WHERE e.odinId =
    (SELECT o.odinId
     FROM EngineEntity e,
          EngineTrackingEntity t,
          OdinEntity o,
          SlotEntity s,
          MroEngineCenterEntity c
     WHERE c.mroEcShopCode = :mroShopCode
       AND e.engineID = t.engtrackId
       AND e.esn = :esn
       AND e.eventId = :eventId
       AND e.slotID = s.slotID
       AND o.engineId = e.engineID
       AND o.esn = e.esn
       AND o.eventId = e.eventId
       AND s.engineCenterID = c.ecId
       AND t.engtrackWorkOrder = :mroWorkOrder)
""";
	}
}
