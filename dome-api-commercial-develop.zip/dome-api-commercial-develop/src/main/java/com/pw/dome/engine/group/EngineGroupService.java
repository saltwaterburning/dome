package com.pw.dome.engine.group;

import java.util.List;

import com.pw.dome.user.UserProfile;

/**
 * @author John De Lello
 */
public interface EngineGroupService {
	List<EngineGroupEntity> getEngineGroups(final UserProfile userProfile, final String engineCenterID);
	List<EngineGroupEntity> getEngineGroups(final UserProfile userProfile, final String engineCenterID, final String engineTypeID);
}
