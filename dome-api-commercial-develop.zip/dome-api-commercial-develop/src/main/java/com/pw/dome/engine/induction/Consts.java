package com.pw.dome.engine.induction;

import static com.pw.dome.engine.removed.DTO_FQCN.DTO_NAME;

import com.pw.dome.engine.phase.EnginePhases;

/**
 * JPA projections performance. <b>Avoid interface projections.</b>
 *
 * <pre>
 * <li>Tuple projections took 21.41 ms on average out of 100 iterations.
 * <li>Dynamic projections took 23.62 ms on average out of 100 iterations.
 * <li>Constructor projections took 24.84 ms on average out of 100 iterations.
 * <li>Entity projections took 161.61 ms on average out of 100 iterations.
 * <li>Interface projections took 252.26 ms on average out of 100 iterations.
 * </pre>
 *
 * @see  <a href="https://tousu.in/?qa=899600/">Why are interface projections much slower...</a>.
 * @see  <a href="https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#projections">JPA Projections</a>.
 *
 * @see  <a href="https://poorsql.com/">SQL Formatter</a>.
 *
 * <pre>
 * <b>Poor Man's T-SQL Formatter Settings</b>
 * Indentation level: <b>3</b>
 * Change case of SQL keywords (select, from, where, etc.): <b>Modify to upper case</b>
 * Change case of identifiers (tables, columns, etc.): <b>Do not modify case</b>
 * </pre>
 */
interface Consts {
	// Must have constant expression for annotations.
	String AVAILABLE_ENGINE_FQCN = "com.pw.dome.engine.induction.AvailableEngine";

	String AND_IS_DISABLED = " AND cast(nvl(a.disabled, 0) as int) = 1 ";

	String AND_IS_MODULE = " AND e.moduleID is not null ";
	String AND_NOT_MODULE = " AND e.moduleID is null ";

	/**
     * Log query information above this threshold.
     */
    int SLOW_SQL_THRESHOLD_MILLIS = 3000;

    /**
     * Induction phases SQL queries.
     *
     * @see EnginePhases
     * @see <a href="https://sqlformat.org/" target="_blank">SQL Format</a>
     */
    interface SQL {
        /**
         * JPQL constructor expression.
         * Note that columns are needed from the EngineAssetEntity (a),
         * Customer (c),
         * EngineEntity (e),
         * EngineEventEntity (ee),
         * EngineRemoved (r),
         * SlotEntity (s) and EngineTrackingEntity (t) DB tables.
         */
    	// ESN + eventId (except for on-wing)
    	String SELECT_NEW_DTO =
        "SELECT DISTINCT NEW " + DTO_NAME +
"""
(ROWNUM + :rowNumOffset,
 a.assetID,
 a.contractType,
 o.customerApprovalDate,
 a.engineAssetID,
 s.engineCenterID,
 e.engineID,
 a.engineModelID,
 a.engineModelName,
 COALESCE(e.engineTypeId, a.engineTypeID),
 COALESCE(ee.pk.esn, e.esn, a.esn),
 ee.pk.eventId,
 a.installed,
 o.odinId,
 c.customerID,
 c.name,
 p.enginePhaseID,
 a.planned,
 t.engtrackPlanIndDate,
 COALESCE(ee.removalDate, t.engtrackRemoval),
 COALESCE(ee.removalReason, e.removalReason),
 a.removed,
 s.caldate,
 ee.slotId,
 a.thrust,

 o.accyDeliveryDate,
 t.engtrackRecDate,
 o.adListDate,
 o.fanBladeMapDate,
 o.llpDeliveryDate,
 o.nisDeliveryDate,
 t.engtrackPlanRecDate,
 o.smiNeedDate,
 o.wsOrigReleaseDate )\
""";

        String SELECT_NEW_AVAILABLE_ENGINE =
        "SELECT NEW " + AVAILABLE_ENGINE_FQCN +
"""
(a.engineAssetID,
 a.esn,
 ee.pk.eventId,
 a.installed,
 a.operatorID,
 c.name,
 a.planned,
 a.removed,
 ee.slotId)\
""";

        /**
         * Query for Induction Schedule available engines.
         * engineTypeID in (:engineTypeIds), esn% = :esn
         */
        String AVAILABLE_ENGINES =
        		SELECT_NEW_AVAILABLE_ENGINE +
"""
FROM EngineAssetEntity a
LEFT OUTER JOIN a.operator c
   ON a.operatorID = c.customerID
     AND a.operator.active = true
INNER JOIN CustomerCenterMatrixEntity ccm
   ON a.operatorID = ccm.id.customerId
      AND a.engineTypeID = ccm.id.engineTypeId
LEFT OUTER JOIN EngineEventEntity ee
   ON a.esn = ee.pk.esn
      AND ee.shipped = false
LEFT OUTER JOIN SlotEntity s
   ON ee.slotId = s.slotID
INNER JOIN EnginePhaseEntity p
   ON p.enginePhaseID = :phaseCode
WHERE a.engineTypeID in (:engineTypeIds)
   AND UPPER(a.esn) LIKE UPPER(:esn || '%')
   AND ccm.id.engineCenterId = :engineCenterId
""";

        /**
         * Query for {@code EnginePhases.COMPLETE}.
         * AKA Complete in clm_phases table.
         */
        String COMPLETE_PHASE =
        		SELECT_NEW_DTO +
"""
FROM EngineEntity e
LEFT OUTER JOIN EngineAssetEntity a
   ON a.esn = e.esn
LEFT OUTER JOIN EngineGroupEntity eg
   ON eg.engineGroupID = e.groupID
      AND eg.active = true
LEFT OUTER JOIN CustomerEntity c
   ON c.customerID = e.customerID
      AND c.active = true
LEFT OUTER JOIN a.operator preventCrossJoinForImplicitAssociation1
   ON preventCrossJoinForImplicitAssociation1.customerID is null
LEFT OUTER JOIN e.customer preventCrossJoinForImplicitAssociation2
   ON preventCrossJoinForImplicitAssociation2.customerID is null
LEFT OUTER JOIN EngineEventEntity ee
   ON ee.pk.esn = e.esn
      AND ee.pk.eventId = e.eventId
INNER JOIN EngineTrackingEntity t
   ON t.engtrackId = e.engineID
      AND t.engtrackShipmentDate is not null
LEFT OUTER JOIN OdinEntity o
   ON o.esn = a.esn
      AND o.engineId = e.engineID
LEFT OUTER JOIN SlotEntity s
   ON s.slotID = e.slotID
INNER JOIN EnginePhaseEntity p
   ON p.enginePhaseID = :phaseCode
WHERE e.engineTypeId in (:engineTypeIds)
   AND e.moduleID is null
   AND t.engtrackShipmentDate is not null
   AND UPPER(e.esn) LIKE UPPER(:esn || '%')
""" + AND_NOT_MODULE;

        /**
         * Query for {@code EnginePhases.INACTIVE}.
         */
        String INACTIVE_PHASE =
        SELECT_NEW_DTO +
"""
FROM EngineAssetEntity a
LEFT OUTER JOIN EngineEventEntity ee
   ON a.esn = CONCAT (
         ee.pk.esn,
         'FOO'
         )
      AND ee.shipped = false
LEFT OUTER JOIN EngineEntity e
   ON a.esn = CONCAT (
         e.esn,
         'FOO'
         )
      AND ee.slotId = e.slotID
      AND e.moduleID is null
LEFT OUTER JOIN CustomerEntity c
   ON c.customerID = e.customerID
      AND c.active = true
LEFT OUTER JOIN a.operator preventCrossJoinForImplicitAssociation1
   ON preventCrossJoinForImplicitAssociation1.customerID is null
LEFT OUTER JOIN e.customer preventCrossJoinForImplicitAssociation2
   ON preventCrossJoinForImplicitAssociation2.customerID is null
LEFT OUTER JOIN SlotEntity s
   ON e.slotID = s.slotID
LEFT OUTER JOIN EngineTrackingEntity t
   ON e.engineID = t.engtrackId
      AND t.engtrackShipmentDate is null
LEFT OUTER JOIN OdinEntity o
   ON a.esn = CONCAT (
         o.esn,
         'FOO'
         )
INNER JOIN EnginePhaseEntity p
   ON p.enginePhaseID = :phaseCode
WHERE a.engineTypeID in (:engineTypeIds)
""" + AND_IS_DISABLED + AND_NOT_MODULE;

        /**
         * Query for {@code EnginePhases.REMOVED}.
         * AKA Removed in clm_phases table.
         *  planned and shipped.
         *  ee.pk.esn
         *  engineAssets.
         *  cust.id + oper.id
         */
        String REMOVED_PHASE =
        		SELECT_NEW_DTO +
"""
FROM EngineEventEntity ee
LEFT OUTER JOIN EngineEntity e
   ON e.esn = ee.pk.esn
      AND e.eventId = ee.pk.eventId
      AND e.moduleID is null
LEFT OUTER JOIN EngineAssetEntity a
   ON a.esn = ee.pk.esn
LEFT OUTER JOIN CustomerEntity c
   ON c.customerID = a.operatorID
      AND c.active = true
LEFT OUTER JOIN a.operator preventCrossJoinForImplicitAssociation1
   ON preventCrossJoinForImplicitAssociation1.customerID is null
LEFT OUTER JOIN e.customer preventCrossJoinForImplicitAssociation2
   ON preventCrossJoinForImplicitAssociation2.customerID is null
LEFT OUTER JOIN EngineTrackingEntity t
   ON t.engtrackId = e.engineID
      AND t.engtrackShipmentDate is null
LEFT OUTER JOIN OdinEntity o
   ON o.esn = a.esn
      AND o.eventId = ee.pk.eventId
LEFT OUTER JOIN SlotEntity s
   ON s.slotID = a.slotId
      OR s.slotID = e.slotID
INNER JOIN EnginePhaseEntity p
   ON p.enginePhaseID = :phaseCode
WHERE a.engineTypeID in (:engineTypeIds)
   AND ee.planned = false
   AND ee.shipped = false
""" + AND_NOT_MODULE;

        /**
         * Query for {@code EnginePhases.REMOVED}.
         * AKA Removed in clm_phases table.
         *  planned and shipped.
         *  ee.pk.esn
         *  engineAssets.
         *  cust.id + oper.id
         */
        String SCHEDULED_PHASE =
            SELECT_NEW_DTO +
"""
FROM EngineEntity e
LEFT OUTER JOIN EngineAssetEntity a ON a.esn = e.esn
LEFT OUTER JOIN EngineGroupEntity eg ON eg.engineGroupID = e.groupID
AND eg.active = true
LEFT OUTER JOIN EngineEventEntity ee ON ee.pk.esn = e.esn
AND ee.pk.eventId = e.eventId
LEFT OUTER JOIN CustomerEntity c ON c.customerID = e.customerID
AND c.active = true
LEFT OUTER JOIN a.operator preventCrossJoinForImplicitAssociation1 ON preventCrossJoinForImplicitAssociation1.customerID is null
LEFT OUTER JOIN e.customer preventCrossJoinForImplicitAssociation2 ON preventCrossJoinForImplicitAssociation2.customerID is null
LEFT OUTER JOIN EngineTrackingEntity t ON t.engtrackId = e.engineID
INNER JOIN OdinEntity o ON o.engineId = e.engineID
AND o.esn = e.esn
AND (e.eventId = o.eventId
     OR (e.eventId is null
         AND o.eventId is null))
INNER JOIN SlotEntity s ON s.slotID = e.slotID
INNER JOIN EnginePhaseEntity p ON p.enginePhaseID = :phaseCode
WHERE e.engineTypeId in (:engineTypeIds)
  AND t.engtrackIndDate is null
  AND t.engtrackShipmentDate is null
""" + AND_NOT_MODULE;

//        Select from DOME_ENGINE A, DOME_ENGINE_TRACKING
//        WHERE ENGTRACK_IND_DATE is null

            /**
         * Query for {@code EnginePhases.WIP}.
         * AKA WIP in clm_phases table.
         */
        String WIP_PHASE =
        		SELECT_NEW_DTO +
"""
FROM EngineEntity e
LEFT OUTER JOIN EngineAssetEntity a
   ON a.esn = e.esn
LEFT OUTER JOIN EngineGroupEntity eg
   ON eg.engineGroupID = e.groupID
      AND eg.active = true
LEFT OUTER JOIN EngineEventEntity ee
   ON ee.pk.esn = e.esn
      AND ee.pk.eventId = e.eventId
LEFT OUTER JOIN CustomerEntity c
   ON c.customerID = e.customerID
      AND c.active = true
LEFT OUTER JOIN a.operator preventCrossJoinForImplicitAssociation1
   ON preventCrossJoinForImplicitAssociation1.customerID is null
LEFT OUTER JOIN e.customer preventCrossJoinForImplicitAssociation2
   ON preventCrossJoinForImplicitAssociation2.customerID is null
LEFT OUTER JOIN EngineTrackingEntity t
   ON t.engtrackId = e.engineID
INNER JOIN OdinEntity o
   ON o.engineId = e.engineID
      AND o.esn = e.esn
      AND (
         e.eventId = o.eventId
         OR e.eventId is null
         AND o.eventId is null
         )
INNER JOIN SlotEntity s
   ON s.slotID = e.slotID
INNER JOIN EnginePhaseEntity p
   ON p.enginePhaseID = :phaseCode
WHERE e.engineTypeId in (:engineTypeIds)
   AND t.engtrackIndDate is not null
   AND t.engtrackShipmentDate is null
""" + AND_NOT_MODULE;


        /**
         * Used for {@code EnginePhases.ALL} searches to limit by ESN.
         */
        String LIKE_ENGINE_ESN = " AND upper(e.esn) LIKE upper(:esn || '%')";
        String LIKE_ENGINE_EVENT_ESN = " AND upper(ee.pk.esn) LIKE upper(:esn || '%')";

       /**
        * Queries for {@code EnginePhases.ALL}. Since JPQL doesn't support the UNION keyword
        * all queries run separately and then combined. The {@code LIKE_ENGINE_ESN} criteria
        * is added to queries not already having one.
        */
        PhaseQuery[] ALL_SEARCHES = {
        		new PhaseQuery(EnginePhases.COMPLETE, COMPLETE_PHASE),
        		new PhaseQuery(EnginePhases.REMOVED_ENG, REMOVED_PHASE + LIKE_ENGINE_EVENT_ESN),
        		new PhaseQuery(EnginePhases.SCHEDULED, SCHEDULED_PHASE + LIKE_ENGINE_ESN),
        		new PhaseQuery(EnginePhases.WIP, WIP_PHASE + LIKE_ENGINE_ESN)
        };
    }
}
