package com.pw.dome.calendar.slots;

import static java.util.Objects.isNull;

import java.util.ArrayList;
import java.util.Collection;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class GetSlotResponse{
	private int day;
	private String engineCenterID;
	private Collection<SlotEngine> engines;
	private String engineTypeID;
	private String engineTypeName;
	private int month;
	private ShopVisitType shopVisitType;
	private int slotID;
	private int year;
	
	public void addEngine(final SlotEngine slotEngine) {
		if (isNull(slotEngine)) {
			return;
		}

		if (isNull(engines)) {
			engines = new ArrayList<>();
		}

		engines.add(slotEngine);
	}
}
