package com.pw.dome.engine.type;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.user.UserProfile;


@RestController()
@RequestMapping("/v1/engines/types")
public class EngineTypeController {
	@Autowired
	private EngineTypeService engineTypeService;

	/**
	 * @api {get} /v1/engines/types/:engineCenterID Get All Types
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/engines/types/EC1
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName getEngineTypes
     * @apiGroup Engine Types
     * @apiParam {String} engineCenterID The engine center ID to get engine types for
     * @apiDescription Returns a list of engine types that are available for the current user and engine center 
     * @apiSuccess {Object[]} engineTypes An array engine types 
     * @apiSuccess {Number} engineTypes.engineTypeID The engine type ID
     * @apiSuccess {String} engineTypes.name The engine type name
     * @apiSuccess {Boolean} engineTypes.edata Whether this engine type is in Edata or not
     * @apiUse GetEngineTypesSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/
    @GetMapping(path = "/{engineCenterID}", produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<EngineTypeListResponse> getEngineTypes(@AuthenticationPrincipal UserProfile userProfile,
    	                                                          @PathVariable(name = "engineCenterID") String engineCenterID){
    	
		List<EngineTypeEntity> types = engineTypeService.getEngineTypes(userProfile, engineCenterID);
    	
    	return ResponseEntity.ok(EngineTypeListResponse.builder().engineTypes(types).build());
    }

	/**
	 * @api {get} /v1/engines/types/:engineCenterID/:engineGroupID Get Types for Engine Group
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/engines/types/EC3/EG615
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName getEngineTypesByEngineGroup
     * @apiGroup Engine Types
     * @apiParam {String} engineCenterID The engine center ID to get engine types for
     * @apiDescription Returns a list of engine types that are available for the current user and engine center 
     * @apiSuccess {Object[]} engineTypes An array engine types 
     * @apiSuccess {Number} engineTypes.engineTypeID The engine type ID
     * @apiSuccess {String} engineTypes.name The engine type name
     * @apiSuccess {Boolean} engineTypes.edata Whether this engine type is in Edata or not
     * @apiUse GetEngineTypesSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/
    @GetMapping(path = "/{engineCenterID}/{engineGroupID}", produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<EngineTypeListResponse> getEngineTypesByEngineGroup(@AuthenticationPrincipal UserProfile userProfile,
    		                                                                  @PathVariable(name = "engineCenterID") String engineCenterID,    		
   		                                                                      @PathVariable(name = "engineGroupID") String engineGroupID){
    	
		List<EngineTypeEntity> models =  engineTypeService.getEngineTypes(userProfile, engineCenterID, engineGroupID);
    	
    	return ResponseEntity.ok(EngineTypeListResponse.builder().engineTypes(models).build());
    }
    
	/**
	 * @api {get} /v1/engines/types/detail/:engineTypeID Get Engine Type Detail
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/engines/types/detail/ET720
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName getEngineTypeDetail
     * @apiGroup Engine Types
     * @apiParam {String} engineTypeID The engine type ID to get details for
     * @apiDescription Returns the engine type details for the specified Engine Type ID 
     * @apiSuccess {Number} engineTypeID The engine type ID
     * @apiSuccess {String} name The engine type name
     * @apiSuccess {Boolean} edata Whether this engine type is in Edata or not
     * @apiUse GetEngineTypeDetailSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/    
    @GetMapping(path = "/detail/{engineTypeID}", produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<EngineTypeEntity> getEngineTypeDetail(@AuthenticationPrincipal UserProfile userProfile,
    		                                              @PathVariable(name = "engineTypeID") String engineTypeID){
    	
		EngineTypeEntity engineType=  engineTypeService.getEngineTypeByID(engineTypeID);
    	
    	return ResponseEntity.ok(engineType);
    }    

}
