package com.pw.dome.audit;

import static org.apache.commons.lang3.StringUtils.equalsIgnoreCase;

import java.util.Arrays;

public enum AUDIT_TYPES {
  ADD,
  DELETE,
  UPDATE;

  public static AUDIT_TYPES of(final String type) {
    return Arrays.stream(values())
        .filter(value -> equalsIgnoreCase(value.name(), type))
        .findFirst()
        .orElse(null);
  }
}
