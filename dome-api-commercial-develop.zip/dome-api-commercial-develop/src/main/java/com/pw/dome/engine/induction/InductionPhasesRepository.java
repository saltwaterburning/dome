package com.pw.dome.engine.induction;

import static com.pw.dome.engine.induction.Consts.SQL.AVAILABLE_ENGINES;
import static com.pw.dome.engine.induction.Consts.SQL.COMPLETE_PHASE;
import static com.pw.dome.engine.induction.Consts.SQL.INACTIVE_PHASE;
import static com.pw.dome.engine.induction.Consts.SQL.REMOVED_PHASE;
import static com.pw.dome.engine.induction.Consts.SQL.SCHEDULED_PHASE;
import static com.pw.dome.engine.induction.Consts.SQL.WIP_PHASE;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pw.dome.engine.asset.EngineAssetEntity;
import com.pw.dome.engine.induction.Consts.SQL;
import com.pw.dome.engine.removed.EngineRemovedDTO;

/**
 * Queries for induction engine phases. Returns new {@code EngineRemovedDTO} directly from the result set.
 * This approach performs better than returning JPA entities then mapping to DTOs.
 * The {@link String#ALL} query executes all of the queries as defined by {@link SQL#ALL_PHASES}.
 */
@Repository
public interface InductionPhasesRepository extends JpaRepository<EngineAssetEntity, Integer> {
	@Query(AVAILABLE_ENGINES)
	List<AvailableEngine> getAvailableEngines(@Param("engineCenterId") final String engineCenterId, @Param("engineTypeIds")final String engineTypeId, @Param("esn")final String esn, @Param("phaseCode")final String phaseCode);

	@Query(COMPLETE_PHASE)
	List<EngineRemovedDTO> getPhaseComplete(@Param("rowNumOffset")long rowNumOffset, @Param("engineTypeIds")final List<String> engineTypeId, @Param("esn")final String esn, @Param("phaseCode")final String phaseCode);

	@Query(INACTIVE_PHASE)
	List<EngineRemovedDTO> getPhaseInactive(@Param("rowNumOffset")long rowNumOffset, @Param("engineTypeIds")final List<String> engineTypeId, @Param("phaseCode")final String phaseCode);

	@Query(REMOVED_PHASE)
	List<EngineRemovedDTO> getPhaseREMOVED(@Param("rowNumOffset")long rowNumOffset, @Param("engineTypeIds")final List<String> engineTypeId, @Param("phaseCode")final String phaseCode);

	@Query(SCHEDULED_PHASE)
	List<EngineRemovedDTO> getPhaseSCHEDULED(@Param("rowNumOffset")long rowNumOffset, @Param("engineTypeIds")final List<String> engineTypeId, @Param("phaseCode")final String phaseCode);

	@Query(WIP_PHASE)
	List<EngineRemovedDTO> getPhaseWIP(@Param("rowNumOffset")long rowNumOffset, @Param("engineTypeIds")final List<String> engineTypeId, @Param("phaseCode")final String phaseCode);
}
