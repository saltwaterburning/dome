package com.pw.dome.calendar.slots;

import static com.pw.dome.calendar.slots.ShopVisitType.HOLIDAY;
import static com.pw.dome.calendar.slots.ShopVisitType.MODULE;
import static com.pw.dome.calendar.slots.ShopVisitType.NEW;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.calendar.inductionplanning.InductionPlanningEngine;
import com.pw.dome.engine.EngineService;
import com.pw.dome.engine.type.EngineTypeEntity;
import com.pw.dome.engine.type.EngineTypeRepository;
import com.pw.dome.enginecenter.EngineCenterEntity;
import com.pw.dome.enginecenter.EngineCenterRepository;
import com.pw.dome.exception.BadRequestException;
import com.pw.dome.exception.ConflictException;
import com.pw.dome.exception.NotFoundException;
import com.pw.dome.user.UserProfile;
import com.pw.dome.web.authorization.SecurityService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author John De Lello
 */
@Slf4j
@Service
public class SlotService {
  @Autowired
  private EngineCenterRepository engCenterRepo;
  @Autowired
  private EngineService engineService;
  @Autowired
  private EngineTypeRepository engTypeRepo;
  @Autowired
  private SecurityService securitySvc;
  @Autowired
  private SlotRepository slotRepository;

  @Transactional
  public SlotEntity createSlot(final UserProfile userProfile,
      final CreateSlotRequest createSlotRequest) {
    LocalDate calDate = getDate(createSlotRequest.getYear(),
        createSlotRequest.getMonth(),
        createSlotRequest.getDay());
    if (isNull(calDate)) {
      String errorMsg = String.format(
          "Unable to create calendar slot. Specified date is invalid: %d-%d-%d",
          createSlotRequest.getYear(),
          createSlotRequest.getMonth(),
          createSlotRequest.getDay());
      log.error(errorMsg);
      throw new IllegalArgumentException(errorMsg);
    }

    ShopVisitType requestedType = createSlotRequest.getShopVisitType();
    if (!HOLIDAY.equals(requestedType) && !MODULE.equals(requestedType)
        && !NEW.equals(requestedType)) {
      String msg = String.format("New slot with shop visit type of %s isn't allowed.",
          nonNull(requestedType) ? requestedType.name() : "null");
      throw new BadRequestException(msg);
    }

    boolean isAllowable = securitySvc.isAllowableEngineCenter(userProfile,
        createSlotRequest.getEngineCenterID());
    if (!isAllowable) {
      String ecName = getEngCenterName(createSlotRequest.getEngineCenterID());
      String msg = String.format("Unable to access slot. User inaccessible Engine Center: %s",
          ecName);
      log.error(msg);
      throw new AccessDeniedException(msg);
    }

    List<SlotEntity> slotsOnDate = getSlots(createSlotRequest.getEngineCenterID(),
        createSlotRequest.getMonth(),
        createSlotRequest.getDay(),
        createSlotRequest.getYear());

    slotsOnDate.stream().forEach(slot -> {
      if (HOLIDAY.equals(slot.getShopVisitType())) {
        List<Integer> slotIds = slotsOnDate.stream()
            .map(s -> s.getSlotID())
            .collect(Collectors.toList());

        String msg = String.format("Slot can't be created on %s due to existing holiday slot.",
            calDate.toString());
        log.warn(msg + "\nSlotId: {}", slotIds);
        throw new BadRequestException(msg);
      }
    });

    if (!slotsOnDate.isEmpty() && HOLIDAY.equals(createSlotRequest.getShopVisitType())) {
      List<Integer> slotIds = slotsOnDate.stream()
          .map(s -> s.getSlotID())
          .collect(Collectors.toList());

      String msg = String.format(
          "Holiday slot can't be added on %s. Slot(s) exist for EngineType: %s.",
          calDate.toString(),
          getEngTypeName(createSlotRequest.getEngineTypeID()));
      log.warn(msg + "\nSlotIds: {}", slotIds);
      throw new BadRequestException(msg);
    }

    SlotEntity slot = DataMapper.INSTANCE.toNewSlot(createSlotRequest, calDate);
    SlotEntity savedSlot = null;

    try {
      savedSlot = slotRepository.saveAndFlush(slot);
    } catch (DataIntegrityViolationException cvEx) {
      // See DOMEINDX_SLOTTING: Unique on SP_EC_ID, SP_ENG_TYPE, SP_SLOT_TYPE, SP_DATE
      log.error("DataIntegrityViolationException", cvEx);

      String engCenter = getEngCenterName(createSlotRequest.getEngineCenterID());
      List<Integer> slotIds = slotsOnDate.stream()
          .map(s -> s.getSlotID())
          .collect(Collectors.toList());

      String msg = String.format(
          "A slot already exists for EC: %s, EngineType: %s, SlotType: %s, Date: %s",
          engCenter,
          getEngTypeName(createSlotRequest.getEngineTypeID()),
          createSlotRequest.getShopVisitType(),
          calDate.toString());

      log.warn(msg + "\nSlotIds: {}", slotIds);
      throw new ConflictException(msg);
    }

    return savedSlot;
  }

  @Transactional
  public void deleteSlot(final UserProfile userProfile, final int slotID) {
    if (!slotRepository.existsById(slotID)) {
      String msg = String.format("Unable to delete slot. SlotId %d not found.", slotID);
      log.error(msg);
      throw new NotFoundException(msg);
    }

    SlotEntity slot = slotRepository.findByID(slotID);
    boolean isAllowable = securitySvc.isAllowableEngineCenter(userProfile,
        slot.getEngineCenterID());

    if (!isAllowable) {
      String ecName = getEngCenterName(slot.getEngineCenterID());
      String msg = String.format("Unable to delete slot. User inaccessible Engine Center: %s",
          ecName);
      log.error(msg);
      throw new AccessDeniedException(msg);
    }

    int slotEngineCount = engineService.countBySlotID(slotID);
    if (slotEngineCount > 0) {
      String errorMsg = String.format(
          "Unable to delete slot because %d engine(s) are assigned to it.",
          slotEngineCount);
      log.error(errorMsg + "; slotId: {}", slotID);
      throw new BadRequestException(errorMsg);
    }

    slotRepository.delete(slot);
  }

  public List<InductionPlanningEngine> getInductionPlanningCalendarVisitSummary(
      final String emailAddress,
      final List<String> engineTypeID,
      final int month,
      final int year) {
    return slotRepository
        .getInductionPlanningCalendarVisitSummary(emailAddress, engineTypeID, month, year);
  }

  @Transactional
  public SlotEntity getSlotByID(final UserProfile userProfile, final int slotID) {
    if (!slotRepository.existsById(slotID)) {
      String msg = String.format("Unable to retrieve slot. SlotId %d not found.", slotID);
      log.warn(msg);
      throw new NotFoundException(msg);
    }

    SlotEntity slot = slotRepository.findByID(slotID);
    boolean isAllowable = securitySvc.isAllowableEngineCenter(userProfile,
        slot.getEngineCenterID());

    if (!isAllowable) {
      String ecName = getEngCenterName(slot.getEngineCenterID());
      String msg = String.format("Unable to retrieve slot. User inaccessible Engine Center: %s",
          ecName);
      log.error(msg);
      throw new AccessDeniedException(msg);
    }

    return slot;
  }

  public List<SlotEntity> getSlots(final String engineCenterID, final int month, final int year) {
    return slotRepository.findByEngineCenterIDAndMonthAndYear(engineCenterID, month, year);
  }

  public List<SlotEntity> getSlots(final String engineCenterID,
      final int month,
      final int day,
      final int year) {
    return slotRepository
        .findByEngineCenterIDAndMonthAndDayAndYear(engineCenterID, month, day, year);
  }

  @Transactional
  public SlotEntity updateSlot(final UserProfile userProfile,
      final int slotID,
      final UpdateSlotRequest updateSlotRequest) {
    final String msg = String.format("Unable to perform update. SlotId %d not found.", slotID);

    if (!slotRepository.existsById(slotID)) {
      log.error(msg);
      throw new NotFoundException(msg);
    }

    SlotEntity slotToUpdate = slotRepository.findById(slotID)
        .orElseThrow(() -> new NotFoundException(msg));

    slotToUpdate.setSlotCount(updateSlotRequest.getSlotCount());
    slotToUpdate.setShopVisitType(updateSlotRequest.getShopVisitType());

    boolean isAllowable = securitySvc.isAllowableEngineCenter(userProfile,
        slotToUpdate.getEngineCenterID());
    if (!isAllowable) {
      String ecName = getEngCenterName(slotToUpdate.getEngineCenterID());
      String err = String.format("Unable to perform update. User inaccessible Engine Center: %s",
          ecName);
      log.error(err);
      throw new AccessDeniedException(err);
    } 

    slotToUpdate = slotRepository.save(slotToUpdate);
    return slotToUpdate;
  }

  private LocalDate getDate(final int year, final int month, final int dayOfMonth) {
    try {
      return LocalDate.of(year, month, dayOfMonth);
    } catch (DateTimeException e) {
      String msg = String.format("LocalDate.of(%d, %d, %d) failed.", year, month, dayOfMonth);
      log.error(msg, e);
    }

    return null;
  }

  private String getEngCenterName(String engCenterId) {
    EngineCenterEntity ecEntity = engCenterRepo.findById(engCenterId).orElse(null);
    return isNull(ecEntity) ? "null" : ecEntity.getName();
  }

  private String getEngTypeName(String engineTypeId) {
    if (nonNull(engineTypeId)) {
      EngineTypeEntity entity;
      if (nonNull(entity = engTypeRepo.getByEngineTypeId(engineTypeId))) {
        return entity.getName();
      }
    }

    return null;
  }
}
