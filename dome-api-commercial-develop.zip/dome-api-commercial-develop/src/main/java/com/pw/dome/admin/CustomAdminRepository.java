package com.pw.dome.admin;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.pw.dome.user.UserProfileEngineCenter;
import com.pw.dome.user.UserProfileEngineGroup;

@Repository
interface CustomAdminRepository {
	void create(Object entity);

	List<UserProfileEngineCenter> getAllEngineCenters();

	List<UserProfileEngineCenter> getAllEngineCentersAndGroups();

	List<UserProfileEngineGroup> getAllEngineGroups();

	List<OperatorEngineCenter> getOperatorEngineCenters();

	List<Operator> getOperators();

	void update(Object entity);

	List<UserProfileEngineCenter> getAllEngineCentersAndGroups(String filterEngGroupName);
}
