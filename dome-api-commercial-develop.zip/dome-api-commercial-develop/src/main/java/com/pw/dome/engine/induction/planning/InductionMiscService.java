package com.pw.dome.engine.induction.planning;

import java.util.EnumMap;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pw.dome.engine.type.EngineTypeEntity;
import com.pw.dome.engine.type.EngineTypeRepository;
import com.pw.dome.exception.NotFoundException;

@Service
public class InductionMiscService {
	@Autowired
	private EngineTypeRepository engineTypeRepo;
	@Autowired
	private InductionMiscRepo repo;

	public InductionMiscDTO getInductionValue(InductionMiscKeys key) {
	     List<String> list = repo.findByIdKeyOrderByIdFieldSeq(key.name()).stream().map(s->s.getValue()).collect(Collectors.toList());
		 return new InductionMiscDTO(list);
	}

	public List<InductionMiscShortValueDTO> getInductionShortValue(InductionMiscKeys key) {
	    return repo.findByIdKeyOrderByIdFieldSeq(key.name()).stream().map(this::getDto).collect(Collectors.toList());
	}
	
	public List<InductionMiscShortValueDTO> getInductionShortValue(String engineType) {
		EngineTypeEntity et = engineTypeRepo.findById(engineType).orElseThrow(() -> new NotFoundException("Engine type not found: " + engineType));
		InductionMiscKeys key = InductionMiscKeys.ofEngineTypeName(et.getName());
		return getInductionShortValue(key);
	}

	public InductionMiscShortValuesDTO getInductionShortValues() {
		EnumMap<InductionMiscKeys, List<InductionMiscShortValueDTO>> map = new EnumMap<>(InductionMiscKeys.class);
	    
		for (InductionMiscKeys key : InductionMiscKeys.values()) {
			List<InductionMiscShortValueDTO> list = repo.findByIdKeyOrderByIdFieldSeq(key.name()).stream().map(this::getDto).collect(Collectors.toList());;
			map.put(key, list);
		}
		
		return new InductionMiscShortValuesDTO(map);
	}
	
	private InductionMiscShortValueDTO getDto(InductionMiscellaneousEntity entity) {
	    return InductionMiscShortValueDTO.builder().shortField(entity.getShorValue()).valueField(entity.getValue()).build();
	}

	public InductionValuesDTO getInductionValues() {
		EnumMap<InductionMiscKeys, List<String>> map = new EnumMap<>(InductionMiscKeys.class);
		for (InductionMiscKeys key : InductionMiscKeys.values()) {
			List<String> list = repo.findByIdKeyOrderByIdFieldSeq(key.name()).stream().map(s->s.getValue()).collect(Collectors.toList());
			map.put(key, list);
		}

		return new InductionValuesDTO(map);
	}
}
