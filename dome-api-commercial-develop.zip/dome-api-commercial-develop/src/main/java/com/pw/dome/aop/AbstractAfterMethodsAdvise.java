package com.pw.dome.aop;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;

import org.springframework.aop.AfterReturningAdvice;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractAfterMethodsAdvise<T, ID>
extends AbstractMethodsAdvice<T, ID>
implements AfterReturningAdvice {
	private final Map<String, Method> adviserMethods;

	public AbstractAfterMethodsAdvise() {
		adviserMethods = new TreeMap<>();

		Method[] adviceMethods = getClass().getDeclaredMethods();

		if (adviceMethods == null || adviceMethods.length == 0) {
			String msg = "No declared methods in advisor: " + getClass().getName();
			throw new RuntimeException(msg);
		}

		Stream.of(adviceMethods).filter(s->Modifier.isPublic(s.getModifiers()))
		                        .forEach(s->adviserMethods.put(getMethodSignature(s), s));

		log.debug("Advise cached for {}...\n    {}", getClass().getName(), adviceMethods);
	}

	@Override
	public void afterReturning(Object returnValue, Method repoMethod, Object[] args, Object jpaRepository)
			throws Throwable {
		// Validate JPA transaction isn't active.
//		Validate.isTrue(!TransactionSynchronizationManager.isActualTransactionActive());

		try {
			Method method;

			String sig = getReturnMethodSignature(repoMethod);
			if ((method = adviserMethods.get(sig)) == null) {
				// Generics type erasure?
				// CrudRepository.delete(T entity) becomes CrudRepository.delete(Object entity)
				String sig2 = getParameterizedReturnMethodSignature(repoMethod);

				boolean sameSig = sig.equals(sig2);

				if (sameSig || (method = adviserMethods.get(sig2)) == null) {
					String repo = repoMethod.getDeclaringClass().getName();
					log.debug("No JPA Repository advise after Method {}.{}", repo, sig);
					if (!sameSig) {
						log.debug("...AND No JPA Repository advise after Method {}.{}", repo, sig2);
					}

					return;
				}
			}

			Object[] afterMethodArgs = getReturnArgs(returnValue, args);
			method.invoke(this, afterMethodArgs); // Invoke the local return method
			if (log.isDebugEnabled()) {
				String repo = repoMethod.getDeclaringClass().getName();
				log.debug("Advise invoked after...\n  Args: {}\n  Repo: {}\n  Method: {}",
						  Arrays.toString(args), repo, sig);
			}
		} catch (Exception e) {
			String msg = String.format("%s() error, Args=%s", repoMethod.getName(), Arrays.toString(args));
			log.error(msg, e);
		}
	}

	// Prepend return Object to args array.
	private Object[] getReturnArgs(Object returnValue, Object[] args) {
		Object[] afterArgs = new Object[args == null ? 1 : args.length + 1];
		afterArgs[0] = returnValue;
		for (int i = 1; i < afterArgs.length; ++i) {
			afterArgs[i] = args[i - 1];
		}

		return afterArgs;
	}
}
