package com.pw.dome.engine;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.NaturalId;

import com.pw.dome.jpa.AbstractEntityWithNaturalId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "DOME_ENGINE_TRACKING_ARCHIVE")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EngineTrackingArchiveEntity extends AbstractEntityWithNaturalId<Long> {

	@Id
	@NaturalId
	@Column(name = "ARCHIVE_ID")
	private Long archiveID;

	@Column(name = "ENGTRACK_FORECAST_DATE")
	private LocalDateTime forecastDate;

	@Column(name = "ENGTRACK_ID")
	private Integer engtrackId;

	@Column(name = "ENGTRACK_EXT_ASSET_COMPLETE")
	private LocalDate engExternalAssetCompleteDate;

	@Column(name = "ENGTRACK_ACTUAL_CORE_ASSEMBLY")
	private LocalDate engineActualCoreAssemblyDate;

	@Column(name = "ENGTRACK_ACTUAL_SHIP_TO_CUST")
	private LocalDate engineActualShipToCustDate;

	@Column(name = "ENGTRACK_EXT_CONTRACT")
	private LocalDate engineExternalContractDate;

	@Column(name = "ENGTRACK_EXT_CORE_ASSEMBLY")
	private LocalDate engineExternalCoreAssemblyDate;

	@Column(name = "ENGTRACK_EXT_GATE1_CLOSE")
	private LocalDate engineExternalGate1CloseDate;

	@Column(name = "ENGTRACK_EXT_GATE3_CLOSE")
	private LocalDate engineExternalGate3CloseDate;

	@Column(name = "ENGTRACK_EXT_GATE3_START")
	private LocalDate engineExternalGate3StartDate;

	@Column(name = "ENGTRACK_EXT_INDUCT_DATE")
	private LocalDate engineExternalInductDate;

	// External dates...
	@Column(name = "ENGTRACK_EXT_RECEIPT_DATE")
	private LocalDate engineExternalReceiptDate;

	@Column(name = "ENGTRACK_EXT_RECEIVING_DATE")
	private LocalDate engineExternalReceiveDate;

	@Column(name = "ENGTRACK_EXT_SHIP")
	private LocalDate engineExternalShipDate;

	@Column(name = "ENGTRACK_EXT_SHIP_TO_CUST")
	private LocalDate engineExternalShipToCustDate;

	@Column(name = "ENGTRACK_EXT_TEST_COMPLETE")
	private LocalDate engineExternalTestCompleteDate;

	@Column(name = "ENGTRACK_EXT_TEST_START")
	private LocalDate engineExternalTestStartDate;

	@Column(name = "ENGTRACK_PLAN_CORE_ASSEMBLY")
	private LocalDate enginePlanCoreAssemblyDate;

	@Column(name = "ENGTRACK_PLAN_SHIP_TO_CUST")
	private LocalDate enginePlanShipToCustDate;

	@Column(name = "ENGTRACK_ACTUAL_GATE3_CLOSE")
	private LocalDate engtrackActualGate3Close;

	@Column(name = "ENGTRACK_ACTUAL_KIT_COMPLETE")
	private LocalDate engtrackActualKitComplete;

	@Column(name = "ENGTRACK_ACTUAL_RECEIVING_DATE")
	private LocalDate engtrackActualReceivingDate;

	@Column(name = "ENGTRACK_ACTUAL_TEST_COMPLETE")
	private LocalDate engtrackActualTestComplete;

	@Column(name = "ENGTRACK_CONTRACT_DATE")
	private LocalDate engtrackContractDate;

	@Column(name = "ENGTRACK_GATE3_ACT")
	private LocalDate engtrackGate3Act;

	@Column(name = "ENGTRACK_HOLD_DAY")
	private Integer engtrackHoldDay;

	@Column(name = "ENGTRACK_HOLDDAY2")
	private Integer engtrackHoldday2;

	@Column(name = "ENGTRACK_HOLDDAY3")
	private Integer engtrackHoldday3;

	@Column(name = "ENGTRACK_IND_DATE")
	private LocalDate engtrackIndDate;

	// @Column(name="ENGTRACK_ISOPPORTUNITY​")
	private Integer engtrackIsopportunity;
	// @Column(name="CORE_ASSEMBLY_DATE")
	// private LocalDate coreAssemblyDate;

	@Column(name = "ENGTRACK_MPSDISPL", columnDefinition = "char")
	private String engtrackMpsdispl;

	@Column(name = "ENGTRACK_PLAN_ENG_COMPLETE")
	private LocalDate engtrackPlanEngComplete;

	@Column(name = "ENGTRACK_PLAN_GATE3_CLOSE_DATE")
	private LocalDate engtrackPlanGate3CloseDate;

	@Column(name = "ENGTRACK_PLAN_IND_DATE")
	private LocalDate engtrackPlanIndDate;

	@Column(name = "ENGTRACK_PLAN_KIT_COMPLETE")
	private LocalDate engtrackPlanKitComplete;

	@Column(name = "ENGTRACK_PLAN_REC_DATE")
	private LocalDate engtrackPlanRecDate;

	@Column(name = "ENGTRACK_PLAN_RECEIVING_DATE")
	private LocalDate engtrackPlanReceivingDate;

	@Column(name = "ENGTRACK_PLAN_REMOVAL_DATE")
	private LocalDate engtrackPlanRemovalDate;

	@Column(name = "ENGTRACK_PLAN_REV_DATE")
	private LocalDate engtrackPlanRevDate;

	@Column(name = "ENGTRACK_PLAN_TEST_START_DATE")
	private LocalDate engtrackPlanTestStartDate;

	@Column(name = "ENGTRACK_PLN_SHIP_DATE")
	private LocalDate engtrackPlnShipDate;
	@Column(name = "ENGTRACK_REC_DATE")
	private LocalDate engtrackRecDate;
	@Column(name = "ENGTRACK_REMOVAL")
	private LocalDate engtrackRemoval;
	@Column(name = "ENGTRACK_REV_CONTRACT_DATE")
	private LocalDate engtrackRevContractDate;
	@Column(name = "ENGTRACK_REV_SHIP_DATE")
	private LocalDate engtrackRevShipDate;
	@Column(name = "ENGTRACK_SHIP_DATE")
	private LocalDate engtrackShipDate;
	@Column(name = "ENGTRACK_SHIPMENT_DATE")
	private LocalDate engtrackShipmentDate;
	@Column(name = "ENGTRACK_SHIP_TO_EC")
	private LocalDate engtrackShipToEc;
	@Column(name = "ENGTRACK_WIP_INCL", columnDefinition = "char")
	private String engtrackWipIncl;

	@Column(name = "ENGTRACK_WORK_ORDER")
	private String engtrackWorkOrder;
	@Column(name = "ENGTRACK_EXT_KIT_COMPLETE")
	private LocalDate engtrackWorkOrderExtKitComplete;

	@Column(name = "GATE3_COMPLETE")
	private LocalDate gate3Complete;
	@Column(name = "GATE3_PLAN")
	private LocalDate gate3Plan;
	@Column(name = "GATE3_PLAN_COMPLETE")
	private LocalDate gate3PlanComplete;
	@Column(name = "MAIL_STATUS")
	private BigDecimal mailStatus;
	@Column(name = "TEST_DATE")
	private LocalDate testDate;
	@Column(name = "TEST_PLAN_COMPLETE")
	private LocalDate testPlanComplete;

	@Column(name = "STANDARD_REMOVE_DATE")
	private LocalDate standardRemoveDate;
	@Column(name = "STANDARD_RECEIPT_DATE")
	private LocalDate standardReceiptDate;
	@Column(name = "STANDARD_INDUCT_DATE")
	private LocalDate standardInductionDate;
	@Column(name = "STANDARD_G1CLOSE_DATE")
	private LocalDate standardG1CloseDate;
	@Column(name = "STANDARD_KIT_DATE")
	private LocalDate standardKitDate;
	@Column(name = "STANDARD_G3START_DATE")
	private LocalDate standardG3StartDate;
	@Column(name = "STANDARD_ASSEMBLY_DATE")
	private LocalDate standardAssemblyDate;
	@Column(name = "STANDARD_G3CLOSE_DATE")
	private LocalDate standardG3CloseDate;
	@Column(name = "STANDARD_TEST_START_DATE")
	private LocalDate standardTestStartDate;
	@Column(name = "STANDARD_TEST_COMPLETE_DATE")
	private LocalDate standardTestCompleteDate;
	@Column(name = "STANDARD_CONTRACT_DATE")
	private LocalDate standardContractDate;
	@Column(name = "STANDARD_ASSET_COMPLETE_DATE")
	private LocalDate standardAssetCompleteDate;
	@Column(name = "STANDARD_SHIP_DATE")
	private LocalDate standardShipDate;
	@Column(name = "STANDARD_SHIP_TO_CUST_DATE")
	private LocalDate standardShipToCustDate;
	@Column(name = "STANDARD_RECEIVE_DATE")
	private LocalDate standardReceiveDate;
	@Column(name = "ARCHIVE_UPDATE_USER")
	private String archiveUpdateUser;

	@Override
	public Long getId() {
		return archiveID;
	}
}
