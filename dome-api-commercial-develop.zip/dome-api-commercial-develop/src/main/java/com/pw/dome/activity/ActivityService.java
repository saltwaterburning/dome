package com.pw.dome.activity;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.exception.GenericJDBCException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.exception.NotFoundException;

@Service
public class ActivityService {

    @Autowired
    private ActivityRepo activityRepo;
    
    @Transactional(propagation = Propagation.REQUIRES_NEW, noRollbackFor = GenericJDBCException.class)
    public void saveActivity(ActivityEntity request) {
        activityRepo.save(request);
    }
    
    public List<Activity> findAll() {
        List<ActivityEntity> activities = activityRepo.findAll();
        if (activities.isEmpty()) {
            throw new NotFoundException("No activities found in the database");
        }

        return activities.stream().map( x -> toActivity(x)).collect(Collectors.toList());
    }
    
    public Activity save(Activity request) {
            
        ActivityEntity entity = toActivityEntity(request);
        return toActivity(activityRepo.save(entity));
    }
    
    private Activity toActivity(final ActivityEntity request) {
        return Activity.builder()
                              .activityId(request.getActivityId())
                              .item(request.getItem())
                              .activityDate(request.getActivityDate().toString())
                              .engineCenterId(request.getEngineCenterId())
                              .engineType(request.getEngineType())
                              .engineGroup(request.getEngineGroup())
                              .engineModel(request.getEngineModel())
                              .engineModule(request.getEngineModule())
                              .engineSerialNumber(request.getEngineSerialNumber())
                              .customerID(request.getCustomerID())
                              .userEmail(request.getUserEmail())
                              .type(request.getType())
                              .description(request.getDescription())
                              .build();
    }
    
    private ActivityEntity toActivityEntity(final Activity request) {
        return ActivityEntity.builder()
                              .item(request.getItem())
                              .activityDate(LocalDateTime.now())
                              .engineCenterId(request.getEngineCenterId())
                              .engineType(request.getEngineType())
                              .engineGroup(request.getEngineGroup())
                              .engineModel(request.getEngineModel())
                              .engineModule(request.getEngineModule())
                              .engineSerialNumber(request.getEngineSerialNumber())
                              .customerID(request.getCustomerID())
                              .userEmail(request.getUserEmail())
                              .type(request.getType())
                              .description(request.getDescription())
                              .build();
    }
}
