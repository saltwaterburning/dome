package com.pw.dome.engine.removed.notinducted.excel;

import static com.pw.dome.engine.removed.notinducted.excel.Consts.SQL.REMOVED_NOT_INDUCTED;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pw.dome.engine.removed.EngineRemovedEntity;

@Repository
interface EngineRemovedNotInductedRepository extends JpaRepository<EngineRemovedEntity, Integer> {
	
		@Query(value = REMOVED_NOT_INDUCTED)
		List<EngineRemovedNotInducted> getEngineRemovedNotInducted(@Param("ignoreEngType") final boolean ignoreEngType, 
																	@Param("engType") final List<String> engType,
																	@Param("ignoreCustId") final boolean ignoreCustId,
																	@Param("custId") final List<String> custId);

}
