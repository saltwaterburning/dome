package com.pw.dome.customer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.wip.WipRequest;


@RestController()
@RequestMapping("/v1/customers")
public class CustomerController {
	@Autowired
	private CustomerService customerService;

	/**
	 * @api {get} /v1/customers/ Get Customers
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/customers
     *           --header 'Authorization: Bearer [jwt]' 
     * @apiName getCustomerList
     * @apiGroup Customers
     * @apiDescription Returns a list of customers in alpha-order
     * @apiSuccess {Object[]} customers An array customers 
     * @apiSuccess {String} customers.customerID The Customer ID
     * @apiSuccess {String} customers.name The full name of the customer
     * @apiSuccess {String} customers.shortName The short version of the customer name
     * @apiSuccess {String} customers.region The region of the customer
     * @apiUse GetCustomersSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/
    @RequestMapping(method = RequestMethod.GET)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<CustomerListResponse> getCustomerList() {
    	
    	List<CustomerEntity> customers = customerService.findAllOrderByName();
    	List<CustomerDTO> dtos = DataMapper.INSTANCE.toDTO(customers);
    	return ResponseEntity.ok(CustomerListResponse.builder().customers(dtos).build());
    }
    
    @PostMapping
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<CustomerListResponse> getCustomerList(@RequestBody WipRequest request) {
    	List<CustomerEntity> customers = customerService.findAllOrderByName();
    	List<CustomerDTO> dtos = DataMapper.INSTANCE.toDTO(customers);
    	return ResponseEntity.ok(CustomerListResponse.builder().customers(dtos).build());
    }
}
