package com.pw.dome.mml;

import static com.pw.dome.mml.MonthlyConsts.SQL.MONTHLY_MML_INDUCTION_DATA;
import static com.pw.dome.mml.MonthlyConsts.SQL.MONTHLY_MML_PLAN_INDUCTION_DATA;
import static com.pw.dome.mml.MonthlyConsts.SQL.MONTHLY_MML_PLAN_REVENUE_DATA;
import static com.pw.dome.mml.MonthlyConsts.SQL.MONTHLY_MML_PLAN_SHIPMENT_DATA;
import static com.pw.dome.mml.MonthlyConsts.SQL.MONTHLY_MML_REVENUE_DATA;
import static com.pw.dome.mml.MonthlyConsts.SQL.MONTHLY_MML_SHIPMENT;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
interface MmlMonthlyRepository extends JpaRepository<MmlMonthlyEntity, Integer> {

    // Monthly MML Induction Data
	@Query(MONTHLY_MML_INDUCTION_DATA)
    List<MmlEntity> getMmlMonthlyInductionData(@Param("planMonth") final int planMonth,
											   @Param("planYear") final int planYear, 
											   @Param("ecid") final String ecid, 
											   @Param("engineGroupIds") final List<String> engineGroups, 
											   @Param("planType") final PlanType planType, 
											   @Param("planMarket") final PlanMarket planMarket);
	// Monthly MML Revenue Data
    @Query(MONTHLY_MML_REVENUE_DATA)
    List<MmlEntity> getMmlMonthlyRevenueData(@Param("planMonth") final int planMonth,
                                             @Param("planYear") final int planYear, 
                                             @Param("ecid") final String ecid, 
                                             @Param("engineGroupIds") final List<String> engineGroups, 
                                             @Param("planType") final PlanType planType, 
                                             @Param("planMarket") final PlanMarket planMarket);

   // Monthly MML Shipment Data
    @Query(MONTHLY_MML_SHIPMENT)
    List<MmlEntity> getMmlMonthlyShipmentData(@Param("planMonth") final int planMonth,
                                              @Param("planYear") final int planYear, 
                                              @Param("ecid") final String ecid, 
                                              @Param("engineGroupIds") final List<String> engineGroups, 
                                              @Param("planType") final PlanType planType, 
                                              @Param("planMarket") final PlanMarket planMarket);

    // Monthly MML Induction Plan Data
    @Query(MONTHLY_MML_PLAN_INDUCTION_DATA)
    List<MmlEntity> getMmlMonthlyPlanInductionData(@Param("ecid") final String ecid, 
                                                   @Param("engineGroupIds") final List<String> engineGroups, 
                                                   @Param("planType") final PlanType planType, 
                                                   @Param("planMarket") final PlanMarket planMarket, 
                                                   @Param("planYear") final int planYear);

    // Monthly MML Revenue Plan Data
    @Query(MONTHLY_MML_PLAN_REVENUE_DATA)
    List<MmlEntity> getMmlMonthlyPlanRevenueData(@Param("ecid") final String ecid, 
                                                 @Param("engineGroupIds") final List<String> engineGroups, 
                                                 @Param("planType") final PlanType planType, 
                                                 @Param("planMarket") final PlanMarket planMarket, 
                                                 @Param("planYear") final int planYear);

   // Monthly MML Shipment Plan Data
    @Query(MONTHLY_MML_PLAN_SHIPMENT_DATA)
    List<MmlEntity> getMmlMonthlyPlanShipmentData(@Param("ecid") final String ecid, 
												  @Param("engineGroupIds") final List<String> engineGroups, 
												  @Param("planType") final PlanType planType, 
												  @Param("planMarket") final PlanMarket planMarket, 
												  @Param("planYear") final int planYear);

    @Modifying
    @Query(value="DELETE from MmlMonthlyEntity mmlMonthlyEntity where mmlMonthlyEntity.engineId = :engineId")
    Integer deleteByEngineId(@Param("engineId") Integer engineId);
    
    @Modifying
    @Query(value="DELETE from MmlMonthlyEntity mmlMonthlyEntity where mmlMonthlyEntity.planMarket = :planMarket and mmlMonthlyEntity.planType = :planType and mmlMonthlyEntity.engineId in :engineIds")
    Integer deleteByEngineIds(@Param("planMarket") final PlanMarket planMarket, @Param("planType") final PlanType planType, @Param("engineIds") final List<Integer> engineIds);

}
