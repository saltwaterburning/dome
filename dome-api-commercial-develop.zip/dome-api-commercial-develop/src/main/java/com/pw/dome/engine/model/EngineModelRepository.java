package com.pw.dome.engine.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * @author John De Lello
 */
@Repository
public interface EngineModelRepository extends JpaRepository<EngineModelEntity, String> {

	@Query(value = "SELECT e FROM EngineModelEntity e WHERE e.engineGroupID IN(SELECT engineGroupId FROM SecurityEngineCenterEntity s where lower(emailAddress) = lower(?1) AND s.engineCenterId =?2) AND e.engineGroupID = ?3 AND e.active = true  ORDER BY e.name")
	List<EngineModelEntity> getEngineModels(final String userEmailID, final String engineCenterID, final String engineGroupID);

	@Query(value = "SELECT e FROM EngineModelEntity e WHERE e.engineGroupID IN(SELECT engineGroupId FROM SecurityEngineCenterEntity s where lower(emailAddress) = lower(?1) AND s.engineCenterId =?2) AND e.active = true ORDER BY e.name")
	List<EngineModelEntity> getEngineModels(final String userEmailID, final String engineCenterID);

	@Query(value = "SELECT dome_eng_mod_id_seq.nextval FROM dual", nativeQuery = true)
	Long getNextSeqVal();

	@Query(value = "SELECT * FROM dome_eng_mod_mst WHERE eng_mod_action = 'A' AND eng_group_id = ?1 ORDER BY eng_mod_name", nativeQuery = true)
    List<EngineModelEntity> getActiveEngineModels(final String groupId);

	@Query(value = "SELECT * FROM dome_eng_mod_mst WHERE eng_group_id = ?1 ORDER BY eng_mod_name", nativeQuery = true)
    List<EngineModelEntity> getAllEngineModels(final String groupId);

	@Modifying
	@Query(value = "UPDATE EngineModelEntity x SET x.active = ?1 WHERE x.active != ?1 AND x.engineGroupID = ?2 AND x.engineModelID = ?3")
	int setAction(final boolean active, final String groupId, final String modelId);
}
