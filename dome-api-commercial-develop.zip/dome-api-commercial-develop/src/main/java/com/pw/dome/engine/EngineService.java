package com.pw.dome.engine;

import static com.pw.dome.engine.Consts.DEFAULT_SHIPMENT_TYPE;
import static com.pw.dome.engine.Consts.INVESTIGATION_CATEGORY_DEFAULT;
import static com.pw.dome.engine.Consts.NORTH_AMERICA;
import static com.pw.dome.util.Messages.engAssetNotFoundUsingEngAssetId;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.equalsIgnoreCase;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.Constants;
import com.pw.dome.calendar.CalendarService;
import com.pw.dome.calendar.induction.CalendarEngine;
import com.pw.dome.calendar.induction.CalendarShopVisit;
import com.pw.dome.calendar.slots.ShopVisitType;
import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.calendar.slots.SlotRepository;
import com.pw.dome.calendar.slots.SlotService;
import com.pw.dome.customer.CustomerEntity;
import com.pw.dome.customer.CustomerService;
import com.pw.dome.engine.asset.AddEngineToSlotRequest;
import com.pw.dome.engine.asset.AddToSlotByCustomerRequest;
import com.pw.dome.engine.asset.EngineAssetEntity;
import com.pw.dome.engine.asset.EngineAssetRepository;
import com.pw.dome.engine.events.EngineEventEntity;
import com.pw.dome.engine.events.EngineEventRepository;
import com.pw.dome.engine.manual.AddManualEngineToSlotRequest;
import com.pw.dome.engine.manual.UpdateManualEngineRequest;
import com.pw.dome.engine.odin.EngineOdinRepository;
import com.pw.dome.engine.odin.OdinEntity;
import com.pw.dome.engine.odin.history.OdinHistoryEntity;
import com.pw.dome.engine.odin.history.OdinHistoryRepository;
import com.pw.dome.engine.tracking.EngineTrackingEntity;
import com.pw.dome.engine.tracking.EngineTrackingService;
import com.pw.dome.engine.type.EngineTypeEntity;
import com.pw.dome.engine.type.EngineTypeRepository;
import com.pw.dome.enginecenter.EngineCenterEntity;
import com.pw.dome.enginecenter.EngineCenterRepository;
import com.pw.dome.exception.BadRequestException;
import com.pw.dome.exception.ConflictException;
import com.pw.dome.exception.NotFoundException;
import com.pw.dome.external.mro.collab.client.MroWebClientAsyncService;
import com.pw.dome.module.ModuleAssetEntity;
import com.pw.dome.module.ModuleAssetEntityPK;
import com.pw.dome.module.ModuleAssetRepository;
import com.pw.dome.user.UserProfile;

import lombok.extern.slf4j.Slf4j;

/**
 * @author John De Lello
 */
@Service
@Slf4j
public class EngineService {
  @Autowired
  private CalendarService calendarService;
  @Autowired
  private CustomerService customerService;
  @Autowired
  private EngineAssetRepository engineAssetRepo;
  @Autowired
  private EngineCenterRepository ecRepo;
  @Autowired
  private EngineEventRepository engineEventRepo;
  @Autowired
  private EngineOdinRepository odinRepo;
  @Autowired
  private EngineRepository engineRepo;
  @Autowired
  private EngineTrackingService engineTrackingService;
  @Autowired
  private EngineTypeRepository engTypeRepo;
  @PersistenceContext
  private EntityManager entityManager;
  @Autowired
  private ModuleAssetRepository moduleRepo;
  @Autowired
  private MroWebClientAsyncService mroSvc;
  @Autowired
  private OdinHistoryRepository odinHistoryRepo;
  @Autowired
  private SlotRepository slotRepo;
  @Autowired
  private SlotService slotService;

  LocalDate getSmiNeedDate(SlotEntity slot) {
    if (isNull(slot)) {
      return null;
    }

    EngineCenterEntity engineCenter = ecRepo.findById(slot.getEngineCenterID())
        .orElse(new EngineCenterEntity());
    LocalDate planInductDate = slot.getCaldate();

    int offset = 11;
    if (equalsIgnoreCase(engineCenter.getLocation(), NORTH_AMERICA)) {
      offset = 10;
    }

    LocalDate smiNeedDate = planInductDate.minusDays(offset);
    DayOfWeek weekDay = smiNeedDate.getDayOfWeek();

    if (weekDay == DayOfWeek.SATURDAY) {
      smiNeedDate = smiNeedDate.minusDays(1);
    } else if (weekDay == DayOfWeek.SUNDAY) {
      smiNeedDate = smiNeedDate.minusDays(2);
    }

    log.debug("SMI Need Date: {}, Offset: {}, SlotId: {}, planInductDate: {}",
        smiNeedDate,
        offset,
        slot.getId(),
        planInductDate);
    return smiNeedDate;
  }

  /**
   * The add engine should be adding a unique esn event Id. If the engine is on wing it won�t have
   * an event id but we shouldn�t add a second null event to the same esn. This is true for the
   * edata engines. The non edata engines do not have events and are added manually. They are
   * allowed dups.
   * 
   * @param userProfile
   * @param slotID
   * @param engineAssetID
   * @param request
   * @return
   */
  @Transactional
  public CalendarShopVisit addEngineAssetToSlotByEngine(final UserProfile userProfile,
      final AddEngineToSlotRequest request) {
    int engineAssetID = request.getEngineAssetID();
    int slotID = request.getSlotID();

//	CustomerCenterMatrix customerCenterMatrix = adminService.getCustomerCenterMatrix(request.getCustomerId(), request.getEngineCenterId(), request.getEngineTypeId());
//	if (isNull(customerCenterMatrix)) {
//	      log.error("Customer : {}, Engine Type : {}, Engine Center :{} - Combination not in Matrix. Engine cannot be added.",
//	    		  request.getCustomerId(), request.getEngineCenterId(), request.getEngineTypeId());
//	      throw new NotFoundException(
//	          "Customer, Engine Type, Engine Center Combination not in Matrix. Engine cannot be added.");
//	}

    EngineAssetEntity engineAsset = engineAssetRepo.findById(engineAssetID)
        .orElseThrow(() -> new NotFoundException(engAssetNotFoundUsingEngAssetId(engineAssetID)));

    EngineEventEntity engEvent;
    if (engineAsset.isPlanned()) {
//    	if (nonNull(engEvent.getSlotId())) {
      String msg = String.format(
          "The specified engine asset ID [%s] is already slotted in slot ID [%s]. Unable to use this engine asset again.",
          engineAssetID,
          slotID);
      log.error(msg);
      throw new ConflictException("Can't SlotEntity Engine. Engine already slotted.");
    } else {
      engineAsset.setPlanned(true);
      engineAsset.setSlotId(slotID);
      engineAssetRepo.save(engineAsset);
    }

    Integer eventId = request.getEventId();

    if (nonNull((engEvent = engineEventRepo.findByPkEsnAndPkEventId(engineAsset.getEsn(), eventId)))) {
      engEvent.setPlanned(true);
      engEvent.setSlotId(slotID);
      engineEventRepo.saveAndFlush(engEvent);
    }

//    } else { // ToDo
//    	EngineEventEntityPK pk = EngineEventEntityPK.builder().esn(engineAsset.getEsn()).eventId(eventId).build();
//    	log.warn("Creating EngineEventEntity; engineAssetID={}, slotId={}", engineAssetID, slotID);
//    	engEvent = AuditHelper.INSTANCE.toEngineEntity(pk, request, engineAsset, slotID);

    SlotEntity slot = slotService.getSlotByID(userProfile, slotID);

    EngineEntity newEngine = DataMapper.INSTANCE.toEngine(engineAsset,
        userProfile.getEmailAddress(),
        false,
        request,
        Consts.ENGINE_REVENUE_DEFAULT,
        DEFAULT_SHIPMENT_TYPE);

//    EngineEntity newEngine = EngineEntity.builder().assetID(engineAsset.getAssetID())
//                                                   .category(request.getCategory())
//                                                   .customerID(engineAsset.getOperatorID())
//                                                   .esn(engineAsset.getEsn())
//                                                   .eventId(eventId)
//                                                   .groupID(engineAsset.getEngineGroupID())
//                                                   .logEmail(userProfile.getEmailAddress())
//                                                   .manualEngine(false)
//                                                   .modelID(engineAsset.getEngineModelID())
//                                                   .salesOrderType(request.getSalesOrderType())
//                                                   .shipmentType(DEFAULT_SHIPMENT_TYPE)
//                                                   .slotID(slotID)
//                                                   .build();
    //@formatter:on

    newEngine = engineRepo.saveAndFlush(newEngine);
    entityManager.detach(newEngine);

    LocalDate removalDate = null;
    if (nonNull(eventId)) {
      removalDate = engineAsset.getRemovalDate();
    }

  //@formatter:off
    EngineTrackingEntity newEngineTrack = EngineTrackingEntity.builder()
    		                                                  .engtrackId(newEngine.getEngineID())
    		                                                  .engtrackPlanIndDate(toLocalDate(slot.getYear(), slot.getMonth(), slot.getDay()))
    		                                                  .engtrackRemoval(removalDate)
    		                                                  .build();
    //@formatter:on

    newEngineTrack = engineTrackingService.save(newEngineTrack);

    Integer odinId = request.getOdinId();
    String esn = engineAsset.getEsn();
    Integer engId = newEngine.getEngineID();
    OdinEntity odin = getExistingOrNewOdinRecord(odinId, esn, engId, eventId);

    odin.setInvestigationCategory(INVESTIGATION_CATEGORY_DEFAULT);
    String ecId = slot.getEngineCenterID();
    odin.setMaintenanceCenter(ecId);
    LocalDate smiNeedDate = getSmiNeedDate(slot);
    odin.setSmiNeedDate(smiNeedDate);

    odinRepo.save(odin);

    // Add record to OdinHistory table
  //@formatter:off
    OdinHistoryEntity entity = OdinHistoryEntity.builder().engineId(newEngine.getEngineID())
                                                          .esn(newEngine.getEsn())
                                                          .eventId(newEngine.getEventId())
                                                          .logEmail(userProfile.getEmailAddress())
                                                          .prelimInductionDate(slot.getCaldate())
                                                          .updateDate(LocalDate.now())
                                                          .build();
    //@formatter:on
    odinHistoryRepo.save(entity);

    // Everything saved OK, so prepare the response now.
    CalendarShopVisit calendarShopVisit = calendarService.getCalendarShopVisitForSlotID(userProfile,
        slotID);

    return calendarShopVisit;
  }

  /**
   * Used from Induction Calendar page for manual engines (non eData). See DOME_ENG_TYPE_MST
   * IN_EDATA.
   * 
   * @param userProfile
   * @param slotID
   * @param addManualEngineToSlotRequest
   * @return
   */
  @Transactional
  public CalendarShopVisit addManualEngineToSlot(final UserProfile userProfile,
      final int slotID,
      final AddManualEngineToSlotRequest addManualEngineToSlotRequest) {
    if (isNull(addManualEngineToSlotRequest)) {
      log.error(
          "Invalid addManualEngineToSlotRequest was spcified. Unable to add manual engine to slot ID [{}]",
          slotID);
      throw new BadRequestException(
          "Invalid parameters. Unable to add manual engine to slot ID [" + slotID + "]");
    }

    if (StringUtils.isEmpty(addManualEngineToSlotRequest.getCategory())) {
      log.error("Invalid category was specified. Unable to add manual engine to slot ID [{}]",
          slotID);
      throw new BadRequestException(
          "Invalid category was specified. Unable to add manual engine to slot ID [" + slotID
              + "]");
    }

    if (StringUtils.isEmpty(addManualEngineToSlotRequest.getSalesOrderType())) {
      log.error(
          "Invalid Sales Order Type was specified. Unable to add manual engine to slot ID [{}]",
          slotID);
      throw new BadRequestException(
          "Invalid Sales Order Type was specified was specified. Unable to add manual engine to slot ID ["
              + slotID + "]");
    }

    SlotEntity slot = slotService.getSlotByID(userProfile, slotID);
    entityManager.detach(slot);
    log.debug("Successfully retrieved slot ID [{}]", slotID);

    if (ShopVisitType.HEAVY == slot.getShopVisitType()) {
      if (!addManualEngineToSlotRequest.getCategory().equals("H")) {
        log.error(
            "Invalid Category was specified. A Heavy slot can only accept category 'H'. Unable to add manual engine to slot ID ["
                + slotID + "]");
        throw new BadRequestException(
            "Invalid Category was specified. A Heavy slot can only accept category 'H'. Unable to add manual engine to slot ID ["
                + slotID + "]");
      }
    } else if (ShopVisitType.MEDIUM == slot.getShopVisitType()) {
      if (!addManualEngineToSlotRequest.getCategory().equals("M")) {
        log.error(
            "Invalid Category was specified. A Medium slot can only accept category 'M'. Unable to add manual engine to slot ID ["
                + slotID + "]");
        throw new BadRequestException(
            "Invalid Category was specified. A Medium slot can only accept category 'M'. Unable to add manual engine to slot ID ["
                + slotID + "]");
      }
    } else if (ShopVisitType.LIGHT == slot.getShopVisitType()) {
      if (!addManualEngineToSlotRequest.getCategory().equals("L")
          && !addManualEngineToSlotRequest.getCategory().equals("T")) {
        log.error(
            "Invalid Category spcified was specified. A Light slot can only accept category 'L' or 'T'. Unable to add manual engine to slot ID ["
                + slotID + "]");
        throw new BadRequestException(
            "Invalid Category was specified. A Light slot can only accept category 'L' or 'T'. Unable to add manual engine to slot ID ["
                + slotID + "]");
      }
    }

//    String customerID = addManualEngineToSlotRequest.getCustomerID();
    String engineEsn = addManualEngineToSlotRequest.getEsn();

//    if (StringUtils.isEmpty(addManualEngineToSlotRequest.getCustomerID())) {
//      customerID = NO_CUSTOMER_ESN;
//    } else {
//      Customer customer =
//          customerService.getCustomerByID(addManualEngineToSlotRequest.getCustomerID());
//      entityManager.detach(customer);
//      log.debug("Successfully retrieved customer ID [{}]",
//          addManualEngineToSlotRequest.getCustomerID());
//      customerID = customer.getCustomerID();
//    }
//
//    if (StringUtils.isEmpty(addManualEngineToSlotRequest.getEsn())) {
//      engineEsn = NO_ENGINE_ESN;
//    } else {
//      engineEsn = addManualEngineToSlotRequest.getEsn();
//    }

//    if (nonNull(request)) {
//        engineEntity.groupID( request.getEngineGroupID() );
//        engineEntity.modelID( request.getEngineModelID() );
//        engineEntity.category( request.getCategory() );
//        engineEntity.customerID( request.getCustomerID() );
//        engineEntity.esn( request.getEsn() );
//        engineEntity.salesOrderType( request.getSalesOrderType() );
//        engineEntity.subVisitType( request.getSubVisitType() );
//    }
//    engineEntity.logEmail( logEmail );
//    engineEntity.manualEngine( true );

    EngineEntity newEngine = DataMapper.INSTANCE.toEngine(addManualEngineToSlotRequest,
        slotID,
        slot.getEngineTypeID(),
        userProfile.getEmailAddress(),
        DEFAULT_SHIPMENT_TYPE);

    log.debug("About to save to engine table");
    newEngine = engineRepo.saveAndFlush(newEngine);
    entityManager.detach(newEngine);
    log.debug("Successfully saved to engine table. New Engine ID is [{}]", newEngine.getEngineID());

  //@formatter:off
    EngineTrackingEntity newEngineTrack = EngineTrackingEntity.builder().engtrackId(newEngine.getEngineID())
                                                                        .engtrackPlanIndDate(toLocalDate(slot.getYear(), slot.getMonth(), slot.getDay()))
                                                                        .build();
    //@formatter:on

    log.debug("About to save to engine tracking table");
    newEngineTrack = engineTrackingService.save(newEngineTrack);
    entityManager.detach(newEngineTrack);

    log.debug("Successfully saved to engine tracking table. New Engine tracking ID is [{}]",
        newEngine.getEngineID());

    OdinEntity odin = getExistingOrNewOdinRecord(null, engineEsn, newEngine.getEngineID(), null);
    odinRepo.save(odin);

    // Everything saved OK, so prepare the response now.
    CalendarShopVisit calendarShopVisit = calendarService.getCalendarShopVisitForSlotID(userProfile,
        slotID);

    return calendarShopVisit;
  }

  @Transactional
  public CalendarShopVisit addToSlotByCustomer(UserProfile userProfile,
      Integer slotID,
      AddToSlotByCustomerRequest addToSlotByCustomerRequest) {
    /*
     * if(StringUtils.isEmpty(addToSlotByCustomerRequest.getCategory())){ log.
     * error("Invalid category was specified. Unable to add engine to slot ID [{}]", slotID); throw
     * new BadRequestException("Invalid category was specified. Unable to add engine to slot ID [" +
     * slotID + "]"); }
     * 
     * if(StringUtils.isEmpty(addToSlotByCustomerRequest.getSalesOrderType())){ log.
     * error("Invalid Sales Order Type was specified. Unable to add engine to slot ID [{}]" ,
     * slotID); throw new
     * BadRequestException("Invalid Sales Order Type was specified was specified. Unable to add engine to slot ID ["
     * + slotID + "]"); }
     */
    CustomerEntity customer = customerService
        .getCustomerByID(addToSlotByCustomerRequest.getCustomerID());
    entityManager.detach(customer);
    log.debug("Successfully retrieved customer ID [{}]",
        addToSlotByCustomerRequest.getCustomerID());

    SlotEntity slot = slotService.getSlotByID(userProfile, slotID);
    entityManager.detach(slot);
    log.debug("Successfully retrieved slot ID [{}]", slotID);

    EngineEntity newEngine = DataMapper.INSTANCE.toEngine(addToSlotByCustomerRequest,
        slotID,
        slot.getEngineTypeID(),
        Constants.NO_ENGINE_ESN,
        userProfile.getEmailAddress(),
        DEFAULT_SHIPMENT_TYPE);

    log.debug("About to save to engine table");
    newEngine = engineRepo.saveAndFlush(newEngine);
    entityManager.detach(newEngine);
    log.debug("Successfully saved to engine table. New Engine ID is [{}]", newEngine.getEngineID());

  //@formatter:off
    EngineTrackingEntity newEngineTrack = EngineTrackingEntity.builder().engtrackId(newEngine.getEngineID())
                                                                        .engtrackPlanIndDate(toLocalDate(slot.getYear(), slot.getMonth(), slot.getDay()))
                                                                        .build();
    //@formatter:on

    log.debug("About to save to engine tracking table");
    newEngineTrack = engineTrackingService.save(newEngineTrack);
    entityManager.detach(newEngineTrack);

    log.debug("Successfully saved to engine tracking table. New Engine tracking ID is [{}]",
        newEngine.getEngineID());

    String ecId = slot.getEngineCenterID();
    Integer engId = newEngine.getEngineID();

    LocalDate smiNeedDate = getSmiNeedDate(slot);

    OdinEntity odin = getExistingOrNewOdinRecord(null, Constants.NO_ENGINE_ESN, engId, null);
    odin.setMaintenanceCenter(ecId);
    odin.setSmiNeedDate(smiNeedDate);
    odinRepo.save(odin);

    // Add record to OdinHistory table
  //@formatter:off
    /*OdinHistoryEntity entity = OdinHistoryEntity.builder().engineId(newEngine.getEngineID())
                                                        .esn(newEngine.getEsn())
                                                        .eventId(newEngine.getEventId())
                                                        .logEmail(userProfile.getEmailAddress())
                                                        .prelimInductionDate(slot.getCaldate())
                                                        .build();
    //@formatter:on
    odinHistoryRepo.save(entity);*/ // TODO: Removing this code for now, as empty eventId is causing
                                    // the
    // functionality to fail.

    // Everything saved OK, so prepare the response now.
    CalendarShopVisit calendarShopVisit = calendarService.getCalendarShopVisitForSlotID(userProfile,
        slotID);

    return calendarShopVisit;
  }

  @Transactional
  public int countBySlotID(int slotID) {
    return engineRepo.countBySlotID(slotID);
  }

  /**
   * Steps...
   * 
   * 1) Do nothing if Engine not exists 2) getEngineAssetByAssetIdAndEsn() Set planned=false,
   * slotId=null 3) getEngineEventByEsnAndEventId() Set planned=false, slotId=null 4) Delete module
   * assets record matching moduleId and ESN 5) Delete EngineTracking record matching engineId 6)
   * Delete ODIN record matching ESN, engineId, eventId 7) Delete ODIN history matching engineId 8)
   * Delete engine record
   * 
   * @param userProfile
   * @param engineID
   */
  @Transactional
  public void deleteSlottedEngine(final UserProfile userProfile, final int engineID) {
    EngineEntity engine = engineRepo.findById(engineID).orElse(null);

    if (isNull(engine)) {
      log.warn("EngineId [{}] couldn't be found. Assuming already deleted.", engineID);
      return;
    }

    if (nonNull(engine.getEsn())) {
      EngineAssetEntity engineAsset = engineAssetRepo.findByEsnIgnoreCase(engine.getEsn());
      if (nonNull(engineAsset)) {
        engineAsset.setPlanned(false);
        engineAsset.setSlotId(null);
        engineAssetRepo.save(engineAsset);
      }
    }

    if (nonNull(engine.getEsn()) && nonNull(engine.getEventId())) {
      EngineEventEntity ee = engineEventRepo.findByPkEsnAndPkEventId(engine.getEsn(),
          engine.getEventId());
      if (nonNull(ee)) {
        if (nonNull(engine.getSlotID()) && nonNull(ee.getSlotId())
            && Integer.compare(engine.getSlotID(), ee.getSlotId()) != 0) {
          log.error("SlotId mismatch! engineId={}, esn={}, eventId={}, slotId={}",
              engineID,
              engine.getEsn(),
              engine.getEventId(),
              engine.getSlotID());
        } else {
          ee.setPlanned(false);
          ee.setSlotId(null);
          engineEventRepo.save(ee);
        }
      }
    }

    EngineTrackingEntity engineTracking = engineTrackingService.getEngineTrackingByID(engineID);
    engineTrackingService.delete(engineTracking);

    Integer moduleId = engine.getModuleID();
    if (nonNull(moduleId)) {
      String esn = engine.getEsn();
      ModuleAssetEntityPK pk = ModuleAssetEntityPK.builder().moduleID(moduleId).sn(esn).build();
      ModuleAssetEntity moduleAsset = moduleRepo.findById(pk).orElse(null);
      if (nonNull(moduleAsset)) {
        log.debug("Deleteing ModuleAsset: moduleId={}, ESN={}", moduleId, esn);
        moduleRepo.delete(moduleAsset);
      }
    }

    OdinEntity odinEntity = getExistingOrNewOdinRecord(null,
        engine.getEsn(),
        engine.getEngineID(),
        engine.getEventId());

    if (nonNull(odinEntity)) { // ???
    	initializeOdinEntity(odinEntity);

    	odinRepo.save(odinEntity);
    }

    int cnt = odinHistoryRepo.deleteByEngineId(engineID);
    log.debug("{} DOME_ODIN_HISTORY record(s) deleted.", cnt);

//	  if (nonNull(engineAsset)) {
//		  SlotEntity slot = slotService.getSlotByID(userProfile, engine.getSlotID());
//
//		  if (nonNull(slot)) {
//			  Integer eventId = isNull(engine.getEventId()) ? 0 : engine.getEventId();
//
//      //@formatter:off
//      OdinHistoryEntity entity = OdinHistoryEntity.builder().changeReason(DELETE_ENG_SLOT_REASON)
//                                                            .engineId(engineID)
//                                                            .esn(engine.getEsn())
//                                                            .eventId(eventId)
//                                                            .logEmail(userProfile.getEmailAddress())
//                                                            .prelimInductionDate(slot.getCaldate())
//                                                            .build();
//      //@formatter:on
//      odinHistoryRepo.save(entity);
//    }
//  }

    Integer engineId = engine.getEngineID();
    Integer eventId = engine.getEventId();
    String esn = engine.getEsn();
    engineRepo.delete(engine);

    if (nonNull(engineId) && nonNull(esn) && nonNull(eventId)) {
    	mroSvc.deleteEngineEsn(engineId, esn, eventId);
    } else {
    	log.warn("MRO.deleteEngineEsn() not called due to null params. EngineId: {}", engineId);
    }

    log.debug("Successfully deleted slotted engine [{}]", engineID);
  }

  private void initializeOdinEntity(OdinEntity odinEntity) {
      odinEntity.setEngineId(null);
      odinEntity.setMaintenanceCenter(null);
      odinEntity.setMaintenanceCenter(null); 
      odinEntity.setEbuShop(null);
      odinEntity.setPowerEngineer(null);
      odinEntity.setWsInitiationDate(null);
      odinEntity.setWsDraftCompleteEngDate(null);
      odinEntity.setWsDraftCompleteAccyDate(null);
      odinEntity.setCustomerApprovalDate(null);
      odinEntity.setWsOrigReleaseDate(null);
      odinEntity.setWsDraftCompleteEngDate(null);
      odinEntity.setSmiNeedDate(null);
      odinEntity.setFanBladeMapDate(null);
      odinEntity.setAdListDate(null);
      odinEntity.setActualRecEbuDate(null);
      odinEntity.setProjRecEbuDate(null);
      odinEntity.setTestAtReceipt(null);
  }

  @Transactional(readOnly = true)
  public EngineEntity getEngineByID(final Integer engineID) {
    return engineRepo.findById(engineID).orElse(null);
  }

  @Transactional(readOnly = true)
  public List<EngineEntity> getEnginesByEngineCenterIDAndMonthAndYear(final String engineCenterID,
      final int month,
      final int year) {
    return engineRepo.findByEngineCenterIdAndMonthAndYear(engineCenterID, month, year);
  }

  @Transactional(readOnly = true)
  public List<CalendarEngine> getEnginesBySlotID(int slotId) {
    List<EngineEntity> slotEngines = engineRepo.getEnginesBySlotID(slotId);
    List<CalendarEngine> response = new ArrayList<>();

    slotEngines.stream()
        .filter(engine -> engine.getSlotID() == slotId)
        .forEach(engine -> response
            .add(DataMapper.INSTANCE.toCalendarEngine(engine, getEngineType(engine))));

    if (slotEngines.isEmpty()) {
      return null;
    }

    return response;
  }

  @Transactional
  public EngineDTO editEngine(UserProfile userProfile, EngineDTO dto) {
	  String msg = "Matching engine record not found.";
	  EngineEntity entity = engineRepo.findById(dto.engineID()).orElseThrow(()->new NotFoundException(msg));
	  DataMapper.INSTANCE.mutateEngineEntity(dto, entity);
	  entity = engineRepo.save(entity);
	  return DataMapper.INSTANCE.toEngineDTO(entity);
  }

  @Transactional
  public EngineEntity saveAndFlush(EngineEntity engine) {
    return engineRepo.saveAndFlush(engine);
  }

//	When EDIT Engine need to set isplanned = 1 and sloit_id on engine_assets.
//	Also update Engine Events.
//  Update ODIN.
  @Transactional
  public CalendarShopVisit updateEngineEsn(UserProfile userProfile,
      int engineID,
      int newEngineAssetID) {
    EngineEntity engine = engineRepo.findById(engineID).orElse(null);

    if (isNull(engine)) {
      log.error("Engine ID [{}] could not be found. Unable to perform ESN update.", engineID);
      throw new IllegalArgumentException(
          "Engine ID [" + engineID + "] could not be found. Unable to perform ESN update.");
    }

    if (!Constants.NO_ENGINE_ESN.equals(engine.getEsn())) {
      String msg = String.format(
          "Engine ID [%s] already has a valid ESN of [%s]. An Engines ESN can only be updated if it has an ESN of [%s]",
          engineID,
          engine.getEsn(),
          Constants.NO_ENGINE_ESN);
      log.error(msg);
//      throw new BadRequestException(msg);
    }

    EngineAssetEntity engineAsset = engineAssetRepo.findById(newEngineAssetID)
        .orElseThrow(
            () -> new NotFoundException(engAssetNotFoundUsingEngAssetId(newEngineAssetID)));
    log.debug("Successfully retrieved removedEngine.");

    final Integer slotId = engine.getSlotID();

//    final int engineSlotID = nonNull(engine.getSlot()) ? engine.getSlot().getSlotID() : -1;

//		if (engineAsset.isPlanned()) {
//        if (nonNull(engEvent.getSlotId())) {
//			String msg = String.format(
//					"The specified engine asset ID [%s] is already slotted in slot ID [%s]. Unable to use this engine asset again.",
//					engineAsset.getEngineAssetID(), engineAsset.getSlotId());
//			log.error(msg);
//			throw new ConflictException("Can't SlotEntity Engine. Engine already slotted.");

    engineAsset.setPlanned(true);
    engineAsset.setSlotId(slotId);
    engineAssetRepo.save(engineAsset);

    EngineEventEntity engEvent = null;
    final String newEsn = engineAsset.getEsn();
    final Integer newEventId = engineAsset.getEventId();
    if (nonNull(newEventId) //
        && nonNull((engEvent = engineEventRepo.findByPkEsnAndPkEventId(newEsn, newEventId)))) {
//        && nonNull(engEvent.getSlotId())) {
      engEvent.setPlanned(true);
      engEvent.setSlotId(slotId);
      engineEventRepo.saveAndFlush(engEvent);
    }
//    if (nonNull(engineAsset.getSlotID())) {
//      String msg = String.format(
//          "The specified engine asset ID [%s] is already slotted in slot ID [%s]. Unable to use this engine asset again.",
//          newEngineAssetID, engineAsset.getSlotID());
//      log.error(msg);
//      throw new ConflictException("Cannot SlotEntity Engine. Engine already slotted.");
//    }

    SlotEntity slot = null;
    if (nonNull(slotId)) {
      slot = slotRepo.findById(slotId).orElse(null);
    }

    // Update ODIN using unmodified engine record.
    OdinEntity odin = getExistingOrNewOdinRecord(null,
    		engine.getEsn(),
        engine.getEngineID(),
        engine.getEventId());
//    odin.setEventId(engine.getEventId());
    LocalDate smiNeedDate = getSmiNeedDate(slot);
    odin.setSmiNeedDate(smiNeedDate);
    odin.setEsn(newEsn);
    odin.setEventId(newEventId);
    odinRepo.save(odin);

    log.debug("About to save updated engine to DB with new ESN. ESN changing from [{}] to [{}]",
        engine.getEsn(),
        engineAsset.getEsn());

    engine.setEsn(newEsn);
    engine.setEventId(newEventId);
    engine.setCustomerID(engineAsset.getOperatorID());
    engine.setAssetID(engineAsset.getAssetID());
    engine = engineRepo.save(engine);
//    entityManager.detach(engine);
    log.debug("Successfully saved engine ESN change.");

    if (nonNull(engine.getEsn()) && nonNull(engine.getEventId())) {
      EngineEventEntity ee = engineEventRepo.findByPkEsnAndPkEventId(engine.getEsn(),
          engine.getEventId());
      if (nonNull(ee)) {
        ee.setPlanned(true);
        ee.getId().setEsn(engineAsset.getEsn());
        ee.setSlotId(slotId);
        engineEventRepo.saveAndFlush(ee);
      }
    }

    log.debug("Attempting to retrieve engine tracking record for engine ID [{}]", engineID);
    EngineTrackingEntity engineTracking = engineTrackingService.getEngineTrackingByID(engineID);
    log.debug("Successfully retrieved engine tracking record for engine ID [{}]", engineID);
    engineTracking.setEngtrackRemoval(engineAsset.getRemovalDate());
    log.debug("About to save to engine tracking table");
    engineTrackingService.save(engineTracking);
    entityManager.detach(engineTracking);
    log.debug("Successfully updated engine tracking table.");
//    log.debug("About to update Engine Asset slot ID to indicate engine is slotted.");
//    engineAsset.setSlotID(engineSlotID);
//    engineAsset = engineAssetService.save(engineAsset);
//    entityManager.detach(engineAsset);
//    log.debug("Successfully to updated Engine Asset slot ID");

    CalendarShopVisit calendarShopVisit = calendarService.getCalendarShopVisitForSlotID(userProfile,
        engine.getSlotID());

    return calendarShopVisit;
  }

  /**
   * User change slot date function.
   * 
   * @param userProfile
   * @param engineID
   * @param newSlotID
   * @return
   */
  @Transactional
  public CalendarShopVisit updateEngineSlot(UserProfile userProfile,
      int engineID,
      int newSlotID,
      UpdateEngineSlotRequest request) {
    log.debug("Enter updateEngineSlot. engineID [{}] | new SlotID [{}]", engineID, newSlotID);

    SlotEntity slot = slotService.getSlotByID(userProfile, newSlotID);
    log.debug("Successfully retrieved slot id [{}]", slot.getSlotID());

    EngineEntity engine = engineRepo.findById(engineID).orElse(null);

    if (isNull(engine)) {
      log.error("Engine ID [{}] could not be found. Unable to perform update.", engineID);
      throw new IllegalArgumentException(
          "Engine ID [" + engineID + "] could not be found. Unable to perform update.");
    } else {
      log.debug("Successfully retrieved engine id [{}]", engineID);
    }

    log.debug(
        "About to save updated engine to DB with new slot. SlotEntity changing from [{}] to [{}]",
        engine.getSlotID(),
        newSlotID);
    engine.setSlotID(newSlotID);
    engine = engineRepo.saveAndFlush(engine);
    entityManager.detach(engine);
    log.debug("Successfully saved engine slot change.");

    if (nonNull(engine.getEsn())) {
      EngineAssetEntity engineAsset = engineAssetRepo.findByEsnIgnoreCase(engine.getEsn());
      if (nonNull(engineAsset)) {
        engineAsset.setPlanned(true);
        engineAsset.setSlotId(newSlotID);
        engineAssetRepo.save(engineAsset);
        log.debug("Successfully saved engineAsset slot change.");
      }

      if (nonNull(engine.getEventId())) {
        EngineEventEntity ee = engineEventRepo.findByPkEsnAndPkEventId(engine.getEsn(),
            engine.getEventId());
        if (nonNull(ee)) {
          ee.setPlanned(true);
          ee.setSlotId(newSlotID);
          engineEventRepo.saveAndFlush(ee);
        }
      }
    }

    EngineTrackingEntity engineTrack = engineTrackingService.getEngineTrackingByID(engineID);
    if (nonNull(engineTrack)) {
      engineTrack
          .setEngtrackPlanIndDate(toLocalDate(slot.getYear(), slot.getMonth(), slot.getDay()));
      engineTrackingService.save(engineTrack);
    }

    CalendarShopVisit calendarShopVisit = calendarService.getCalendarShopVisitForSlotID(userProfile,
        newSlotID);

    if (nonNull(engine.getEventId())) {
      List<OdinHistoryEntity> odinHistories = odinHistoryRepo
          .findByEsnAndEventIdOrderByPrelimInductionDateAsc(engine.getEsn(), engine.getEventId());
      LocalDate preliminaryInductionDate = slot.getCaldate();

      // Save history only when the history table doesn't have an entry for
      // preliminary date.
      if (nonNull(preliminaryInductionDate)) {
        if (!CollectionUtils.isEmpty(odinHistories)) {
          boolean prelimIndDateExists = odinHistories.stream()
              .anyMatch(hist -> hist.getPrelimInductionDate().equals(preliminaryInductionDate));
          if (!prelimIndDateExists) {
            saveOdinHistory(engine, userProfile, request, slot);
          }
        } else {
          saveOdinHistory(engine, userProfile, request, slot);
        }
      }
    }

    OdinEntity odin = getExistingOrNewOdinRecord(null,
        engine.getEsn(),
        engine.getEngineID(),
        engine.getEventId());
//	    odin.setEventId(engine.getEventId());
    LocalDate smiNeedDate = getSmiNeedDate(slot);
    odin.setSmiNeedDate(smiNeedDate);
    odinRepo.save(odin);

    return calendarShopVisit;
  }

  @Transactional
  public CalendarShopVisit updateManualEngine(final UserProfile userProfile,
      final int engineID,
      final UpdateManualEngineRequest updateManualEngineRequest) {
    if (isNull(updateManualEngineRequest)) {
      log.error(
          "Invalid updateManualEngineRequest was specified. Unable to update manual engine ID [{}]",
          engineID);
      throw new BadRequestException(
          "Invalid parameters. Unable to update manual engine ID [" + engineID + "]");
    }

    if (StringUtils.isEmpty(updateManualEngineRequest.getCategory())) {
      log.error("Invalid category was specified. Unable to update manual engine ID [{}]", engineID);
      throw new BadRequestException(
          "Invalid category was specified. Unable to update manual engine ID [" + engineID + "]");
    }

    if (StringUtils.isEmpty(updateManualEngineRequest.getSalesOrderType())) {
      log.error("Invalid Sales Order Type was specified. Unable to update manual engine ID [{}]",
          engineID);
      throw new BadRequestException(
          "Invalid Sales Order Type was specified was specified. Unable to update manual engine ID ["
              + engineID + "]");
    }

    EngineEntity manualEngine = getEngineByID(engineID);

    if (isNull(manualEngine)) {
      log.error("Invalid engine ID was specified. Unable to find manual engine ID [{}]", engineID);
      throw new BadRequestException(
          "Invalid engine ID was specified. Unable to find manual engine ID [" + engineID + "]");
    }

    if (!manualEngine.getManualEngine()) {
      log.error("Engine ID [{}] is not a manual engine. Unable to update this engine ID.",
          engineID);
      throw new BadRequestException(
          "Engine ID [" + engineID + "] is not a manual engine. Unable to update this engine ID.");
    }

    Integer slotID = manualEngine.getSlotID();

    SlotEntity slot = slotService.getSlotByID(userProfile, slotID);
    entityManager.detach(slot);
    log.debug("Successfully retrieved slot ID [{}]", slotID);

    if (ShopVisitType.HEAVY == slot.getShopVisitType()) {
      if (!updateManualEngineRequest.getCategory().equals("H")) {
        log.error(
            "Invalid Category spcified was specified. A Heavy slot can only accept category 'H'. Unable to update manual engine ID ["
                + engineID + "]");
        throw new BadRequestException(
            "Invalid Category specified was specified. A Heavy slot can only accept category 'H'. Unable to update manual engine ID ["
                + engineID + "]");
      }
    } else if (ShopVisitType.MEDIUM == slot.getShopVisitType()) {
      if (!updateManualEngineRequest.getCategory().equals("M")) {
        log.error(
            "Invalid Category was specified. A Medium slot can only accept category 'M'. Unable to update manual engine ID ["
                + engineID + "]");
        throw new BadRequestException(
            "Invalid Category was specified. A Medium slot can only accept category 'M'. Unable to update manual engine ID ["
                + engineID + "]");
      }
    } else if (ShopVisitType.LIGHT == slot.getShopVisitType()) {
      if (!updateManualEngineRequest.getCategory().equals("L")
          && !updateManualEngineRequest.getCategory().equals("T")) {
        log.error(
            "Invalid Category was specified. A Light slot can only accept category 'L' or 'T'. Unable to update manual engine ID ["
                + engineID + "]");
        throw new BadRequestException(
            "Invalid Category was specified. A Light slot can only accept category 'L' or 'T'. Unable to update manual engine ID ["
                + engineID + "]");
      }
    }

    String customerID = null;
    String engineEsn = null;

    if (StringUtils.isEmpty(updateManualEngineRequest.getCustomerID())) {
      customerID = Constants.NO_CUSTOMER_ESN;
    } else {
      CustomerEntity customer = customerService
          .getCustomerByID(updateManualEngineRequest.getCustomerID());
      entityManager.detach(customer);
      log.debug("Successfully retrieved customer ID [{}]",
          updateManualEngineRequest.getCustomerID());
      customerID = customer.getCustomerID();
    }

    if (StringUtils.isEmpty(updateManualEngineRequest.getEsn())) {
      engineEsn = Constants.NO_ENGINE_ESN;
    } else {
      engineEsn = updateManualEngineRequest.getEsn();
    }

    manualEngine.setCategory(updateManualEngineRequest.getCategory());
    manualEngine.setCustomerID(customerID);
    manualEngine.setEsn(engineEsn);
    manualEngine.setSalesOrderType(updateManualEngineRequest.getSalesOrderType());

    manualEngine = engineRepo.saveAndFlush(manualEngine);
    entityManager.detach(manualEngine);

    // Everything saved OK, so prepare the response now.
    CalendarShopVisit calendarShopVisit = calendarService.getCalendarShopVisitForSlotID(userProfile,
        slotID);

    return calendarShopVisit;
  }

  @Transactional(readOnly = true)
  private EngineTypeEntity getEngineType(EngineEntity engine) {
    EngineTypeEntity entity = null;
    String engineTypeId = engine.getEngineTypeId();

    if (Objects.nonNull(engineTypeId)) {
      entity = engTypeRepo.getEngineType(engineTypeId);
    }

    return entity;
  }

  private OdinEntity getExistingOrNewOdinRecord(Integer odinId,
      String esn,
      Integer engineId,
      Integer eventId) {
    OdinEntity entity = null;

    // Find by ODIN Id?
    if (nonNull(odinId)) {
      entity = odinRepo.findById(odinId).orElse(null);
      if (isNull(entity)) {
        log.error("Unable to find OdinEntity with supplied Id: {}", odinId);
      } else {
        log.info("Found 1st, OdinId: {}", entity.getId());
      }
    }

    // Find by ESN and other Id(s)?
    if (isNull(entity)) {
      Validate.notBlank(esn, "The ESN must be supplied.");

      List<OdinEntity> odinList = odinRepo.findByEsnAndEngineIdAndEventId(esn, engineId, eventId);
      if (!odinList.isEmpty()) {
        entity = odinList.get(0);
        log.info("Found 2nd, OdinId: {}", entity.getId());
      }
    }

    // Reuse removed record?
    if (isNull(entity) && nonNull(eventId)) {
      List<OdinEntity> list = odinRepo.findByEsnAndEngineIdAndEventId(esn, null, eventId);
      if (!list.isEmpty()) {
        entity = list.get(0);
        entity.setEngineId(engineId);
        entity = odinRepo.save(entity);
        log.info("Found 3rd, OdinId: {}", entity.getId());
      }
    }

    // Reuse removed record?
    if (isNull(entity)) {
      List<OdinEntity> list = odinRepo.findByEsnAndEngineIdAndEventId(esn, null, null);
      if (!list.isEmpty()) {
        entity = list.get(0);
        entity.setEngineId(engineId);
        entity.setEventId(eventId);
        entity = odinRepo.save(entity);
        log.info("Found 4th, OdinId: {}", entity.getId());
      }
    }

    // Create new record?
    if (isNull(entity)) {
      entity = OdinEntity.builder().esn(esn).engineId(engineId).eventId(eventId).build();
      entity = odinRepo.save(entity);
      log.info("Found 5th, OdinId: {}", entity.getId());
    }

    return entity;
  }

  private void saveOdinHistory(final EngineEntity engine,
      final UserProfile userProfile,
      final UpdateEngineSlotRequest request,
      final SlotEntity slot) {
    OdinHistoryEntity odinHistory = DataMapper.INSTANCE
        .toOdinHistory(engine, userProfile, request, slot);

    odinHistoryRepo.saveAndFlush(odinHistory);
  }

  private LocalDate toLocalDate(final int year, final int month, final int dayOfMonth) {
    try {
      return LocalDate.of(year, month, dayOfMonth);
    } catch (Exception e) {
      String msg = String
          .format("Unable to create LocalDate.of(%d, %d, %d)", year, month, dayOfMonth);
      log.warn(msg, e);
    }

    return null;
  }
}
