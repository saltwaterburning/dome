package com.pw.dome.calendar.induction;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.calendar.CalendarService;
import com.pw.dome.user.UserProfile;

/**
 * @author John De Lello
 */
@RestController
@RequestMapping("/v1/calendars/induction")
public class InductionCalendarController {
	
	@Autowired
	private CalendarService calService;
	
    /**
     * @api {get} /v1/calendars/induction/engines/:engineCenterID/:month/:year Get Induction Calendar Engines
     * @apiExample {curl} Example usage: 
     *         curl --request GET
     *              --url http://localhost:8080/v1/calendars/induction/EC41/7/2019
     *              --header 'authorization: Bearer [jwt]'
     *              --header 'content-type: application/json'
     * @apiName getCalendarData 
     * @apiGroup Calendars
     * @apiParam {String} engineCenterID The Engine Center to get the calendar for
     * @apiParam {Number} month The month to get the calendar for
     * @apiParam {Number} year The year to get the calendar for
     * @apiDescription Returns the calendar for the requested engine center ID, month, and year.
     * @apiSuccess {String} cal The cal of the calendar
     * @apiSuccess {String} year The year of the calendar
     * @apiSuccess {String} month The month of the calendar
     * @apiSuccess {String} engineCenterID The Engine Center ID of the calendar
     * @apiSuccess {String} engineCenterName The Engine Center Name of the calendar
     * @apiSuccess {Object[]} days An array of 42 objects used to generate the calendar 
     * @apiSuccess {Boolean} days.validDate Whether this day is a valid calendar date for the current month year combination
     * @apiSuccess {Number} days.boxNumber Indicates the box number for this item. Valid values are 0-41
     * @apiSuccess {Number} days.day Indicates the day of the month for this item. If it is not a valid date location, this will be 0.
     * @apiSuccess {Object[]} days.shopVisitsByEngineType An array of slots that are assigned to the specific date
     * @apiSuccess {Number} days.shopVisitsByEngineType.slotID The ID of this slot
     * @apiSuccess {Number} days.shopVisitsByEngineType.shopVisitType The slot type assigned to this slot
     * @apiSuccess {String} days.shopVisitsByEngineType.subShopVisitType The code indicator of the sub slot type
     * @apiSuccess {String} days.shopVisitsByEngineType.engineTypeID The Engine Type ID for this slot
     * @apiSuccess {String} days.shopVisitsByEngineType.engineTypeName The Engine Type Name for this slot
     * @apiSuccess {Object[]} [days.shopVisitsByEngineType.engines] An array of associated engines to this slot
     * @apiSuccess {Number} days.shopVisitsByEngineType.engines.engineID The ID for the engine
     * @apiSuccess {Number} [days.shopVisitsByEngineType.engines.engineGroupID] The group ID for the engine
     * @apiSuccess {Number} [days.shopVisitsByEngineType.engines.engineModelID] The model ID for the engine
     * @apiSuccess {Number} [days.shopVisitsByEngineType.engines.moduleID] The module ID if present
     * @apiSuccess {Number} [days.shopVisitsByEngineType.engines.moduleName] The module name if present
     * @apiSuccess {String} [days.shopVisitsByEngineType.engines.esn] The serial number for the engine
     * @apiSuccess {String} [days.shopVisitsByEngineType.engines.customerID] The Customer ID for the engine
     * @apiSuccess {String} [days.shopVisitsByEngineType.engines.customerShortName] The customer short name
     * @apiSuccess {String} [days.shopVisitsByEngineType.engines.customerName] The Customer Name for the engine
     * @apiSuccess {String} [days.shopVisitsByEngineType.engines.manualEngine] Whether this engine is a manually added engine, which requires a different REST call than normal engines.
     * @apiSuccess {String} [days.shopVisitsByEngineType.engines.salesOrderType] The engine sales order type
     * @apiSuccess {String} [days.shopVisitsByEngineType.engines.category] The engine category
     * 
     * @apiUse CalendarSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     */
	@RequestMapping(value = "/{engineCenterID}/{month}/{year}", method = RequestMethod.GET)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
	public ResponseEntity<CalendarMonthYear> getCalendarData(
			@AuthenticationPrincipal UserProfile userProfile, 
			@PathVariable("engineCenterID") String engineCenterID, 
			@PathVariable("month") int month, 
			@PathVariable("year") int year) {
		
		CalendarMonthYear calMY = calService.getCalendar(userProfile, engineCenterID, "", month, year);

//		for (CalendarDay day : calMY.getDays()) {
//			if (day.getShopVisitsByEngineType() != null) {
//				for (CalendarShopVisit vt : day.getShopVisitsByEngineType()) {
//					vt.setShopVisitType(3);
//					vt.setSubShopVisitType("Unreserved");
//				}
//			}
//		}
		
		return new ResponseEntity<CalendarMonthYear>(calMY, HttpStatus.OK);
	}

	@RequestMapping(value = "/{engineCenterID}/{month}/{year}/{months}", method = RequestMethod.GET)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
	public ResponseEntity<List<CalendarMonthYear>> getCalendarMonths(
			@AuthenticationPrincipal UserProfile userProfile, 
			@PathVariable("engineCenterID") String engineCenterID, 
			@PathVariable("month") int month, 
			@PathVariable("year") int year,
			@PathVariable("months") int months) {
		
		List<CalendarMonthYear> calMY = calService.getCalendar(userProfile, engineCenterID, "", month, year, months);

//		for (CalendarDay day : calMY.getDays()) {
//			if (day.getShopVisitsByEngineType() != null) {
//				for (CalendarShopVisit vt : day.getShopVisitsByEngineType()) {
//					vt.setShopVisitType(3);
//					vt.setSubShopVisitType("Unreserved");
//				}
//			}
//		}
		
		return new ResponseEntity<List<CalendarMonthYear>>(calMY, HttpStatus.OK);
	}
}
