/**
 * Provides services to match/umatch engines with SAP data.
 */
@java.lang.Deprecated
package com.pw.dome.data.match;