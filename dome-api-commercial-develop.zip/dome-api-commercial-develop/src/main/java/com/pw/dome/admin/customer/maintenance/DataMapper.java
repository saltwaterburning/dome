package com.pw.dome.admin.customer.maintenance;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.customer.CustomerDTO;
import com.pw.dome.customer.CustomerEntity;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

	CustomerDTO toDTO(CustomerEntity entity);

	@Mapping(target = "customerIdValue", ignore = true)
	@Mapping(target = "region", ignore = true)
	CustomerEntity toEntity(CustomerDTO dto);

	@Mapping(target = "name", ignore = true)
	@Mapping(target = "shortName", ignore = true)
	@Mapping(target = "active", ignore = true)
	void merge(CustomerEntity from, @MappingTarget CustomerEntity to);
}
