package com.pw.dome.admin;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class Operator {

	private String customerId;
	private String customerName;
	private String customerShortName;
	private String engineTypeId;
	private String engineTypeName;
	
}
