package com.pw.dome.mml.induction;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import jakarta.validation.Valid;

//import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.mml.PlanMarket;
import com.pw.dome.mml.PlanType;



@RestController()
@RequestMapping("/v1/materials/stages")
class InductionMMLController {
	@Autowired
	private InductionAnnualPlanService inductionAnnualPlanService;

	@GetMapping(path = {"/planned/{engine-center}/{engine-group}/{plan-market}/{plan-type}/{year}"}, produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AnnualPlanResponse> getInductionAnnualPlan(
            @PathVariable(name = "engine-center", required = true)
            final String engineCenter,
            @PathVariable(name = "engine-group", required = true)
            final String engineGroup,
            @PathVariable(name = "plan-market", required = true)
            final PlanMarket planMarket,
            @PathVariable(name = "plan-type", required = true)
            final PlanType planType,
            @PathVariable(name = "year", required = true)           
            final int year) {

	    AnnualPlanResponse response = inductionAnnualPlanService.getAnnualPlans(engineCenter, engineGroup, planMarket, planType, year);
        return ResponseEntity.ok(response);
    }

	@PutMapping(path = "/planned", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<AnnualPlanResponse> updateInductionAnnualPlan(
	   		@Valid
    		@RequestBody
    		final AnnualPlanResponse request) {
		return ResponseEntity.ok(inductionAnnualPlanService.save(request));
	}
}
