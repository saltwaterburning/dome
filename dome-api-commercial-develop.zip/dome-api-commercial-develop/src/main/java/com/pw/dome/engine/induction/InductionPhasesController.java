package com.pw.dome.engine.induction;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.engine.removed.EngineRemovedDTO;
import com.pw.dome.engine.removed.EngineRemovedListResponse;
import com.pw.dome.user.UserProfile;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;

/**
 * @author John De Lello
 */
@RestController()
@RequestMapping("/v1/engines/induction")
@Validated
public class InductionPhasesController {
  @Autowired
  private InductionPhasesService engineRemovedSvc;

	@PostMapping(path = "/phases", produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<EngineRemovedListResponse>
    getEngineRemovedList(@AuthenticationPrincipal
    		             UserProfile userProfile,
    		             @RequestBody
    		             @Valid
    		             PhaseRequest request) {

    	List<EngineRemovedDTO> engines = engineRemovedSvc.getEngineInPhase(request);
    	return ResponseEntity.ok(EngineRemovedListResponse.builder().engines(engines).build());
    }

	@GetMapping(path = "/{engine-center-id}/{engine-type-id}/{esn}", produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
	public ResponseEntity<AvailableEngineListResponse>
	getAvailableEngines(@AuthenticationPrincipal
	                    UserProfile userProfile,
                        @PathVariable(name = "engine-center-id")
                        @NotBlank
                        String engineCenterId,
                        @PathVariable(name = "engine-type-id")
                        @NotBlank
                        String engineTypeId,
                        @PathVariable(name = "esn")
	                    @NotBlank
	                    String esn) {

	  List<AvailableEngine> engines = engineRemovedSvc.getAvailableEngines(engineCenterId, engineTypeId, esn);
	  return ResponseEntity.ok(AvailableEngineListResponse.builder().engines(engines).build());
	}
}
