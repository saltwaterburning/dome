package com.pw.dome.mml.induction;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import com.pw.dome.mml.PlanMarket;
import com.pw.dome.mml.PlanType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AnnualPlan {
    @NotNull
    private String category;
    @NotNull
    private String engCenterId;
    private String engCenterName;
    @NotNull
    private String engGroupId;
    private String engGroupName;

    @NotNull
    private PlanMarket planMarket;
    @NotNull
    private PlanType planType;
    @NotNull
    private int planYear;
    @NotNull
    private String salesOrderType;

    @NotEmpty
    @NotNull
    private List<MonthlyPlan> monthlyPlans;
}
