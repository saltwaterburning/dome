package com.pw.dome.engine.induction.planning;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.common.oas.BaseRESTfulResource;
import com.pw.dome.exception.ErrorResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RestController
@RequestMapping("/v1/engines/induction")
@Validated
class InductionMiscController extends BaseRESTfulResource {
    @Autowired
    private InductionMiscService svc;

    /**
     * Fetches miscellaneous values for induction planning from the DOME_MISC table.
     * 
     * <pre>
     * OAS example documentation using a Java Enumeration and a single path parameter.
     * 
     * Notes:
     * 1) The client key path parameter is mapped to the {@code InductionMiscKeys} enum via a {@code Converter}.
     * 2) The {@code InductionMiscKeys} enum is annotated appropriately.
     * 3) The key parameter must be be described within the {@code Operation} annotation using {@code parameters = @Parameter}.
     *    Using the {@code @Parameter} annotation on the key method parameter won't produce correct documentation.
     * 4) The parameter type, name and required indication are derived from the key method parameter annotation this case {@code PathVariable}.
     * 
     * </pre>
     * 
     * @param key a name matching the {@code InductionMiscKeys} enum
     * @return list of miscellaneous values
     *
     * @see InductionMiscKeys
     * @see EnumConverters
     * @see <a href="http://dbdsdev/api/doc.html#tag/Induction-Planning" target="_blank">This Method API Doc</a>
     */
    @Operation(tags = { Tags.INDUCTION_PLANNING }, // For multi-tagging
               description = "Fetches miscellaneous induction values given an InductionKeys enum value.",
               parameters = {
                   @Parameter(schema = @Schema(implementation = InductionMiscKeys.class))
               },
               responses = {
                   @ApiResponse(content = @Content(schema = @Schema(implementation = InductionMiscDTO.class),
                                                   mediaType = MediaType.APPLICATION_JSON_VALUE),
                                responseCode = OK),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = BAD_REQUEST,
                                description = Descriptions.BAD_REQUEST),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = UNAUTHORIZED,
                                description = Descriptions.UNAUTHORIZED),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = NOT_FOUND,
                                description = Descriptions.NOT_FOUND),
                   @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                    implementation = ErrorResponse.class)),
                                responseCode = INTERNAL_SERVER_ERROR,
                                description = Descriptions.INTERNAL_SERVER_ERROR)
               })
    @GetMapping(path = "/values/{key}",
                produces = APPLICATION_JSON_VALUE)
    InductionMiscDTO getInductionValue(
    		@NotNull
    		@PathVariable(name = "key")
    		InductionMiscKeys key) {
    	return svc.getInductionValue(key);
    }

    // TODO How to make map show enum key values in API docs?
    @Operation(tags = { Tags.INDUCTION_PLANNING }, // For multi-tagging
            description = "Fetches miscellaneous induction values given an InductionKeys enum value.",
            responses = {
                @ApiResponse(content = @Content(schema = @Schema(implementation = InductionValuesDTO.class),
                                                mediaType = MediaType.APPLICATION_JSON_VALUE),
                             responseCode = OK),
                @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                 implementation = ErrorResponse.class)),
                             responseCode = BAD_REQUEST,
                             description = Descriptions.BAD_REQUEST),
                @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                 implementation = ErrorResponse.class)),
                             responseCode = UNAUTHORIZED,
                             description = Descriptions.UNAUTHORIZED),
                @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                 implementation = ErrorResponse.class)),
                             responseCode = NOT_FOUND,
                             description = Descriptions.NOT_FOUND),
                @ApiResponse(content = @Content(schema = @Schema(enumAsRef = false,
                                                                 implementation = ErrorResponse.class)),
                             responseCode = INTERNAL_SERVER_ERROR,
                             description = Descriptions.INTERNAL_SERVER_ERROR)
            })
    @GetMapping(path = "/values", produces = APPLICATION_JSON_VALUE)
    InductionValuesDTO getInductionValues() {
    	return svc.getInductionValues();
    }

    @GetMapping(path = "/shortvalues/{key}", produces = APPLICATION_JSON_VALUE)
    List<InductionMiscShortValueDTO> getInductionShortValue(
        @NotNull
        @PathVariable("key")
        InductionMiscKeys key) {
        return svc.getInductionShortValue(key);
    }

    @GetMapping(path = "/shortvalues/sales-order-type/{engine-type}", produces = APPLICATION_JSON_VALUE)
    List<InductionMiscShortValueDTO> getInductionShortValue(
        @NotNull
        @PathVariable("engine-type")
        String engineType) {
        return svc.getInductionShortValue(engineType);
    }
    
    @GetMapping(path = "/shortvalues", produces = APPLICATION_JSON_VALUE)
    InductionMiscShortValuesDTO getInductionShortValues() {
        return svc.getInductionShortValues();
    }
}
