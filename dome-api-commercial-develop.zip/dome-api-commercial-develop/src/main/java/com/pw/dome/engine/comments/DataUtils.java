package com.pw.dome.engine.comments;

import java.time.LocalDateTime;
import java.util.Objects;

import com.pw.dome.user.UserProfile;
import com.pw.dome.util.SecurityUtils;

class DataUtils {
	private DataUtils() {
		throw new IllegalAccessError();
	}

	static Comment toComment(CommentEntity entity) {
		return Comment.builder()
				      .commentId(entity.getCommentId())
				      .dateUpdated(entity.getDateUpdated())
				      .external(entity.isExternal())
				      .logEmail(entity.getLogEmail())
				      .notes(entity.getNotes())
				      .build();
	}

	static Comment toComment(CommentEntity entity, UserProfile user) {
		Comment comment = toComment(entity);

		if (user != null) {
			comment.setFirstName(user.getFirstName());
			comment.setLastName(user.getLastName());
		}

		return comment;
	}

	static CommentEntity toCommentEntity(Integer engineId, Comment obj) {
	    return CommentEntity.builder()
                            .commentId(obj.getCommentId())
                            .dateUpdated(LocalDateTime.now())
                            .engineId(engineId)
                            .isExternal(obj.getExternal())
                            .logEmail(SecurityUtils.getUserEmailAddress())
                            .notes(Objects.isNull(obj.getNotes()) ? "" : obj.getNotes())
                            .build();
	}
}
