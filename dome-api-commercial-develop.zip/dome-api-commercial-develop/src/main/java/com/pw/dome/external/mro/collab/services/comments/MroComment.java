package com.pw.dome.external.mro.collab.services.comments;

import java.time.LocalDate;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "Comment DTO schema.")
@Valid
public class MroComment {
	@NotNull
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Integer commentId;

	@NotNull
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private LocalDate dateUpdated;

	// logEmail, dateUpdated, commentId, external
	@NotNull
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Integer engineId;

	@Size(min = 1, max = 20)
    @NotBlank
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String esn;

	@Min(1)
    @NotNull
	private Integer eventId;

	@NotNull
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Boolean external;

	@Size(min = 1, max = 50)
    @NotBlank(message = "{NotBlank.required}")
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String logEmail;

	@Size(min = 1, max = 10)
    @NotBlank
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String mroShopCode;

	@Size(min = 1, max = 25)
    @NotBlank
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "Named SMI in MRO system.")
	private String mroWorkOrder;

	@Size(min = 0, max = 2000)
//	@NotNull
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String notes;
}
