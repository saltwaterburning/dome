package com.pw.dome.mml.induction;


interface Consts {
    
    String[] PLAN_CATEGORY = { "H", "M", "L" };

	/** Regex used to capture the alias names. */
	String ALIAS_REGEX = "(?i)\\s+AS\\s+(\\w+)";

	interface SQL {
        String ANNUAL_PLANS =
        "SELECT e " +
        "FROM InductionAnnualPlanEntity e " +
        "WHERE e.engCenterId = :engCenterId" +
        "  AND e.engGroupId = :engGroupId" +
        "  AND e.planMarket = :planMarket" +
        "  AND e.planType = :planType" +
        "  AND e.planYear = :year";
	}
}
