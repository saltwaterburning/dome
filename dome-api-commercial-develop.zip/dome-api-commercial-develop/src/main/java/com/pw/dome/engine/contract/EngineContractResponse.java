package com.pw.dome.engine.contract;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class EngineContractResponse {
	private String accessoryCoverage;
	private String description;
	private LocalDate endDate;
	private String esn;
	private String leaseReturnCoverage;

	private LocalDate leaseReturnDate;
	private String llpCoverage;

	private String refurbPayStructure;
	private String s1RetrofitCoverage;
	private String shippingCoverage;
	private String subFleet;
	private String svs;
	private String years;

}
