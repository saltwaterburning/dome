package com.pw.dome.audit;

import org.apache.commons.lang3.Validate;

import lombok.Builder;

/**
 * AuditEvent item name holder.
 */
@Builder
public record AuditItem(String name) {
  public AuditItem {
    Validate.notBlank(name);
  }
}
