package com.pw.dome.mml;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.pw.dome.jpa.AbstractEntityWithGeneratedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "DOME_MML_MONTH")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MmlMonthlyEntity extends AbstractEntityWithGeneratedId<Integer> {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOME_MML_MONTH_SEQ")
    @SequenceGenerator(sequenceName = "DOME_MML_MONTH_SEQ", allocationSize = 1, name = "DOME_MML_MONTH_SEQ")
    @Column(name = "MML_MONTH_ID")
    private Integer id;

    @Column(name = "ENG_ID")
    private int engineId;

    @Column(name = "PLAN_MARKET")
    @Enumerated
    private PlanMarket planMarket;

    @Column(name = "PLAN_MONTH")
    private int planMonth;

    @Column(name = "PLAN_TYPE")
    @Enumerated
    private PlanType planType;

    @Column(name = "PLAN_YEAR")
    private int planYear;
}
