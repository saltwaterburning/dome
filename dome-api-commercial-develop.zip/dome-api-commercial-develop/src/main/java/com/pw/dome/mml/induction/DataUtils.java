package com.pw.dome.mml.induction;

final class DataUtils {
    private DataUtils() {}

    static InductionAnnualPlanEntity toEntity(int counter, AnnualPlan ap, MonthlyPlan mp) {
        InductionAnnualPlanEntity entity =
                InductionAnnualPlanEntity.builder()
                                         .category(ap.getCategory())
                                         .engCenterId(ap.getEngCenterId())
                                         .engGroupId(ap.getEngGroupId())
                                         .planCounter(counter)
                                         .planId(mp.getPlanId())
                                         .planMarket(ap.getPlanMarket())
                                         .planMonth(mp.getPlanMonth())
                                         .planType(ap.getPlanType())
                                         .planYear(ap.getPlanYear())
                                         .salesOrderType(ap.getSalesOrderType())
                                         .build();

        return entity;
    }

}
