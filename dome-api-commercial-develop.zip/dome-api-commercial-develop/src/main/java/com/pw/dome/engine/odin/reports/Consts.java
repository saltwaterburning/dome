package com.pw.dome.engine.odin.reports;

import static com.pw.dome.engine.odin.DTO_FQCN.BASE_DTO_NAME;;

interface Consts {
	String AND_NOT_DISABLED = " AND cast(nvl(a.disabled, 0) as int) = 0";

    /**
     * 
     */
    String EXPORT_CLASSIFICATION = "U.S. Export Classification: ";
    String EXPORT_CLASSIFICATION_TYPE = "EAR 99";

    /** Report headers */
    String[] HEADERS = { "Event_ID",
        "Contract",
        "Oper",
        "ESN",
        "Thrust",
        "Model",
        "TSN",
        "CSN",
        "TSO",
        "CSO",
        "LLP\nCyc\nRem",
        "Removal Reason",
        "Maint Cent",
        "SV Class",
        "LLP Type",
        "Upgrade",
        "Actual\nRemoval",
        "Rec\nRemoval",
        "Allocation",
        "Data/App",
        "LLP Del",
        "Accy Data",
        "NIS",
        "WS\nInitiation",
        "Eng WS Draft",
        "Accy\nWS\nDraft",
        "Cust\nApp",
        "WS\nActual\nRelease",
        "WS\nPlanned\nRelease",
        "TAR\nDate",
        "Planned\nEngine\nDelivery\nDate",
        "Actual\nEngine\nDelivery\nDate",
        "S1\nKit\nOrdered\nDate",
        "Prelim\nInduct",
        "Scheduled\nInduct",
        "Act\nInduct",
        "Rec\nInduct",
        "Contract\nRem",
        "Investigation",
        "FHA\nEligible",
        "Comments"};

    /**
     * JPQL constructor expression.
     * Note columns refer to entity aliases a, c, o, r, s, and t.
     */
    String NEW_DTO =
    " NEW " + BASE_DTO_NAME +
    "(o.accyDeliveryDate," +
    " o.actualRecEbuDate," +
    " t.engtrackRecDate," +
    " o.adListDate," +
    " o.aimAllocationDate," +
    " a.assetID," +
    " o.ber," +
    " o.cfdFm," +
// ChangeReason isn't used by report and causing duplicate rows so set to null.
//  " h.changeReason," +
    " NULLIF('', '')," +
    " o.comments," +
    " t.engtrackIndDate," +
    " o.contractRemoval," +
    " c.contractType," +
    " e.csn," +
    " e.cso," +
    " o.currentLocation," +
    " o.customerApprovalDate," +
    " a.disabled," +
    " o.ebuShop," +
    " e.manualEngine," +
    " t.engtrackRecDate," +
//    " r.engtrackRecDate," +
    " o.engineId," +
    " em.name," +
    " e.esn," +
    " o.estimatedWorkscope," +
    " o.eventId," +
    " o.fanBladeMapDate," +
    " o.fhaEligible," +
    " o.investigationEngine," +
    " e.llpCycRemain," +
    " o.llpDeliveryDate," +
    " o.llpReplaceType," +
    " o.maintenanceCenter," +
    " ec.name," +
    " o.nisDeliveryDate," +
    " o.odinId," +
    " o.onHold," +
    " a.operatorShortName," +
    " t.engtrackIsopportunity," +
    " o.powerEngineer," +
    " t.engtrackPlanIndDate," +
    " o.projRecEbuDate," +
    " t.engtrackPlanRecDate," +
    " o.pwelAsset," +
    " t.engtrackRemoval," +
    " e.removalReason," +
    " ee.removalDate," +
    " ee.slotId," +
    " o.rslPO," +
    " s.caldate," +
    " o.speidPO," +
    " o.svClass," +
    " o.tarCheckbox," +
    " o.testAtReceipt," +
    " a.thrust," +
    " e.tsn," +
    " e.tso," +
    " o.upgradeEligible," +
    " o.warranty," +
    " t.engtrackWorkOrder," +
    " o.wsDraftCompleteAccyDate," +
    " o.wsDraftCompleteEngDate," +
    " o.wsInitiationDate," +
    " o.wsOrigReleaseDate)";

    interface SQL {
    	String ODIN_REPORT =
    			"SELECT DISTINCT" +
    			NEW_DTO +
"""
FROM OdinEntity o
LEFT OUTER JOIN EngineEntity e ON e.esn = o.esn
  AND e.eventId = o.eventId
LEFT OUTER JOIN EngineCenterEntity ec ON ec.id = o.maintenanceCenter
  AND e.engineID = o.engineId
LEFT OUTER JOIN EngineAssetEntity a ON a.assetID = e.assetID
INNER JOIN EngineEventEntity ee ON e.esn = ee.pk.esn
  AND e.eventId = ee.pk.eventId
LEFT OUTER JOIN EngineModelEntity em ON em.engineModelID = e.modelID
INNER JOIN EngineTrackingEntity t ON t.engtrackId = o.engineId
LEFT OUTER JOIN ContractEntity c ON c.esn = e.esn
LEFT OUTER JOIN SlotEntity s ON s.slotID = e.slotID
WHERE e.engineTypeId IN (:engineTypeIds)
  AND (:ignoreContractType = true
       OR c.contractType IN (:contractTypes))
  AND o.ber = false
  AND o.onHold = false
  AND t.engtrackIndDate is not null
  AND t.engtrackRemoval BETWEEN :fromDate AND :toDate
""" + AND_NOT_DISABLED;
    }
}
