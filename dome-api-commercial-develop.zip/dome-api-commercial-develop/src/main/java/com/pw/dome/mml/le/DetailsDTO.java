package com.pw.dome.mml.le;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Note that the {@link AllArgsConstructor} is used in JPQL constructor expressions.
 * Maintaining property order is critical.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DetailsDTO {
    // EngineTrackingEntity.engtrackRecDate
    private LocalDate actualReceipentDate;
    // Customer.name
    private String customerName;
    // EngineEntity.category
    private String engineCategory;
    // EngineCenterEntity.name
    private String engineCenterName;
    // EngineGroup.engineGroupId
    private String engineGroupId;
    // EngineGroup.name
    private String engineGroupName;
    // EngineEntity.engineID
    private Integer engineId;
    // EngineEntity.esn
    private String engineSerialNumber;
    // LeMonthlyOpportunityEntity.opportunity or LeQuarterlyOpportunityEntity.opportunity
    private Boolean opportunity;
    // LeMonthlyOpportunityEntity.id or LeQuarterlyOpportunityEntity.id
    private Integer opportunityId;
    // EngineTrackingEntity.engtrackPlanIndDate
    private LocalDate planInductionDate;
    // LeMonthlyEntity.risk or LeQuarterlyEntity.risk
    private Boolean risk;
    // LeMonthlyEntity.id or LeQuarterlyEntity.id
    private Integer riskId;
}
