package com.pw.dome.calendar.induction;

import java.util.ArrayList;
import java.util.Collection;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Getter 
@Setter 
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class CalendarDay{
	private boolean validDate;
	private int boxNumber;
	private int dayOfMonth;
	private Collection<CalendarShopVisit> shopVisitsByEngineType;
	
	public void addShoptVisit(CalendarShopVisit shopVisit) {
		if(shopVisitsByEngineType == null) {
			shopVisitsByEngineType = new ArrayList<>();
		}
		// add date error logging
		shopVisitsByEngineType.add(shopVisit);
	}
}
