package com.pw.dome;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * @author John De Lello
 */
@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args)
    throws Exception {
        /*
        this.users.save(DomeApiUser.builder()
            .username("domeApiUser")
            .password(this.passwordEncoder.encode("K@ndyCan3_2019!"))
            .enabled(true)
            .build()
        );
        */
    }
}
