package com.pw.dome.external;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

import java.net.HttpRetryException;
import java.net.URISyntaxException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;

import jakarta.annotation.PostConstruct;
import jakarta.validation.ValidationException;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import com.pw.dome.web.requestlogging.RequestLoggingService;
import com.pw.dome.web.requestlogging.RestRequestLogEntity;

import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;
import reactor.util.retry.Retry;
import reactor.util.retry.RetryBackoffSpec;

public class RemoteServicesWebClient {
	private Logger log;
	private boolean async;
	private final RemoteServiceConfig remoteSvc;
	private final RequestLoggingService loggingSvc;

	private RetryBackoffSpec retry;
	private Scheduler scheduler;
	private WebClient webClient;

	public RemoteServicesWebClient(Class<?> clazz, RemoteServiceConfig remoteSvc, RequestLoggingService loggingSvc) {
		this.log = LoggerFactory.getLogger(clazz.getName() + "$" + this.getClass().getSimpleName());
		this.remoteSvc = remoteSvc;
		this.loggingSvc = loggingSvc;
		this.webClient = createWebClient(remoteSvc);
	}

	WebClient createWebClient(RemoteServiceConfig remoteSvc) {
		ConnectionProvider connectionProvider = //
				ConnectionProvider.builder("connectionPool") //
				.maxConnections(ConnectionProvider.DEFAULT_POOL_MAX_CONNECTIONS) //
				.pendingAcquireMaxCount(-1) // -1 is unbounded
				.pendingAcquireTimeout(Duration.ofSeconds(90)) // Default is 45secs
				.build();
		ReactorClientHttpConnector clientHttpConnector = //
				new ReactorClientHttpConnector(HttpClient.create(connectionProvider));

		return WebClient.builder()
				.baseUrl(remoteSvc.getBaseUrl()) //
				.clientConnector(clientHttpConnector) //
				.defaultHeaders(h->h.setContentType(MediaType.APPLICATION_JSON)) //
				.filter((request, next) -> next.exchange(ClientRequest.from(request) //
						.headers(h -> h.setBearerAuth(remoteSvc.getJsonWebToken())) //
						.build())) // filter(
				.build();
	}

	/**
	 * Logs the WebClient response to DB and logging framework.
	 * 
	 * @param dto
	 * @param request
	 * @param response
	 * @return
	 */
	private Mono<ClientResponse> logResponse(String jsonBody, ClientResponse response, StopWatch stopWatch, String uri) {
		final AtomicInteger cnt = new AtomicInteger();

		// TODO pass user email

		return response.bodyToMono(String.class).flatMap(body -> {
			int rawStatusCode = 0;
			try {
//				stopWatch.stop();
				cnt.set(getRequestCount(uri));
				rawStatusCode = response.statusCode().value();
//				HttpStatus httpStatus = HttpStatus.resolve(rawStatusCode);
				boolean isError = isError(rawStatusCode) ? true : false;

				RestRequestLogEntity dbLog = RestRequestLogEntity.builder()
						                             .endPoint(uri)
						                             .errorMessage(isError ? body : null)
						                             .httpMethod("POST") // Obtainable from WebClient?
						                             .httpStatusResponse(rawStatusCode)
						                             .logEmail(getClass().getName())
						                             .parms(jsonBody)
						                             .remoteIp(null) // Obtainable??
						                             .requestDate(LocalDateTime.now())
						                             .requestPayload(jsonBody)
						                             .responsePayload(body)
						                             .runtime(stopWatch.getTime()) // Obtainable???
						                             .build();
				loggingSvc.save(dbLog);
			} catch (Exception e) {
				log.error("RequestLoggingService.save() failed.", e);
			}

			// Always log request and response for auditing since DB entries aren't permanent...
			// TODO adjust by status code.
			log.info("Request ET:{}\nHttpStatus: {}\nPath: {}\nRequest: {}\nRequest Counter:{}\nResponse: {}", stopWatch.formatTime(), rawStatusCode, uri, jsonBody, cnt.get(), body);

			return Mono.just(response);
		});
	}

	/**
	 * Posts the JSON body to the specified location and log the response.
	 * 
	 * @param jsonBody
	 * @param uri
	 * @throws URISyntaxException
	 */
	private void postAsynchronousRequest(String jsonBody, String uri) throws URISyntaxException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		webClient.post()
		         .uri(uri)
		         .body(Mono.just(jsonBody), String.class)
		         .exchangeToMono(response -> logResponse(jsonBody, response, stopWatch, uri))
		         .retryWhen(this.retry)
		         .subscribeOn(this.scheduler)
		         .subscribe();
	}

	@PostConstruct
	private void postConstruct() {
		this.retry = Retry.backoff(remoteSvc.getRetryMaxAttempts(), Duration.ofSeconds(remoteSvc.getRetryMinBackoffSecs()));

		this.async = remoteSvc.getAsynchronous();
		int threadCap = remoteSvc.getWebClientThreadCap();

		if (threadCap == -1) {
			this.scheduler = Schedulers.boundedElastic();
		} else if (threadCap == 0) {
			this.scheduler = Schedulers.immediate();
		} else {
			this.scheduler = Schedulers.newBoundedElastic(threadCap, Integer.MAX_VALUE, getClass().getSimpleName());
		}

		log.debug("Initialized Request Scheduler: {}", this.scheduler);
	}

	private static ConcurrentMap<String, AtomicInteger> requestCounters = new ConcurrentHashMap<>();

	public void postRequest(Object bodyObject, String uri) {
		String jsonBody = JsonUtils.toJSON(bodyObject);

		try {
			if (!remoteSvc.getEnabled()) {
				log.info("WebClient is disabled. See dome.workscope-api.enabled configuration.");
			}
			else if (async) {
				postAsynchronousRequest(jsonBody, uri);
			} else {
				postSynchronousRequest(jsonBody, uri);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private static boolean isError(int statusCode) {
		HttpStatus status = HttpStatus.valueOf(statusCode);
		return status.isError();
	}

	// https://stackoverflow.com/questions/61047452/spring-webclient-retry-and-execute-a-code-if-all-retries-are-exhausted
	private synchronized void postSynchronousRequest(String jsonBody, String uri) throws URISyntaxException {
    	final AtomicInteger rawStatusCode = new AtomicInteger();
		Instant start = Instant.now();

		try {
        	Mono<String> result =
        			webClient.post()
        			.uri(uri)
        			//        .headers(h->h.setBearerAuth(jwt))
        			.bodyValue(jsonBody)
        			.exchangeToMono(response -> {
        				rawStatusCode.set(response.statusCode().value());
        				if (!isError(rawStatusCode.get())) {
        					return response.bodyToMono(String.class);
        				}
        				else {
        					return response.createException().flatMap(Mono::error);
        				}
        			})
        			.timeout(Duration.ofSeconds(remoteSvc.getResponseTimeoutSecs()))
        			.retryWhen(this.retry
        					.doAfterRetry(retrySignal -> {
        						log.info("Request retry count: {}, URI: {}", retrySignal.totalRetries(), uri);
        					})
        					.onRetryExhaustedThrow((retryBackoffSpec, retrySignal)
        							-> new HttpRetryException("Retries Exhausted, maxAttempts=" + retryBackoffSpec.maxAttempts, rawStatusCode.get())))
        			.doOnSuccess(clientResponse -> {
        				log.info("doOnSuccess() response: {}", clientResponse);
        			})
        			.doOnError(ValidationException.class, (error) -> {
        				;
        			});

        	String response = result.block();
        	String et = Duration.between(start, Instant.now()).toString();

        	int statusCode = rawStatusCode.get();
        	if (statusCode >= BAD_REQUEST.value()) {
        		log.error("Response: {}, ET: {}, Status Code: {}, URI: {}\nRequest Body: {}",
        				response, et, statusCode, uri, jsonBody);
        	} else if (log.isDebugEnabled()) {
        		log.info("Response: {}, ET: {}, Status Code: {}, URI: {}\nRequest Body: {}",
        				response, et, statusCode, uri, jsonBody);
        	} else {
        		log.info("Response: {}, ET: {}, Status Code: {}, URI: {}",
        				response, et, statusCode, uri);
        	}
        } catch (Exception e) {
        	String et = Duration.between(start, Instant.now()).toString();
        	String message = String.format("%s, ET: %s, Status Code: %d, URI: %s\nRequest Body: %s",
        			e.getMessage(), et, rawStatusCode.get(), uri, jsonBody);
        	log.error(message, e);
        	throw e;
		} finally {
			;
		}
	}

	private int getRequestCount(String path) {
		return requestCounters.computeIfAbsent(path, s->new AtomicInteger()).incrementAndGet();
	}
}
