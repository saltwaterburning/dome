package com.pw.dome.audit;

public interface AuditItems {

  AuditItem INDUCTION_CALENDAR = new AuditItem("Induction Calendar");
  AuditItem INDUCTION_PLANNING = new AuditItem("Induction Planning");
  AuditItem LE_MONTHLY = new AuditItem("LE Monthly");
  AuditItem LE_QUARTERLY = new AuditItem("LE Quarterly");
  AuditItem MML_MONTHLY = new AuditItem("MML Monthly");
  AuditItem MML_QUARTERLY = new AuditItem("MML Quarterly");
  AuditItem USER_MAINTENANCE = new AuditItem("User Maintenance");
  AuditItem WIP = new AuditItem("Work In Progress");
}
