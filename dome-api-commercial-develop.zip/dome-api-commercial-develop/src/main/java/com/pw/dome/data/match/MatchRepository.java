package com.pw.dome.data.match;

import static com.pw.dome.data.match.Consts.ALIAS_REGEX;
import static com.pw.dome.data.match.Consts.SQL.GET;
import static com.pw.dome.data.match.Consts.SQL.ORDER_BY;
import static com.pw.dome.data.match.Consts.SQL.WHERE_ESN;
import static com.pw.dome.data.match.Consts.SQL.WHERE_IDS;
import static com.pw.dome.data.match.Consts.SQL.WHERE_MATCHED;
import static com.pw.dome.data.match.Consts.SQL.WHERE_UNMATCHED;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.query.NativeQuery;
import org.springframework.stereotype.Repository;

import com.pw.dome.user.UserProfileEngineCenter;
import com.pw.dome.util.hibernate.ValidatingTupleTransformer;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class MatchRepository {
	@PersistenceContext
	private EntityManager em;

	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");
	private static final String GET_MATCHED_BY_ESN = strip(quoteAliases(GET) + WHERE_UNMATCHED + WHERE_ESN + ORDER_BY);
	private static final String GET_MATCHED_BY_IDS = strip(quoteAliases(GET) + WHERE_UNMATCHED + WHERE_IDS + ORDER_BY);
	private static final String GET_UNMATCHED_BY_ESN = strip(quoteAliases(GET) + WHERE_MATCHED + WHERE_ESN + ORDER_BY);
	private static final String GET_UNMATCHED_BY_IDS = strip(quoteAliases(GET) + WHERE_MATCHED + WHERE_IDS + ORDER_BY);
	private static final String GET_MATCHED= strip(quoteAliases(GET) + WHERE_UNMATCHED + ORDER_BY);// get the unmatched data under Match tab, to match record by record using "Match" button.
	private static final String GET_UNMATCHED = strip(quoteAliases(GET) + WHERE_MATCHED + ORDER_BY);// get the matched data under unMatch tab, to unmatch record by record using "UnMatch" button.

	// Wrap SQL alias names in quotes to preserve letter case.
	static String quoteAliases(final String sql) {
		return sql.replaceAll(ALIAS_REGEX, " as \"$1\"");
	}

	// Strip extra whitespace.
	static String strip(final String sql) {
		return sql.replaceAll("\\s{2,}", " ");
	}

	public List<EngineData> getMatchedData(final String engineCenterId, final String engineTypeId) {
		return getByIds(GET_MATCHED_BY_IDS, engineCenterId, engineTypeId);
	}

	public List<EngineData> getUnmatchedData(final String engineCenterId, final String engineTypeId) {
		return getByIds(GET_UNMATCHED_BY_IDS, engineCenterId, engineTypeId);
	}

	public List<EngineData> getMatchedData(final String engineSN) {
		return getByESN(GET_MATCHED_BY_ESN, engineSN);
	}

	public List<EngineData> getUnmatchedData(final String engineSN) {
		return getByESN(GET_UNMATCHED_BY_ESN, engineSN);
	}
	public List<EngineData> getMatchedData() {
		return getMachedUnmatched(GET_MATCHED);
	}

	public List<EngineData> getUnmatchedData() {
		return getMachedUnmatched(GET_UNMATCHED);
	}

	public List<UserProfileEngineCenter> getAllEngineCenters() {
        Query query = em.createNativeQuery("FOO");
        @SuppressWarnings("unchecked")
		List<Object[]> qryResults = query.getResultList();

		List<UserProfileEngineCenter> response = new ArrayList<>(qryResults.size());
        for (Object[] row: qryResults) {
        	UserProfileEngineCenter upec =
        	  UserProfileEngineCenter.builder()
        	                         .engineCenterID((String)row[0])
        	                         .engineCenterName((String)row[1])
        	                         .build();
        	response.add(upec);
        }

        return response;
	}

	private List<EngineData> getMachedUnmatched(final String qry) {
		@SuppressWarnings({ "unchecked" })
		List<EngineData> response = em.createNativeQuery(qry)
                                     .unwrap(NativeQuery.class)
		                             .setTupleTransformer(new ValidatingTupleTransformer<EngineData>(EngineData.class))
		                             .getResultList();

		return response;
	}
	private List<EngineData> getByESN(final String qry, final String engineSN) {
		@SuppressWarnings({ "unchecked" })
		List<EngineData> response = em.createNativeQuery(qry)
                                     .setParameter("engineSN", engineSN)
                                     .unwrap(NativeQuery.class)
		                             .setTupleTransformer(new ValidatingTupleTransformer<EngineData>(EngineData.class))
		                             .getResultList();

		return response;
	}

	private List<EngineData> getByIds(final String qry, final String engineCenterId, final String engineGroupId) {
		@SuppressWarnings({ "unchecked" })
		List<EngineData> response = em.createNativeQuery(qry)
		                              .setParameter("engineCenterId", engineCenterId)
//		                                .setParameter("engineTypeId", engineGroupId)
		                              .unwrap(NativeQuery.class)
		                              .setTupleTransformer(new ValidatingTupleTransformer<EngineData>(EngineData.class))
		                              .getResultList();

		List<EngineData> list = new ArrayList<>(response.size());
		String prevNotifyNum = null;
		EngineData prevData = null;
		final int SIZE = response.size();
		for (int index = 0; index < SIZE; ++index) {
			EngineData data = response.get(index);
			String notifyNum = data.getNotifyNum();
			if (!StringUtils.equals(notifyNum, prevNotifyNum)) {
				list.add(prevData = data);
			}

			String engActivity = data.getEngActivity();
			String engActivitydate = data.getEngActivityDate();
			if ("INDUCTED".equals(engActivity)) {
				prevData.setEngineInductDate(toLocalDate(engActivitydate));
			} else if ("RECEIVED".equals(engActivity)) {
				prevData.setEngineReceiveDate(toLocalDate(engActivitydate));
			} else if ("SHIP DATE".equals(engActivity)) {
				prevData.setEngineShipDate(toLocalDate(engActivitydate));
			}

			prevNotifyNum = notifyNum;
		}

		Collections.sort(list, Comparator.comparing(EngineData::getEngineOperator, Comparator.nullsFirst(null))
				   .thenComparing(Comparator.comparing(EngineData::getEngineModel, Comparator.nullsFirst(null))));
		return list;
	}

	private LocalDate toLocalDate(String engActivitydate) {
		try {
			return LocalDate.parse(engActivitydate, FORMATTER);
		} catch (DateTimeParseException e) {
			log.warn("Unable to parse activity date.", e);
		}

		return null;
	}
}
