package com.pw.dome.calendar.slots;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 * @author John De Lello
 */    
public interface SlotRepository extends SlotRespositoryCustom, JpaRepository<SlotEntity, Integer> {

	@Query("SELECT s FROM SlotEntity s LEFT JOIN FETCH s.engineType EngineTypeEntity WHERE s.engineCenterID = ?1 AND s.month = ?2 AND s.year = ?3")
	List<SlotEntity> findByEngineCenterIDAndMonthAndYear(final String engineCenterID, final int month, final int year);

	@Query("SELECT s FROM SlotEntity s LEFT JOIN FETCH s.engineType EngineTypeEntity WHERE s.slotID = ?1")
	SlotEntity findByID(final int slotID);

	@Query("SELECT s FROM SlotEntity s WHERE s.slotID in ?1")
	List<SlotEntity> findByID(final List<Integer> slotIds);

	@Query("SELECT s FROM SlotEntity s LEFT JOIN FETCH s.engineType EngineTypeEntity WHERE s.engineCenterID = ?1 AND s.month = ?2 AND s.day = ?3 AND s.year = ?4")
	List<SlotEntity> findByEngineCenterIDAndMonthAndDayAndYear(final String engineCenterID, final int month, final int day, final int year);

	@Query("SELECT s FROM SlotEntity s " +
			"WHERE s.caldate >= ?3 AND s.caldate < ?4 " +
			"AND s.engineCenterID = ?1 AND s.shopVisitType = ?2 order by s.caldate")
	List<SlotEntity> findByEngineCenterIDAndSlotTypeAndBetweenSpDates(final String engineCenterID, final ShopVisitType slotType, final LocalDate actualInductionDate, final LocalDate actualCompletionDate);
}
