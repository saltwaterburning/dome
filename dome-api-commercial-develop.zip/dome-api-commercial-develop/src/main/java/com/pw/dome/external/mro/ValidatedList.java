package com.pw.dome.external.mro;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.validation.Valid;

import lombok.Data;
import lombok.experimental.Delegate;

@Data
public class ValidatedList<E> implements List<E> {
	@Valid
	@Delegate
	private final List<E> list;

	public ValidatedList() {
		this.list = new ArrayList<E>();
	}

	public ValidatedList(int initialCapacity) {
		this.list = new ArrayList<E>(initialCapacity);
	}

	public ValidatedList(List<E> list) {
		Objects.requireNonNull(list);
		this.list = new ArrayList<E>(list.size());
		this.list.addAll(list);
	}
}
