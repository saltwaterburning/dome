package com.pw.dome.engine.networkmanagement.excel;

import static com.pw.dome.report.excel.ReportConstants.EXCEL_MEDIA_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.user.UserProfile;

@RestController()
@RequestMapping("/v1/wip/reports/network-management")
@Validated
class NetworkManagementExcelController {

	private final NetworkManagementExcelService excelService;

	@Autowired
	public NetworkManagementExcelController(NetworkManagementExcelService excelService) {
		this.excelService = excelService;
	}

	@PostMapping(produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<InputStreamResource> getNetworkManagementReport(
			@AuthenticationPrincipal
			UserProfile userProfile,
			@RequestBody
			NetWorkManagementRequest request)
			throws IOException {
		ByteArrayInputStream inputStream = excelService.getNetworkManagementData(userProfile, request);
		return ResponseEntity.ok()
				             .contentType(EXCEL_MEDIA_TYPE)
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=network-management.xlsx")
				.body(new InputStreamResource(inputStream));

	}
}
