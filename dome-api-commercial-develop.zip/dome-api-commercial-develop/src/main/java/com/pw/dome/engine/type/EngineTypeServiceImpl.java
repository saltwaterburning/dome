package com.pw.dome.engine.type;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import com.pw.dome.exception.NotFoundException;
import com.pw.dome.user.UserProfile;
import com.pw.dome.web.authorization.SecurityService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author John De Lello
 */
@Slf4j
@Service
public class EngineTypeServiceImpl implements EngineTypeService {
	@Autowired
	private SecurityService securityService; 
	
	@Autowired
	private EngineTypeRepository engineTypeRepo;

	@Override
	public List<EngineTypeEntity> getAllEngineTypes(){
		return engineTypeRepo.getAllEngineTypes();
	}
	
	@Override
	public String getEngineTypeNameByID(final String engineTypeID) {
		if(StringUtils.isEmpty(engineTypeID)) {
			return null;
		}
		
		EngineTypeEntity engType = engineTypeRepo.findById(engineTypeID).orElse(null);
		
		if(engType == null) {
			return null;
		}
		
		return engType.getName();
	}

	@Override
	public List<EngineTypeEntity> getEngineTypes(final UserProfile userProfile, final String engineCenterID) {
		if(userProfile == null) {
			throw new IllegalArgumentException("No valid user profile was specified. Unable to get engine types list.");
		}
		
    	boolean isAllowable = securityService.isAllowableEngineCenter(userProfile, engineCenterID);
		
    	if(!isAllowable) {
			log.error("User does not have access to engineCenterID [{}]", engineCenterID);
			throw new AccessDeniedException("User does not have access to engineCenterID [" + engineCenterID + "]. Unable to get engine types list.");
    	}		
    	
    	return engineTypeRepo.getEngineTypes(userProfile.getEmailAddress(), engineCenterID);
	}

	@Override
	public List<EngineTypeEntity> getEngineTypes(final UserProfile userProfile, final String engineCenterID, final String engineGroupID) {
		if(userProfile == null) {
			throw new IllegalArgumentException("No valid user profile was specified. Unable to get engine types list.");
		}
		
		if(StringUtils.isEmpty(engineCenterID)) {
			throw new IllegalArgumentException("No valid Engine Center ID was specified. Unable to get engine types list.");
		}
		
		if(StringUtils.isEmpty(engineGroupID)) {
			throw new IllegalArgumentException("No valid Engine Type ID was specified. Unable to get engine types list.");
		}
		
    	boolean isAllowable = securityService.isAllowableEngineCenter(userProfile, engineCenterID);
		
    	if(!isAllowable) {
			log.error("User does not have access to engineCenterID [{}]", engineCenterID);
			throw new AccessDeniedException("User does not have access to engineCenterID [" + engineCenterID + "]. Unable to get engine types list.");
    	}
    	
		return engineTypeRepo.getEngineTypes(userProfile.getEmailAddress(), engineCenterID, engineGroupID);
	}

	@Override
	public EngineTypeEntity getEngineTypeByID(final String engineTypeID) {
		EngineTypeEntity engType = engineTypeRepo.findById(engineTypeID).orElse(null);
		
		if(engType == null) {
			log.error("Engine Type ID [{}] was not found.", engineTypeID);
			throw new NotFoundException("Engine Type ID [" + engineTypeID + "] was not found.");
		}
		
		return engType;
	}
}
