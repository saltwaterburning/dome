package com.pw.dome.customer;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Embeddable
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CustomerTypeMapEntityPK implements Serializable {
	private static final long serialVersionUID = 271975105561960184L;

	@Column(name="CUST_ID")
	private String customerID;

	@Column(name="ENG_TYPE_ID")
	private String engineTypeId;

	@Override
	public int hashCode() {
		return Objects.hash(customerID, engineTypeId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof CustomerTypeMapEntityPK))
			return false;
		CustomerTypeMapEntityPK other = (CustomerTypeMapEntityPK) obj;
		return Objects.equals(customerID, other.customerID) && Objects.equals(engineTypeId, other.engineTypeId);
	}

}
