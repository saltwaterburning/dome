/**
 * @author John De Lello
 */
package com.pw.dome;

public class SuccessResponse {
    private String result = "success";

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
