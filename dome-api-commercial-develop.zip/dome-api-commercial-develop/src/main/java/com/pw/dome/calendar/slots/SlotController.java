package com.pw.dome.calendar.slots;


import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.engine.EngineEntity;
import com.pw.dome.engine.EngineRepository;
import com.pw.dome.user.UserProfile;

/**
 * @author John De Lello
 */
@RestController
@RequestMapping("/v1/calendars/slots")
@Validated
public class SlotController {
	@Autowired
	private SlotService slotService; 
	
	@Autowired
	private EngineRepository engineRepository;
	
	@RequestMapping(method = RequestMethod.POST)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE"})
	public ResponseEntity<CreateSlotResponse> createSlot(
			@NotNull
			@AuthenticationPrincipal
			UserProfile userProfile,
			@NotNull
			@Valid
			@RequestBody
			CreateSlotRequest createSlotRequest) {

		SlotEntity slot = slotService.createSlot(userProfile, createSlotRequest);
		CreateSlotResponse createSlotResponse = DataMapper.INSTANCE.toCreateResponse(slot);
		return new ResponseEntity<>(createSlotResponse, HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/{slotID}", method = RequestMethod.PUT)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE"})
	public ResponseEntity<CreateSlotResponse> updateSlot(
			@NotNull
			@AuthenticationPrincipal
			UserProfile userProfile,
			@NotNull
			@PathVariable("slotID")
			Integer slotID,
			@NotNull
			@Valid
			@RequestBody
			UpdateSlotRequest updateSlotRequest) {

		SlotEntity slot = slotService.updateSlot(userProfile, slotID, updateSlotRequest);
		CreateSlotResponse updateSlotResponse = DataMapper.INSTANCE.toCreateResponse(slot);
		return new ResponseEntity<>(updateSlotResponse, HttpStatus.OK);
	}

	@RequestMapping(value = "/{slotID}", method = RequestMethod.GET)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
	public ResponseEntity<GetSlotResponse> getSlot(
			@NotNull
			@AuthenticationPrincipal
			UserProfile userProfile,
			@NotNull
			@PathVariable("slotID")
			Integer slotID) {

		List<EngineEntity> engines = engineRepository.getEnginesBySlotID(slotID);
		SlotEntity slot = slotService.getSlotByID(userProfile, slotID);
		GetSlotResponse slotResponse = DataMapper.INSTANCE.toGetResponse(slot, engines);
		return new ResponseEntity<>(slotResponse, HttpStatus.OK);
	}

	@RequestMapping(value = "/{slotID}", method = RequestMethod.DELETE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE"})
	public ResponseEntity<?> deleteSlot(
			@NotNull
			@AuthenticationPrincipal
			UserProfile userProfile,
			@NotNull
			@PathVariable("slotID")
			Integer slotID) {

		slotService.deleteSlot(userProfile, slotID);
		return ResponseEntity.ok(null);
	}
}
