package com.pw.dome.admin;

import static com.pw.dome.common.oas.ApiOperations.Tags.ADMIN;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.common.oas.BaseRESTfulResource;
import com.pw.dome.exception.ErrorResponse;
import com.pw.dome.user.UserProfile;
import com.pw.dome.user.UserProfileResponse;
import com.pw.dome.user.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController()
@RequestMapping("/v1/admin")
@Tag(name = ADMIN)
class AdminController extends BaseRESTfulResource {
    @Autowired
    private AdminService adminService;
    @Autowired
    private UserService userService;

    @PostMapping(path = "/users",
                 produces = APPLICATION_JSON_VALUE)
    @Operation(tags = { Tags.ADMIN }, // For multi-tagging
               description = "Create new user profile.",
               responses = {
                   @ApiResponse(content = @Content(schema = @Schema(implementation = UserProfileResponse.class),
                                                   mediaType = MediaType.APPLICATION_JSON_VALUE),
                                responseCode = OK),
                   @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                                responseCode = BAD_REQUEST,
                                description = Descriptions.BAD_REQUEST),
                   @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                                responseCode = UNAUTHORIZED,
                                description = Descriptions.UNAUTHORIZED),
                   @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                                responseCode = INTERNAL_SERVER_ERROR,
                                description = Descriptions.INTERNAL_SERVER_ERROR)
               })
    public ResponseEntity<UserProfileResponse> createUserProfile(
        @Valid
        @RequestBody
        @Parameter(description = "User Profile",
                   required = true,
                   schema = @Schema(implementation = UserProfileResponse.class)
        )
        UserProfileResponse userDetails,
        @AuthenticationPrincipal UserProfile userProfile) {
        adminService.userCreate(userDetails, userProfile);
        String userEmail =
            userDetails.getEmailAddress();

    	UserProfileResponse response = userService.getUserProfileByEmail(userEmail);
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/accounts",
                produces = APPLICATION_JSON_VALUE)
    @Operation(tags = { Tags.ADMIN }, // For multi-tagging
               description = "Gets account management information.",
               responses = {
                   @ApiResponse(content = @Content(schema = @Schema(implementation = AccountManagementResponse.class),
                                                   mediaType = MediaType.APPLICATION_JSON_VALUE),
                                responseCode = OK),
                   @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                                responseCode = UNAUTHORIZED,
                                description = Descriptions.UNAUTHORIZED),
                   @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                                responseCode = INTERNAL_SERVER_ERROR,
                                description = Descriptions.INTERNAL_SERVER_ERROR)
               })
    public ResponseEntity<AccountManagementResponse> getAccountManagementResponse(@RequestParam(defaultValue = "false", name = "filtered", required = false) boolean filtered) {
        AccountManagementResponse response = adminService.getAccountManagementResponse(filtered);
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/operatorCenterMatrix",
            produces = APPLICATION_JSON_VALUE)
    @Operation(tags = { Tags.ADMIN },
           description = "Get operator centers matrix information.",
           responses = {
               @ApiResponse(content = @Content(schema = @Schema(implementation = OperatorCentersResponse.class),
                                               mediaType = MediaType.APPLICATION_JSON_VALUE),
                            responseCode = OK),
                @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = UNAUTHORIZED,
                            description = Descriptions.UNAUTHORIZED),
               @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = INTERNAL_SERVER_ERROR,
                            description = Descriptions.INTERNAL_SERVER_ERROR)
           })
    public ResponseEntity<CustomerCenterMatrixResponse> getOperatorCenterMatrix() {
    	
    	List<CustomerCenterMatrixDTO> centersMatrix = adminService.getCustomerCenterMatrix();
    	CustomerCenterMatrixResponse response = CustomerCenterMatrixResponse.builder().customerCenterMatrixList(centersMatrix).build();
    	
    	return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/operatorCenters",
            produces = APPLICATION_JSON_VALUE)
    @Operation(tags = { Tags.ADMIN },
           description = "Get operator centers information.",
           responses = {
               @ApiResponse(content = @Content(schema = @Schema(implementation = OperatorCentersResponse.class),
                                               mediaType = MediaType.APPLICATION_JSON_VALUE),
                            responseCode = OK),
                @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = UNAUTHORIZED,
                            description = Descriptions.UNAUTHORIZED),
               @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = INTERNAL_SERVER_ERROR,
                            description = Descriptions.INTERNAL_SERVER_ERROR)
           })
    public ResponseEntity<OperatorCentersResponse> getOperatorCenters() {
    	
    	List<OperatorEngineCenter> centers = adminService.getOperatorEngineCenters();
    	OperatorCentersResponse response = OperatorCentersResponse.builder().engineCenters(centers).build();
    	
    	return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/operators",
            produces = APPLICATION_JSON_VALUE)
    @Operation(tags = { Tags.ADMIN },
           description = "Get operators information.",
           responses = {
               @ApiResponse(content = @Content(schema = @Schema(implementation = OperatorResponse.class),
                                               mediaType = MediaType.APPLICATION_JSON_VALUE),
                            responseCode = OK),
                @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = UNAUTHORIZED,
                            description = Descriptions.UNAUTHORIZED),
               @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = INTERNAL_SERVER_ERROR,
                            description = Descriptions.INTERNAL_SERVER_ERROR)
           })
    public ResponseEntity<OperatorResponse> getOperators(){
    	
    	List<Operator> operators = adminService.getOperators();
    	OperatorResponse response = OperatorResponse.builder().operators(operators).build();
    	
    	return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/users",
    		produces = APPLICATION_JSON_VALUE)
    @Operation(tags = { Tags.ADMIN }, // For multi-tagging
    description = "Returns user info of profiles having status of APPROVED.",
    responses = {
    		@ApiResponse(content = @Content(schema = @Schema(implementation = UserProfile.class),
    				mediaType = MediaType.APPLICATION_JSON_VALUE),
    				responseCode = OK),
    		@ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
    		responseCode = BAD_REQUEST,
    		description = Descriptions.BAD_REQUEST),
    		@ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
    		responseCode = UNAUTHORIZED,
    		description = Descriptions.UNAUTHORIZED),
    		@ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
    		responseCode = INTERNAL_SERVER_ERROR,
    		description = Descriptions.INTERNAL_SERVER_ERROR)
    })
    public ResponseEntity<UserInfoResponse> getUserInfo() {

    	UserInfoResponse response = adminService.getUserInfoApproved();
    	return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/users-pending-approval",
            produces = APPLICATION_JSON_VALUE)
    @Operation(tags = { Tags.ADMIN }, // For multi-tagging
           description = "Returns user info of profiles having status of REQUEST or UPDATE.",
           responses = {
               @ApiResponse(content = @Content(schema = @Schema(implementation = UserProfile.class),
                                               mediaType = MediaType.APPLICATION_JSON_VALUE),
                            responseCode = OK),
               @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = BAD_REQUEST,
                            description = Descriptions.BAD_REQUEST),
               @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = UNAUTHORIZED,
                            description = Descriptions.UNAUTHORIZED),
               @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = INTERNAL_SERVER_ERROR,
                            description = Descriptions.INTERNAL_SERVER_ERROR)
           })
    public ResponseEntity<UserInfoResponse> getUserInfoPendingApproval() {
    	UserInfoResponse response = adminService.getUsersPendingApproval();

    	return ResponseEntity.ok(response);
    }
    
    @GetMapping(path = "/user-profile",
                produces = APPLICATION_JSON_VALUE)
    @Operation(tags = { Tags.ADMIN }, // For multi-tagging
               description = "Returns user profile details for the given email address.",
               responses = {
                   @ApiResponse(content = @Content(schema = @Schema(implementation = UserProfile.class),
                                                   mediaType = MediaType.APPLICATION_JSON_VALUE),
                                responseCode = OK),
                   @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                                responseCode = BAD_REQUEST,
                                description = Descriptions.BAD_REQUEST),
                   @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                                responseCode = UNAUTHORIZED,
                                description = Descriptions.UNAUTHORIZED),
                   @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                                responseCode = INTERNAL_SERVER_ERROR,
                                description = Descriptions.INTERNAL_SERVER_ERROR)
               })
    public ResponseEntity<UserProfileResponse> getUserProfileByEmail (
        @Parameter(description = "User Email", required = true)
        @RequestParam(name = "user-email", required = true)
        String userEmail) {

        UserProfileResponse response = userService.getUserProfileByEmail(userEmail);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping(path = "/user-profile-pending-approval",
    		produces = APPLICATION_JSON_VALUE)
    @Operation(tags = { Tags.ADMIN }, // For multi-tagging
    description = "Returns user profile details for the given email address having status of REQUEST or UPDATE.",
    responses = {
    		@ApiResponse(content = @Content(schema = @Schema(implementation = UserProfile.class),
    				mediaType = MediaType.APPLICATION_JSON_VALUE),
    				responseCode = OK),
    		@ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
    		responseCode = BAD_REQUEST,
    		description = Descriptions.BAD_REQUEST),
    		@ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
    		responseCode = UNAUTHORIZED,
    		description = Descriptions.UNAUTHORIZED),
    		@ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
    		responseCode = INTERNAL_SERVER_ERROR,
    		description = Descriptions.INTERNAL_SERVER_ERROR)
    })
    public ResponseEntity<UserProfileResponse> getUserProfileByEmailPendingApproval (
    		@Parameter(description = "User Email", required = true)
    		@RequestParam(name = "user-email", required = true)
    		String userEmail) {

    	UserProfileResponse response = userService.getMergedUserProfileByEmail(userEmail);

    	return ResponseEntity.ok(response);
    }
    
    @PutMapping(path = "/operatorCenterMatrix",
            produces = APPLICATION_JSON_VALUE)
    @Operation(tags = { Tags.ADMIN },
           description = "Add operator centers matrix information.",
           responses = {
               @ApiResponse(content = @Content(schema = @Schema(implementation = CustomerCenterMatrixResponse.class),
                                               mediaType = MediaType.APPLICATION_JSON_VALUE),
                            responseCode = OK),
                @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = UNAUTHORIZED,
                            description = Descriptions.UNAUTHORIZED),
               @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = INTERNAL_SERVER_ERROR,
                            description = Descriptions.INTERNAL_SERVER_ERROR)
           })
    public ResponseEntity<CustomerCenterMatrixResponse> updateOperatorCenterMatrix(
    		@Valid
    		@RequestBody
    		CustomerCenterMatrixResponse request){
    	
    	adminService.addCustomerCenterMatrix(request);
    	
    	return ResponseEntity.ok(request);
    }

    @PutMapping(path = "/user-maintenance",
            produces = APPLICATION_JSON_VALUE)
@Operation(tags = { Tags.ADMIN }, // For multi-tagging
           description = "Update user profile.",
           responses = {
               @ApiResponse(content = @Content(schema = @Schema(implementation = UserProfileResponse.class),
                                               mediaType = MediaType.APPLICATION_JSON_VALUE),
                            responseCode = OK),
               @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = BAD_REQUEST,
                            description = Descriptions.BAD_REQUEST),
               @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = UNAUTHORIZED,
                            description = Descriptions.UNAUTHORIZED),
               @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                            responseCode = INTERNAL_SERVER_ERROR,
                            description = Descriptions.INTERNAL_SERVER_ERROR)
           })
public ResponseEntity<UserProfileResponse> userMaintenance(
        @Valid
        @RequestBody
        UserProfileResponse userDetails,
        @AuthenticationPrincipal UserProfile userProfile) {

	adminService.userMaintenance(userDetails, userProfile);

	String userEmail = userDetails.getEmailAddress();
	UserProfileResponse response = userService.getUserProfileByEmail(userEmail);

	return ResponseEntity.ok(response);
}

    @PutMapping(path = "/user-approval",
                produces = APPLICATION_JSON_VALUE)
    @Operation(tags = { Tags.ADMIN }, // For multi-tagging
               description = "Update user profile.",
               responses = {
                   @ApiResponse(content = @Content(schema = @Schema(implementation = UserProfileResponse.class),
                                                   mediaType = MediaType.APPLICATION_JSON_VALUE),
                                responseCode = OK),
                   @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                                responseCode = BAD_REQUEST,
                                description = Descriptions.BAD_REQUEST),
                   @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                                responseCode = UNAUTHORIZED,
                                description = Descriptions.UNAUTHORIZED),
                   @ApiResponse(content = @Content(schema = @Schema(implementation = ErrorResponse.class)),
                                responseCode = INTERNAL_SERVER_ERROR,
                                description = Descriptions.INTERNAL_SERVER_ERROR)
               })
    public ResponseEntity<UserProfileResponse> userApproval(
            @Valid
            @RequestBody
            UserProfileResponse userDetails,
            @AuthenticationPrincipal UserProfile userProfile) {

    	adminService.userApproval(userDetails, userProfile);

    	String userEmail = userDetails.getEmailAddress();
    	UserProfileResponse response = userService.getUserProfileByEmail(userEmail);

    	return ResponseEntity.ok(response);
    }
}
