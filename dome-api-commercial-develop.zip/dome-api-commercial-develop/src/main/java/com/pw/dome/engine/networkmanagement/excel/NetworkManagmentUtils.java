package com.pw.dome.engine.networkmanagement.excel;

import static com.pw.dome.report.excel.ReportConstants.DATE_FORMAT;
import static com.pw.dome.util.excel.Border.BorderStyles.THIN;
import static com.pw.dome.util.excel.CellStyle.AlignH.LEFT;

import java.util.Arrays;

import com.pw.dome.util.excel.Border;
import com.pw.dome.util.excel.CellStyle;
import com.pw.dome.util.excel.CellStyle.AlignH;
import com.pw.dome.util.excel.CellStyle.AlignV;
import com.pw.dome.util.excel.CellStyle.FillPattern;
import com.pw.dome.util.excel.CellValues;
import com.pw.dome.util.excel.CellValues.Builder;
import com.pw.dome.util.excel.Colors;
import com.pw.dome.util.excel.FontStyle;

import lombok.Getter;

class NetworkManagmentUtils {

	@Getter
	private static final CellStyle boldLeftBlueWrapperHeader = getStyle(true, true, false, true, Colors.SKY_BLUE, null,
			LEFT, null);
	@Getter
	private static final CellStyle plainLeft = getStyle(false, false, false, false, null, null, LEFT, null);
	@Getter
	private static final CellStyle leftPlainDate = getStyle(false, false, true, false, null, null, LEFT, null);

	private static CellStyle getStyle(boolean bold, boolean border, boolean date, boolean wrapText, Colors bgColor,
			Colors textColor, AlignH horizontalAlignment, AlignV verticalAlignment) {
		final CellStyle.CellStyleBuilder cb = CellStyle.builder();
		final FontStyle.FontStyleBuilder fb = FontStyle.builder();

		fb.bold(bold);
		if (textColor != null) {
			fb.color(textColor);
		}
		if (border) {
			cb.border(Border.of(THIN));
		}
		if (date) {
			cb.dataFormat(DATE_FORMAT);
		}
		cb.wrapText(wrapText);
		if (bgColor != null) {
			cb.fillForegroundColor(bgColor).fillPattern(FillPattern.SOLID_FOREGROUND);
		}
		cb.fontStyle(fb.build());
		if (horizontalAlignment != null) {
			cb.alignH(horizontalAlignment);
		}
		if (verticalAlignment != null) {
			cb.alignV(verticalAlignment);
		}
		return cb.build();
	}

	public static CellValues getNetworkDataReportHeaders() {
		String[] hdrs = { "ESN ", "Event ID ", "Engine Type ", "Customer ", "Operator ", "Thrust ", "TSN ", "CSN ", "TSO ",
				"CSO ", "LLP Cyc Rem ", "Contractual\nRemoval ", "Investigation\nEngine ", "FHA\nEligibility\nRemoval ",
				"PWEL\nAsset ", "Removal\nReason ", "Contract\nType ", "Contract\nDescription ", "Subfleet ",
				"Contracted\nYears ", "Contracted SVs ", "Coverage\nEnd\nDate ", "Lease\nReturn\nDate ", "Refurb\nPay\nStructure ",
				"LLP\nCoverage ", "S1\nRetrofit\nConverage ", "Lease\nReturn\nCoverage ", "Acessory\nCoverage ",
				"Shipping\nCoverage ", "Disabled ", "Warranty ", "Removal Date\nActual ", "Removal Date\nRecorded ",
				"SPEID PO (txt) ", "RSL PO (txt) ",
				"AIM\nAllocation\nDate ", "LLP Data\nDelivery\nDate ", "Accessory Data\nDelivery Date ", "NIS\nDelivery\nDate ",
				"Fan Blade\nMap\nDate ", "AD\nList\nDate ", "WS\nInitial\nDate ", "WS Draft\nComplete Date\nEng ",
				"WS Draft\nComplete Date\nAccy ", "Customer\nApproval\nDate ", "WS Original\nRelease\nDate ", "Plan EBU Shop ",
				"Maintenance\nCenter ", "Estimated\nWorkscope ", "SV Classification / WS ", "LLP Replacement Type ", "Upgrade\nEligibility ",
				"Powerplant Engineer ", "CFD/FM ", "Comment ", "Current\nLocation ", "ETA at EBU ", "Actual\nArrival\nat EBU ",
				"TAR Date ", "Sales Order ", "Priority ", "Shop Visit# ", "Revenue ", "Parent ESN ", "Category ",
				"Order Type Shipment Type ", "Maintenance Center\nETA/\nForecast ", "Forecast\nReceiving ",
				"Forecast\nRemoval ", "Forecast\nInduct ", "Forecast\nGate1\nClose ", "Forecast\nKit\nComplete ",
				"Forecast\nGate3\nStart ", "Forecast\nGate3\nClose ", "Forecast\nCore\nAssembly ", "Forecast\nTest\nStart ",
				"Forecast\nTest\nComplete ", "Forecast\nAsset\nComplete ", "Forecast\nShip ", "Forecast\nShip\nCustomer ",
				"Actual Arrival\nat Maintenance Center /\nActual Receipt  ", "Actual\nReceiving ", "Actual\nRemoval ",
				"Actual\nInduct ", "Actual\nGate1\nClose ", "Actual\nKit\nComplete ", "Actual\nGate3\nStart ",
				"Actual\nGate3\nClose ", "Actual\nCore\nAssembly ", "Actual\nTest\nStart ", "Actual\nTest\nComplete ",
				"Actual\nAsset\nComplete ", "Actual\nShip ", "Actual\nShip\nCustomer ",
				"External\nReceipt ", "External\nReceiving ", "External\nInduct ", "External\nGate1\nClose ",
				"External\nKit\nComplete ", "External\nGate3\nStart ", "External\nGate3\nClose ",
				"External\nCore\nAssembly ", "External\nTest\nStart ", "External\nTest\nComplete ",
				"External\nAsset\nComplete ", "External\nShip ", "External\nShip\nCustomer ",
				"Standard\nReceipt ", "Standard\nReceiving ", "Standard\nRemove ", "Standard\nInduct ",
				"Standard\nGate1\nClose ", "Standard\nKit\nComplete ", "Standard\nGate3\nStart ", "Standard\nGate3\nClose ",
				"Standard\nCore\nAssembly ", "Standard\nTest\nStart ", "Standard\nTest\nComplete ",
				"Standard\nAsset\nComplete ", "Standard\nShip ", "Standard\nShip\nCustomer ",
				"SMI\nNeed\nDate ", "Investigation\nCategory ", "Tar\nCheckbox"};

		CellStyle style = getBoldLeftBlueWrapperHeader();
		Builder b = CellValues.builder();
		Arrays.stream(hdrs).forEach(h -> b.add(style, h));
		return b.build();
	}

	public static CellValues getData(NetworkManagement data) {
		CellStyle style = getPlainLeft();
		CellStyle dateStyle = getLeftPlainDate();
		Builder b = CellValues.builder();

		b.add(style, data.getEsn());
		b.add(style, data.getEventId());
		b.add(style, data.getEngineType());
		b.add(style, data.getCustomerName());
		b.add(style, data.getOperator());
		b.add(style, data.getThrust());
		b.add(style, data.getTsn());
		b.add(style, data.getCsn());
		b.add(style, data.getTso());
		b.add(style, data.getCso());
		b.add(style, data.getLlpCyclesRem());
		b.add(style, data.getContractualRemoval(), "Y", "N", "N");
		b.add(style, data.getInvestigationEngine(), "Y", "N", "N");
		b.add(style, data.getFhaEligibilityRemoval(), "Y", "N", "N");
		b.add(style, data.getPwelAsset(), "Y", "N", "N");
		b.add(style, data.getRemovalReason());
		b.add(style, data.getContractType());
		b.add(style, data.getContractDescription());
		b.add(style, data.getContractSubFleet());
		b.add(style, data.getContractedYears());
		b.add(style, data.getContractedSvs());
		b.add(dateStyle, data.getCoverageEndDate());
		b.add(dateStyle, data.getLeaseReturnDate());
		b.add(style, data.getRefurbPayStructure());
		b.add(style, data.getLlpCoverage());
		b.add(style, data.getS1RetrofitCoverage());
		b.add(style, data.getLeaseReturnCoverage());
		b.add(style, data.getAccessoryCoverage());
		b.add(style, data.getShippingCoverage());
		b.add(style, data.getDisabled(), "Y", "N", "N");
		b.add(style, data.getEngineWarranty(), "Y", "N", "N");
		b.add(dateStyle, data.getActualRemoval());
		b.add(dateStyle, data.getRemovalDateRecorded());
		b.add(style, data.getSpeidPo());
		b.add(style, data.getRslPo());
		b.add(style, data.getAimAllocation());
		b.add(dateStyle, data.getLlpDelivery());
		b.add(dateStyle, data.getAccyDelivery());
		b.add(dateStyle, data.getNisDelivery());
		b.add(dateStyle, data.getFanBladeMapDate());
		b.add(dateStyle, data.getAdListDate());
		b.add(dateStyle, data.getWsInitialDate());
		b.add(dateStyle, data.getWsDraftCompleteEngDate());
		b.add(dateStyle, data.getWsDraftCompleteAccyDate());
		b.add(dateStyle, data.getCustomerApprovalDate());
		b.add(dateStyle, data.getWsOriginalReleaseDate());
		b.add(style, data.getPlanEbuShop());
		b.add(style, data.getMaintenanceCenter());
		b.add(style, data.getEstimatedWorkscope());
		b.add(style, data.getSvClassificationCenter());
		b.add(style, data.getLlpReplacementType());
		b.add(style, data.getUpgradeEligibility());
		b.add(style, data.getPowerplantEngineer());
		b.add(style, data.getCfdFm());
		b.add(style, data.getComment());
		b.add(style, data.getCurrentLocation());
		b.add(style, data.getEtaAtEbu());
		b.add(dateStyle, data.getActualArrivalAtEbu());
		b.add(dateStyle, data.getTarDate());
		b.add(style, data.getSalesOrder());
		b.add(style, data.getPriority());
		b.add(style, data.getShopVisitNumber());
		b.add(style, data.getRevenue(), "Y", "N", "N");
		b.add(style, data.getParentEsn());
		b.add(style, data.getCategory());
		b.add(style, data.getOrderType());
		b.add(dateStyle, data.getForecastReceipt());
		b.add(dateStyle, data.getForecaseReceiving());
		b.add(dateStyle, data.getForecastRemoval());
		b.add(dateStyle, data.getForecastInduction());
		b.add(dateStyle, data.getForecastGate1Close());
		b.add(dateStyle, data.getForecastKitComplete());
		b.add(dateStyle, data.getForecastGate3Start());
		b.add(dateStyle, data.getForecastGate3Close());
		b.add(dateStyle, data.getForecastCoreAssembly());
		b.add(dateStyle, data.getForecastTestStart());
		b.add(dateStyle, data.getForecastTestComplete());
		b.add(dateStyle, data.getForecastAssetComplete());
		b.add(dateStyle, data.getForecastShip());
		b.add(dateStyle, data.getForecastShipCustomer());
		b.add(dateStyle, data.getActualReceipt());
		b.add(dateStyle, data.getActualReceiving());
		b.add(dateStyle, data.getActualRemoval());
		b.add(dateStyle, data.getActualInduction());
		b.add(dateStyle, data.getActualGate1Close());
		b.add(dateStyle, data.getActualKitComplete());
		b.add(dateStyle, data.getActualGate3Start());
		b.add(dateStyle, data.getActualGate3Close());
		b.add(dateStyle, data.getActualCoreAssembly());
		b.add(dateStyle, data.getActualTestStart());
		b.add(dateStyle, data.getActualTestComplete());
		b.add(dateStyle, data.getActualAssetComplete());
		b.add(dateStyle, data.getActualShip());
		b.add(dateStyle, data.getActualShipCustomer());
		b.add(dateStyle, data.getExternalReceipt());
		b.add(dateStyle, data.getExternalReceiving());
		b.add(dateStyle, data.getExternalInduc());
		b.add(dateStyle, data.getExternalGate1Close());
		b.add(dateStyle, data.getExternalKitComplete());
		b.add(dateStyle, data.getExternalGate3Start());
		b.add(dateStyle, data.getExternalGate3Close());
		b.add(dateStyle, data.getExternalCoreAssembly());
		b.add(dateStyle, data.getExternalTestStart());
		b.add(dateStyle, data.getExternalTestComplete());
		b.add(dateStyle, data.getExternalAssetComplete());
		b.add(dateStyle, data.getExternalShip());
		b.add(dateStyle, data.getExternalShipCustomer());
//		b.add(dateStyle, data.getActualShipCustomer());
		b.add(dateStyle, data.getStandardReceipt());
		b.add(dateStyle, data.getStandardReceiving());
		b.add(dateStyle, data.getStandardRemove());
		b.add(dateStyle, data.getStandardInduc());
		b.add(dateStyle, data.getStandardGate1Close());
		b.add(dateStyle, data.getStandardKitComplete());
		b.add(dateStyle, data.getStandardGate3Start());
		b.add(dateStyle, data.getStandardGate3Close());
		b.add(dateStyle, data.getStandardCoreAssembly());
		b.add(dateStyle, data.getStandardTestStart());
		b.add(dateStyle, data.getStandardTestComplete());
		b.add(dateStyle, data.getStandardAssetComplete());
		b.add(dateStyle, data.getStandardShip());
		b.add(dateStyle, data.getStandardShipCustomer());
		b.add(dateStyle, data.getSmiNeedDate());
		b.add(style, data.getInvestigationCategory());
		b.add(style, data.getTarCheckbox(), "Y", "N", "N");

		return b.build();
	}
}
