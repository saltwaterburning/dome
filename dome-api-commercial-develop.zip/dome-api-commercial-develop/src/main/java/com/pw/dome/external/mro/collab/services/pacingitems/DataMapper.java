package com.pw.dome.external.mro.collab.services.pacingitems;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.wip.pacing.PacingItemEntity;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

	@Mapping(target = "description", source = "entity.partDesc")
	@Mapping(target = "esn", source = "entity.engSN")
	@Mapping(target = "eventId", ignore = true)
//	@Mapping(target = "createDateTime", source = "entity.logDateTime")
	@Mapping(target = "mroShopCode", ignore = true)
	@Mapping(target = "mroWorkOrder", ignore = true)
	@Mapping(target = "subCategory", source = "entity.subcategory")
	MroPacingItem toMroPacingItem(PacingItemEntity entity);

	List<MroPacingItem> toPacingItem(List<PacingItemEntity> entities);
}
