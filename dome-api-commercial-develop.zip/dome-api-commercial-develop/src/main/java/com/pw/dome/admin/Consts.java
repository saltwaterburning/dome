package com.pw.dome.admin;

/**
 * Defines package private constants.
 */
interface Consts {

    String DELIM = "@";
    String FILTER_ENGINE_GROUP_NAME = "V2500-E5";

    interface SQL {
        String GET_ALL_ENGINE_CENTERS =
            "SELECT" +
            "    ec_id, ec_name" +
            " FROM" +
            "    dome_engine_center" +
            " WHERE ec_action = 'A'" +
            " ORDER BY" +
            "    2";

        String GET_ALL_ENGINE_CENTERS_AND_MATCHING_ENGINE_GROUPS =
            "SELECT DISTINCT" +
            "    ec.ec_id, ec.ec_name, egm.eng_group_id, egm.eng_group_name, egm.eng_type_id, etm.eng_type_name" +
            " FROM" +
            "    dome_engine_center       ec," +
            "    dome_eng_group_mst       egm," +
            "    dome_eng_type_center_map etcm," +
            "    dome_eng_type_mst        etm" +
            " WHERE" +
            "    ec.ec_id = etcm.ec_center_id" +
            "    AND egm.eng_type_id = etm.eng_type_id" +
            "    AND egm.eng_type_id = etcm.ec_type_id" +
            "    AND ec_action = 'A'" +
            "    AND eng_group_action = 'A'" +
            "    AND eng_type_action = 'A'" +
            " ORDER BY" +
            "    2, 4, 5";

        String GET_ALL_ENGINE_CENTERS_AND_MATCHING_ENGINE_GROUPS_EXCEPT =
                "SELECT DISTINCT" +
                "    ec.ec_id, ec.ec_name, egm.eng_group_id, egm.eng_group_name, egm.eng_type_id, etm.eng_type_name" +
                " FROM" +
                "    dome_engine_center       ec," +
                "    dome_eng_group_mst       egm," +
                "    dome_eng_type_center_map etcm," +
                "    dome_eng_type_mst        etm" +
                " WHERE" +
                "    ec.ec_id = etcm.ec_center_id" +
                "    AND egm.eng_type_id = etm.eng_type_id" +
                "    AND egm.eng_type_id = etcm.ec_type_id" +
                "    AND ec_action = 'A'" +
                "    AND eng_group_action = 'A'" +
                "    AND eng_type_action = 'A'" +
                "    AND egm.eng_group_name != :filterEngGroupName" +
                " ORDER BY" +
                "    2, 4, 5";

        String GET_ALL_ENGINE_GROUPS =
            "SELECT" +
            "    eng_group_id, eng_group_name, egm.eng_type_id, eng_type_name" +
            " FROM" +
            "    dome_eng_group_mst egm," +
            "    dome_eng_type_mst  etm" +
            " WHERE" +
            "    egm.eng_type_id = etm.eng_type_id" +
            "    AND eng_group_action = 'A'" +
            "    AND eng_type_action = 'A'" +
            " ORDER BY" +
            "    2";

        String GET_PENDING_USER_APPROVALS =
        		"""
        				SELECT new com.pw.dome.admin.UserInfo(
        				updateDate,
        				emailAddress,
        				firstName,
        				lastName,
        				organization,
        				status)
        				FROM UserProfileUpdateEntity p
        				ORDER BY updateDate
        				""";
//         				WHERE status in (:userStatus)

        String GET_APPROVED_USERS =
        		"""
        				SELECT new com.pw.dome.admin.UserInfo(
        				updateDate,
        				emailAddress,
        				firstName,
        				lastName,
        				organization,
        				status)
        				FROM UserProfile p
        				WHERE status = com.pw.dome.admin.ProfileStatus.APPROVED
        				ORDER BY updateDate
        				""";

        String GET_ALL_USERS_WITH_STATUS__ =
        		"""
        				SELECT new com.pw.dome.admin.UserInfo(
        				COALESCE(p2.updateDate, p1.updateDate),
        				p1.emailAddress,
        				COALESCE(p2.firstName, p1.firstName),
        				COALESCE(p2.lastName, p1.lastName),
        				COALESCE(p2.organization, p1.organization),
        				COALESCE(p2.status, p1.status)
        				FROM UserProfile p1
        				LEFT OUTER JOIN UserProfileUpdateEntity        p2 ON p1.emailAddress = p2.emailAddress
        				WHERE p1.status in (:userStatus)
        				OR p2.status in (:userStatus)
        				ORDER BY COALESCE(p2.updateDate, p1.status)
        				""";

        String GET_ALL_USERS_WITH_STATUS_ =
                "SELECT log_email, log_firstname, log_lastname, log_status, log_update_date, log_organization" +
                "  FROM dome_login" +
                " WHERE log_status in (:userStatus)" +
                "    OR log_status = 'UPDATE'" +
                " ORDER BY log_update_date";
        
        String GET_OPERATOR_CENTER_LIST = 
				" SELECT " +
				" 	map.ec_center_id, ec.ec_name,  map.ec_type_id, etm.eng_type_name " + 
				" FROM dome_eng_type_center_map map, " + 
				"   dome_engine_center ec, " + 
				"   dome_eng_type_mst etm " + 
				" WHERE " +
				" 	map.ec_center_id = ec.EC_ID " + 
				"  	AND map.EC_TYPE_ID = etm.ENG_TYPE_ID " + 
				"  	AND ec.EC_ACTION = 'A' " + 
				"  	AND etm.ENG_TYPE_ACTION = 'A' " + 
				"  ORDER BY ec.EC_name, etm.eng_type_name";
		
        String GET_OPERATORS_LIST = 
				" SELECT " +
				" 	map.cust_id as customerId, customer.cust_name as customerName, customer.cust_sname as customerSName, map.eng_type_id as engineTypeId, engType.eng_type_name as engineTypeName " +
				" FROM " + 
				" 	dome_customer_type_map map, " + 
				" 	dome_customer customer, " + 
				" 	dome_eng_type_mst engType " +
				" WHERE " +
				"	map.cust_id = customer.cust_id " + 
				" 	AND map.eng_type_id = engType.eng_type_id " +
				" 	AND customer.cust_status = 'Active' " + " AND engType.eng_type_action = 'A' " +
				" ORDER BY customer.cust_name, engType.eng_type_name";
    }
}
