package com.pw.dome.enginecenter;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * @author John De Lello
 */
@Repository
public interface EngineCenterRepository extends JpaRepository<EngineCenterEntity, String> {

	@Query(value = "SELECT e FROM EngineCenterEntity e WHERE e.active = true ORDER BY e.name")
	List<EngineCenterEntity> getActiveEngineCenters();

	@Query(value = "SELECT ec FROM EngineCenterEntity ec WHERE ec.id IN (SELECT engineCenterId FROM SecurityEngineCenterEntity s where lower(s.emailAddress) = lower(?1)) AND ec.active = true ORDER BY ec.name")
	List<EngineCenterEntity> getActiveEngineCenters(final String emailAddress);

	@Query(value = "SELECT * FROM dome_engine_center ORDER BY ec_name", nativeQuery = true)
	List<EngineCenterEntity> getAllEngineCenters();

	@Query(value = "SELECT dome_eng_center_id_seq.nextval FROM dual", nativeQuery = true)
	Long getNextSeqVal();
}
