package com.pw.dome.engine.removed;


import java.time.LocalDate;

import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class EngineRemovedDetailResponse {
	private LocalDate accyDeliveryDate;
	private LocalDate actualRecEbu;
	private LocalDate adListDate;
	private LocalDate aimAllocationDate;
	private int assetId;
	private String comments;
	private String contractRemoval;
	private Integer csn;
	private Integer cso;
	private String currentLocation;
	private LocalDate customerApprovalDate;
	private String ebuShop;
	private LocalDate engineActualReceiptDate;
	private int engineAssetId;
	private Integer engineId;
	private String engineModelID;

	private String engineModelName;
	
	private LocalDate enginePlanReceiptDate;

	private String esn;
	private LocalDate fanBladeMapDate;
	
	private String fhaEligible;
	
	private String investigationEngine;
	
	private Integer llpCycRemain;
    
	private LocalDate llpDeliveryDate;
    
	private String llpReplacementType;
	
	private String maintenanceCenter;
    
	private LocalDate nisDeliveryDate;
    
	private Integer odinId;

	private String operatorID;

	private String operatorName;

	private String operatorShortName;
	@Size(max = 50)
	private String powerEngineer;
	private LocalDate projRecEbu;
	private LocalDate removalDateActual;
	private LocalDate removalDateRecorded;
	private String removalReason;
	private String rslPO;
	private LocalDate scheduledInductionDate;
	//ODIN Data
	private String speidPO;
	private String svClassification;
	
	private String thrust;
	
	private Integer tsn;
	
	private Integer tso;
	
	private String upgradeEligibility;
	
	private String workOrder;

	private LocalDate wsDraftCompleteAccyDate;
	
	private LocalDate wsDraftCompleteEngDate;

	private LocalDate wsInitiationDate;

	private LocalDate wsOrigReleaseDate;
}
