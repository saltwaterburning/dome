package com.pw.dome.engine;

import static java.util.Objects.isNull;
import static org.hibernate.annotations.NotFoundAction.IGNORE;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import org.hibernate.annotations.NotFound;

import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.customer.CustomerEntity;
import com.pw.dome.engine.tracking.EngineTrackingEntity;
import com.pw.dome.jpa.AbstractEntityWithGeneratedId;
import com.pw.dome.module.ModuleEntity;
import com.pw.dome.user.UserProfile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author John De Lello
 */
@Entity
@Table(name = "DOME_ENGINE")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EngineEntity extends AbstractEntityWithGeneratedId<Integer> {
	@Column(name = "ASSET_ID")
	private Integer assetID;

    @Column(name = "CSN")
    private Integer csn;

    @Column(name = "CSO")
    private Integer cso;
    
	@Column(name = "ENG_CATEGORY")
	private String category;

	@Column(name = "ENG_CUST_ID")
	private String customerID;

    @OneToOne
	@NotFound(action = IGNORE)
	@JoinColumn(name = "ENG_CUST_ID", insertable = false, updatable = false)
	private CustomerEntity customer;

	@Column(name = "ENG_TYPE_ID")
	private String engineTypeId;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOME_ENG_ID_SEQ")
	@SequenceGenerator(sequenceName = "DOME_ENG_ID_SEQ", allocationSize = 1, name = "DOME_ENG_ID_SEQ")
	@Column(name = "ENG_ID")
	private Integer engineID;

    @OneToOne
	@NotFound(action = IGNORE)
	@JoinColumn(name = "ENG_ID", insertable = false, updatable = false)
	private EngineTrackingEntity engineTrackingEntity;

    @Column(name = "ENG_SN")
	private String esn;

	@Column(name = "EVENT_ID")
	private Integer eventId;

	// engineActualReceiptDate
	@Column(name = "GATE1")
	private LocalDate gate1;

	// enginePlanReceiptDate
	@Column(name = "GATE1_PLAN")
	private LocalDate gate1Plan;

	@Column(name = "ENG_GROUP")
	private String groupID;

    @Column(name = "LLPCYCREMAIN")
    private Integer llpCycRemain;
    
	@Column(name = "LOG_EMAIL")
	private String logEmail;

	@Column(name = "ISMANUAL")
	private Boolean manualEngine;

	@Column(name = "ENG_MODEL")
	private String modelID;

    @OneToOne
	@NotFound(action = IGNORE)
	@JoinColumn(name = "ENG_MODULE", insertable = false, updatable = false)
	private ModuleEntity module;

	@Column(name = "ENG_MODULE")
	private Integer moduleID;

	@Column(name = "NOTIFY_NUMBER")
	private String notifyNum;

	@Column(name = "PARENT_ESN")
	private String parentEsn;

	@Column(name = "ENG_PROBABILITY")
	private Integer priority;
	
	@Column(name = "PURCHASE_ORDER")
	private String purchaseOrder;

	@Column(name = "REMOVAL_REASON")
	private String removalReason;

	@Column(name = "ENG_REVENUE")
	private Boolean revenue;

	@Column(name = "SALES_ORDER_NO")
	private String salesOrderNum;

	@Column(name = "ENG_ORDER_TYPE")
	private String salesOrderType;

	@Column(name = "SHIPMENT_TYPE")
	private String shipmentType;

	@Column(name = "ENG_SHOP_VISIT_NO")
	private Integer shopVisitNum;

	@Column(name = "SUB_VISIT_TYPE")
	private String subVisitType;

    @OneToOne
	@NotFound(action = IGNORE)
	@JoinColumn(name = "LOG_EMAIL", insertable = false, updatable = false)
	private UserProfile user;

    @OneToOne
	@NotFound(action = IGNORE)
	@JoinColumn(name = "SLOT_ID", insertable = false, updatable = false)
	private SlotEntity slot;

	@Column(name = "SLOT_ID")
	private Integer slotID;
	
    @Column(name = "TSN")
    private Integer tsn;

    @Column(name = "TSO")
    private Integer tso;

	@Column(name = "SLOT_UPDATE_DATE")
	private LocalDate updateDate;

	@Column(name = "ENG_WRNTY")
	private Boolean warranty;

	@Override
	public Integer getId() {
		return engineID;
	}

	@PrePersist
	void preInsert() {
		updateDate = LocalDate.now();

		if (isNull(this.manualEngine))
			this.manualEngine = false;
	}

	@PreUpdate
	void preUpdate() {
		updateDate = LocalDate.now();

		if (isNull(this.manualEngine))
			this.manualEngine = false;
	}
}
