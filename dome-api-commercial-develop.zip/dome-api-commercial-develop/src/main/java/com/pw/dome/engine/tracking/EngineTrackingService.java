package com.pw.dome.engine.tracking;

/**
 * @author John De Lello
 */

public interface EngineTrackingService {

	EngineTrackingEntity save(final EngineTrackingEntity engineTracking);

	EngineTrackingEntity getEngineTrackingByID(final int engineID);

	void delete(final EngineTrackingEntity engineTracking);
	
}
