package com.pw.dome.external.mro.collab.services.pacingitems;

interface Consts {

	interface SQL {
		String GET_ALL = 
		"SELECT new com.pw.dome.external.mro.collab.services.pacingitems.MroPacingItem("
		+ "pi.category,"
		+ "pi.closeDate,"
		+ "pi.commitDate,"
		+ "pi.datReceivedDate,"
		+ "pi.datShipOutDate,"
		+ "pi.partDesc,"
		+ "pi.dollarsSaved,"
		+ "pi.engineId,"
		+ "pi.escItem,"
		+ "pi.engSN,"
		+ "e.eventId,"
		+ "pi.holdDaysApproved,"
		+ "pi.logDateTime,"
		+ "et.mroShopCode,"
		+ "et.engtrackWorkOrder,"
		+ "pi.needDate,"
		+ "pi.notes,"
		+ "pi.pacingId,"
		+ "pi.partId,"
		+ "pi.purchaseOrder,"
		+ "pi.startDate,"
		+ "pi.subcategory,"
		+ "pi.uniqueId,"
		+ "pi.vendorInDate,"
		+ "pi.vendorName,"
		+ "pi.vendorOutDate,"
		+ "pi.wsInd"
		+ ") "
		+ "FROM EngineEntity e,"
		+ "EngineTrackingEntity et,"
		+ "PacingItemEntity pi "
		+ "WHERE e.engineID = et.engtrackId"
		+ "  AND e.eventId is not null"
		+ "  AND et.engtrackWorkOrder is not null"
		+ "  AND pi.engineId = e.engineID"
		+ "  AND pi.engSN = e.esn"
		+ "  ORDER BY e.engineID, pi.pacingId";
	}
}
