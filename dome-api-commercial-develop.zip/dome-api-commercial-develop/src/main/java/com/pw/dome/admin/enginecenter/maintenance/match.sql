CREATE OR REPLACE PROCEDURE "DOME_ESTORE_ACTIVITY_AUTOMATCH" AS

    CURSOR cur_fetch IS
    SELECT DISTINCT
        ea.notify_number      AS ea_notify_number,
        ea.eng_act_seq_number,
        ea.eng_activity,
        ea.eng_activ_completed,
        ea.sales_doc_number   AS ea_sales_doc_number,
        ea.eng_sn             AS ea_eng_sn,
        eng.sales_order_no,
        eng.notify_number     AS eng_notify_number,
        eng.eng_id            AS eng_eng_id,
        slt.sp_ec_id,
        slt.sp_eng_type,
        eng.eng_group,
        eng.eng_model,
        eng.eng_module,
        eng.eng_sn            AS eng_eng_sn,
        eng.eng_cust_id,
        eng.slot_id,
        slt.sp_date,
        ea.remarks,
        ea.last_changed_by,
        ea.last_changed_on,
        ea.personal_name,
        ea.cust_name,
        ea.model,
        ea.short_desc,
        ea.eng_sn,
        ea.problem,
        ea.short_text,
        ea.plant,
        ea.description
    FROM
        pwebis.estore_activity   ea,
        pwebis.dome_engine       eng,
        dome_slotting            slt
    WHERE
        eng.sales_order_no IS NULL
        AND eng.notify_number IS NULL
        AND ( ( rtrim(ea.eng_activity, ' ') = 'RECEIVED'
                AND ea.eng_activ_completed != '00000000' )
              OR ( rtrim(ea.eng_activity, ' ') = 'INDUCTED'
                   AND ea.eng_activ_completed != '00000000' ) )
        AND ( ( substr(rtrim(ea.eng_sn, ' '), - 6, 6) = eng.eng_sn )           -- Andy Stewart : APU required to use longer ESN. Match on last 6.
              OR ( ( substr(rtrim(ea.eng_sn, ' '), - 6, 6) IS NULL )		   -- Andy Stewart : If Estore ESN is null, try to match on Sales Doc 2-7
                   AND ( substr(ea.sales_doc_number, 2, 6) ) = eng.eng_sn ) )
        AND eng.automatched = 'N'                                              -- AutoMatch an ENINE row only once.  Scheduler may wish to Un-Match an engine.
        AND eng.slot_id IS NOT NULL
        AND eng.slot_id = slt.slot_id
        AND eng.eng_entry != 9                                                 -- Andy Stewart : 9 => Backlogged entry from Fly Forward exclude from Auto Match
        AND ( sysdate - ( to_date(ea.eng_activ_completed, 'yyyymmdd') ) < (
            SELECT
                short_field
            FROM
                pwebis.eibs_misc
            WHERE
                key_field = 'AUTOM'
                AND value_field = 'EstoreActivityLookBack'
        ) )
        AND ea.notify_number NOT IN (
            SELECT
                eng1.notify_number
            FROM
                pwebis.dome_engine eng1
            WHERE
                eng1.notify_number = ea.notify_number
        )
    ORDER BY
        ea.notify_number,
        ea.eng_act_seq_number;

    cur_val                          cur_fetch%rowtype;
    ea_trimmed_eng_activity          VARCHAR2(30);
    ea_eng_activ_completed           DATE;
    eng_planned_yyyy                 VARCHAR2(4);
    eng_planned_ind_yyyy_mm_dd       VARCHAR2(10);
    eng_planned_ind_date             DATE;
	--RECEIVE_NUM_DAYS_PRIOR_TO_CURR  NUMBER;
    received_num_days_prior_to_ind   NUMBER;
    received_prior_days_limit        NUMBER;
    diff_induction_days_limit        NUMBER;
    diff_induction_days              NUMBER;
    estoreactivitylookback           NUMBER;
    auto_match_stmt                  VARCHAR2(500);
BEGIN
    dbms_output.put_line('Estore_Activity_AutoMatch_Engine Begin ');
    SELECT
        short_field
    INTO estoreactivitylookback
    FROM
        pwebis.eibs_misc
    WHERE
        key_field = 'AUTOM'
        AND value_field = 'EstoreActivityLookBack';

    dbms_output.put_line('EStore Activity LookBack Limit Number of days  : ' || estoreactivitylookback);
    SELECT
        short_field
    INTO received_prior_days_limit
    FROM
        pwebis.eibs_misc
    WHERE
        key_field = 'AUTOM'
        AND value_field = 'EstoreActivityReceivedPriorDays';

    dbms_output.put_line('EStore Received Prior Days Limit Number of days : ' || received_prior_days_limit);
    SELECT
        short_field
    INTO diff_induction_days_limit
    FROM
        pwebis.eibs_misc
    WHERE
        key_field = 'AUTOM'
        AND value_field = 'EstoreActivityDiffInductionDays';

    dbms_output.put_line('Difference EStore vs. Planned Induction Days Limit (+ or -) : ' || diff_induction_days_limit);
    dbms_output.put_line('  ');
    FOR cur_val IN cur_fetch LOOP
        ea_trimmed_eng_activity := ( rtrim(cur_val.eng_activity) );
        ea_eng_activ_completed := ( to_date(cur_val.eng_activ_completed, 'yyyymmdd') );
        eng_planned_ind_yyyy_mm_dd := ( cur_val.sp_date );
        dbms_output.put_line('  ');
        dbms_output.put_line('EStore Activity :'
                             || cur_val.ea_sales_doc_number
                             || ':'
                             || cur_val.ea_notify_number
                             || ':'
                             || cur_val.ea_eng_sn
                             || ':'
                             || 'ENGINE :'
                             || cur_val.eng_eng_sn
                             || ': ENG PLANNED INDUCT DT :'
                             || eng_planned_ind_yyyy_mm_dd);

        eng_planned_ind_date := ( to_date(eng_planned_ind_yyyy_mm_dd, 'yyyy-mm-dd') );
        IF ( ea_trimmed_eng_activity = 'RECEIVED' ) THEN
            received_num_days_prior_to_ind := eng_planned_ind_date - ea_eng_activ_completed;
            IF ( received_num_days_prior_to_ind > -1 )												-- Ignore negative days.
             AND ( received_num_days_prior_to_ind < received_prior_days_limit ) THEN
                UPDATE pwebis.dome_engine
                SET
                    sales_order_no = cur_val.ea_sales_doc_number,
                    notify_number = cur_val.ea_notify_number,
                    automatched = 'Y'
                WHERE
                    eng_id = cur_val.eng_eng_id
                    AND sales_order_no IS NULL
                    AND cur_val.ea_notify_number NOT IN (
                        SELECT
                            eng2.notify_number
                        FROM
                            pwebis.dome_engine eng2
                        WHERE
                            eng2.notify_number = cur_val.ea_notify_number
                    );

                IF SQL%found THEN
                    auto_match_stmt := ( cur_val.ea_sales_doc_number
                                         || ' and Notify Number '
                                         || cur_val.ea_notify_number
                                         || ' ESTORE_ACTIVITY RECEIVED Auto Matched to the slot date '
                                         || cur_val.sp_date );

                    INSERT INTO dome_activity (
                        act_trackno,
                        act_date,
                        act_cen_id,
                        act_fam_id,
                        act_eng_group,
                        act_eng_mod,
                        act_eng_modu,
                        act_sno,
                        act_cust_id,
                        act_user,
                        act_type,
                        act_desc
                    ) VALUES (
                        dome_activity_seq.NEXTVAL,
                        sysdate,
                        cur_val.sp_ec_id,
                        cur_val.sp_eng_type,
                        cur_val.eng_group,
                        cur_val.eng_model,
                        TRIM(cur_val.eng_module),
                        TRIM(cur_val.eng_eng_sn),
                        cur_val.eng_cust_id,
                        'Estore_Activity_AutoMatch',
                        'Update',
                        auto_match_stmt
                    );

                    COMMIT;
                END IF;

            END IF;

        ELSE
            diff_induction_days := eng_planned_ind_date - ea_eng_activ_completed;
            IF ( diff_induction_days < + 0 ) THEN
                diff_induction_days := diff_induction_days * -1;
            END IF;

            IF ( diff_induction_days < diff_induction_days_limit ) THEN
                UPDATE pwebis.dome_engine
                SET
                    sales_order_no = cur_val.ea_sales_doc_number,
                    notify_number = cur_val.ea_notify_number,
                    automatched = 'Y'
                WHERE
                    eng_id = cur_val.eng_eng_id
                    AND sales_order_no IS NULL
                    AND cur_val.ea_notify_number NOT IN (
                        SELECT
                            eng3.notify_number
                        FROM
                            pwebis.dome_engine eng3
                        WHERE
                            eng3.notify_number = cur_val.ea_notify_number
                    );

                IF SQL%found THEN
                    auto_match_stmt := ( cur_val.ea_sales_doc_number
                                         || ' and Notify Number '
                                         || cur_val.ea_notify_number
                                         || ' ESTORE_ACTIVITY INDUCTED Auto Matched to the slot id '
                                         || cur_val.slot_id );

                    INSERT INTO dome_activity (
                        act_trackno,
                        act_date,
                        act_cen_id,
                        act_fam_id,
                        act_eng_group,
                        act_eng_mod,
                        act_eng_modu,
                        act_sno,
                        act_cust_id,
                        act_user,
                        act_type,
                        act_desc
                    ) VALUES (
                        dome_activity_seq.NEXTVAL,
                        sysdate,
                        cur_val.sp_ec_id,
                        cur_val.sp_eng_type,
                        cur_val.eng_group,
                        cur_val.eng_model,
                        TRIM(cur_val.eng_module),
                        TRIM(cur_val.eng_eng_sn),
                        cur_val.eng_cust_id,
                        'Estore_Activity_AutoMatch',
                        'Update',
                        auto_match_stmt
                    );

                    COMMIT;
                END IF;

            END IF;

        END IF;

    END LOOP;

    COMMIT;
    dbms_output.put_line('Loop. Ended');
END;