package com.pw.dome.engine.removed;


import static java.util.Objects.nonNull;

import java.time.LocalDate;

import com.pw.dome.engine.asset.EngineAssetEntity;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * JPQL DTO record for all induction phase queries.
 * 
 * <pre>
 * <b>Note: </b> the order and number of properties affects the JPQL queries which use the all args constructor.
 * </pre>
 * 
 * @see EngineRemovedDTOTest
 */

@Schema(description = "Removed Engine Data Model")
public record EngineRemovedDTO (
		Long seqNum,
  // EngineAssetEntity.assetID
  Integer assetID,
  // EngineAssetEntity.contractType
  String contractType,
  // OdinEntity.customerApprovalDate
  LocalDate customerApprovalDate,
  // EngineAssetEntity.engineAssetID
  Integer engineAssetID,
  
  // Slot.engineCenterID
  String engineCenterId,

  // EngineEntity.engineID
  Integer engineId,

  // EngineAssetEntity.engineModelID
  String engineModelID,
  // EngineAssetEntity.engineModelName
  String engineModelName,

  String engineTypeId,
  // COALESCE(ee.esn, e.esn, a.esn)
  String esn,

  // EngineEventEntity.eventId
  Integer eventId,

  // EngineAssetEntity.installed
  Boolean installed,
  
  // OdinEntity.odinId
  Integer odinId,

  // COALESCE(e.customerID, a.operatorID)
  String operatorID,
  // EngineAssetEntity.Customer.name
  String operatorName,
  // EnginePhaseEntity.enginePhaseID
  String phaseCode,

  // EngineAssetEntity.planned
  Boolean planned,

  // EngineTrackingEntity.engtrackPlanRemovalDate
  LocalDate preliminaryInductionDate,

  // COALESCE(t.engtrackRemoval, ee.removalDate)
  LocalDate removalDate,
  
  // EngineEventEntity.removalReason
  String removalReason,

  // EngineAssetEntity.removed
  Boolean removed,

  // EngineRemoved.removedEngineID
//  Integer removedEnginesID;
  // EngineRemoved.Slot.caldate
  LocalDate slotDate,
  // EngineAssetEntity.slotID
  Integer slotID,
  // EngineAssetEntity.thrust
  String thrust,

  // New properties added on 2023-11-01
  //OdinEntity.getAccyDeliveryDate()
  LocalDate accyDeliveryDate,
  // EngineTrackingEntity.getEngtrackRecDate()
  LocalDate actualRecEcDate,
  // OdinEntity.getAdListDate()
  LocalDate adListDate,
  // OdinEntity.getFanBladeMapDate()
  LocalDate fanBladeMapDate,
  // OdinEntity.getLlpDeliveryDate()
  LocalDate llpDeliveryDate,
  // OdinEntity.getNisDeliveryDate()
  LocalDate nisDeliveryDate,
  // EngineTrackingEntity.getEngtrackPlanRecDate()
  LocalDate projRecEcDate,
  // OdinEntity.getSmiNeedDate
  LocalDate smiNeedDate,
  // OdinEntity.wsOrigReleaseDate
  LocalDate wsOrigReleaseDate) {

	  /**
	   * Returns the status description.
	   * 
	   * See {@link EngineAssetEntity}.
	   * 
	   * @return the status description
	   */
	  public String getStatus() {
		  if (nonNull(planned) && planned) {
			  return "Planned";
		  } else if (nonNull(installed) && installed) {
			  return "On-Wing";
		  } else if (nonNull(removed) && removed) {
			  return "Removed";
		  } else {
			  return "Available";
		  }
	  }
}
