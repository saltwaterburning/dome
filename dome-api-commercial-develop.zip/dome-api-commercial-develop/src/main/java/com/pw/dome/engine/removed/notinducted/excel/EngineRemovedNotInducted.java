package com.pw.dome.engine.removed.notinducted.excel;

import java.time.LocalDate;

interface EngineRemovedNotInducted {
	LocalDate getActualRemovalDate();
	String getComments();
	String getCurrentLocation();
	String getCustomerName();
	Boolean getDisabled();
	String getEngineType();
	String getEsn();
	Integer getEventId();
	String getInvestigationLevel();
	String getMaintenanceCenter();
	String getOperator();
	LocalDate getPlanInductionDate();
	LocalDate getReceivedDate();
	LocalDate getRecordedRemovalDate();
	String getSvClass();
	Boolean getUnserviceable();
	Integer getOdinId();
}
