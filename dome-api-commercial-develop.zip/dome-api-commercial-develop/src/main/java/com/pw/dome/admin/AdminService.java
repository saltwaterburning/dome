package com.pw.dome.admin;

import static com.pw.dome.admin.Consts.FILTER_ENGINE_GROUP_NAME;
import static com.pw.dome.admin.ProfileStatus.APPROVED;
import static com.pw.dome.admin.ProfileStatus.DISAPPROVE;
import static com.pw.dome.admin.ProfileStatus.NEW;
import static com.pw.dome.admin.ProfileStatus.REQUEST;
import static java.util.Objects.isNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.enginecenter.SecurityEngineCenterEntity;
import com.pw.dome.enginecenter.SecurityEngineCenterRespository;
import com.pw.dome.exception.BadRequestException;
import com.pw.dome.exception.UnauthorizedException;
import com.pw.dome.user.UserProfile;
import com.pw.dome.user.UserProfileEngineCenter;
import com.pw.dome.user.UserProfileEngineGroup;
import com.pw.dome.user.UserProfileResponse;
import com.pw.dome.user.UserRepository;
import com.pw.dome.user.UserService;
import com.pw.dome.user.request.SecurityUpdateRespository;
import com.pw.dome.user.request.UserProfileUpdateEntity;
import com.pw.dome.user.request.UserUpdateRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AdminService {
    private static final boolean VALIDATE_REQUEST = false;

    @Autowired
    private AdminRepository adminRepo;

    @Autowired
    private CustomAdminRepository customAdminRepo;
    @Autowired
    private CustomerCenterMatrixRepository customerMatrixRepo;
    @Autowired
    private Emailer emailer;
    @Autowired
    private SecurityEngineCenterRespository secRepo;
    @Autowired
	private SecurityUpdateRespository securityUpdateRepo;
    @Autowired
    private UserRepository userRepo;
    @Autowired
    private UserService userService;
	@Autowired
	private UserUpdateRepository userUpdateRepo;

    public void addCustomerCenterMatrix(CustomerCenterMatrixResponse request) {
    	List<CustomerCenterMatrixDTO> fromRequestCcm = request.getCustomerCenterMatrixList();
    	List<CustomerCenterMatrixEntity> updatedCcm = DataMapper.INSTANCE.toEntities(fromRequestCcm);
    	List<CustomerCenterMatrixEntity> existingCcm = customerMatrixRepo.findAll();

    	Set<CustomerCenterMatrixEntity> ccmToDelete = existingCcm.stream()
    			                                           .filter(ccm -> !updatedCcm.contains(ccm))
    			                                           .collect(Collectors.toSet());

    	Set<CustomerCenterMatrixEntity> ccmToAdd = updatedCcm.stream()
								  			           .filter(ccm -> !existingCcm.contains(ccm))
								  			           .collect(Collectors.toSet());

    	if(!CollectionUtils.isEmpty(ccmToAdd)) {
    		customerMatrixRepo.saveAll(ccmToAdd);
    	}

    	if(!CollectionUtils.isEmpty(ccmToDelete)) {
    		customerMatrixRepo.deleteAll(ccmToDelete);
    	}

    	customerMatrixRepo.flush();
    }

    @Transactional
    public void userCreate(UserProfileResponse request, UserProfile userProfile) {
		String profileEmail = userProfile.getEmailAddress();
    	String requestEmail = request.getEmailAddress();

    	// Admin created new user from User Maintenance.
    	if (isNull(request.getStatus()) && userProfile.isAdministrator()) {
    		if (userRepo.existsByEmailAddress(requestEmail)) {
    			throw new BadRequestException("The user email already exists.");
    		}

    		request.setBusinessJustification("Created by admin: " + profileEmail);
    		request.setComments("Created profile from User Maintenance screen.");
    		request.setStatus(APPROVED);
    	} else if (profileEmail.equals(requestEmail) && //
    			request.getStatus() == REQUEST && //
    			userProfile.getStatus() == NEW) { // DOME started as new user.
    		// Business justification is required by the UI
    		request.setComments("Created by new user request.");
    		userProfile.setComments("Created by new DOME user.");
    		UserProfileUpdateEntity userUpdate = DataMapper.INSTANCE.toUserProfileUpdateEntity(request);
    		userUpdateRepo.save(userUpdate);
    	} else if (userRepo.existsByEmailAddress(requestEmail)) {
			log.error("request->{}", request);
			log.error("userProfile->{}", userProfile);
    		throw new BadRequestException("The user email already exists.");
    	}

        UserProfile modifiedUserProfile = DataMapper.INSTANCE.toUserProfile(request);
        userRepo.save(modifiedUserProfile);

    	UserProfileResponse response = deduplicateEngineCentersAndGroups(request);

    	for (UserProfileEngineCenter ec : response.getUserEngineCenters()) {

            for (UserProfileEngineGroup eg : ec.getEngineGroups()) {
                SecurityEngineCenterEntity sec = SecurityEngineCenterEntity.builder()
                    .engineCenterId(ec.getEngineCenterID())
                    .emailAddress(response.getEmailAddress())
                    .engineGroupId(eg.getEngineGroupID())
                    .engineTypeId(eg.getEngineTypeID())
                    .build();
                secRepo.save(sec);
            }
        }
    }

    /**
     * UI request workaround.
     * 
     * @param request
     * @return
     */
    // TODO Fix UI request
    private UserProfileResponse deduplicateEngineCentersAndGroups(
        UserProfileResponse request) {
        List<UserProfileEngineCenter> newList = new ArrayList<>();
        Set<String> engCentersSet = new HashSet<>();
        boolean logIt = true;

        for (UserProfileEngineCenter ec : request.getUserEngineCenters()) {
            if (engCentersSet.add(ec.getEngineCenterID())) {
                newList.add(ec);
                List<UserProfileEngineGroup> engGroupsList = new ArrayList<>();
                Set<String> engGroupsSet = new HashSet<>();
                for (UserProfileEngineGroup eg : ec.getEngineGroups()) {
                	String key = getKey(ec, eg);
                	if (engGroupsSet.add(key)) {
                		engGroupsList.add(eg);
                    } else if (logIt) {
                    	log.warn("deduplicateEngineCentersAndGroups({}), key={}", request, key);
                    	logIt = false;
                    }
                }

                ec.setEngineGroups(engGroupsList);
            } else if (logIt) {
            	log.warn("deduplicateEngineCentersAndGroups({}), EngineCenterID={}", request, ec.getEngineCenterID());
            	logIt = false;
            }
        }

        request.setUserEngineCenters(newList);

        if (VALIDATE_REQUEST) {
            return validateUserProfileRequest(request);
        }
        return request;
    }

    public AccountManagementResponse getAccountManagementResponse(boolean filtered) {
        List<UserProfileEngineCenter> engineCenterGroups;
        if (filtered) {
        	engineCenterGroups = customAdminRepo.getAllEngineCentersAndGroups(FILTER_ENGINE_GROUP_NAME);
        } else {
        	engineCenterGroups = customAdminRepo.getAllEngineCentersAndGroups();
        }

        return AccountManagementResponse.builder()
            .additionalRoles(SecurityRoles.getAdditionalSecurityRoles())
            .engineCenterGroups(engineCenterGroups)
            .engineCenters(customAdminRepo.getAllEngineCenters())
            .engineGroups(customAdminRepo.getAllEngineGroups())
            .securityRoles(SecurityRoles.getSecurityRoles())
            .build();
    }

    private Map<String, Map<String, UserProfileEngineGroup>> getAllEngineCentersAndGroups() {
        Map<String, Map<String, UserProfileEngineGroup>> engineCenterGroups = new HashMap<>();

        List<UserProfileEngineCenter> engineCenterGroupList = customAdminRepo.getAllEngineCentersAndGroups();

        for (UserProfileEngineCenter engineCenter : engineCenterGroupList) {
            Map<String, UserProfileEngineGroup> groups =
                engineCenter.getEngineGroups()
                    .stream()
                    .collect(Collectors.toConcurrentMap(UserProfileEngineGroup::getEngineGroupID,
                                                        s -> s));
            engineCenterGroups.put(engineCenter.getEngineCenterID(),
                                   groups);
        }
        return engineCenterGroups;
    }

    public List<CustomerCenterMatrixDTO> getCustomerCenterMatrix(){
    	List<CustomerCenterMatrixEntity> response = customerMatrixRepo.findAll();
    	
    	return DataMapper.INSTANCE.toDTOs(response);
    }

    public CustomerCenterMatrixEntity getCustomerCenterMatrix(String customerId, String engineCenterId, String engineTypeId){
    	CustomerCenterMatrixEntityPK pk = CustomerCenterMatrixEntityPK.builder().customerId(customerId).engineCenterId(engineCenterId).engineTypeId(engineTypeId).build();
    	return customerMatrixRepo.findById(pk).orElse(null);
//    	return customerMatrixRepo.findByCustomerIdAndEngineCenterIdAndEngineTypeId(customerId, engineCenterId, engineTypeId);
    }

    public List<OperatorEngineCenter> getOperatorEngineCenters(){
    	return customAdminRepo.getOperatorEngineCenters();
    }

    public List<Operator> getOperators(){
    	return customAdminRepo.getOperators();
    }

    public UserInfoResponse getUserInfoApproved() {
        List<UserInfo> users = adminRepo.getApprovedUsers();

        return UserInfoResponse.builder()
                               .users(users)
                               .build();
    }

    public UserInfoResponse getUsersPendingApproval() {
        List<UserInfo> users = adminRepo.getPendingUsers();

        return UserInfoResponse.builder()
                               .users(users)
                               .build();
    }

    @Transactional
    public void userApproval(final UserProfileResponse request, final UserProfile authenticationPrincipal) {
    	if (request.getStatus() != APPROVED && request.getStatus() != DISAPPROVE) {
    		throw new BadRequestException("Status can only be APPROVED or DISAPPROVE.");
    	}



    	userMaintenance(request, authenticationPrincipal);

    	String email = request.getEmailAddress();

    	userUpdateRepo.deleteByEmailAddressIgnoreCase(email);
    	securityUpdateRepo.deleteByEmailAddressIgnoreCase(email);

    	emailer.sendEmail(request.getEmailAddress(), request.getStatus(), request.getComments());
    }

    @Transactional
    public void userMaintenance(final UserProfileResponse request, final UserProfile authenticationPrincipal) {
    	if (isNull(request.getBusinessJustification())) {
    		request.setBusinessJustification("Created by admin: " + authenticationPrincipal.getEmailAddress());
    	}

    	String authenticatedEmail = authenticationPrincipal.getEmailAddress();
        String requestEmail = request.getEmailAddress();

        if (!StringUtils.equalsIgnoreCase(authenticatedEmail, requestEmail)) {
    		ProfileStatus profileStatus = authenticationPrincipal.getStatus();
    		if (!authenticationPrincipal.isAdministrator() || profileStatus != APPROVED) {
    			log.error("Profile update is not authorized\nAuthenticated User: {}\nRequest Profile Email: {}", authenticatedEmail, requestEmail);
    			throw new UnauthorizedException("Profile update is not authorized for " + authenticatedEmail);
    		}
    	}
    	
        UserProfileResponse user = deduplicateEngineCentersAndGroups(request);

        UserProfile userProfile = DataMapper.INSTANCE.toUserProfile(user);
        userService.update(userProfile);

        List<SecurityEngineCenterEntity> currentSECList = secRepo.getSecurityEngineCentersByEmailAddressIgnoreCase(requestEmail);
        Map<String, SecurityEngineCenterEntity> currentSECMap = DataUtils.getMapByUniqueKey(currentSECList);

        List<SecurityEngineCenterEntity> newSecurityEngineCenters = new ArrayList<SecurityEngineCenterEntity>();

        for (UserProfileEngineCenter ec : user.getUserEngineCenters()) {
            for (UserProfileEngineGroup eg : ec.getEngineGroups()) {
                SecurityEngineCenterEntity newSec =
                    SecurityEngineCenterEntity.builder()
                        .emailAddress(user.getEmailAddress())
                        .engineCenterId(ec.getEngineCenterID())
                        .engineGroupId(eg.getEngineGroupID())
                        .engineTypeId(eg.getEngineTypeID())
                        .build();

                // currentSECMap will be left with SecurityEngineCenters that are no longer used.
                if (currentSECMap.remove(DataUtils.getUniqueKey(newSec)) == null) {
                    newSecurityEngineCenters.add(newSec);
                }
            }
        }

        //    	boolean flushIt = !currentSECMap.isEmpty() || !newSecurityEngineCenters.isEmpty();

        Iterator<SecurityEngineCenterEntity> currentSECIterator = currentSECMap.values()
            .iterator();

        for (SecurityEngineCenterEntity newSEC : newSecurityEngineCenters) {
            if (currentSECIterator.hasNext()) { // Reuse existing Id.
                SecurityEngineCenterEntity next = currentSECIterator.next();
                DataMapper.INSTANCE.copy(newSEC, next);
                secRepo.save(next);
            } else {
                secRepo.save(newSEC);
            }
        }

        while (currentSECIterator.hasNext()) {
            SecurityEngineCenterEntity next = currentSECIterator.next();
            secRepo.delete(next);
        }

        List<String> engCenters = currentSECMap.values().stream().map(s->s.getEngineCenterId()).collect(Collectors.toList());
        userRepo.dropDefaultEngineCenter(engCenters, requestEmail);

        // Delete any user requested profile changes.
		securityUpdateRepo.deleteByEmailAddressIgnoreCase(requestEmail);
		userUpdateRepo.deleteByEmailAddressIgnoreCase(requestEmail);

        //    	if (flushIt) {
        //    		secRepo.flush();
        //    	}
    }

    /**
     * Checks the {@code UserProfileResponse} for the following:
     * <ul>
     * <li>invalid EngineCenter Id</li>
     * <li>duplicate EngineCenter Id</li>
     * <li>invalid EngineGroup Id</li>
     * <li>duplicate EngineCenter Id + EngineGroup Id</li>
     * <li>invalid EngineGroup fields</li>
     * </ul>
     * @param request
     */
    private UserProfileResponse validateUserProfileRequest(final UserProfileResponse request) {
        Map<String, Map<String, UserProfileEngineGroup>> cache = getAllEngineCentersAndGroups();
        Set<String> dupes = new HashSet<>();

        List<UserProfileEngineCenter> engineCenters = request.getUserEngineCenters();

        // TODO Add defaultEngineTypeID check and/or DB constraints.
        //    	String id = user.getDefaultEngineCenterID();
        //    	if (StringUtils.isNoneBlank(id) && !getCache(null).containsKey(id)) {
        //    		throw new BadRequestException("An invalid DefaultEngineCenterID supplied: " + id);
        //    	}

        if (engineCenters.isEmpty()) {
            String msg = String.format("The request has no engine centers.");
            throw new BadRequestException(msg);
        }

        for (UserProfileEngineCenter ec : engineCenters) {
            Map<String, UserProfileEngineGroup> map;
            final String ecId = ec.getEngineCenterID();

            if ((map = cache.get(ecId)) == null) {
                String msg = String.format("Invalid engine center Id supplied: %s",
                                           ecId);
                throw new BadRequestException(msg);
            } else if (!dupes.add(ec.getEngineCenterID())) {
                String msg = String.format("Duplicate engine centers aren't allowed: %s",
                                           ec.getEngineCenterID());
                throw new BadRequestException(msg);
            }
            List<UserProfileEngineGroup> engineGroups = ec.getEngineGroups();

            if (engineGroups.isEmpty()) {
                String msg = String.format("EngineCenter has no engine groups. EC: %s",
                                           ecId);
                throw new BadRequestException(msg);
            }

            for (UserProfileEngineGroup eg : engineGroups) {
                String egId = eg.getEngineGroupID();
                UserProfileEngineGroup cachedEg = map.get(egId);
                String key = getKey(ec, eg);

                if (cachedEg == null) {
                    String msg = String.format("Invalid engine group ID supplied: %s",
                                               egId);
                    throw new BadRequestException(msg);
                } else if (!dupes.add(key)) {
                    String msg = String.format("Duplicate engine center/groups aren't allowed. EC: %s, EG: %s",
                                               ec.getEngineCenterID(),
                                               egId);
                    throw new BadRequestException(msg);
                } else if (!eg.equals(cachedEg)) {
                    String msg = String.format("Invalid engine group supplied. %s",
                                               eg);
                    throw new BadRequestException(msg);
                }
            }
        }
        return request;
    }

	private String getKey(UserProfileEngineCenter ec, UserProfileEngineGroup eg) {
		return ec.getEngineCenterID() + "," + eg.getEngineGroupID() + "," + eg.getEngineTypeID();
	}
}
