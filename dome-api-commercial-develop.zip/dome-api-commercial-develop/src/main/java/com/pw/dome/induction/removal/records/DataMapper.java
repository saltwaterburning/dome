package com.pw.dome.induction.removal.records;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedSourcePolicy = ReportingPolicy.WARN, unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

	List<RemovalRecordsDTO> toDTO(List<RemovalRecordsEntity> list);
	RemovalRecordsDTO toDTO(RemovalRecordsEntity entity);
}
