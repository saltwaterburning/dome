package com.pw.dome.calendar;

import static java.util.Objects.nonNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.Constants;
import com.pw.dome.calendar.induction.CalendarDay;
import com.pw.dome.calendar.induction.CalendarEngine;
import com.pw.dome.calendar.induction.CalendarMonthYear;
import com.pw.dome.calendar.induction.CalendarShopVisit;
import com.pw.dome.calendar.inductionplanning.InductionPlanningCalendar;
import com.pw.dome.calendar.inductionplanning.InductionPlanningCalendarDay;
import com.pw.dome.calendar.inductionplanning.InductionPlanningCalendarEngine;
import com.pw.dome.calendar.inductionplanning.InductionPlanningCalendarVisitSummary;
import com.pw.dome.calendar.inductionplanning.InductionPlanningEngine;
import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.calendar.slots.SlotService;
import com.pw.dome.engine.EngineEntity;
import com.pw.dome.engine.EngineService;
import com.pw.dome.engine.type.EngineTypeEntity;
import com.pw.dome.engine.type.EngineTypeRepository;
import com.pw.dome.enginecenter.EngineCenterEntity;
import com.pw.dome.enginecenter.EngineCenterService;
import com.pw.dome.exception.BadRequestException;
import com.pw.dome.exception.NotFoundException;
import com.pw.dome.user.UserProfile;
import com.pw.dome.web.authorization.SecurityService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author John De Lello
 */
@Slf4j
@Service
public class CalendarService {

	@Autowired
	private EngineService engineSvc;
	
	@Autowired
	private EngineCenterService engineCenterSvc;
	
	@Autowired
	private EngineTypeRepository engTypeRepo;

//	@Autowired
//	private EngineTypeService engineTypeSvc;

	@Autowired
	private SecurityService securitySvc;
	
	@Autowired
	private SlotService slotSvc;

	
	@Transactional
	public List<CalendarMonthYear> getCalendar(final UserProfile userProfile, final String engineCenterID, final String engineTypeID, final int month, final int year, final int months) {
		List<CalendarMonthYear> list = new ArrayList<>();

		LocalDate localDate = LocalDate.of(year, month, 1);
		for (int i = 0; i < months; ++i) {
			int monthValue = localDate.getMonthValue();
			int yearValue = localDate.getYear();
			CalendarMonthYear calYear = getCalendar(userProfile, engineCenterID, engineTypeID, monthValue, yearValue);
			list.add(calYear);
			localDate = localDate.plusMonths(1);
		}

		return list;
	}

	public CalendarMonthYear getCalendar(final UserProfile userProfile, final String engineCenterID, final String engineTypeID, final int month, final int year) {
		// add date error logging
		if(userProfile == null) {
			throw new IllegalArgumentException("No valid user profile was specified. Unable to generate calendar.");
		}
		
		if(StringUtils.isEmpty(engineCenterID)) {
			throw new IllegalArgumentException("No valid Engine Center ID was specified. Unable to generate calendar.");
		}

    	boolean isAllowable = securitySvc.isAllowableEngineCenter(userProfile, engineCenterID);
		
    	if(!isAllowable) {
			log.error("User does not have access to engineCenterID [{}]", engineCenterID);
			throw new AccessDeniedException("User does not have access to engineCenterID [" + engineCenterID + "]. Unable to generate calendar.");
    	}
    	
		String calYYMM = String.valueOf(year) + StringUtils.leftPad(String.valueOf(month),  2, "0");
		EngineCenterEntity engineCenter = engineCenterSvc.getEngineCenterByID(engineCenterID);
		
		if(engineCenter == null) {
			log.error("Unable to locate Engine Center ID [{}] in DB. Unable to handle request", engineCenterID);
			throw new BadRequestException("Invalid Engine Center ID [" + engineCenterID + "] was specified. Unable to generate calendar.");
			
		}

		Collection<CalendarDay> days = getCalendarDays(engineCenterID, month, year);
		CalendarMonthYear calMY = CalendarMonthYear.builder()
				.year(year)
				.month(month)
				.calYYMM(calYYMM)
				.engineCenterID(engineCenterID)
				.engineCenterName(engineCenter.getName())
				.days(days)
				.build();
		
		return calMY;
	}
	
		
	private List<CalendarDay> getEmptyCalendarGrid(final int month, final int year){
		List<CalendarDay> calGrid = new ArrayList<>();
		
		// The DOME calendar is a grid of 7 x 6 with a total of 42 slots.
		// We start at slot 0 and increment until we come to the first DOW for the 
		// specified month/year combo
		Calendar cal = Calendar.getInstance();
		
		//Calendar month is 0 based, so we need to subtract 1 to use it
		cal.set(year, month - 1, 1, 0, 0); 
 
		int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
		int lastDayOfMonth = cal.getActualMaximum(Calendar.DATE);
		int monthDayNumber=0;
		
		for (int boxNumber = 1; boxNumber <= 42; boxNumber++) {
			if(boxNumber < firstDayOfWeek || monthDayNumber >= lastDayOfMonth) {
				calGrid.add(CalendarDay.builder()
								.boxNumber(boxNumber - 1)
								.dayOfMonth(0)
								.validDate(false)
								.build());
			}else {
				monthDayNumber++;
				calGrid.add(CalendarDay.builder()
						.boxNumber(boxNumber - 1)
						.dayOfMonth(monthDayNumber)
						.validDate(true)
						.build());
			}
		}
		
		return calGrid;

	}
	
	private Collection<CalendarDay> getCalendarDays(final String engineCenterID, final int month, final int year) {
		List<CalendarDay> calDays = getEmptyCalendarGrid(month, year);
		List<CalendarShopVisit> shopVisits = getCalendarShopVisits(month, year, engineCenterID);
		
		for (CalendarShopVisit calendarShopVisit : shopVisits) {
			int dayOfMonth = calendarShopVisit.getDayOfMonth();
			
			for (CalendarDay calendarDay : calDays) {
				if(dayOfMonth == calendarDay.getDayOfMonth()) {
					calendarDay.addShoptVisit(calendarShopVisit);
					break;
				}
			}
			
		}
		
		return calDays;
	}
	
	private List<CalendarShopVisit> getCalendarShopVisits(final int month, final int year, final String engineCenterID) {
		List<SlotEntity> slots = slotSvc.getSlots(engineCenterID, month, year);
		List<EngineEntity> engines = null;

		if(slots!=null && !slots.isEmpty()){
			engines = engineSvc.getEnginesByEngineCenterIDAndMonthAndYear(engineCenterID, month, year);
		}
		
		List<CalendarShopVisit> shopVisits = new ArrayList<>();
		
		for (SlotEntity slot : slots) {
			Collection<CalendarEngine> slotEngines = getEnginesForSlot(slot.getSlotID(), engines);
	    	CalendarShopVisit calendarShopVisit = DataMapper.INSTANCE.toShopVisit(slot, slotEngines);
			shopVisits.add(calendarShopVisit);
		}
	
		return shopVisits;
	}
	
	private Collection<CalendarEngine> getEnginesForSlot(int slotId, List<EngineEntity> engines) {
		List<CalendarEngine> slotEngines = new ArrayList<>();

		engines.stream()
               .filter(engine -> engine.getSlotID() == slotId)
               .forEach(engine->slotEngines.add(DataMapper.INSTANCE.toCalendarEngine(engine, getEngineType(engine))));

		return slotEngines.isEmpty() ? null : slotEngines;
	}

	@Transactional(readOnly = true)
	private EngineTypeEntity getEngineType(EngineEntity engine) {
		if (nonNull(engine.getEngineTypeId())) {
			return engTypeRepo.getByEngineTypeId(engine.getEngineTypeId());
		} else if (nonNull(engine.getGroupID())) {
			return engTypeRepo.getEngineType(engine.getGroupID());
		} else {
			String msg = "Unable to find EngineType without EngineTypeId or GroupId.";
			log.error(msg + " EngineId: {}", engine.getEngineID());
			throw new NotFoundException(msg);
		}
	}

	private Collection<InductionPlanningCalendarEngine> getInductionPlanningEnginesForSlotID(int slotID, List<InductionPlanningEngine> engines) {
		List<InductionPlanningCalendarEngine> slotEngines = new ArrayList<>();
		
		engines.stream()
				.filter(engine -> engine.getSlotID() == slotID && engine.getEngineID() != null)
				.forEach(engine ->slotEngines.add(InductionPlanningCalendarEngine.builder()
						.category(engine.getCategory())
						.categoryCode(engine.getCategoryCode())
						.esn(engine.getEsn())
						.engineID(engine.getEngineID())
						.build()));

		if(slotEngines.isEmpty()) {
			return null;
		} 
		
		return slotEngines;
	}

	private List<InductionPlanningCalendarDay> getEmptyInductionPlanningCalendarGrid(final int month, final int year){
		List<InductionPlanningCalendarDay> calGrid = new ArrayList<>();
		
		// The DOME calendar is a grid of 7 x 6 with a total of 42 slots.
		// We start at slot 0 and increment until we come to the first DOW for the 
		// specified month/year combo
		Calendar cal = Calendar.getInstance();
		
		//Calendar month is 0 based, so we need to subtract 1 to use it
		cal.set(year, month - 1, 1, 0, 0); 
 
		int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
		int lastDayOfMonth = cal.getActualMaximum(Calendar.DATE);
		int monthDayNumber=0;
		
		for (int boxNumber = 1; boxNumber <= 42; boxNumber++) {
			if(boxNumber < firstDayOfWeek || monthDayNumber >= lastDayOfMonth) {
				calGrid.add(InductionPlanningCalendarDay.builder()
								.boxNumber(boxNumber - 1)
								.dayOfMonth(0)
								.validDate(false)
								.build());
			}else {
				monthDayNumber++;
				calGrid.add(InductionPlanningCalendarDay.builder()
						.boxNumber(boxNumber - 1)
						.dayOfMonth(monthDayNumber)
						.validDate(true)
						.build());
			}
		}
		
		return calGrid;

	}


	
	@Transactional
	public InductionPlanningCalendar getInductionPlanningCalendar(final UserProfile userProfile, final CalendarRequest request) {
		DataMapper mapper = DataMapper.INSTANCE;
		int month = request.month();
		int year = request.year();

		if(userProfile == null) {
			throw new IllegalArgumentException("No valid user profile was specified. Unable to generate induction planning calendar.");
		}
		
		if(CollectionUtils.isEmpty(request.engineTypeIds())) {
			throw new IllegalArgumentException("No valid Engine Type ID was specified. Unable to generate induction planning calendar.");
		}

		InductionPlanningCalendar inductionPlanningCalendar = InductionPlanningCalendar.builder()
				.calendarName(Constants.INDUCTION_PLANNING_CALENDAR_NAME)
				.calYYMM(String.valueOf(year) + StringUtils.leftPad(String.valueOf(month),  2, "0"))
				.year(year)
				.month(month)
				.engineTypeIds(request.engineTypeIds())
				.engineTypeNames(engTypeRepo.getEngineNames(request.engineTypeIds()))
				.days(getEmptyInductionPlanningCalendarGrid(month, year))
				.build();
		
		List<InductionPlanningEngine> allEngines = slotSvc.getInductionPlanningCalendarVisitSummary(userProfile.getEmailAddress(), request.engineTypeIds(), month, year);
		
		List<InductionPlanningEngine> slots = allEngines.stream()
                .filter( distinctByKey(p -> p.getSlotID()) )
                .collect( Collectors.toList() );
	
		for (InductionPlanningEngine inductionPlanningEngine : slots) {
			int dayOfMonth = inductionPlanningEngine.getDayOfMonth();
			for (InductionPlanningCalendarDay calDay : inductionPlanningCalendar.getDays()) {
				if(calDay.getDayOfMonth() == dayOfMonth) {
					Collection<InductionPlanningCalendarEngine> engines = getInductionPlanningEnginesForSlotID(inductionPlanningEngine.getSlotID(), allEngines);
					InductionPlanningCalendarVisitSummary summary = mapper.toInductionPlanningCalendarVisitSummary(inductionPlanningEngine, engines);
					calDay.addShoptVisitSummary(summary);
					break;
				}
			}
		}
		
		return inductionPlanningCalendar;
	}


	
	@Transactional
	public CalendarShopVisit getCalendarShopVisitForSlotID(final UserProfile userProfile, final int slotID) {
		SlotEntity slot = slotSvc.getSlotByID(userProfile, slotID);
		
    	Collection<CalendarEngine> slotEngines = engineSvc.getEnginesBySlotID(slotID);

    	CalendarShopVisit calendarShopVisit = DataMapper.INSTANCE.toShopVisit(slot, slotEngines);

    	return calendarShopVisit; 

	}

	public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor)
	{
	    Map<Object, Boolean> map = new ConcurrentHashMap<>();
	    return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}
}
