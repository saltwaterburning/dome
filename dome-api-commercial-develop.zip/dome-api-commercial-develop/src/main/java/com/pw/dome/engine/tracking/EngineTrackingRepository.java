package com.pw.dome.engine.tracking;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * @author John De Lello
 */
@Repository
public interface EngineTrackingRepository extends JpaRepository<EngineTrackingEntity, Integer> {
	EngineTrackingEntity findByengtrackIdAndEngtrackWorkOrderNotNull(final Integer engineId);

	@Query("select count(e) > 0 from EngineTrackingEntity e where engtrackId = ?1 and engtrackWorkOrder is not null")
	boolean existsWhereWorkOrderIsNotNull(Integer engId);
}
