package com.pw.dome.mml.le;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequestMapping("/v1/le")
class LeController {
    @Autowired
    private LeService leService;

    @PostMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<LeResponse> getLeData(@Valid @RequestBody final LeRequest leRequest) {
        LeResponse response = leService.getLeInfo(leRequest);
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/plan", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<LeResponse> getLePlanData(@Valid @RequestBody final LePlanRequest lePlanRequest) {
        LeResponse response = leService.getLePlanInfo(lePlanRequest);
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/update", produces = APPLICATION_JSON_VALUE)
    // TODO Add response.
    public ResponseEntity<Void> save(@Valid @RequestBody final LeUpdateRequest leUpdateRequest) {
        leService.save(leUpdateRequest);
        return ResponseEntity.ok().build();
    }
}
