package com.pw.dome.engine.phase;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author John De Lello
 */
@Repository
public interface EnginePhaseRepository extends JpaRepository<EnginePhaseEntity, String> {

}
