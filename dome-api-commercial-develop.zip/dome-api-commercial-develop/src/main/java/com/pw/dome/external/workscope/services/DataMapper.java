package com.pw.dome.external.workscope.services;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.util.MapStructMappingHelper;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR, uses = MapStructMappingHelper.class)
interface DataMapper {

	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

}
