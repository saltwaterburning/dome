package com.pw.dome;

/**
 * @author John De Lello
 */
public abstract class Constants {
    public static final String VALUE_YES = "Y";

    public static final String ROLE_PREFIX = "ROLE_";
    public static final String ROLE_RCM = ROLE_PREFIX + "RCM";
    public static final String ROLE_NET_MANAGEMENT = ROLE_PREFIX + "NETMANAGEMENT";

    public static final String SLOT_TYPE_2_NAME = "Heavy";
    public static final String SLOT_TYPE_3_NAME = "Light";
    public static final String SLOT_TYPE_4_NAME = "Holiday";

    public static final String INDUCTION_PLANNING_CALENDAR_NAME = "Induction Planning Calendar";

	public static final String NO_ENGINE_ESN = "XXXXXX";

	public static final String NO_CUSTOMER_ESN = "XXX";

}
