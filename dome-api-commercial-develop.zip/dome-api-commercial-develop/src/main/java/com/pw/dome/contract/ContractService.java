package com.pw.dome.contract;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
class ContractService {
	@Autowired
	private ContractRepository repo;

	ContractListResponse getContractTypes() {
		return new ContractListResponse(repo.getContractTypes());
	}
}
