package com.pw.dome.external.mro.collab.client;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.engine.EngineEntity;
import com.pw.dome.engine.comments.CommentEntity;
import com.pw.dome.engine.tracking.EngineTrackingEntity;
import com.pw.dome.external.mro.collab.services.comments.MroComment;
import com.pw.dome.external.mro.collab.services.comments.MroDeleteSmiRequest;
import com.pw.dome.external.mro.collab.services.pacingitems.MroPacingItem;
import com.pw.dome.wip.WorkInProgress;
import com.pw.dome.wip.pacing.PacingItemDTO;
import com.pw.dome.wip.pacing.PacingItemEntity;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

	@Mapping(target = "actualAssetCompleteDate", source = "wip.engineActualAssetCompleteDate")
	@Mapping(target = "actualCoreAssemblyDate", source = "wip.engineActualCoreAssemblyDate")
	@Mapping(target = "actualGate1CloseDate", source = "wip.engineActualGate1CloseDate")
	@Mapping(target = "actualGate3CloseDate", source = "wip.engineActualGate3CloseDate")
	@Mapping(target = "actualGate3StartDate", source = "wip.engineActualGate3StartDate")
	@Mapping(target = "actualInductDate", source = "wip.engineActualInductDate")
	@Mapping(target = "actualKitCompleteDate", source = "wip.engineActualKitCompleteDate")
	@Mapping(target = "actualReceiptDate", source = "wip.engineActualReceiptDate")
	@Mapping(target = "actualReceiveDate", source = "wip.engineActualReceiveDate")
	@Mapping(target = "actualRemovalDate", source = "wip.engineActualRemovalDate")
	@Mapping(target = "actualShipDate", source = "wip.engineActualShipDate")
	@Mapping(target = "actualShipToCustDate", source = "wip.engineActualShipToCustDate")
	@Mapping(target = "actualTestCompleteDate", source = "wip.engineActualTestCompleteDate")
	@Mapping(target = "actualTestStartDate", source = "wip.engineActualTestStartDate")
	@Mapping(target = "contractDate", source = "wip.engineContractDate")
	@Mapping(target = "externalAssetCompleteDate", source = "wip.engExternalAssetCompleteDate")
	@Mapping(target = "externalContractDate", source = "wip.engineExternalContractDate")
	@Mapping(target = "externalCoreAssemblyDate", source = "wip.engineExternalCoreAssemblyDate")
	@Mapping(target = "externalGate1CloseDate", source = "wip.engineExternalGate1CloseDate")
	@Mapping(target = "externalGate3CloseDate", source = "wip.engineExternalGate3CloseDate")
	@Mapping(target = "externalGate3StartDate", source = "wip.engineExternalGate3StartDate")
	@Mapping(target = "externalInductDate", source = "wip.engineExternalInductDate")
	@Mapping(target = "externalKitCompleteDate", source = "wip.engineExternalKitCompleteDate")
	@Mapping(target = "externalReceiptDate", source = "wip.engineExternalReceiptDate")
	@Mapping(target = "externalReceiveDate", source = "wip.engineExternalReceiveDate")
	@Mapping(target = "externalShipDate", source = "wip.engineExternalShipDate")
	@Mapping(target = "externalShipToCustDate", source = "wip.engineExternalShipToCustDate")
	@Mapping(target = "externalTestCompleteDate", source = "wip.engineExternalTestCompleteDate")
	@Mapping(target = "externalTestStartDate", source = "wip.engineExternalTestStartDate")
	@Mapping(target = "planAssetCompleteDate", source = "wip.enginePlanAssetCompleteDate")
	@Mapping(target = "planCoreAssemblyDate", source = "wip.enginePlanCoreAssemblyDate")
	@Mapping(target = "planGate1CloseDate", source = "wip.enginePlanGate1CloseDate")
	@Mapping(target = "planGate3CloseDate", source = "wip.enginePlanGate3CloseDate")
	@Mapping(target = "planGate3StartDate", source = "wip.enginePlanGate3StartDate")
	@Mapping(target = "planInductDate", source = "wip.enginePlanInductDate")
	@Mapping(target = "planKitCompleteDate", source = "wip.enginePlanKitCompleteDate")
	@Mapping(target = "planReceiptDate", source = "wip.enginePlanReceiptDate")
	@Mapping(target = "planReceiveDate", source = "wip.enginePlanReceiveDate")
	@Mapping(target = "planRemovalDate", source = "wip.enginePlanRemovalDate")
	@Mapping(target = "planShipDate", source = "wip.enginePlanShipDate")
	@Mapping(target = "planShipToCustDate", source = "wip.enginePlanShipToCustDate")
	@Mapping(target = "planTestCompleteDate", source = "wip.enginePlanTestCompleteDate")
	@Mapping(target = "planTestStartDate", source = "wip.enginePlanTestStartDate")
	@Mapping(target = "workorder", source = "wip.workOrder")
	MroGateInfo toMroGateInfo(WorkInProgress wip);

	@Mapping(target = "category", source = "entity.category")
	@Mapping(target = "description", source = "entity.partDesc")
	@Mapping(target = "esn", source = "entity.engSN")
//	@Mapping(target = "createDateTime", source = "entity.logDateTime")
	@Mapping(target = "mroWorkOrder", source = "engTracking.engtrackWorkOrder")
	@Mapping(target = "purchaseOrder", source = "entity.purchaseOrder")
	@Mapping(target = "subCategory", source = "entity.subcategory")
	MroPacingItem toMroPacingItem(PacingItemEntity entity, EngineEntity engine, EngineTrackingEntity engTracking);

	MroDeleteSmiRequest toMroDeleteSmiRequest(EngineEntity engine, EngineTrackingEntity engTracking);

	@Mapping(target = "category", source = "pi.category")
	@Mapping(target = "mroWorkOrder", source = "engTracking.engtrackWorkOrder")
	@Mapping(target = "purchaseOrder", source = "pi.purchaseOrder")
	@Mapping(target = "subCategory", source = "pi.subCategory")
	MroPacingItem toMroPacingItem(PacingItemDTO pi, EngineEntity engine, EngineTrackingEntity engTracking);

	@Mapping(target = "logEmail", source = "cmt.logEmail")
	@Mapping(target = "mroWorkOrder", source = "engTracking.engtrackWorkOrder")
	MroComment toMroComment(CommentEntity cmt, EngineEntity engine, EngineTrackingEntity engTracking);
}
