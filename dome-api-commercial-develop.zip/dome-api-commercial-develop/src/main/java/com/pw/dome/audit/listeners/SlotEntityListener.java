package com.pw.dome.audit.listeners;

import jakarta.persistence.PrePersist;
import jakarta.persistence.PreRemove;
import jakarta.persistence.PreUpdate;

import org.springframework.stereotype.Component;

import com.pw.dome.audit.AuditItem;
import com.pw.dome.calendar.slots.SlotEntity;

@Component
public class SlotEntityListener implements AuditableEntityListener<SlotEntity> {

  public static AuditItem ITEM = new AuditItem("Slotting Entity");  

  @PrePersist
  @Override
  public void onPrePersist(SlotEntity entity) {	  
	  AuditHelper.addShopVisit(entity);
  }

  @PreUpdate
  @Override
  public void onPreUpdate(SlotEntity entity) {
	  AuditHelper.updateShopVisit(entity);
  }

  @PreRemove
  @Override
  public void onPreRemove(SlotEntity entity) {
	  AuditHelper.deleteShopVisit(entity);
  }

  @Override
  public AuditItem getAuditItem() {
    return ITEM;
  }
}
