package com.pw.dome.mml.induction;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.engine.group.EngineGroupEntity;
import com.pw.dome.engine.group.EngineGroupRepository;
import com.pw.dome.engine.induction.planning.InductionMiscService;
import com.pw.dome.engine.induction.planning.InductionMiscShortValueDTO;
import com.pw.dome.enginecenter.EngineCenterEntity;
import com.pw.dome.enginecenter.EngineCenterRepository;
import com.pw.dome.mml.PlanMarket;
import com.pw.dome.mml.PlanType;

@Service
public class InductionAnnualPlanService {

	@Autowired
	private InductionAnnualPlanRepository iapRepo;
	
	@Autowired 
	private EngineCenterRepository ecRepo;
	
	@Autowired
	private EngineGroupRepository engGroupRepo;
	
	@Autowired
    private InductionMiscService svc;
	

    @Transactional(readOnly = true)
	public AnnualPlanResponse getAnnualPlans(final String engineCenter,
			                                 final String engineGroup,
			                                 final PlanMarket planMarket,
			                                 final PlanType planType,
			                                 final Integer year) {
        final AnnualPlanResponse response = AnnualPlanResponse.builder().annualPlans(new ArrayList<>()).build();
        final EngineCenterEntity ec = ecRepo.getReferenceById(engineCenter);
        final EngineGroupEntity eg = engGroupRepo.getReferenceById(engineGroup);
        final List<InductionMiscShortValueDTO> salesOrderTypes = svc.getInductionShortValue(eg.getEngineTypeID());

        List<InductionAnnualPlanEntity> currentPlan = iapRepo.getAnnualPlan(engineCenter, engineGroup, planMarket, planType, year);
	    Map<String, InductionAnnualPlanEntity> currentPlanMap = currentPlan.stream().collect(Collectors.toMap(k->toKey(k), v->v));

	    // Create an AnnualPlan for each category + type with all 12 months using existing planCount or zero if none.
	    for (String category : Consts.PLAN_CATEGORY) {
	        for (InductionMiscShortValueDTO type : salesOrderTypes) {
                List<MonthlyPlan> monthlyPlans = new ArrayList<>();
	            AnnualPlan ap = AnnualPlan.builder().category(category)
	                                                .engCenterId(ec.getId())
	                                                .engCenterName(ec.getName())
	                                                .engGroupId(eg.getEngineGroupID())
	                                                .engGroupName(eg.getName())
	                                                .monthlyPlans(monthlyPlans)
	                                                .planMarket(planMarket)
	                                                .planType(planType)
	                                                .planYear(year)
	                                                .salesOrderType(type.getShortField())
	                                                .build();
	            response.getAnnualPlans().add(ap);
	            for (int planMonth = 1; planMonth <= 12; ++planMonth) {
	                InductionAnnualPlanEntity entity = currentPlanMap.get(toKey(category, type.getShortField(), planMonth));
	                int planCounter = (entity == null) ? 0 : entity.getPlanCounter();
	                Integer planId = (entity == null) ? null : entity.getPlanId();
	                MonthlyPlan monthly = MonthlyPlan.builder()
	                                                 .planCounter(planCounter)
	                                                 .planId(planId)
	                                                 .planMonth(planMonth)
	                                                 .build();
	                monthlyPlans.add(monthly);
	            }
	        }
	        
	    }

	    return response;
	}

    String toKey(String category, String salesOrderType, int planMonth) {
        return category + ":" + salesOrderType + ":" + planMonth;
    }

    String toKey(InductionAnnualPlanEntity plan) {
	    return plan.getCategory() + ":" + plan.getSalesOrderType() + ":" + plan.getPlanMonth();
	}

	@Transactional
	public AnnualPlanResponse save(final AnnualPlanResponse request) {

        for (AnnualPlan ap : request.getAnnualPlans()) {
		    for (MonthlyPlan mp : ap.getMonthlyPlans()) {
		        final int counter = mp.getPlanCounter();
		        InductionAnnualPlanEntity entity = DataUtils.toEntity(counter, ap, mp);

		        if (!entity.isNew()) {
                    entity = iapRepo.saveAndFlush(entity);
                } else if (entity.isNew() && counter > 0) {
                    entity = iapRepo.saveAndFlush(entity);
                    mp.setPlanId(entity.getId());
                }
		    }
		}

	    return request;
	}
}
