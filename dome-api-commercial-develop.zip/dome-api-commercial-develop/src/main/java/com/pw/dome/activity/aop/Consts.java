package com.pw.dome.activity.aop;

import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.engine.EngineRepository;

interface Consts {
    String ACTIVITY_ITEM = "ActivityItem";

    String INDUCTION_CALENDAR = "Induction Calendar";

    // FIXME-  Add other repositories of interest...
    Class<?>[] REPOSITORIES = {EngineRepository.class, SlotEntity.class};
    String[] REPO_ACTIVITIES = {"Induction Calendar", "Induction Planning"};

//    private static final String USER_MAINTENANCE = "User Maintenance";
//    private static final String INDUCTION_CALENDAR = "Induction Calendar";
//    private static final String INDUCTION_PLANNING = "Induction Planning";
//    private static final String WIP = "Work In Progress Management";
//    private static final String MML_MONTHLY = "MML Monthly";
//    private static final String MML_QUARTERLY = "MML Quarterly";
//    private static final String LE_MONTHLY = "LE Monthly";
//    private static final String LE_QUARTERLY = "LE Quarterly";

    String ADD = "ADD";
    String UPDATE = "UPDATE";
    String DELETE = "DELETE";
}
