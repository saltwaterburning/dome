package com.pw.dome.calendar.slots;

import static java.util.Objects.isNull;

import java.util.stream.Stream;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import org.springframework.dao.DataIntegrityViolationException;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.pw.dome.exception.RestExceptionHandler;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Enumeration of shop visit types.
 * This enum has annotations to direct JSON processing
 * and a nested class to handle JPA conversions.
 * 
 * @see JsonCreator
 * @see JsonValue
 * @see ShopVisitTypeJpaConverter
 * @see RestExceptionHandler
 */
@Schema(enumAsRef = true)
public enum ShopVisitType {
    /** NONE is not used. Value = 0. */
	NONE,
    /** Is module visit. Value = 1. */
	MODULE,
    /** Is light visit. Value = 2. */
	LIGHT,
    /** Is heavy visit. Value = 3. */
	HEAVY,
    /** Is holiday visit. Value = 4. */
    HOLIDAY,
    /** Is medium visit. Value = 5. */
	MEDIUM,
    /** Is new visit. Value = 6. */
    NEW;

    /**
     * Returns the shop visit integer value.
     * @return the shop visit integer value
     * 
     * @see JsonValue
     */
    // JsonValue annotation indicates how to marshall this enum instance into a JSON String for client requests.
    // The name() will otherwise be used by default for marshalling.
    @JsonValue
    public int getValue() {
        return ordinal();
    }

    /**
     * Creates a {@code ShopVisitType} instance from an integer value.
     * Range validation is performed.
     * 
     * @param value ShopVisitType integer of between 1 and 6
     * @return a {@code ShopVisitType} instance
     * @throws IllegalArgumentException if unable to convert to a {@code ShopVisitType}
     * 
     * @see JsonCreator
     */
    // JsonCreator annotation indicates how to unmarshall a JSON String into this enum instance for client requests.
    // Otherwise ShopVisitType.values()[value] be used by default for unmarshalling.
    @JsonCreator
    public static ShopVisitType of(Integer value) {
    	if (isNull(value)) {
    		return null;
    	}

    	ShopVisitType rv = Stream.of(ShopVisitType.values()).filter(s -> value.equals(s.getValue()))
                .findFirst()
                .orElse(null);

    	// Maps to HttpStatus.BAD_REQUEST request status.
    	if (isNull(rv)) {
    		throw new IllegalArgumentException("Invalid shop vist type value: " + value);
    	}

    	return rv;
    }

    /**
     * Used by JPA implementation (Hibernate) to map DB column value to/from a {@code ShopVisitType}.
     * Range validation is performed on the DB column value.
     * Note that this converter is needed in place of the @Enumerated(ORDINAL|STRING)
     * entity annotation in order to provide a useful client error message.
     */
    @Converter(autoApply = true)
    public static class ShopVisitTypeJpaConverter implements AttributeConverter<ShopVisitType, Integer> {

        @Override
        public Integer convertToDatabaseColumn(ShopVisitType attribute) {
            if (isNull(attribute)) {
                return null;
            }

            return attribute.getValue();
        }

        @Override
        public ShopVisitType convertToEntityAttribute(Integer dbData) {
            if (isNull(dbData)) {
                return null;
            }

            try {
                return ShopVisitType.of(dbData);
            } catch (IllegalArgumentException e) {
                // Subclasses of NestedRuntimeException map to HttpStatus.INTERNAL_SERVER_ERROR (500) request status.
                throw new DataIntegrityViolationException("Invalid shop vist type DB value: " + dbData, e);
            }

// Alternate implementation.
//            return Stream.of(ShopVisitType.values())
//            .filter(s -> s.getValue() == dbData)
//            .findFirst()
            // Subclasses of NestedRuntimeException map to HttpStatus.INTERNAL_SERVER_ERROR (500) request status.
//            .orElseThrow(()-> new DataIntegrityViolationException("Invalid shop visit type DB value: " + dbData));
        }
    }
}
