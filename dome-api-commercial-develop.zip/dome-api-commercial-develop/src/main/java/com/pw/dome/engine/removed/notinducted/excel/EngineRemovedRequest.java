package com.pw.dome.engine.removed.notinducted.excel;

import java.util.List;

import lombok.Builder;

@Builder(toBuilder = true)
public record EngineRemovedRequest (
		List<String> customers,
		List<String> engineTypes) {}