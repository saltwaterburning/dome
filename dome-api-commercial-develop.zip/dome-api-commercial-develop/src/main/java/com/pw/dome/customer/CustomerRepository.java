package com.pw.dome.customer;

import static com.pw.dome.customer.Consts.SQL.GET_CUSTOMERS_QUERY;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
/**
 * @author John De Lello
 */
@Repository
public interface CustomerRepository extends JpaRepository<CustomerEntity, String> {
	public static interface CustomerEsn {
		String getEsn();
		String getName();
		String getShortName();
	}

	@Query(value = GET_CUSTOMERS_QUERY)
	List<CustomerEntity> getCustomersByUser(@Param("email") String email);

	boolean existsByName(String name);

	@Query(value = "SELECT distinct esn, cust_name as name, cust_sname as shortName from dome_customer c, dome_engine_events e where c.cust_sname = e.operator_code and c.cust_sname in (select distinct operator_code from dome_engine_events where esn in (?1) or esn in (?2) and operator_code is not null)", nativeQuery = true)
	List<CustomerEsn> findByEsnIn(List<String> esns1, List<String> esns2);

	boolean existsByShortName(String shortName);

	List<CustomerEntity> findByActiveTrueOrderByNameAsc();

	@Query(value = "SELECT dome_cust_id_seq.nextval FROM dual", nativeQuery = true)
	Long getNextSeqVal();

	@Modifying
	@Query(value = "UPDATE CustomerEntity x set x.active = TRUE WHERE x.customerID in (:ids)")
    int setActive(final @Param("ids") Set<String> ids);

	@Modifying
	@Query(value = "UPDATE CustomerEntity x set x.active = FALSE WHERE x.customerID in (:ids)")
    int setInactive(final @Param("ids") Set<String> ids);
}
