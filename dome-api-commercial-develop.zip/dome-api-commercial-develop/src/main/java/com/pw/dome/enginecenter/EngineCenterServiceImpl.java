package com.pw.dome.enginecenter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author John De Lello
 */
@Service
public class EngineCenterServiceImpl implements EngineCenterService {

	@Autowired
	EngineCenterRepository engineRepo;
	
	@Override
	public EngineCenterEntity getEngineCenterByID(final String engineCenterID) {
		return engineRepo.findById(engineCenterID).orElse(null);		
	}

}
