package com.pw.dome.engine.contract;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author John De Lello
 */
@Service
public class EngineContractServiceImpl implements EngineContractService {
	@Autowired
	private EngineContractRepository engineContractRepo;
	
	
	@Override
	public EngineContractResponse findByEsnIgnoreCase(final String esn) {
	
		if(StringUtils.isEmpty(esn)) {
			throw new IllegalArgumentException("No valid Engine ESN was specified. Unable to get engine contract details.");
		}
		
		List<EngineContractEntity> esnContracts = engineContractRepo.findByEsnIgnoreCase(esn);
		
		EngineContractEntity engineContract = null;
		
		if (esnContracts.isEmpty()) {
			return null;
		} else {
			engineContract = esnContracts.get(0);
		}
		
		EngineContractResponse response = EngineContractResponse.builder()
											.accessoryCoverage(engineContract.getAccessoryCoverage())
											.description(engineContract.getDescription())
											.endDate(engineContract.getEndDate())
											.esn(engineContract.getEsn())
											.leaseReturnCoverage(engineContract.getLeaseReturnCoverage())
											.leaseReturnDate(engineContract.getLeaseReturnDate())
											.llpCoverage(engineContract.getLlpCoverage())
											.refurbPayStructure(engineContract.getRefurbPayStructure())
											.s1RetrofitCoverage(engineContract.getS1RetrofitCoverage())
											.shippingCoverage(engineContract.getShippingCoverage())
											.subFleet(engineContract.getSubFleet())
											.svs(engineContract.getSvs())
											.years(engineContract.getYears())
											.build();
											
		return response;
	}
}
