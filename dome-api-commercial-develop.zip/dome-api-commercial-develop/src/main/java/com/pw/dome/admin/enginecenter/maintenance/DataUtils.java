package com.pw.dome.admin.enginecenter.maintenance;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.pw.dome.engine.group.EngineGroupEntity;
import com.pw.dome.engine.model.EngineModelEntity;
import com.pw.dome.engine.type.EngineTypeEntity;
import com.pw.dome.enginecenter.EngineCenterEntity;

final class DataUtils {
	private DataUtils() {}

	static BasicEngineCenter toBasicEngineCenter(final EngineCenterEntity ec) {
		return BasicEngineCenter.builder()
				                .active(ec.isActive())
				                .centerId(ec.getId())
				                .centerName(ec.getName())
				                .build();
	}

	static List<BasicEngineCenter> toBasicEngineCenter(final List<EngineCenterEntity> ec) {
		return ec.stream().map(s->toBasicEngineCenter(s)).collect(Collectors.toList());
	}

	static BasicEngineGroup toBasicEngineGroup(final EngineGroupEntity eg) {
		return BasicEngineGroup.builder()
				               .active(eg.isActive())
				               .groupId(eg.getEngineGroupID())
				               .groupName(eg.getName())
				               .build();
	}

	static List<BasicEngineGroup> toBasicEngineGroup(final List<EngineGroupEntity> eg) {
		return eg.stream().map(s->toBasicEngineGroup(s)).collect(Collectors.toList());
	}

	static BasicEngineModel toBasicEngineModel(final EngineModelEntity em) {
		return BasicEngineModel.builder()
				               .active(em.isActive())
				               .modelId(em.getEngineModelID())
				               .modelName(em.getName())
				               .build();
	}

	static List<BasicEngineModel> toBasicEngineModel(final List<EngineModelEntity> em) {
		return em.stream().map(s->toBasicEngineModel(s)).collect(Collectors.toList());
	}

	static BasicEngineType toBasicEngineType(final EngineTypeEntity et, final Set<String> etSet) {
		String etId = et.getEngineTypeID();
		return BasicEngineType.builder()
				              .active(et.isActive())
				              .inEngineCenter(etSet.contains(etId))
				              .eagleData(et.isEData())
				              .typeId(etId)
				              .typeName(et.getName())
				              .build();
	}

	static List<BasicEngineType> toBasicEngineType(final List<EngineTypeEntity> ec, final Set<String> etSet) {
		return ec.stream().map(s->toBasicEngineType(s, etSet)).collect(Collectors.toList());
	}
	
	static BasicEngineType toBasicEngineTypeForCustomer(final EngineTypeEntity et, final Set<String> etSet) {
		String etId = et.getEngineTypeID();
		return BasicEngineType.builder()
				              .active(et.isActive())
				              .assignedToCustomer(etSet.contains(etId))
				              .eagleData(et.isEData())
				              .typeId(etId)
				              .typeName(et.getName())
				              .build();
	}
	
	static List<BasicEngineType> toBasicEngineTypeForCustomer(final List<EngineTypeEntity> ec, final Set<String> etSet) {
		return ec.stream().map(s->toBasicEngineTypeForCustomer(s, etSet)).collect(Collectors.toList());
	}

	static EngineTypeEntity toEngineType(final BasicEngineType et) {
		return EngineTypeEntity.builder()
				         .active(et.isActive())
				         .eData(false)
				         .engineTypeID(et.getTypeId())
				         .name(et.getTypeName())
				         .build();
	}
}
