package com.pw.dome.calendar.inductionplanning;

import java.util.ArrayList;
import java.util.Collection;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Getter 
@Setter 
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class InductionPlanningCalendarDay{
	private boolean validDate;
	private int boxNumber;
	private int dayOfMonth;
	private Collection<InductionPlanningCalendarVisitSummary> shopVisitsSummary;
	
	public void addShoptVisitSummary(InductionPlanningCalendarVisitSummary shopVisitSummary) {
		if(shopVisitsSummary == null) {
			shopVisitsSummary = new ArrayList<>();
		}

		shopVisitsSummary.add(shopVisitSummary);
	}
}
