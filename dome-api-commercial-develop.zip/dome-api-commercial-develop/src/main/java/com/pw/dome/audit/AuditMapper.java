package com.pw.dome.audit;

import java.time.LocalDateTime;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.util.SecurityUtils;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface AuditMapper {
  AuditMapper INSTANCE = Mappers.getMapper(AuditMapper.class);

  AuditEvent toAuditEvent(AuditEntity entity);

  @Mapping(target = "activityId", ignore = true)
  AuditEntity toAuditEntity(AuditEvent audit, LocalDateTime activityDate, String userEmail);

  default AuditEntity toEntity(AuditEvent audit) {
    return toAuditEntity(audit, LocalDateTime.now(), SecurityUtils.getUserEmailAddress());
  }
}
