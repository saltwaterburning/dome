package com.pw.dome.external.mro.collab.services.comments;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Valid
class MroCommentResponse {
	@NotNull
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Integer engineId;

	@Size(min = 1, max = 20)
    @NotBlank
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String esn;

	@Min(1)
    @NotNull
    @NotBlank
	private Integer eventId;

	@Size(min = 1, max = 10)
    @NotBlank
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String mroShopCode;

	@Size(min = 1, max = 25)
    @NotBlank
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "Named SMI in MRO system.")
	private String mroWorkOrder;

	@NotNull
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private List<MroComment> comments;
}
