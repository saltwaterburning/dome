/**
 * Provides the Induction MML info.
 * 
 */
package com.pw.dome.mml.induction;