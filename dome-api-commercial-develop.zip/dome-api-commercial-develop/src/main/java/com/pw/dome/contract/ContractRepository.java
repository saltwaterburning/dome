package com.pw.dome.contract;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ContractRepository extends JpaRepository<ContractEntity, String> {
	@Query(value = "SELECT DISTINCT c.contractType FROM ContractEntity c WHERE LENGTH(c.contractType) > 1 order by 1")
	List<String> getContractTypes();
}
