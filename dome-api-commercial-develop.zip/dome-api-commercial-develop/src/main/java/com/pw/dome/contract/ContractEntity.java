package com.pw.dome.contract;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.NaturalId;

import com.pw.dome.jpa.AbstractEntityWithNaturalId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_SPEID")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Immutable
public class ContractEntity extends AbstractEntityWithNaturalId<String> {
	@Id
	@NaturalId
	@Column(name="ESN")
	private String esn;
	
	@Column(name="CONTRACT_TYPE")
	private String contractType;

	@Override
	public String getId() {
		return esn;
	}
}
