package com.pw.dome.external.mro.collab.services.customerapproval;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.common.oas.BaseRESTfulResource;
import com.pw.dome.exception.ErrorResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/v1/mro-collab/customer-approval")
@Tag(name = BaseRESTfulResource.Tags.MRO)
@Validated
class MroCustomerApprovalController extends BaseRESTfulResource {
	@Autowired
	private MroCustomerApprovalService customerApprovalService;

	  @Operation(description = "Updates the matching ODIN record with the MRO Customer Approval Date.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = OK,
					      description = "Successfully updated the matching ODIN record.",
					          content = @Content(mediaType = APP_JSON,
					                              examples = @ExampleObject(name = "OK", value = "Success"),
					           schema = @Schema(implementation = ErrorResponse.class))),
			@ApiResponse(responseCode = CONFLICT,
			              description = "The approval date wasn't updated as one already exists.")})
	@PutMapping(produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<ErrorResponse> updateEngineComments(
			@Valid
			@RequestBody
			MroCustomerApprovalRequest request) {
		  customerApprovalService.updateCustomerApprovalDate(request);
		  ErrorResponse reponse = new ErrorResponse(HttpStatus.OK, "Success");
		return ResponseEntity.ok(reponse);
	}
}
