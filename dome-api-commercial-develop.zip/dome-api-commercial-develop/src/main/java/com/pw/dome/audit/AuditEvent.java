package com.pw.dome.audit;

import lombok.Builder;

@Builder(toBuilder = true)
public record AuditEvent(
    String customerID,
    String description,
    String engineCenterId,
    String engineGroup,
    String engineModel,
    String engineModule,
    String engineSerialNumber,
    String engineType,
    AuditItem item,
    AUDIT_TYPES type) {
  ;
}
