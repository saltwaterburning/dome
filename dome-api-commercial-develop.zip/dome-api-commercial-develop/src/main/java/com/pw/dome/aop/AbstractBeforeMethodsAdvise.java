package com.pw.dome.aop;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;

import org.springframework.aop.MethodBeforeAdvice;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractBeforeMethodsAdvise<T, ID> extends AbstractMethodsAdvice<T, ID>
		implements BeforeMethodsAdvise<T, ID>, MethodBeforeAdvice {
	private final Map<String, Method> adviserMethods;

	public AbstractBeforeMethodsAdvise() {
		adviserMethods = new TreeMap<>();

		Method[] declaredMethods = getClass().getDeclaredMethods();

		if (declaredMethods == null || declaredMethods.length == 0) {
			String msg = "No declared methods in advisor: " + getClass().getName();
			throw new RuntimeException(msg);
		}

		Stream.of(declaredMethods).filter(s -> Modifier.isPublic(s.getModifiers()))
				.forEach(s -> adviserMethods.put(getMethodSignature(s), s));

		log.debug("Advise cached for {}...\n    {}", getClass().getName(), adviserMethods);
	}

	@Override
	public void before(Method repoMethod, Object[] args, Object target) throws Throwable {
		// Validate JPA transaction isn't active.
//		Validate.isTrue(!TransactionSynchronizationManager.isActualTransactionActive());

		try {
			Method method;
			String sig = getMethodSignature(repoMethod);

			if ((method = adviserMethods.get(sig)) == null) {
				// Generics type erasure?
				// CrudRepository.delete(T entity) becomes CrudRepository.delete(Object entity)
				String sig2 = getParameterizedMethodSignature(repoMethod);

				boolean sameSig = sig.equals(sig2);

				if (sameSig || (method = adviserMethods.get(sig2)) == null) {
					String repo = repoMethod.getDeclaringClass().getName();
					log.debug("No JPA Repository advise before Method {}.{}", repo, sig);
					if (!sameSig) {
						log.debug("...AND No JPA Repository advise before Method {}.{}", repo, sig2);
					}

					return;
				}
			}

			method.invoke(this, args); // Invoke the local return method
			if (log.isDebugEnabled()) {
				String repo = repoMethod.getDeclaringClass().getName();
				log.debug("Advise invoked before...\n  Args: {}\n  Repo: {}\n  Method: {}", Arrays.toString(args), repo,
						sig);
			}
		} catch (Exception e) {
			String msg = String.format("%s() error, Args=%s", repoMethod.getName(), Arrays.toString(args));
			log.error(msg, e);
		}
	}
}
