package com.pw.dome.engine.removed;

import org.springframework.data.jpa.repository.Query;

/**
 * Fully Classified Class Name constants used by JPQL Constructor Expressions.
 * Needed because the {@link Query}.value must be a constant expression.
 */
public interface DTO_FQCN {
    String DTO_NAME = "com.pw.dome.engine.removed.EngineRemovedDTO";
}
