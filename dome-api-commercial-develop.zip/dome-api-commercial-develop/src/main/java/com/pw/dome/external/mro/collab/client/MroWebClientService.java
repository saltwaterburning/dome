package com.pw.dome.external.mro.collab.client;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pw.dome.engine.comments.CommentEntity;
import com.pw.dome.external.mro.collab.services.comments.MroComment;
import com.pw.dome.external.mro.collab.services.pacingitems.MroPacingItem;
import com.pw.dome.wip.WorkInProgress;
import com.pw.dome.wip.pacing.PacingItemDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * Handles all requests to MRO and guards against exceptions to prevent failures in calling service.
 * All methods are invoked synchronously.
 * 
 * @see MroWebClientAsyncService
 */
@Service
@Slf4j
public class MroWebClientService extends MroWebClientAbstractService {

	public void deleteComment(Long commentId) {
		try {
			doDeleteComment(commentId);
		} catch (Exception e) {
			log.error("MRO.deleteComment() failed. CommentId: " + commentId, e);
		}
	}

	public void deleteEngineEsn(Integer engineId, String esn, Integer eventId) {
		try {
			doDeleteEngineEsn(engineId, esn, eventId);
		} catch (Exception e) {
			log.error("MRO.deleteComment() failed. EventId: " + eventId, e);
		}
	}

	public void deletePacingItem(Long pacingItemId) {
		try {
			doDeletePacingItem(pacingItemId);
		} catch (Exception e) {
			log.error("MRO.deletePacingItem failed. PacingItemId: " + pacingItemId, e);
		}
	}

	public void pushComments(List<CommentEntity> commentEntities) {
		try {
			doPushComments(commentEntities);
		} catch (Exception e) {
			log.error("MRO.pushComments failed.", e);
		}
	}

	/**
	 * Sends comments to MRO batched by engineId. Used for MRO testing.
	 * 
	 * @param commentEntities
	 * @return
	 */
	public void pushCommentsGroupByEngineId(List<CommentEntity> commentEntities) {
		try {
			doPushCommentsGroupByEngineId(commentEntities);
		} catch (Exception e) {
			log.error("MRO.pushCommentsGroupByEngineId failed.", e);
		}
	}

	public void pushEngineGateInfo(WorkInProgress wip) {
		try {
			doPushEngineGateInfo(wip);
		} catch (Exception e) {
			log.error("MRO.pushEngineGateInfo failed.", e);
		}
	}

	public void pushMroComments(List<MroComment> mroComments) {
		try {
			doPushMroComments(mroComments);
		} catch (Exception e) {
			log.error("MRO.pushMroComments failed.", e);
		}
	}

	public void pushMroPacingItems(List<MroPacingItem> mroPacingItems) {
		try {
			doPushMroPacingItems(mroPacingItems);
		} catch (Exception e) {
			log.error("MRO.pushMroPacingItems failed.", e);
		}
	}

	public void pushPacingItem(List<PacingItemDTO> pacingItems) {
		try {
			doPushPacingItems(pacingItems);
		} catch (Exception e) {
			log.error("MRO.pushPacingItem failed.", e);
		}
	}

	/**
	 * Sends PacingItems to MRO grouped by engineId. Used for MRO testing.
	 * 
	 * @param mroPacingItems
	 * @return
	 */
	public void pushPacingItemGroupedByEngineId(List<MroPacingItem> mroPacingItems) {
		try {
			doPushPacingItemsGroupedByEngineId(mroPacingItems);
		} catch (Exception e) {
			log.error("MRO.doPushPacingItemGroupedByEngineId failed.", e);
		}
	}
}
