package com.pw.dome.external.mro.collab.client;

import java.util.List;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.pw.dome.engine.comments.CommentEntity;
import com.pw.dome.wip.WorkInProgress;
import com.pw.dome.wip.pacing.PacingItemDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * Handles all requests to MRO and guards against exceptions to prevent failures in calling service.
 * All methods are invoked asynchronously.
 * 
 * @see MroWebClientService
 */
@Service
@Slf4j
public class MroWebClientAsyncService extends MroWebClientAbstractService {

	@Async
	public void deleteComment(Long commentId) {
		try {
			doDeleteComment(commentId);
		} catch (Exception e) {
			log.error("deleteComment() failed.", e);
		}
	}

	@Async
	public void deleteEngineEsn(Integer engineId, String esn, Integer eventId) {
		try {
			doDeleteEngineEsn(engineId, esn, eventId);
		} catch (Exception e) {
			log.error("deleteEngineEsn() failed.", e);
		}
	}

	@Async
	public void deletePacingItem(Long pacingItemId) {
		try {
			doDeletePacingItem(pacingItemId);
		} catch (Exception e) {
			log.error("deletePacingItem() failed.", e);
		}
	}

	@Async
	public void pushComments(List<CommentEntity> commentEntities) {
		try {
			doPushComments(commentEntities);
		} catch (Exception e) {
			log.error("pushComments() failed.", e);
		}
	}

	@Async
	public void pushEngineGateInfo(WorkInProgress wip) {
		try {
			doPushEngineGateInfo(wip);
		} catch (Exception e) {
			log.error("pushEngineGateInfo() failed.", e);
		}
	}

	@Async
	public void pushPacingItem(List<PacingItemDTO> pacingItems) {
		try {
			doPushPacingItems(pacingItems);
		} catch (Exception e) {
			log.error("pushPacingItem() failed.", e);
		}
	}
}
