package com.pw.dome.audit;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import org.springframework.data.annotation.LastModifiedBy;

import com.pw.dome.jpa.AbstractEntityWithGeneratedId;
import com.pw.dome.util.hibernate.AuditItemConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "DOME_ACTIVITY")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AuditEntity extends AbstractEntityWithGeneratedId<Long> {
  @NotNull
  @Column(name = "ACTIVITY_DATE")
//  @LastModifiedDate // Added by container
  private LocalDateTime activityDate;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOME_ACTIVITY_SEQ")
  @SequenceGenerator(sequenceName = "DOME_ACTIVITY_SEQ", allocationSize = 1, name = "DOME_ACTIVITY_SEQ")
  @Column(name = "ACTIVITY_TRACKNO")
  private Long activityId;

  @Column(name = "ACTIVITY_CUST_ID")
  @Size(min = 0, max = 20)
  private String customerID;

  @NotNull
  @Column(name = "ACTIVITY_DESCRIPTION")
  @Size(min = 0, max = 1000)
  private String description;

  @Column(name = "ACTIVITY_EC_ID")
  @Size(min = 0, max = 10)
  private String engineCenterId;

  @Column(name = "ACTIVITY_ENG_GROUP")
  @Size(min = 0, max = 10)
  private String engineGroup;

  @Column(name = "ACTIVITY_ENG_MODEL")
  @Size(min = 0, max = 10)
  private String engineModel;

  @Column(name = "ACTIVITY_ENG_MODULE")
  @Size(min = 0, max = 10)
  private String engineModule;

  @Column(name = "ACTIVITY_ENG_SN")
  @Size(min = 0, max = 20)
  private String engineSerialNumber;

  @Column(name = "ACTIVITY_ENG_TYPE")
  @Size(min = 0, max = 10)
  private String engineType;

  @NotNull
  @Column(name = "ACTIVITY_ITEM")
  @Convert(converter = AuditItemConverter.class)
  private AuditItem item;

  @NotNull
  @Column(name = "ACTIVITY_TYPE")
  @Enumerated(EnumType.STRING)
  private AUDIT_TYPES type;

  @NotNull
  @Column(name = "ACTIVITY_USER")
  @LastModifiedBy // Added by container
  private String userEmail;

  @Override
  public Long getId() {
    return activityId;
  }
}
