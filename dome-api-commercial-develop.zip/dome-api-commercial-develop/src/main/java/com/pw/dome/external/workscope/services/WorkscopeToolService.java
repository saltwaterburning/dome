package com.pw.dome.external.workscope.services;

import static java.util.Objects.nonNull;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.pw.dome.engine.odin.OdinEntity;
import com.pw.dome.exception.ErrorResponse;
import com.pw.dome.exception.NotFoundException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
class WorkscopeToolService {
	@Autowired
	private WorkscopeToolRepository repo;

	ErrorResponse updateWorkscopeFromWST(WorkscopeRequest request) {
		Optional<OdinEntity> result = repo.findOdin(request.esn(), request.eventId(), request.smiNumber());
		if (result.isEmpty()) {
			log.warn("ODIN record not found. Request: {}", request);
			throw new NotFoundException("ODIN record not found.");
		}

		OdinEntity entity = result.get();

		LocalDate initiationDate = null;
		if (nonNull(request.wSInitiationDateTime())) {
			initiationDate = request.wSInitiationDateTime().toLocalDate();
		}
		entity.setWsInitiationDate(initiationDate);

		repo.save(entity);

		return new ErrorResponse(HttpStatus.OK, "DOME update successful from WST.");
	}
}
