package com.pw.dome.engine;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EngineArchiveRepository extends JpaRepository<EngineArchiveEntity, Long> {

//	@Query(value = "SELECT DOME_ENG_ARCHIVE_ID_SEQ.nextval FROM dual", nativeQuery = true)
//	Long getNextSeqVal();
}
