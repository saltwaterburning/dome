package com.pw.dome.engine.removed.notinducted.excel;

import static com.pw.dome.engine.removed.notinducted.excel.Consts.CLASSIFICATION;
import static com.pw.dome.engine.removed.notinducted.excel.Consts.DISCLAIMER;
import static com.pw.dome.util.QueryUtils.isAllOrAny;
import static org.apache.commons.io.FileUtils.ONE_MB;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pw.dome.util.excel.CellValues;
import com.pw.dome.util.excel.ExcelSheet;
import com.pw.dome.util.excel.ExcelWorkbook;
import com.pw.dome.wip.reports.tracking.TrackingUtil;

@Service
class EngineRemovedNotInductedExcelService {

private static final boolean DEBUG = false;
	
	private EngineRemovedNotInductedRepository engineRemovedNotIncludedRepo;
	
	@Autowired
	public EngineRemovedNotInductedExcelService(EngineRemovedNotInductedRepository engineRemovedNotIncludedRepo) {
		this.engineRemovedNotIncludedRepo = engineRemovedNotIncludedRepo;
	}
	
	public ByteArrayInputStream getEnginesRemovedNotInducted(final String engType, final String custId) throws IOException {		
		
		return getEnginesRemovedNotInducted(EngineRemovedRequest.builder()
			     .customers(Arrays.asList(custId))
	                .engineTypes(Arrays.asList(engType))
	                .build());
			     
	
	}
	
	/**
	 * Returns the Excel workbook as a {@code ByteArrayInputStream}.
	 * Optionally writes the workbook into local PDF and XLSX files for debugging.
	 * 
	 * @param workbook Excel spreadsheet
	 * @param baseName used as the local filename
	 * @return the Excel workbook as a {@code ByteArrayInputStream}
	 * @throws IOException upon an error
	 */
	
	public ByteArrayInputStream getEnginesRemovedNotInducted(final EngineRemovedRequest request ) throws IOException {
		
		boolean ignoreEngType = isAllOrAny(request.engineTypes());
		boolean ignoreCustId = isAllOrAny(request.customers());
		
		List<EngineRemovedNotInducted> engines = engineRemovedNotIncludedRepo.getEngineRemovedNotInducted(ignoreEngType, request.engineTypes(), ignoreCustId, request.customers());
		
		final ExcelWorkbook workbook = new ExcelWorkbook(true);
		workbook.getSheets().stream().forEach(s->s.withAutoSizedColumns());
		final ExcelSheet classification = workbook.getUniqueExcelSheet(CLASSIFICATION);
		classification.withCells(TrackingUtil.getRedTextStyle(), CellValues.builder().add(DISCLAIMER).build());
		
		final ExcelSheet sheet = workbook.getExcelSheet("Engines Removed Not Inducted").withFreezePane(4, 1);
		sheet.withCells(RemovedNotInductedUtils.getEnginesRemovedNotInductedReportHeaders());
		for (EngineRemovedNotInducted engine : engines) {
			sheet.withNextRow().withCells(RemovedNotInductedUtils.getData(engine));
		}

		sheet.withAutoSizedColumns();

		return writeWorkbook(workbook, "engines-removed-not-inducted");
	}

	private ByteArrayInputStream writeWorkbook(ExcelWorkbook workbook, String baseName)
	throws IOException {
		ByteArrayInputStream inputByteArray;

		if (DEBUG) {
			try {
				String pathName = "/tmp/" + baseName;
				workbook.saveAsXlsx(pathName + ".xlsx");
			} catch (IOException cause) {
				throw new RuntimeException(cause);
			}
		}

		try (ByteArrayOutputStream outputByteArray = new ByteArrayOutputStream((int)ONE_MB)) {
			workbook.saveAsXlsx(outputByteArray);
			inputByteArray = new ByteArrayInputStream(outputByteArray.toByteArray());
		}

		return inputByteArray;
	}
}
