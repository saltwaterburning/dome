package com.pw.dome.external.mro.collab.services.comments;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.engine.comments.CommentEntity;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

	@Mapping(target = "esn", ignore = true)
	@Mapping(target = "eventId", ignore = true)
	@Mapping(target = "mroShopCode", ignore = true)
	@Mapping(target = "mroWorkOrder", ignore = true)
	MroComment toComment(CommentEntity cmt);
	List<MroComment> toComment(List<CommentEntity> cmt);
}
