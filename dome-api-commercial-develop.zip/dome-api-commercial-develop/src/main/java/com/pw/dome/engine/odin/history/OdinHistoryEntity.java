/**
 * @author John De Lello
 */
package com.pw.dome.engine.odin.history;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.pw.dome.jpa.AbstractEntityWithGeneratedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_ODIN_HISTORY")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OdinHistoryEntity extends AbstractEntityWithGeneratedId<Integer> {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOME_ODIN_HIST_SEQ")
    @SequenceGenerator(sequenceName = "DOME_ODIN_HIST_SEQ", allocationSize = 1, name = "DOME_ODIN_HIST_SEQ")
	@Column(name="ODIN_HIST_ID")
	private Integer odinHistId;

    @Column(name="EVENT_ID")
	private Integer eventId;

    @Column(name="ESN")
	private String esn;
	
	@Column(name="ENG_ID")
	private Integer engineId;
	
	@Column(name="PRELIM_INDUCTION")
	private LocalDate prelimInductionDate;
	
	@Column(name="LOG_EMAIL")
    private String logEmail;
	
	@Column(name="CHANGE_REASON")
    private String changeReason;
	
	@Column(name="NOTES")
    private String notes;

	@Column(name="UPDATE_DATE")
	private LocalDate updateDate;

	@Override
	public Integer getId() {
		return odinHistId;
	}
}

