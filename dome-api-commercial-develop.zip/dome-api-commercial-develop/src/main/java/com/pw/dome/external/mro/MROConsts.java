package com.pw.dome.external.mro;

import com.pw.dome.util.JsonDateTimeFormatConfig;

public interface MROConsts {
	/** Override {@link JsonDateTimeFormatConfig} and maintain constant format. */
	String ISO_DATE_FORMAT = "yyyy-MM-dd";
  /** Override {@link JsonDateTimeFormatConfig} and maintain constant format. */
	String ISO_8601_FORMAT = "yyyy-MM-dd'T'h:mm:ss";
  /** Override {@link JsonDateTimeFormatConfig} and maintain constant format. */
  String ISO_8601_VARIATION_FORMAT = "yyyy-MM-dd h:mm:ss";
}
