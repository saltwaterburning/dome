package com.pw.dome.calendar.induction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Getter 
@Setter 
@NoArgsConstructor 
@AllArgsConstructor 
@ToString
@Builder
public class CalendarEngine {
	private String category;
	private String customerID;
	private String customerName;
	private String customerShortName;
	private String engineGroupID;
	private int engineID; 
	private String engineModelID;
	private String engineTypeID;
	private String engineTypeName;
	private String esn;
	private Boolean manualEngine;
	private Integer moduleID;
	private String moduleName;
	private String salesOrderType;
	private String subVisitType;
}
