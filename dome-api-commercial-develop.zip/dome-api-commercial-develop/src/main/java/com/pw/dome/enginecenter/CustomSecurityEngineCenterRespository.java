package com.pw.dome.enginecenter;

import java.util.List;

public interface CustomSecurityEngineCenterRespository {
	List<String> getEngineCenterIdsByEmailAddress(final String emailAddress);
	List<String> getEngineTypeIdsByEmailAddress(final String emailAddress);
}
