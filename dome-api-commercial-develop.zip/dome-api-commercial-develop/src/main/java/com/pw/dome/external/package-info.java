/*
 * Provides external web API client.
 */
package com.pw.dome.external;