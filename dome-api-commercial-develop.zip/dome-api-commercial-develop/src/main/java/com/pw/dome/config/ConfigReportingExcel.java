package com.pw.dome.config;

import jakarta.validation.constraints.NotNull;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import com.pw.dome.util.excel.ExcelWorkbook;

import lombok.Data;

@Configuration
@ConfigurationProperties(prefix = "dome.reporting-excel")
@Data
@Validated
public class ConfigReportingExcel {
	/**
	 * Hide the drop-down list tab unless overridden by configuration setting.
	 * 
	 * @see ExcelWorkbook#createDropDownLists(boolean, String, java.util.Map)
	 */
	@NotNull
	private Boolean hideDropDownListsTab;
}
