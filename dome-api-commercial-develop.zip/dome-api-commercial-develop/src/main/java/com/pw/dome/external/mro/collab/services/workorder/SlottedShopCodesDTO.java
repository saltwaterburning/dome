package com.pw.dome.external.mro.collab.services.workorder;

import lombok.Builder;

@Builder
public record SlottedShopCodesDTO(
		String shopCode,
		String engineCenterId,
		String engineCenterName) {
	;
}
