package com.pw.dome.enginecenter;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

public class CustomSecurityEngineCenterRespositoryImpl implements CustomSecurityEngineCenterRespository {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<String> getEngineCenterIdsByEmailAddress(String emailAddress) {
		@SuppressWarnings("unchecked")
		List<String> list = entityManager.createQuery("Select distinct engineCenterId from SecurityEngineCenterEntity e where UPPER(e.emailAddress) = UPPER(?0)")
		                                 .setParameter(0, emailAddress)
		                                 .getResultList();
		return list;
	}

	@Override
	public List<String> getEngineTypeIdsByEmailAddress(String emailAddress) {
		@SuppressWarnings("unchecked")
		List<String> list = entityManager.createQuery("Select distinct engineTypeId from SecurityEngineCenterEntity e where UPPER(e.emailAddress) = UPPER(?0)")
		                                 .setParameter(0, emailAddress)
		                                 .getResultList();
		return list;
	}
}
