package com.pw.dome.engine.removed.notinducted.excel;

import static com.pw.dome.report.excel.ReportConstants.EXCEL_MEDIA_TYPE;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import jakarta.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequestMapping("/v1/wip/reports/engines-removed-notinducted")
@Validated
class EngineRemovedNotInductedExcelController {

	private final EngineRemovedNotInductedExcelService excelService;

	@Autowired
	public EngineRemovedNotInductedExcelController(EngineRemovedNotInductedExcelService excelService) {
		this.excelService = excelService;
	}
	
	@PostMapping(path = "/{engine-type}/{customer-id}")
	public ResponseEntity<InputStreamResource> getEnginesRemovedNotInducted(
			@PathVariable(name = "engine-type")
            @NotBlank
			final String engineType,
            @PathVariable(name = "customer-id")
			@NotBlank
            final String customerId
			)
			throws IOException {
		ByteArrayInputStream inputStream = excelService.getEnginesRemovedNotInducted(engineType, customerId);
		return ResponseEntity.ok()
				             .contentType(EXCEL_MEDIA_TYPE )
				             .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=engines-removed-not-inducted-report.xlsx")
				             .body(new InputStreamResource(inputStream));
	}
	
	@PostMapping(path="/")
	public ResponseEntity<InputStreamResource> getEnginesRemovedNotInducted(
			@RequestBody
			EngineRemovedRequest request
			) throws IOException {
		
		ByteArrayInputStream inputStream = excelService.getEnginesRemovedNotInducted(request);
		
		return ResponseEntity.ok()
	             .contentType(EXCEL_MEDIA_TYPE )
	             .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=engines-removed-not-inducted-report.xlsx")
	             .body(new InputStreamResource(inputStream));
	}
}
