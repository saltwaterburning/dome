package com.pw.dome.engine.odin.reports;

import static com.pw.dome.engine.odin.reports.Consts.HEADERS;
import static com.pw.dome.report.excel.ReportConstants.CLASSIFICATION;
import static com.pw.dome.util.QueryUtils.isAllOrAny;
import static java.util.Objects.nonNull;
import static org.apache.commons.io.FileUtils.ONE_MB;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pw.dome.engine.odin.OdinBaseDTO;
import com.pw.dome.engine.odin.history.OdinHistoryEntity;
import com.pw.dome.engine.odin.history.OdinHistoryRepository;
import com.pw.dome.util.QueryHelper;
import com.pw.dome.util.excel.CellValues;
import com.pw.dome.util.excel.CellValues.Builder;
import com.pw.dome.util.excel.ExcelSheet;
import com.pw.dome.util.excel.ExcelWorkbook;

@Service
class OdinReportsService {
    static final boolean DEBUG = false;

    @Autowired
    private OdinHistoryRepository historyRepo;
    @Autowired
    private OdinReportsRepository repo;
    @Autowired
    private QueryHelper helper;

    ByteArrayInputStream odinReport(final OdinRequest request)
    throws IOException {
        final ExcelWorkbook workbook = new ExcelWorkbook();
		final ExcelSheet classification = workbook.getUniqueExcelSheet(CLASSIFICATION);
        final ExcelSheet sheet = workbook.getExcelSheet("ODIN Report");

        Builder b = CellValues.builder();
        // Row 0
        classification.withCells(ReportHelper.getRedTextStyle(),
                        b.add(Consts.EXPORT_CLASSIFICATION + Consts.EXPORT_CLASSIFICATION_TYPE).build());
//             .withMergedRegion(0,
//                               rowNum,
//                               HEADERS.length - 1,
//                               rowNum);

        sheet.withCells(ReportHelper.getHeaderCells(HEADERS));

        List<String> engTypes = helper.getUserEngineTypes(request.engineTypes());
        List<String> contractTypes = request.contractTypes();
        boolean ignoreContractType = isAllOrAny(contractTypes);
 
        List<OdinBaseDTO> odin = repo.getOdinReport(ignoreContractType, contractTypes, engTypes, request.fromDate(), request.toDate());

        Collections.sort(odin, Comparator.comparing(OdinBaseDTO::getEventId, Comparator.nullsFirst(Comparator.naturalOrder()))
                                         .thenComparing(Comparator.comparing(OdinBaseDTO::getOperatorName, Comparator.nullsFirst(Comparator.naturalOrder())))
                                         .thenComparing(Comparator.comparing(OdinBaseDTO::getEsn, Comparator.nullsFirst(Comparator.naturalOrder()))));

        for (OdinBaseDTO dto : odin) {
            LocalDate lastPreliminaryIndutionDate = null;

            if (nonNull(dto.getEsn()) && nonNull(dto.getEventId())) { // max hist ID
                List<OdinHistoryEntity> hist = historyRepo.findByEsnAndEventIdOrderByPrelimInductionDateAsc(dto.getEsn(), dto.getEventId());
                if (ObjectUtils.isNotEmpty(hist)) {
                    int index = hist.size() - 1;
                    lastPreliminaryIndutionDate = hist.get(index).getPrelimInductionDate();
                }
            }
            
        	sheet.withNextRow().withCells(ReportHelper.getRow(dto, lastPreliminaryIndutionDate));
        }
        sheet.withNextRow()
             .withNextRow()
             .withAutoSizedColumns();
        return writeWorkbook(workbook,
                             "induction-report");
    }

    /**
     * Returns the Excel workbook as a {@code ByteArrayInputStream}.
     * Optionally writes the workbook into local PDF and XLSX files for debugging.
     * 
     * @param workbook Excel spreadsheet
     * @param baseFileName used as the local filename
     * @return the Excel workbook as a {@code ByteArrayInputStream}
     * @throws IOException upon an error
     */
    private ByteArrayInputStream writeWorkbook(ExcelWorkbook workbook, String baseFileName)
    throws IOException {
        ByteArrayInputStream inputByteArray;

        try (ByteArrayOutputStream outputByteArray = new ByteArrayOutputStream((int)ONE_MB)) {
            workbook.saveAsXlsx(outputByteArray);
            inputByteArray = new ByteArrayInputStream(outputByteArray.toByteArray());
        }

        if (DEBUG) {

            try {
                String pathName = "/tmp/" + baseFileName;
                workbook.saveAsXlsx(pathName + ".xlsx");
            } catch (IOException cause) {
                cause.printStackTrace(System.err);
                throw new RuntimeException(cause);
            }
        }
        return inputByteArray;
    }
}
