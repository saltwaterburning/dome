package com.pw.dome.mml;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Parameter;

@RestController()
@RequestMapping("/v1/mml")
class MmlController {
    
    @Autowired
    private MmlService mmlService;
    
    /**
     * @api {get} /v1/mml Get MML Data
     * @apiExample {curl} Example usage: 
     *      curl --request POST
     *           --url http://localhost:8080/v1/mml
     *           --header 'Authorization: Bearer [jwt]'
     *           --data '{
                            "year" : 2019,
                            "monthQtr": 2,
                            "engineCenterId" : "EC1",
                            "engineGroupId" : "EG754",
                            "planMarket" : 0,
                            "planType" : 1,
                            "period" : "quarterly"
                        }'         
     * @apiName getMmlData
     * @apiDescription Returns MML data for given request parameters
     * @apiGroup MML
     * @apiParam {String} year The year for which mml data is requested
     * @apiParam {String} monthQtr The month number or quarter number for which mml data is requested
     * @apiParam {String} engineCenterID The Engine Center for which mml data is requested
     * @apiParam {String} engineGroupId The Engine Group Id for which mml data is requested
     * @apiParam {String} planMarket Plan Market for which mml data is requested (0 - COMMERCIAL, 1 - AFTERMARKET)
     * @apiParam {String} planMarket Plan Market for which mml data is requested (0 - INDUCTION, 1 - SHIPMENT, 2 - REVENUE)
     * @apiSuccess {Object} mmlDetails List of MML Details Objects
     * @apiSuccess {String} mmlDetails[0].engineId The Engine Id
     * @apiSuccess {String} mmlDetails[0].engineCenterName The Engine Center Name
     * @apiSuccess {String} mmlDetails[0].engineGroupId The Engine Group Id
     * @apiSuccess {String} mmlDetails[0].engineGroupName The Engine Group Name
     * @apiSuccess {String} mmlDetails[0].engineCategory The Engine Category
     * @apiSuccess {String} mmlDetails[0].engineSerialNumber The Engine Serial Number
     * @apiSuccess {String} mmlDetails[0].customerName The Customer Name
     * @apiSuccess {String} mmlDetails[0].planInductionDate The Plan Induction Date
     * @apiSuccess {String} mmlDetails[0].actualReceipentDate The Actual Recipient Date
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/    
    @PostMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<MmlResponse> getMmlData( @Valid @RequestBody final MmlRequest mmlRequest) {
        
        MmlResponse response = mmlService.getMmlInfo(mmlRequest);
        return ResponseEntity.ok(response);
    }
    
    /**
     * @api {get} /v1/mml/plan Get MML Plan Data
     * @apiExample {curl} Example usage: 
     *      curl --request POST
     *           --url http://localhost:8080/v1/mml/plan
     *           --header 'Authorization: Bearer [jwt]'
     *           --data '{
                            "year" : 2019,
                            "monthQtr": 2,
                            "engineCenterId" : "EC1",
                            "engineGroupId" : "EG754",
                            "planMarket" : 0,
                            "planType" : 1,
                            "period" : "quarterly"
                        }'         
     * @apiName getMmlPlanData
     * @apiDescription Returns MML Plan data for given request parameters
     * @apiGroup MML
     * @apiParam {String} year The year for which mml plan data is requested
     * @apiParam {String} monthQtr The month number or quarter number for which mml plan data is requested
     * @apiParam {String} engineCenterID The Engine Center for which mml plan data is requested
     * @apiParam {String} engineGroupId The Engine Group Id for which mml plan data is requested
     * @apiParam {String} planMarket Plan Market for which mml plan data is requested (0 - COMMERCIAL, 1 - AFTERMARKET)
     * @apiParam {String} planMarket Plan Market for which mml plan data is requested (0 - INDUCTION, 1 - SHIPMENT, 2 - REVENUE)
     * @apiSuccess {Object} mmlPlanDetails List of MML Plan Details Objects
     * @apiSuccess {String} mmlPlanDetails[0].engineId The Engine Id
     * @apiSuccess {String} mmlPlanDetails[0].engineCenterName The Engine Center Name
     * @apiSuccess {String} mmlPlanDetails[0].engineGroupId The Engine Group Id
     * @apiSuccess {String} mmlPlanDetails[0].engineGroupName The Engine Group Name
     * @apiSuccess {String} mmlPlanDetails[0].engineCategory The Engine Category
     * @apiSuccess {String} mmlPlanDetails[0].engineSerialNumber The Engine Serial Number
     * @apiSuccess {String} mmlPlanDetails[0].customerName The Customer Name
     * @apiSuccess {String} mmlPlanDetails[0].planInductionDate The Plan Induction Date
     * @apiSuccess {String} mmlPlanDetails[0].actualReceipentDate The Actual Recipient Date
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/    
    @PostMapping(path = "/plan", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<MmlResponse> getMmlPlanData(@Valid
                                                      @RequestBody
                                                      final MmlPlanRequest mmlPlanRequest) {
        MmlResponse response = mmlService.getMmlPlanInfo(mmlPlanRequest);
        return ResponseEntity.ok(response);
    }
    
    /**
     * @api {get} /v1/mml/update Update MML Data
     * @apiExample {curl} Example usage: 
     *      curl --request POST
     *           --url http://localhost:8080/v1/mml/update
     *           --header 'Authorization: Bearer [jwt]'
     *           --data '{
                            "year" : 2019,
                            "monthQtr": 2,
                            "engineCenterId" : "EC1",
                            "engineGroupId" : "EG754",
                            "planMarket" : 0,
                            "planType" : 1,
                            "period" : "quarterly"
                        }'         
     * @apiName updateMmlData
     * @apiDescription Update MML Data for given request parameters
     * @apiGroup MML
     * @apiParam {String} year The year for which mml data is updated
     * @apiParam {String} monthQtr The month number or quarter number for which mml data is updated
     * @apiParam {String} engineCenterID The Engine Center for which mml data is updated
     * @apiParam {String} engineGroupId The Engine Group Id for which mml data is updated
     * @apiParam {String} planMarket Plan Market for which mml data is updated (0 - COMMERCIAL, 1 - AFTERMARKET)
     * @apiParam {String} planMarket Plan Market for which mml data is updated (0 - INDUCTION, 1 - SHIPMENT, 2 - REVENUE)
     * @apiParam {Object} mmlDetails List of MML Details Objects that need to be in MML data. Plan data is updated automatically.
     * @apiParam {String} mmlDetails[0].engineId The Engine Id
     * @apiParam {String} mmlDetails[0].engineCenterName The Engine Center Name
     * @apiParam {String} mmlDetails[0].engineGroupId The Engine Group Id
     * @apiParam {String} mmlDetails[0].engineGroupName The Engine Group Name
     * @apiParam {String} mmlDetails[0].engineCategory The Engine Category
     * @apiParam {String} mmlDetails[0].engineSerialNumber The Engine Serial Number
     * @apiParam {String} mmlDetails[0].customerName The Customer Name
     * @apiParam {String} mmlDetails[0].planInductionDate The Plan Induction Date
     * @apiParam {String} mmlDetails[0].actualReceipentDate The Actual Recipient Date
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/    
    @PostMapping(path = "/update", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> updateMmlData(@Valid
                                              @RequestBody
                                              final MmlUpdateRequest mmlUpdateRequest,
                                              @Parameter(description = "Copy to monthly", required = false)
                                              @RequestParam(name = "copy-to-monthly", required = false)
                                              boolean copyToMonthly) {
        mmlService.update(mmlUpdateRequest, copyToMonthly);
        return ResponseEntity.ok().build();
    }
    
    /**
     * @api {get} /v1/mml/dates/monthly Get months dates
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/mml/dates/monthly
     *           --header 'Authorization: Bearer [jwt]'
     * @apiName getMonths
     * @apiDescription Get 14 months from past to 14 months in future from when the service is invoked
     * @apiGroup MML
     * @apiSuccess {String} month The month number.
     * @apiSuccess {String} monthName The month name.
     * @apiSuccess {String} year The year for the month returned.
     **/    
    @GetMapping(path = "/dates/monthly", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<MonthlyDatesResponse>> getMonthlyDates() {
        List<MonthlyDatesResponse> response = mmlService.getMonthlyDates();
        return ResponseEntity.ok(response);
    }
    
    /**
     * @api {get} /v1/mml/dates/quarterly Get quarters
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/mml/dates/quarterly
     *           --header 'Authorization: Bearer [jwt]'
     * @apiName getMonths
     * @apiDescription Get quarters data for 14 months from past to 14 months in future from when the service is invoked
     * @apiGroup MML
     * @apiSuccess {String} quarter The quarter number (1,2,3,4)
     * @apiSuccess {String} quarterName The quarter name(Q1, Q2, Q3, Q4).
     * @apiSuccess {String} year The year for the quarter is returned.
     **/    
    @GetMapping(path = "/dates/quarterly", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<QuarterlyDatesResponse>> getQuarterlyDates() {
        List<QuarterlyDatesResponse> response = mmlService.getQuarterlyDates();
        return ResponseEntity.ok(response);
    }
}
