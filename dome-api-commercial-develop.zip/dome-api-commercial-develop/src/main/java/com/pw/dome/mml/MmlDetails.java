package com.pw.dome.mml;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MmlDetails {
    private LocalDate actualReceipentDate;
    
    private String customerName;

    private String engineCategory;
    
    private String engineCenterName;
    
    private String engineGroupId;
    
    private String engineGroupName;
    
    private Integer engineId;
    
    private String engineSerialNumber;
    
    private Integer month;
    
    private LocalDate planInductionDate;
}
