package com.pw.dome.engine.networkmanagement.excel;

import java.util.List;

import lombok.Builder;


@Builder(toBuilder = true)
record NetWorkManagementRequest (
		List<String> contractTypes,
		List<String> customers,
		List<String> engineCenters,
		List<String> engineTypes) {}
