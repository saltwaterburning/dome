package com.pw.dome.engine.odin.reports;

import static com.pw.dome.engine.odin.reports.Consts.SQL.ODIN_REPORT;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pw.dome.engine.odin.OdinBaseDTO;
import com.pw.dome.engine.odin.OdinEntity;

@Repository
public interface OdinReportsRepository extends JpaRepository<OdinEntity, Integer> {

    @Query(value = ODIN_REPORT)
	List<OdinBaseDTO> getOdinReport(@Param("ignoreContractType")boolean ignoreContractType,
			                        @Param("contractTypes")List<String> contractTypes,
			                        @Param("engineTypeIds")List<String> engTypeId,
			                        @Param("fromDate")LocalDate fromDate,
			                        @Param("toDate")LocalDate toDate);
    
    List<OdinEntity> findByEngineId(final int engineId);
}
