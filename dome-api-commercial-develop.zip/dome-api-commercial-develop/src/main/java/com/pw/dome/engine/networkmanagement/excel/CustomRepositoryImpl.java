package com.pw.dome.engine.networkmanagement.excel;

import static com.pw.dome.engine.networkmanagement.excel.Consts.SQL.NETWORK_MANAGEMENT;
import static com.pw.dome.engine.networkmanagement.excel.Consts.SQL.REMOVED_NETWORK_MANAGEMENT;

import java.util.List;

import jakarta.persistence.EntityManager;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.pw.dome.util.hibernate.ValidatingTupleTransformer;

class CustomRepositoryImpl implements CustomRepository {
	@Autowired
    private EntityManager entityManager;

	@Override
	@SuppressWarnings("unchecked")
	public List<NetworkManagement> getNetworkManagementData(
			List<String> engCenters, List<String> engTypes,
			boolean ignoreCustId, List<String> custIds,
			boolean ignoreContractType, List<String> contractTypes) {
		return entityManager.createQuery(NETWORK_MANAGEMENT)
				.setParameter("engCenters", engCenters)
				.setParameter("engTypes", engTypes)
				.setParameter("ignoreCustId", ignoreCustId)
				.setParameter("custIds", custIds)
				.setParameter("ignoreContractType", ignoreContractType)
				.setParameter("contractTypes", contractTypes)
				.unwrap(Query.class)
				.setTupleTransformer(new ValidatingTupleTransformer<NetworkManagement>(NetworkManagement.class))
				.getResultList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<NetworkManagement> getRemovedNetworkManagementData(List<String> engTypes) {
		return entityManager.createQuery(REMOVED_NETWORK_MANAGEMENT)
				.setParameter("engTypes", engTypes)
				.unwrap(Query.class)
				.setTupleTransformer(new ValidatingTupleTransformer<NetworkManagement>(NetworkManagement.class))
				.getResultList();
	}
}
