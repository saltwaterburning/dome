package com.pw.dome.customer;

import java.util.List;

/**
 * @author John De Lello
 */
public interface CustomerService {

	List<CustomerEntity> findAllOrderByName();
	
	List<CustomerEntity> findActiveCustomersOrderByName();
	
	CustomerEntity getCustomerByID(final String customerID);

}
