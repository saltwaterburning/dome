package com.pw.dome.external.mro.collab.services.comments;

import com.pw.dome.common.oas.BaseRESTfulResource;

//@RestController
//@RequestMapping("/v1/mro-collab-test")
//@Tag(name = BaseRESTfulResource.Tags.MRO)
//@Validated
class MroCommentsTestController extends BaseRESTfulResource {
//	@Autowired
//	private MroCommentsService commentsSvc;
//
//	@PatchMapping(path = {"/delete-all-comments-from-mro", "/delete-all-comments-from-mro/{count}"}, produces = TEXT_HTML)
//	public ResponseEntity<String> mroDeleteComments () {
//		int cnt = commentsSvc.doDeleteMroComments();
//		return ResponseEntity.ok("Deleted " + cnt + " comments from MRO.");
//	}
//
//	@PatchMapping(path = {"/push-all-comments-to-mro", "/push-all-comments-to-mro/{count}"}, produces = TEXT_HTML)
//	public ResponseEntity<String> mroPushComments (
//			@PathVariable(name = "engine-id", required = false) Integer count) {
//		String msg = commentsSvc.doPushMroComments(count);
//		return ResponseEntity.ok(msg);
//	}
}
