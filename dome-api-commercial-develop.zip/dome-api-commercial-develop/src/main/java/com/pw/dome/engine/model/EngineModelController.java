package com.pw.dome.engine.model;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.user.UserProfile;


@RestController()
@RequestMapping("/v1/engines/models")
public class EngineModelController {
	@Autowired
	private EngineModelService engineModelService;

	/**
	 * @api {get} /v1/engines/models/:engineCenterID Get All Models
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/engines/models/EC1
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName getEngineModels
     * @apiGroup Engine Models
     * @apiParam {String} engineCenterID The engine center ID to get engine models for
     * @apiDescription Returns a list of engine models that are available for the current user and engine center 
     * @apiSuccess {Object[]} engineModels An array engine models 
     * @apiSuccess {Number} engineModels.engineModelID The engine model ID
     * @apiSuccess {Number} engineModels.engineGroupID The engine group ID
     * @apiSuccess {String} engineModels.name The engine model name
     * @apiUse GetEngineModelsSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/
    @GetMapping(path = "/{engineCenterID}", produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<EngineModelListResponse> getEngineModels(@AuthenticationPrincipal UserProfile userProfile,
    	                                                           @PathVariable(name = "engineCenterID") String engineCenterID){
    	
		List<EngineModelEntity> models =  engineModelService.getEngineModels(userProfile, engineCenterID);
    	
    	return ResponseEntity.ok(EngineModelListResponse.builder().engineModels(models).build());
    }

	/**
	 * @api {get} /v1/engines/models/:engineCenterID/:engineGroupID Get Models for Engine Group
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/engines/models/EC1/EG875
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName getEnginelModelsByEngineGroup
     * @apiGroup Engine Models
     * @apiParam {String} engineCenterID The engine center ID to get engine models for
     * @apiParam {String} engineGroupID The engine group ID to get engine models for
     * @apiDescription Returns a list of engine models available to the current user for the specified engine center and engine group 
     * @apiSuccess {Object[]} engineModels An array engine models 
     * @apiSuccess {Number} engineModels.engineModelID The engine model ID
     * @apiSuccess {Number} engineModels.engineGroupID The engine group ID
     * @apiSuccess {String} engineModels.name The engine model name
     * @apiUse GetEngineModelsSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/
    @GetMapping(path = "/{engineCenterID}/{engineGroupID}", produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<EngineModelListResponse> getEnginelModelsByEngineGroup(@AuthenticationPrincipal UserProfile userProfile,
    		                                                                     @PathVariable(name = "engineCenterID") String engineCenterID,    		
   		                                                                         @PathVariable(name = "engineGroupID") String engineGroupID){
    	
		List<EngineModelEntity> models =  engineModelService.getEngineModels(userProfile, engineCenterID, engineGroupID);
    	
    	return ResponseEntity.ok(EngineModelListResponse.builder().engineModels(models).build());
    }    

}
