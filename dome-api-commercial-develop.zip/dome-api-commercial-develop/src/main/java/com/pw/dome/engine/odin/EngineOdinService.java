package com.pw.dome.engine.odin;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.calendar.slots.SlotService;
import com.pw.dome.engine.EngineEntity;
import com.pw.dome.engine.EngineRepository;
import com.pw.dome.engine.asset.EngineAssetEntity;
import com.pw.dome.engine.asset.EngineAssetRepository;
import com.pw.dome.engine.events.EngineEventEntity;
import com.pw.dome.engine.events.EngineEventRepository;
import com.pw.dome.engine.odin.history.OdinHistoryEntity;
import com.pw.dome.engine.odin.history.OdinHistoryRepository;
import com.pw.dome.engine.tracking.EngineTrackingEntity;
import com.pw.dome.engine.tracking.EngineTrackingRepository;
import com.pw.dome.engine.type.EngineTypeEntity;
import com.pw.dome.engine.type.EngineTypeRepository;
import com.pw.dome.enginecenter.EngineCenterEntity;
import com.pw.dome.enginecenter.EngineCenterRepository;
import com.pw.dome.exception.NotFoundException;
import com.pw.dome.user.UserProfile;

/**
 * @author John De Lello
 */
// @Slf4j
@Service
public class EngineOdinService {
	@Autowired
	private EngineAssetRepository engAssetRepo;
	@Autowired
	private EngineCenterRepository engineCenterRepo;
	@Autowired
	private EngineEventRepository engineEventRepo;
	@Autowired
	private EngineOdinRepository engineOdinRepo;
	@Autowired
	private EngineRepository engineRepo;
	@Autowired
	private EngineTrackingRepository engineTrackingRepo;
	@Autowired
	private EngineTypeRepository engTypeRepo;
	@Autowired
	private OdinHistoryRepository odinHistoryRepo;
	@Autowired
	private SlotService slotSvc;

	@Transactional(readOnly = true)
	public OdinDTO getEngineRemovedDetails(final OdinDetailsRequest request, UserProfile userProfile) {
		EngineCenterEntity engCenter = null;
		EngineEventEntity engEvent = null;
		EngineTrackingEntity engTracking = null;
		OdinEntity engineOdin = null;
		List<OdinHistoryEntity> odinHistories = null;
		Boolean eData = null;

		EngineAssetEntity engAsset = null;
		EngineEntity engine = null;

		final String msg2 = "Unable to find matching Engine entity. id: " + request.getEngineId();
		if (nonNull(request.getEngineId())) {
			String engTypeId;
			engine = engineRepo.findById(request.getEngineId()).orElseThrow(() -> new NotFoundException(msg2));

			if (nonNull(engTypeId = engine.getEngineTypeId())) {
				EngineTypeEntity et = engTypeRepo.findById(engTypeId).orElse(new EngineTypeEntity());
				if (et.isActive()) {
					eData = et.isEData();
				}
			}

			final String msg3 = "Unable to find matching EngineTracking entity. id: " + request.getEngineId();
			engTracking = engineTrackingRepo.findById(request.getEngineId())
					.orElseThrow(() -> new NotFoundException(msg3));
		}

		final String msg1 = "Unable to find matching EngineAssetEntity entity. id: " + request.getEngineAssetId();
		if (nonNull(request.getEngineAssetId())) {
			engAsset = engAssetRepo.findById(request.getEngineAssetId()).orElseThrow(() -> new NotFoundException(msg1));
		}

		if (request.getEventId() != null) {
			engEvent = engineEventRepo.findByPkEsnAndPkEventId(request.getEsn(), request.getEventId());
			// Create ODIN record if missing?
			odinHistories = odinHistoryRepo.findByEsnAndEventIdOrderByPrelimInductionDateAsc(request.getEsn(),
					request.getEventId());
		}

		if (request.getOdinId() != null) {
			engineOdin = engineOdinRepo.findById(request.getOdinId())
					.orElseThrow(() -> new NotFoundException("Unable to find matching Odin entity."));
			String ecId;
			if ((ecId = engineOdin.getMaintenanceCenter()) != null) {
				engCenter = engineCenterRepo.findById(ecId).orElse(null);
			}
		}

		SlotEntity slot = null;
		if (engEvent != null && engEvent.getSlotId() != null) {
			slot = slotSvc.getSlotByID(userProfile, engEvent.getSlotId());
		}

		// For actual implementation code see DataMapperImpl.
		OdinDTO odin = DataMapper.INSTANCE.toOdinDTO(eData, engAsset, engine, engCenter, engEvent, engTracking,
				engineOdin, slot, odinHistories);

		if (isNull(odin.getEsn())) { // EngineAssetEntity isn't always present.
			odin.setEsn(request.getEsn()); // Prefer engine?
		}

		if (isNull(odin.getEventId())) { // Manual engine
			if (nonNull(engineOdin) && nonNull(engineOdin.getEventId())) {
				odin.setEventId(engineOdin.getEventId());
			}
		}

		return odin;
	}

	/**
	 * Save the details from the induction Planning screen. Note that
	 * {@code EngineEntity} and {@code EngineRemoved} data is read-only.
	 * 
	 * @param request
	 * @param userProfile
	 * @return
	 */
	@Transactional
	public OdinDTO saveEngineOdinDetails(final OdinDTO request, final UserProfile userProfile) {

//    saveEngineTracking(request);
		saveOdin(request);

		EngineAssetEntity engAsset = null;
		if (nonNull(request.getAssetId())) {
			engAsset = engAssetRepo.findById(request.getAssetId())
					.orElseThrow(() -> new NotFoundException("Unable to find matching EngineAssetEntity entity."));

			if (engAsset.isDisabled() != request.isDisabled()) {
				engAsset.setDisabled(request.isDisabled());
				engAssetRepo.save(engAsset);
			}
		}

		if (nonNull(request.getEngineId())) {
			EngineEntity engine = engineRepo.findById(request.getEngineId()).orElse(new EngineEntity());
			DataMapper.INSTANCE.mutateEngine(request, engine);
			engineRepo.save(engine);

			if (nonNull(request.getRemovalActualDate())) {
				EngineTrackingEntity engTracking = engineTrackingRepo.findById(request.getEngineId())
						.orElse(new EngineTrackingEntity());
				engTracking.setEngtrackRemoval(request.getRemovalActualDate());
				engineTrackingRepo.save(engTracking);
			}
		}

		OdinDetailsRequest response = DataMapper.INSTANCE.toDetailsRequest(engAsset, request);

		return getEngineRemovedDetails(response, userProfile);
	}

	private OdinEntity saveOdin(OdinDTO request) {
		OdinEntity entity;
		Integer eventId = request.getEventId();
		Integer odinId;
		if ((odinId = request.getOdinId()) != null) {
			entity = engineOdinRepo.findById(odinId).orElseThrow(
					() -> new NotFoundException("ODIN ID [" + odinId + "] was not found. Unable to perform update."));

//	  } else if ((eventId = request.getEventId()) != null) {
//		  List<OdinEntity> list = engineOdinRepo.getEngineOdinDetails(request.getEsn(), eventId);
//		  if (list.isEmpty()) {
//			  entity = new OdinEntity();
//		  } else {
//			  entity = list.get(0);
//		  }

		} else {
			entity = OdinEntity.builder().build();
		}

		boolean isNew = entity.isNew() || request.getOdinId() == null;

		EngineTrackingEntity engTracking = null;
		if (nonNull(request.getEngineId())) {
			engTracking = engineTrackingRepo.findById(request.getEngineId())
					.orElse(new EngineTrackingEntity());

			DataMapper.INSTANCE.mutateEngineTrackingEntity(request, engTracking);

			engTracking = engineTrackingRepo.save(engTracking);
		}


		if (!BooleanUtils.isTrue(request.getEData()) && nonNull(eventId)) {
			entity.setEventId(eventId);
		}

		DataMapper.INSTANCE.mutateOdinEntity(request, entity);
		setCurrentLocation(engTracking, entity, request);
		entity = engineOdinRepo.saveAndFlush(entity);

		if (isNew) {
			request.setOdinId(entity.getId());
		}

		return entity;
	}

	@Transactional
	public void setCurentLocation(LocalDate actualReceiptDate, String esn, Integer engineId, Integer eventId) {
		OdinEntity odin;
		
		List<OdinEntity> entitities = engineOdinRepo.findByEsnAndEngineIdAndEventId(esn, engineId, eventId);
		if (entitities.isEmpty()) {
			odin = new OdinEntity();
			odin.setEsn(esn);
			odin.setEngineId(engineId);
			odin.setEventId(eventId);
		} else {
			int index = entitities.size() - 1;
			odin = entitities.get(index);
		}

		if (nonNull(actualReceiptDate)) {
			odin.setCurrentLocation(Consts.CURRENT_LOCATION_DAT);
		} else if (nonNull(odin.getActualRecEbuDate())) {
			String location = odin.getEbuShop();
			odin.setCurrentLocation(location);
		} else {
			odin.setCurrentLocation(null);
		}

		engineOdinRepo.save(odin);
	}

	private void setCurrentLocation(EngineTrackingEntity engTracking, //
			OdinEntity entity, //
			OdinDTO request) {

		if (nonNull(request.getActualRecEbuDate())) {
			String location = entity.getEbuShop();
			entity.setCurrentLocation(location);
		} else if (isNull(engTracking) || isNull(engTracking.getEngtrackRecDate())) {
			String location = request.getCurrentLocation();
			entity.setCurrentLocation(location);
		}

		if (nonNull(request.getActualRecEcDate())) {
			entity.setCurrentLocation(Consts.CURRENT_LOCATION_DAT);
		} else if (nonNull(request.getActualRecEbuDate())) {
			String location = entity.getEbuShop();
			entity.setCurrentLocation(location);
		} else {
			String location = request.getCurrentLocation();
			entity.setCurrentLocation(location);
		}
	}
}
