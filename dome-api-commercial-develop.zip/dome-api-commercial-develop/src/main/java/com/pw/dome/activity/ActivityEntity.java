package com.pw.dome.activity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.pw.dome.jpa.AbstractEntityWithGeneratedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_ACTIVITY")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ActivityEntity extends AbstractEntityWithGeneratedId<Long> {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOME_ACTIVITY_SEQ")
    @SequenceGenerator(sequenceName = "DOME_ACTIVITY_SEQ", allocationSize = 1, name = "DOME_ACTIVITY_SEQ")
    @Column(name="ACTIVITY_TRACKNO")
    private Long activityId;

    @NotNull
    @Column(name="ACTIVITY_ITEM")
    @Size(min=0, max=50)
    private String item;
    
    @NotNull
    @Column(name="ACTIVITY_DATE")
    private LocalDateTime activityDate;

    @Column(name="ACTIVITY_EC_ID")
    @Size(min=0, max=10)
    private String engineCenterId;

    @Column(name="ACTIVITY_ENG_TYPE")
    @Size(min=0, max=10)
    private String engineType;
    
    @Column(name="ACTIVITY_ENG_GROUP")
    @Size(min=0, max=10)
    private String engineGroup;

    @Column(name="ACTIVITY_ENG_MODEL")
    @Size(min=0, max=10)
    private String engineModel;
    
    @Column(name="ACTIVITY_ENG_MODULE")
    @Size(min=0, max=10)
    private String engineModule;
    
    @Column(name="ACTIVITY_ENG_SN")
    @Size(min=0, max=20)
    private String engineSerialNumber;
    
    @Column(name="ACTIVITY_CUST_ID")
    @Size(min=0, max=20)
    private String customerID;
    
    @NotNull
    @Column(name="ACTIVITY_USER")
    private String userEmail;

    @NotNull
    @Column(name="ACTIVITY_TYPE")
    @Size(min=0, max=10)
    private String type;
    
    @NotNull
    @Column(name="ACTIVITY_DESCRIPTION")
    @Size(min=0, max=1000)
    private String description;
    
    @Override
    public Long getId() {
        return activityId;
    }
}
