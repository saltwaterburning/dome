package com.pw.dome.aop.jpa;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AssignableTypeFilter;

import com.pw.dome.aop.AfterMethodsAdvise;
import com.pw.dome.aop.BeforeMethodsAdvise;

/**
 * For each repository find advise match to JPA methods
 * 
 */
public class AdviseToRepositoryValidator {

	public AdviseToRepositoryValidator() throws Exception {
		final boolean useDefaultFilters = false;

		ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(useDefaultFilters);
		List<Class<?>> classList = new ArrayList<>();

		InterfaceTypeFilter typeFilter = new InterfaceTypeFilter(AfterMethodsAdvise.class);
		scanner.addIncludeFilter(typeFilter);

		for (BeanDefinition bd : scanner.findCandidateComponents("com.pw.dome")) {
			String name = bd.getBeanClassName();
			System.out.println("AfterMethodsAdvise->" + name);
			Class<?> clazz = Class.forName(name);
			classList.add(clazz);
		}

		scanner.resetFilters(useDefaultFilters);
		typeFilter = new InterfaceTypeFilter(AfterMethodsAdvise.class);
		scanner.addIncludeFilter(typeFilter);

		for (@SuppressWarnings("unused") Class<?> clazz : classList) {
			typeFilter = new InterfaceTypeFilter(AfterMethodsAdvise.class);
			scanner.addIncludeFilter(typeFilter);
//			scanner.addIncludeFilter(new AssignableTypeFilter(clazz));
		}

		for (BeanDefinition bd : scanner.findCandidateComponents("com.pw.dome")) {
			System.out.println(bd.getBeanClassName());
		}

		classList.clear();
		scanner.resetFilters(useDefaultFilters);
		scanner.addIncludeFilter(new AssignableTypeFilter(BeforeMethodsAdvise.class));

		for (BeanDefinition bd : scanner.findCandidateComponents("com.pw.dome")) {
			String name = bd.getBeanClassName();
			System.out.println("BeforeMethodsAdvise->" + name);
			Class<?> clazz = Class.forName(name);
			classList.add(clazz);
		}

		scanner.resetFilters(useDefaultFilters);

		for (Class<?> clazz : classList) {
			scanner.addIncludeFilter(new AssignableTypeFilter(clazz));
			for (BeanDefinition bd : scanner.findCandidateComponents("com.pw.dome")) {
				System.out.println(bd.getBeanClassName());
			}
		}
	}

	public static void main(String[] args) throws Exception {
		new AdviseToRepositoryValidator();
	}
}
