package com.pw.dome.external.workscope;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
class WstDbRepo {

    private final JdbcTemplate jdbcTemplate;

    public WstDbRepo(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

	String getOdinSvClassification(String esn, Integer eventId) {
		return jdbcTemplate.queryForObject(
		        "select sv_class from dome_odin where esn = ? and event_id = ? and rownum = 1",
		        new RowMapper<String>() {

		        	@Override
		        	public String mapRow(ResultSet rs, int rowNum) throws SQLException {
		        		return rs.getString("sv_class");
		        	}
		        }, esn, eventId);
	}
}