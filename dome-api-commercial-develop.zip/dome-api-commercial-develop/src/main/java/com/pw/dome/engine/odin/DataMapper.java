package com.pw.dome.engine.odin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.mapstruct.AfterMapping;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.engine.EngineEntity;
import com.pw.dome.engine.asset.EngineAssetEntity;
import com.pw.dome.engine.events.EngineEventEntity;
import com.pw.dome.engine.odin.history.OdinHistoryEntity;
import com.pw.dome.engine.tracking.EngineTrackingEntity;
import com.pw.dome.enginecenter.EngineCenterEntity;

import lombok.Builder;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
  DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

  @Mapping(target = "assetID", ignore = true)
  @Mapping(target = "category", ignore = true)
  @Mapping(target = "customer", ignore = true)
  @Mapping(target = "customerID", ignore = true)
  @Mapping(target = "engineID", ignore = true)
  @Mapping(target = "engineTrackingEntity", ignore = true)
  @Mapping(target = "engineTypeId", ignore = true)
  @Mapping(target = "gate1", ignore = true)
  @Mapping(target = "gate1Plan", ignore = true)
  @Mapping(target = "groupID", ignore = true)
  @Mapping(target = "logEmail", ignore = true)
  @Mapping(target = "manualEngine", ignore = true)
  @Mapping(target = "modelID", ignore = true)
  @Mapping(target = "module", ignore = true)
  @Mapping(target = "moduleID", ignore = true)
  @Mapping(target = "notifyNum", ignore = true)
  @Mapping(target = "parentEsn", ignore = true)
  @Mapping(target = "priority", ignore = true)
  @Mapping(target = "purchaseOrder", ignore = true)
  @Mapping(target = "revenue", ignore = true)
  @Mapping(target = "salesOrderNum", ignore = true)
  @Mapping(target = "salesOrderType", ignore = true)
  @Mapping(target = "shipmentType", ignore = true)
  @Mapping(target = "shopVisitNum", ignore = true)
  @Mapping(target = "slot", ignore = true)
  @Mapping(target = "slotID", ignore = true)
  @Mapping(target = "subVisitType", ignore = true)
  @Mapping(target = "updateDate", ignore = true)
  @Mapping(target = "user", ignore = true)
  // TODO refactor
  EngineEntity mutateEngine(OdinDTO dto, @MappingTarget EngineEntity entity);

  /**
   * Invokes {@code OdinHistoryEntity#setPrelimInductiondate(LocalDate)} at end of
   * {@code toOdinDTO()} method. <br>
   * <b> Note:</b> MapStruct prefers Lombok builder when {@code @Builder} annotation is used. </br>
   * 
   * @param odinHistoryEntities
   * @param odin
   * 
   * @see Builder
   * @see MappingTarget
   */
  @AfterMapping
  @SuppressWarnings({ "rawtypes", "unchecked" })
  static void getPreliminaryInductionDates(List<OdinHistoryEntity> odinHistoryEntities,
      @MappingTarget OdinDTO.OdinDTOBuilder odin) {
    if (!CollectionUtils.isEmpty(odinHistoryEntities)) {
      // Sort by insertion order..
      Collections.sort(odinHistoryEntities,
          Comparator.comparingInt(OdinHistoryEntity::getOdinHistId));

      PreliminaryIndDateReason reason = null;
      List<PreliminaryIndDateReason> preliminaryInductionDates = new ArrayList<>();
      for (OdinHistoryEntity odinHistoryEntity : odinHistoryEntities) {
        if (odinHistoryEntity.getPrelimInductionDate() != null) {
          reason = PreliminaryIndDateReason.builder()
              .changeReason(null == odinHistoryEntity.getChangeReason() ? ""
                  : odinHistoryEntity.getChangeReason())
              .inductionDate(odinHistoryEntity.getPrelimInductionDate()).build();
          preliminaryInductionDates.add(reason);
        }
      }

      if (!CollectionUtils.isEmpty(preliminaryInductionDates)) {
        odin.preliminaryInductionDates(preliminaryInductionDates);
      }
    }
  }

  /**
   * The @Mapper class annotation is overridden since only a small subset of the EngineTrackingEntity are used.
   * 
   * @param request
   * @param entity
   * @return
   * 
   * @see BeanMapping
   */
  @BeanMapping(unmappedTargetPolicy = ReportingPolicy.IGNORE)
  @Mapping(target = "engtrackIndDate", source = "committedInductionDate")
  @Mapping(target = "engtrackPlanRecDate", source = "projRecEcDate")
  @Mapping(target = "engtrackRecDate", source = "actualRecEcDate")
  @Mapping(target = "engtrackRemoval", source = "removalActualDate")
  EngineTrackingEntity mutateEngineTrackingEntity(OdinDTO request, @MappingTarget EngineTrackingEntity entity);

  @Mapping(target = "assetId", source = "engineAsset.engineAssetID")
  @Mapping(target = "esn", expression =  "java((java.util.Objects.nonNull(engineEvent) && java.util.Objects.nonNull(engineEvent.getPk()) ? engineEvent.getPk().getEsn() : java.util.Objects.nonNull(engine) ? engine.getEsn() : java.util.Objects.nonNull(engineAsset) ? engineAsset.getEsn() : null))")
  @Mapping(target = "engineId", source = "engine.engineID")
  @Mapping(target = "operatorName", expression = "java((java.util.Objects.nonNull(engineAsset) && java.util.Objects.nonNull(engineAsset.getOperator())) ? engineAsset.getOperator().getName() : (java.util.Objects.nonNull(engine) && java.util.Objects.nonNull(engine.getCustomer())) ? engine.getCustomer().getName() : null )")
  @Mapping(target = "thrust", source = "engineAsset.thrust")
// source = "engine.customer.name", 
  @Mapping(target = "maintenanceCenterName", source = "engineCenter.name")

  @Mapping(target = "engineActualReceiptDate", source = "engineTracking.engtrackActualReceivingDate")
  @Mapping(target = "removedEngineId", source = "engineEvent.pk.eventId")
  @Mapping(target = "removalActualDate", expression = "java(java.util.Objects.nonNull(engineEvent) ? engineEvent.getRemovalDate() : java.util.Objects.nonNull(engineTracking) ? engineTracking.getEngtrackRemoval() : null)")

  @Mapping(target = "removalRecordedDate", source = "engineEvent.removalDate")
  @Mapping(target = "eventId", source = "engineEvent.pk.eventId")
  @Mapping(target = "removalReason", source = "engine.removalReason")

  @Mapping(target = "actualRecEcDate", source = "engineTracking.engtrackRecDate")
  @Mapping(target = "committedInductionDate", source = "engineTracking.engtrackIndDate")
  @Mapping(target = "preliminaryInductionDate", source = "engineTracking.engtrackPlanIndDate")
  @Mapping(target = "projRecEcDate", source = "engineTracking.engtrackPlanRecDate")
  @Mapping(target = "workOrder", source = "engineTracking.engtrackWorkOrder")
  @Mapping(target = "opportunity", source = "engineTracking.engtrackIsopportunity")

  @Mapping(target = "llpReplacementType", source = "odin.llpReplaceType")
  @Mapping(target = "svClassification", source = "odin.svClass")
  @Mapping(target = "upgradeEligibility", source = "odin.upgradeEligible")

  // Note: preliminaryInductionDates added by @AfterMapping via getPreliminaryInductionDates().
  @Mapping(target = "preliminaryInductionDates", ignore = true)
  @Mapping(target = "testAtReceipt", source = "odin.testAtReceipt")
  @Mapping(target = "changeReason", ignore = true)
  @Mapping(target = "warranty", source = "odin.warranty")
  @Mapping(target = "slotDate", source = "slot.caldate")
  @Mapping(target = "slotUpdatedDate", source = "engine.updateDate")
  @Mapping(target = "slotUpdatedUserFirstName", source = "engine.user.firstName")
  @Mapping(target = "slotUpdatedUserLastName", source = "engine.user.lastName")
  OdinDTO toOdinDTO(Boolean eData, EngineAssetEntity engineAsset, EngineEntity engine, EngineCenterEntity engineCenter,
      EngineEventEntity engineEvent,
      EngineTrackingEntity engineTracking, OdinEntity odin, SlotEntity slot,
      List<OdinHistoryEntity> odinHistoryEntities);

  @Mapping(target = "odinId", ignore = true)
  @Mapping(target = "llpReplaceType", source = "llpReplacementType")
  @Mapping(target = "svClass", source = "svClassification")
  @Mapping(target = "upgradeEligible", source = "upgradeEligibility")
  void mutateOdinEntity(OdinDTO engineOdinDTO, @MappingTarget OdinEntity entity);

  @Mapping(target = "engineAssetId", source = "engAsset.engineAssetID")
  @Mapping(target = "removedEngineId", source = "request.removedEngineId")
  @Mapping(target = "esn", source = "request.esn")
  @Mapping(target = "eventId", source = "request.eventId")
  OdinDetailsRequest toDetailsRequest(EngineAssetEntity engAsset, OdinDTO request);
  
//  OdinHistoryEntity toOdinHistory(final OdinDTO request, final UserProfile userProfile);
}
