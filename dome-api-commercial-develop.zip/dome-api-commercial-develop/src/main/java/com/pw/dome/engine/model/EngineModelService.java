package com.pw.dome.engine.model;

import java.util.List;

import com.pw.dome.user.UserProfile;

/**
 * @author John De Lello
 */
public interface EngineModelService {
	List<EngineModelEntity> getEngineModels(final UserProfile userProfile, final String engineCenterID);
	List<EngineModelEntity> getEngineModels(final UserProfile userProfile, final String engineCenterID, final String engineGroupID);
}
