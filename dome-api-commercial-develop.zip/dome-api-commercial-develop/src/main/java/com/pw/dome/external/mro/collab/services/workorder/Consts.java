package com.pw.dome.external.mro.collab.services.workorder;

import static com.pw.dome.external.mro.collab.services.workorder.DTO_FQCN.DTO_NAME;

interface Consts {
  String ESN_NO_MATCH = "{\r\n"
      + "  \"status\": \"NOT_FOUND\",\r\n"
      + "  \"statusCode\": 404,\r\n"
      + "  \"reason\": \"Not Found\",\r\n"
      + "  \"message\": \"No matching records to update found. ESN='72382111' has 0 match(es). EventId='4043679' has 1 match(es). ShopCode='ESA' has 3737 match(es). \",\r\n"
      + "  \"errors\": [\r\n"
      + "    \"No matching records to update found. ESN='72382111' has 0 match(es). EventId='4043679' has 1 match(es). ShopCode='ESA' has 3737 match(es). \"\r\n"
      + "  ]\r\n"
      + "}";

  String EVENT_ID_NO_MATCH = "{\r\n"
      + "  \"status\": \"NOT_FOUND\",\r\n"
      + "  \"statusCode\": 404,\r\n"
      + "  \"reason\": \"Not Found\",\r\n"
      + "  \"message\": \"No matching records to update found. ESN='723821' has 1 match(es). EventId='40436799' has 0 match(es). ShopCode='ESA' has 3737 match(es). \",\r\n"
      + "  \"errors\": [\r\n"
      + "    \"No matching records to update found. ESN='723821' has 1 match(es). EventId='40436799' has 0 match(es). ShopCode='ESA' has 3737 match(es). \"\r\n"
      + "  ]\r\n"
      + "}";

  String SHOP_CODE_NO_MATCH = "{\r\n"
      + "  \"status\": \"NOT_FOUND\",\r\n"
      + "  \"statusCode\": 404,\r\n"
      + "  \"reason\": \"Not Found\",\r\n"
      + "  \"message\": \"No matching records to update found. ESN='723821' has 1 match(es). EventId='4043679' has 1 match(es). ShopCode='ESAAA' has 0 match(es). \",\r\n"
      + "  \"errors\": [\r\n"
      + "    \"No matching records to update found. ESN='723821' has 1 match(es). EventId='4043679' has 1 match(es). ShopCode='ESAAA' has 0 match(es). \"\r\n"
      + "  ]\r\n"
      + "}";

  String BAD_DELETE_REQUEST_ALL = "{\r\n"
      + "  \"status\": \"BAD_REQUEST\",\r\n"
      + "  \"statusCode\": 400,\r\n"
      + "  \"reason\": \"Bad Request\",\r\n"
      + "  \"message\": \"Validation failed for argument [0] in public org.springframework.http.ResponseEntity<?> com.pw.dome.mro.collab.workorder.MroWorkOrderController.deleteWorkOrderFromMRO(com.pw.dome.mro.collab.workorder.MroWorkOrderDeleteRequest) with 3 errors: [Field error in object 'mroWorkOrderDeleteRequest' on field 'mroShopCode': rejected value [ESAdskndsduhsudhisuhdshdshdhsdsdhishdis]; codes [Size.mroWorkOrderDeleteRequest.mroShopCode,Size.mroShopCode,Size.java.lang.String,Size]; arguments [org.springframework.context.support.DefaultMessageSourceResolvable: codes [mroWorkOrderDeleteRequest.mroShopCode,mroShopCode]; arguments []; default message [mroShopCode],10,1]; default message [size must be between 1 and 10]] [Field error in object 'mroWorkOrderDeleteRequest' on field 'eventId': rejected value [-1]; codes [Min.mroWorkOrderDeleteRequest.eventId,Min.eventId,Min.java.lang.Integer,Min]; arguments [org.springframework.context.support.DefaultMessageSourceResolvable: codes [mroWorkOrderDeleteRequest.eventId,eventId]; arguments []; default message [eventId],1]; default message [must be greater than or equal to 1]] [Field error in object 'mroWorkOrderDeleteRequest' on field 'esn': rejected value [723821odaauasashashashahsuhaushuahsasas]; codes [Size.mroWorkOrderDeleteRequest.esn,Size.esn,Size.java.lang.String,Size]; arguments [org.springframework.context.support.DefaultMessageSourceResolvable: codes [mroWorkOrderDeleteRequest.esn,esn]; arguments []; default message [esn],20,1]; default message [size must be between 1 and 20]]\",\r\n"
      + "  \"errors\": [\r\n"
      + "    \"mroShopCode: size must be between 1 and 10\",\r\n"
      + "    \"eventId: must be greater than or equal to 1\",\r\n"
      + "    \"esn: size must be between 1 and 20\"\r\n"
      + "  ]\r\n"
      + "}";

  String BAD_DELETE_REQUEST_NULL = "{\r\n"
      + "  \"status\": \"BAD_REQUEST\",\r\n"
      + "  \"statusCode\": 400,\r\n"
      + "  \"reason\": \"Bad Request\",\r\n"
      + "  \"message\": \"Validation failed for argument [0] in public org.springframework.http.ResponseEntity<?> com.pw.dome.mro.collab.workorder.MroWorkOrderController.deleteWorkOrderFromMRO(com.pw.dome.mro.collab.workorder.MroWorkOrderDeleteRequest): [Field error in object 'mroWorkOrderDeleteRequest' on field 'eventId': rejected value [null]; codes [NotNull.mroWorkOrderDeleteRequest.eventId,NotNull.eventId,NotNull.java.lang.Integer,NotNull]; arguments [org.springframework.context.support.DefaultMessageSourceResolvable: codes [mroWorkOrderDeleteRequest.eventId,eventId]; arguments []; default message [eventId]]; default message [must not be null]]\",\r\n"
      + "  \"errors\": [\r\n"
      + "    \"eventId: must not be null\"\r\n"
      + "  ]\r\n"
      + "}";

  String BAD_UPDATE_REQUEST_ALL = "{\r\n"
      + "  \"status\": \"BAD_REQUEST\",\r\n"
      + "  \"statusCode\": 400,\r\n"
      + "  \"reason\": \"Bad Request\",\r\n"
      + "  \"message\": \"Validation failed for argument [0] in public org.springframework.http.ResponseEntity<java.lang.String> com.pw.dome.mro.collab.workorder.MroWorkOrderController.getMroInfo(com.pw.dome.mro.collab.workorder.MroWorkOrderRequest) with 4 errors: [Field error in object 'mroWorkOrderRequest' on field 'mroShopCode': rejected value [ESAjidjowjdosjdoijsdojsodjsdoisd]; codes [Length.mroWorkOrderRequest.mroShopCode,Length.mroShopCode,Length.java.lang.String,Length]; arguments [org.springframework.context.support.DefaultMessageSourceResolvable: codes [mroWorkOrderRequest.mroShopCode,mroShopCode]; arguments []; default message [mroShopCode],10,1]; default message [length must be between 1 and 10]] [Field error in object 'mroWorkOrderRequest' on field 'esn': rejected value [72382112902912912091290120912098u12]; codes [Length.mroWorkOrderRequest.esn,Length.esn,Length.java.lang.String,Length]; arguments [org.springframework.context.support.DefaultMessageSourceResolvable: codes [mroWorkOrderRequest.esn,esn]; arguments []; default message [esn],20,1]; default message [length must be between 1 and 20]] [Field error in object 'mroWorkOrderRequest' on field 'eventId': rejected value [-1]; codes [Range.mroWorkOrderRequest.eventId,Range.eventId,Range.java.lang.Integer,Range]; arguments [org.springframework.context.support.DefaultMessageSourceResolvable: codes [mroWorkOrderRequest.eventId,eventId]; arguments []; default message [eventId],9223372036854775807,1]; default message [must be between 1 and 9223372036854775807]] [Field error in object 'mroWorkOrderRequest' on field 'mroWorkOrder': rejected value [0123456789mjdoiasjodjnwoidjowdjoidjoihjndo]; codes [Length.mroWorkOrderRequest.mroWorkOrder,Length.mroWorkOrder,Length.java.lang.String,Length]; arguments [org.springframework.context.support.DefaultMessageSourceResolvable: codes [mroWorkOrderRequest.mroWorkOrder,mroWorkOrder]; arguments []; default message [mroWorkOrder],25,1]; default message [length must be between 1 and 25]]\",\r\n"
      + "  \"errors\": [\r\n"
      + "    \"mroShopCode: length must be between 1 and 10\",\r\n"
      + "    \"esn: length must be between 1 and 20\",\r\n"
      + "    \"eventId: must be between 1 and 9223372036854775807\",\r\n"
      + "    \"mroWorkOrder: length must be between 1 and 25\"\r\n"
      + "  ]\r\n"
      + "}";

  String BAD_UPDATE_REQUEST_NULL = "{\r\n"
      + "  \"status\": \"BAD_REQUEST\",\r\n"
      + "  \"statusCode\": 400,\r\n"
      + "  \"reason\": \"Bad Request\",\r\n"
      + "  \"message\": \"Validation failed for argument [0] in public org.springframework.http.ResponseEntity<java.lang.String> com.pw.dome.mro.collab.workorder.MroWorkOrderController.getMroInfo(com.pw.dome.mro.collab.workorder.MroWorkOrderRequest): [Field error in object 'mroWorkOrderRequest' on field 'eventId': rejected value [null]; codes [NotNull.mroWorkOrderRequest.eventId,NotNull.eventId,NotNull.java.lang.Integer,NotNull]; arguments [org.springframework.context.support.DefaultMessageSourceResolvable: codes [mroWorkOrderRequest.eventId,eventId]; arguments []; default message [eventId]]; default message [The field may not be null.]]\",\r\n"
      + "  \"errors\": [\r\n"
      + "    \"eventId: The field may not be null.\"\r\n"
      + "  ]\r\n"
      + "}";

  interface SQL {
	  String FROM_QUERY =
	  " FROM EngineEntity e,"
	  + "     EngineTrackingEntity t,"
	  + "     SlotEntity s,"
	  + "     MroEngineCenterEntity c "
	  + "WHERE e.engineID = t.engtrackId"
	  + "  AND e.slotID = s.slotID"
	  + "  AND s.engineCenterID = c.ecId"
	  + "  AND c.mroEcShopCode = :mroShopCode"
	  + "  AND e.esn = :esn"
	  + "  AND e.eventId = :eventId";

	  /**
       * Returns EngineTrackingEntity count matching criteria from MRO Collab.
       *
       * @see <a href="https://sqlformat.org/" target="_blank">SQL Format</a>
       */
      String COUNT_QUERY =
        "SELECT count(*) "
	  + "  FROM EngineEntity e,"
	  + "       EngineTrackingEntity t,"
	  + "       SlotEntity s,"
	  + "       MroEngineCenterEntity c "
	  + "WHERE e.engineID = t.engtrackId"
	  + "  AND e.slotID = s.slotID"
	  + "  AND s.engineCenterID = c.ecId"
	  + "  AND (:mroShopCode is null OR c.mroEcShopCode = :mroShopCode)"
	  + "  AND (:esn is null OR e.esn = :esn)"
	  + "  AND (:eventId is null OR e.eventId = :eventId)";

      String COUNT_NO_SHOP_CODE_QUERY =
        "SELECT count(*) "
	  + "  FROM EngineEntity e,"
	  + "       EngineTrackingEntity t,"
	  + "       SlotEntity s,"
	  + "       MroEngineCenterEntity c "
	  + "WHERE e.engineID = t.engtrackId"
	  + "  AND e.slotID = s.slotID"
	  + "  AND c.mroEcShopCode = :mroShopCode"
	  + "  AND e.esn = :esn"
	  + "  AND e.eventId = :eventId";

      /**
	   * Returns EngineTrackingEntity id(s) matching criteria from MRO Collab.
	   *
       * @see <a href="https://sqlformat.org/" target="_blank">SQL Format</a>
       */
      String GET_ENG_ID =
	  "SELECT t.engtrackId " + FROM_QUERY;

      String GET_SLOTTED_SHOP_CODES_QUERY = "SELECT NEW " + DTO_NAME +
"""
(c.mroEcShopCode,
 c.ecId,
 ec.name)
FROM
   EngineEntity e,
   EngineCenterEntity ec,
   EngineTrackingEntity t,
   SlotEntity s,
   MroEngineCenterEntity c 
WHERE
   e.engineID = t.engtrackId 
   AND e.slotID = s.slotID 
   AND s.engineCenterID = c.ecId 
   AND ec.id = c.ecId 
   AND e.esn = :esn 
   AND e.eventId = :eventId
""";

      /**
       * Delete the EngineTrackingEntity MROWorkOrder matching criteria from MRO Collab.
       */
      String DELETE_QUERY =
      "UPDATE EngineTrackingEntity t "
      + "SET  t.engtrackWorkOrder = NULL "
      + "WHERE t.engtrackId in ("
      + GET_ENG_ID
      + ")";

        /**
		 * Updates EngineTrackingEntity(s) matching criteria from MRO Collab.
		 */
		String UPDATE_QUERY =
		"UPDATE EngineTrackingEntity t "
	     + "SET t.mroShopCode = :mroShopCode, "
	     + "    t.engtrackWorkOrder = :mroWorkOrder "
	     + "WHERE t.engtrackId in ("
	     + GET_ENG_ID
	     + ")";
	}
}
