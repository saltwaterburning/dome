package com.pw.dome.external.mro.collab.services.workorder;

import static java.util.Objects.nonNull;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.engine.comments.CommentEntity;
import com.pw.dome.engine.comments.CommentsRepo;
import com.pw.dome.engine.odin.OdinEntity;
import com.pw.dome.exception.NotFoundException;
import com.pw.dome.external.mro.collab.client.MroWebClientService;
import com.pw.dome.external.mro.collab.services.comments.MroComment;
import com.pw.dome.external.mro.collab.services.customerapproval.MroOdinRepository;
import com.pw.dome.external.mro.collab.services.pacingitems.MroPacingItem;
import com.pw.dome.wip.WipService;
import com.pw.dome.wip.WorkInProgress;
import com.pw.dome.wip.pacing.PacingItemEntity;
import com.pw.dome.wip.pacing.PacingItemRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MroWorkOrderService {

	@Autowired
	private CommentsRepo commentsRepo;
  @Autowired
  private MroEngineCenterRepository repo; 
	@Autowired
	private MroOdinRepository odinRepo;
	@Autowired
	private MroWebClientService mroWebClientSvc;
  @Autowired
  private PacingItemRepository pacingItemRepo;
	@Autowired
	private WipService wipService;

	@Transactional
	public int deleteWorkOrder(final MroWorkOrderDeleteRequest request) {
		int cnt =
				repo.deleteWorkOrder(request.getEsn(), request.getEventId(), request.getMroShopCode());

		if (cnt < 1) {
			StringBuilder buffy = new StringBuilder("No matching records to update found. ");
			int size = repo.findRowCount(request.getEsn(), null, null);
			buffy.append("ESN='").append(request.getEsn()).append("' has ").append(size)
			.append(" match(es). ");

			size = repo.findRowCount(null, request.getEventId(), null);
			buffy.append("EventId='").append(request.getEventId()).append("' has ").append(size)
			.append(" match(es). ");

			size = repo.findRowCount(null, null, request.getMroShopCode());
			buffy.append("ShopCode='").append(request.getMroShopCode()).append("' has ").append(size)
			.append(" match(es). ");

			String msg = buffy.toString();
			log.info(msg);
			throw new NotFoundException(msg);
		} else {
			log.info("MRO delete successful: {}", request);
		}

		return cnt;
	}

	/**
	 * Pushes gate dates, comments and pacing items for the given engineId asynchronously.
	 * 
	 * @param engId
	 * @param request
	 */
	@Async
	public void pushAllMatchingItemsToMRO(Integer engId, MroWorkOrderUpdateRequest request) {
		pushEngineGateInfo(engId, request);
		pushMroComments(engId, request);
		pushMroPacingItems(engId, request);
	}

	public void updateCustomerApprovalDate(MroWorkOrderUpdateRequest request) {
		Optional<OdinEntity> option =
				odinRepo.findOdin(request.getEsn(),
						          request.getEventId(),
						          request.getMroShopCode(),
						          request.getMroWorkOrder());

		if (option.isPresent()) {
			LocalDate date;
			OdinEntity odin = option.get();

			if (nonNull(date = odin.getWsOrigReleaseDate())) {
				log.info("Original release date is already set. Date:{}, Request: {}", date.toString(), request);
			}

			LocalDateTime dateTime = request.getPublishedDateTime();
			odin.setWsOrigReleaseDate(dateTime.toLocalDate());
			odinRepo.save(odin);
		} else {
			log.error("Unable to find matching ODIN record. Request: {}", request);
			throw new NotFoundException("Unable to find matching ODIN record.");
		}
	}

	@Transactional
	public String updateWorkOrder(final MroWorkOrderUpdateRequest request) {
		int cnt = repo.updateWorkOrder(request.getEsn(), request.getEventId(), request.getMroShopCode(),
				request.getMroWorkOrder());

		if (cnt < 1) {
			// MRO 
			List<SlottedShopCodesDTO> enginesCenters;
			StringBuilder buffy = new StringBuilder("No matching records to update found. ");
			final int msgLength = buffy.length();
			if (!repo.existsByMroEcShopCode(request.getMroShopCode())) {
				List<String> shopCodes = repo.findAll(Sort.by("mroEcShopCode")).stream().map(s->s.getMroEcShopCode()).collect(Collectors.toList());
				buffy.append("Supplied ShopCode '").append(request.getMroShopCode()).append("' not matched. Available ShopCodes").append(shopCodes);
			} else if (!(enginesCenters = repo.getSlottedShopCodes(request.getEsn(), request.getEventId())).isEmpty()) {
				buffy.append("DOME engine records matched with provided ESN & eventId but not for the provided MRO shopCode.");
				if (!enginesCenters.isEmpty()) {
					List<String> ecShopCodes = enginesCenters.stream().map(s->s.shopCode() + "/" + s.engineCenterId() + "/" + s.engineCenterName()).collect(Collectors.toList());
					buffy.append(" However DOME record(s) do exist for ShopCode/EngineCenterId/EngineCenterName: ").append(ecShopCodes);
				}
			} else {
				if (repo.findRowCount(request.getEsn(), null, null) < 1) {
					buffy.append("Provided ESN='").append(request.getEsn()).append("' isn't matching any DOME records.");
				}
				if (repo.findRowCount(null, request.getEventId(), null) < 1) {
					buffy.append("Provided EventId='").append(request.getEventId()).append("' isn't matching any DOME records.");
				}
				if (repo.findRowCount(null, null, request.getMroShopCode()) < 1) {
					MroEngineCenterEntity entity = repo.findByMroEcShopCode(request.getMroShopCode()).orElse(new MroEngineCenterEntity());
					buffy.append("Provided ShopCode='").append(request.getMroShopCode()).append("' (").append(entity.getEcId()).append(") isn't matching any DOME records.");
				}
				if (buffy.length() == msgLength) {
					buffy.append("Unable to supply additonal diagnostic information.");
				}
			}

			String msg = buffy.toString();
			log.info(msg);
			throw new NotFoundException(msg);
		} else { // After update request from MRO push WIP milestone dates to MRO via MroWebClient and log as much detail as possible for auditing.
			updateCustomerApprovalDate(request);

			Integer engId = repo.findEngineTrackingId(request.getEsn(), request.getEventId(), request.getMroShopCode());
	
			if (cnt > 1) {
				log.warn("updateWorkOrder() updated multiple rows: {}, EngId: {}, MRO Request: {}", cnt, engId, request);
			}

			if (engId != null) {
				pushAllMatchingItemsToMRO(engId, request);
			} else {
				log.error("updateWorkOrder()- No engineId found! MRO Request: {}", request);
			}
		}

		return new StringBuilder().append(cnt).append(" records updated sucessfully.").toString();
	}

	private void pushEngineGateInfo(Integer engId, MroWorkOrderUpdateRequest request) {
		WorkInProgress wip = wipService.getWorkInProgressDetails(engId, false);
		if (wip != null) {
			mroWebClientSvc.pushEngineGateInfo(wip);
			log.info("updateWorkOrder()- pushEngineGateInfo(), EngId: {}, Request {}", engId, request);
		} else {
			log.error("updateWorkOrder()- pushEngineGateInfo() not invoked since matching WIP record not found, EngId: {}, Request: {}", engId, request);
		}
	}

	private void pushMroComments(Integer engId, MroWorkOrderUpdateRequest request) {
		List<CommentEntity> comments = commentsRepo.findByEngineIdOrderByDateUpdatedDesc(engId);

		if (CollectionUtils.isNotEmpty(comments)) {
			List<MroComment> mroComments = new ArrayList<>(comments.size());
			comments.stream().forEach(s->mroComments.add(DataMapper.INSTANCE.toMroComment(s, request)));
			mroWebClientSvc.pushMroComments(mroComments);
			List<Integer> commentIds = mroComments.stream().map(s->s.getCommentId()).collect(Collectors.toList());
			log.info("pushMroComments(), EngId: {}, CommentIds: {}, MRO Request: {}", commentIds, engId, request);
		} else {
			log.info("pushMroComments() not invoked. No comments found. EngId: {}, MRO Request: {}", engId, request);
		}
	}

	private void pushMroPacingItems(Integer engId, MroWorkOrderUpdateRequest request) {
		List<PacingItemEntity> pacingItems = pacingItemRepo.findByEngineIdOrderByPacingIdDesc(engId);

		if (CollectionUtils.isNotEmpty(pacingItems)) {
			List<MroPacingItem> mroPacingItems = new ArrayList<>(pacingItems.size());
			pacingItems.stream().forEach(s->mroPacingItems.add(DataMapper.INSTANCE.toMroPacingItem(s, request)));
			mroWebClientSvc.pushMroPacingItems(mroPacingItems);
			List<Integer> pacingIds = mroPacingItems.stream().map(s->s.getPacingId()).collect(Collectors.toList());
			log.info("pushMroPacingItems(), EngId: {}, PacingIds : {}, Request: {}", engId, pacingIds, request);
		} else {
			log.info("pushMroPacingItems() not invoked. No pacingItems found. EngId: {}, Request: {}", engId, request);
		}
	}
}
