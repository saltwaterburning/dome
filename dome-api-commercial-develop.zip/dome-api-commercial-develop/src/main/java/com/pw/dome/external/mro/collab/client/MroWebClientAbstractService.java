package com.pw.dome.external.mro.collab.client;

import static com.pw.dome.external.mro.ValidationUtil.validate;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.stream.Collectors;

import jakarta.validation.Validator;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.pw.dome.engine.EngineEntity;
import com.pw.dome.engine.EngineRepository;
import com.pw.dome.engine.comments.CommentEntity;
import com.pw.dome.engine.tracking.EngineTrackingEntity;
import com.pw.dome.engine.tracking.EngineTrackingRepository;
import com.pw.dome.external.RemoteServicesWebClient;
import com.pw.dome.external.mro.ValidatedList;
import com.pw.dome.external.mro.collab.ConfigMroCollab;
import com.pw.dome.external.mro.collab.services.comments.MroComment;
import com.pw.dome.external.mro.collab.services.comments.MroDeleteCommentRequest;
import com.pw.dome.external.mro.collab.services.comments.MroDeleteSmiRequest;
import com.pw.dome.external.mro.collab.services.pacingitems.MroDeletePacingItemRequest;
import com.pw.dome.external.mro.collab.services.pacingitems.MroPacingItem;
import com.pw.dome.web.requestlogging.RequestLoggingService;
import com.pw.dome.wip.WorkInProgress;
import com.pw.dome.wip.pacing.PacingItemDTO;
import com.pw.dome.wip.pacing.PacingItemEntity;

import lombok.extern.slf4j.Slf4j;

/**
 * MRO request handler implementation.
 */
@Service
@Slf4j
abstract class MroWebClientAbstractService {
	@Autowired
	private ConfigMroCollab config;
	@Autowired
	private EngineRepository engRepo;
	@Autowired
	private EngineTrackingRepository engTrackingRepo;
	@Autowired
	@Lazy
	@Qualifier("MRO")
	private RemoteServicesWebClient webClient;
	@Autowired
	private Validator validator;

	boolean doDeleteComment(Long commentId) {
		MroDeleteCommentRequest request = new MroDeleteCommentRequest(commentId);
		validate(validator, request);

		webClient.postRequest(request, config.getDeleteCommentUri());
		return true;
	}

	boolean doDeleteEngineEsn(Integer engineId, String esn, Integer eventId) {
		if (!engTrackingRepo.existsWhereWorkOrderIsNotNull(engineId)) {
			log.info("Skipping doDeleteEngineEsn({}, {}, {})",
					engineId, esn, eventId);
			return false;
		}

		MroDeleteSmiRequest request = new MroDeleteSmiRequest(esn, eventId);
		validate(validator, request);

		webClient.postRequest(request, config.getDeleteEngineEsnUri());
		return true;
	}

	boolean doDeletePacingItem(Long pacingItemId) {
		MroDeletePacingItemRequest request = new MroDeletePacingItemRequest(pacingItemId);
		validate(validator, request);

		webClient.postRequest(request, config.getDeletePacingItemUri());
		return true;
	}

	void doPushComments(List<CommentEntity> comments) {
		ValidatedList<MroComment> mroComments = toMroComment(comments);

		doPushMroComments(mroComments);
	}

	void doPushCommentsGroupByEngineId(List<CommentEntity> commentEntities) {
		Validate.noNullElements(commentEntities);

		Map<Integer, List<CommentEntity>> mappedByEngineId = commentEntities.stream()
				.collect(Collectors.groupingBy(CommentEntity::getEngineId));

		for (Entry<Integer, List<CommentEntity>> entry : mappedByEngineId.entrySet()) {
			List<CommentEntity> comments = entry.getValue();

			if (CollectionUtils.isNotEmpty(comments)) {
				try {
					doPushComments(comments);
				} catch (Exception ignore) {
					log.error("doPushComments(), size=" + comments.size(), ignore);
				}
			}
		}
	}

	void doPushEngineGateInfo(WorkInProgress wip) {
		Objects.requireNonNull(wip);

		MroGateInfo mroGateInfo = DataMapper.INSTANCE.toMroGateInfo(wip);
		validate(validator, mroGateInfo);

		webClient.postRequest(mroGateInfo, config.getPushEngineGateInfoUri());
	}

	void doPushMroComments(List<MroComment> mroComments) {
		doPushMroComments(new ValidatedList<MroComment>(mroComments));
	}

	void doPushMroComments(ValidatedList<MroComment> mroComments) {
		validate(validator, mroComments);

		webClient.postRequest(mroComments, config.getPushCommentUri());
	}

	void doPushMroPacingItems(List<MroPacingItem> mroPacingItems) {
		doPushMroPacingItems(new ValidatedList<>(mroPacingItems));
	}

	void doPushMroPacingItems(ValidatedList<MroPacingItem> mroPacingItems) {
		validate(validator, mroPacingItems);

		webClient.postRequest(mroPacingItems, config.getPushPacingItemUri());
	}

	void doPushPacingItems(List<PacingItemDTO> pacingItems) {
		ValidatedList<MroPacingItem> mroPacingItems = toMroPacingItems(pacingItems);
		doPushMroPacingItems(mroPacingItems);
	}

	void doPushPacingItemsGroupedByEngineId(List<MroPacingItem> mroPacingItems) {
		Validate.noNullElements(mroPacingItems);

		Map<Integer, List<MroPacingItem>> mapByEngineId = mroPacingItems.stream()
				.collect(Collectors.groupingBy(MroPacingItem::getEngineId));

		for (Entry<Integer, List<MroPacingItem>> entry : mapByEngineId.entrySet()) {
			List<MroPacingItem> pItems = entry.getValue();
			log.debug("doPushPacingItemsGroupedByEngineId().doPushMroPacingItems(), EngineId: {}, PacingItems Cnt: {}",
					entry.getKey(), pItems.size());
			if (CollectionUtils.isNotEmpty(pItems)) {
				try {
					doPushMroPacingItems(pItems);
				} catch (Exception ignore) {
					log.error("doPushMroPacingItems(), size=" + pItems.size(), ignore);
				}
			}
		}
	}

	/**
	 * Generates {@code MroComment}s by finding the matching {@code EngineEntity}
	 * and {@code EngineTrackingEntity}.
	 * 
	 * @param comments
	 * @return
	 */
	private ValidatedList<MroComment> toMroComment(List<CommentEntity> comments) {
		Validate.notEmpty(comments);
		Validate.noNullElements(comments);

		final int engId = comments.get(0).getEngineId();

		EngineEntity engine = engRepo.findById(engId).orElse(null);
		Objects.requireNonNull(engine, "EngineEntity not found for engineId=" + engId);

		EngineTrackingEntity engTracking = engTrackingRepo.findById(engId).orElse(null);
		Objects.requireNonNull(engine, "EngineTrackingEntity not found for engineId=" + engId);

		ValidatedList<MroComment> mroComments = new ValidatedList<>(comments.size());
		comments.stream().forEach(s -> mroComments.add(DataMapper.INSTANCE.toMroComment(s, engine, engTracking)));

		return mroComments;
	}

	/**
	 * Generates {@code MroPacingItem} by finding the matching {@code EngineEntity}
	 * and {@code EngineTrackingEntity}.
	 * 
	 * @param comments
	 * @return
	 */
	@SuppressWarnings("unused")
	private MroPacingItem toMroPacingItem(PacingItemEntity pacingItem) {
		Objects.requireNonNull(pacingItem);

		final int engId = pacingItem.getEngineId();

		EngineEntity engine = engRepo.findById(engId).orElse(null);
		Objects.requireNonNull(engine, "EngineEntity not found for engineId=" + engId);

		EngineTrackingEntity engTracking = engTrackingRepo.findById(engId).orElse(null);
		Objects.requireNonNull(engine, "EngineTrackingEntity not found for engineId=" + engId);

		return DataMapper.INSTANCE.toMroPacingItem(pacingItem, engine, engTracking);
	}

	/**
	 * Generates {@code MroPacingItem} by finding the matching {@code EngineEntity}
	 * and {@code EngineTrackingEntity}.
	 * 
	 * @param comments
	 * @return
	 */
	private ValidatedList<MroPacingItem> toMroPacingItems(List<PacingItemDTO> pacingItem) {
		Objects.requireNonNull(pacingItem);

		final int engId = pacingItem.get(0).getEngineId();

		EngineEntity engine = engRepo.findById(engId).orElse(null);
		Objects.requireNonNull(engine, "EngineEntity not found for engineId=" + engId);

		EngineTrackingEntity engTracking = engTrackingRepo.findById(engId).orElse(null);
		Objects.requireNonNull(engine, "EngineTrackingEntity not found for engineId=" + engId);

		ValidatedList<MroPacingItem> mroPacingItems = new ValidatedList<>(pacingItem.size());

		pacingItem.stream()
				.forEach(s -> mroPacingItems.add(DataMapper.INSTANCE.toMroPacingItem(s, engine, engTracking)));

		return mroPacingItems;
	}

	@Bean("MRO")
	RemoteServicesWebClient createWebClient(ConfigMroCollab config, RequestLoggingService loggingSvc) {
		return new RemoteServicesWebClient(this.getClass(), config, loggingSvc);
	}
}
