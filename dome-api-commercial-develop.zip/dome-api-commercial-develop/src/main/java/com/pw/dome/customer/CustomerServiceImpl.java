package com.pw.dome.customer;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

/**
 * @author John De Lello
 */
@Service
@Slf4j
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public List<CustomerEntity> findAllOrderByName() {
		Sort sort = Sort.by(Sort.Direction.ASC, "name");
		return customerRepository.findAll(sort);
	}
	
	@Override
	public List<CustomerEntity> findActiveCustomersOrderByName() {
		return customerRepository.findByActiveTrueOrderByNameAsc();
	}

	@Override
	public CustomerEntity getCustomerByID(final String customerID) {
		if(StringUtils.isEmpty(customerID)) {
			log.error("No valid customer ID was specified. Unable to retrieve customer.");
			throw new IllegalArgumentException("No valid customer ID was specified. Unable to retrieve customer.");
		}
		
		CustomerEntity customer = customerRepository.findById(customerID).orElse(null);
		
		if(customer == null) {
			log.error("Customer ID [{}] was not found.", customerID);
			throw new IllegalArgumentException("Customer ID [" + customerID + "] was not found.");
		}
		
		return customer;
	}
}
