package com.pw.dome.engine;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import lombok.Builder;

/**
 * Partial engineEntity record.
 */
@Builder(toBuilder = true)
public record EngineDTO(
		@NotNull
		Integer engineID,
		@NotEmpty
		String customerId,
		@NotEmpty
		String engineGroupID,
		@NotEmpty
		String engineModelID,
		@NotEmpty
		String category,
		@NotEmpty
		String subVisitType,
		@NotEmpty
		String salesOrderType) {
	;
}
