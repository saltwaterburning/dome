package com.pw.dome.admin;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Provides basic user information.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
class UserInfo {
    private LocalDateTime dateRequested;
    @NotBlank(message = "{NotBlank.required}")
    private String emailAddress;
    @NotBlank(message = "{NotBlank.required}")
    private String firstName;
    @NotBlank(message = "{NotBlank.required}")
    private String lastName;
    private String organization;
    private ProfileStatus status;
}
