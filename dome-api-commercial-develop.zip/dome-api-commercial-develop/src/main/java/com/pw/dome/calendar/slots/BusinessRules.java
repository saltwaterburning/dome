package com.pw.dome.calendar.slots;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pw.dome.enginecenter.EngineCenterEntity;
import com.pw.dome.enginecenter.EngineCenterRepository;

@Component
public class BusinessRules {
	@Autowired
	private EngineCenterRepository ecRepo;

	/**
	 * Return the three character EC code from the dome_engine_center table.
	 * 
	 * @param ecId engine center Id
	 * @param engineTypeId
	 * 
	 * @return the three character EC code from the dome_engine_center table
	 */
	public String getEngineCenterCode(String ecId, String engineTypeId) {
		String ecCode = "";

		EngineCenterEntity entity = ecRepo.getReferenceById(ecId);
		if (entity.isActive()) {
			ecCode = StringUtils.containsAnyIgnoreCase(engineTypeId, "ET720", "ET780") ? entity.getVDataCode() : entity.getEDataCode();
		}

		return ecCode;
	}

	/**
	 * Return the three character EC code from the dome_engine_center table.
	 * 
	 * @param engineTypeId
	 * @param eData
	 * @param vData
	 * @return the three character EC code from the dome_engine_center table
	 */
	public static String getEngineCenterCode(String engineTypeId, String eData, String vData) {
		return StringUtils.containsAnyIgnoreCase(engineTypeId, "ET720", "ET780") ? vData : eData;
	}
}
