package com.pw.dome.calendar.induction;

import java.util.Collection;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class CalendarMonthYear {
	private String calYYMM;
	private Collection<CalendarDay> days;
	private String engineCenterID;
	private String engineCenterName;
	private int month;
	private int year;
}
