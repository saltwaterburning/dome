package com.pw.dome.external.workscope.provider;

import jakarta.validation.constraints.NotBlank;

public record Provider(
		@NotBlank
		String providerCode,
		@NotBlank
		String providerName) {

}
