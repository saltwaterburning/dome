package com.pw.dome.mml.le;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
interface LeQuarterlyOpportunityRepository extends JpaRepository<LeQuarterlyOpportunityEntity, Integer> {
    int deleteByIdIn(List<Integer> ids);
}
