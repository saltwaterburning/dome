package com.pw.dome.mml.le;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Builder
class LeResponse {

    private List<DetailsDTO> leDetails;
    
    private List<DetailsDTO> lePlanDetails;
}
