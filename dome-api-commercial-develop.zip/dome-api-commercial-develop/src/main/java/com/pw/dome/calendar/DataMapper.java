package com.pw.dome.calendar;

import java.util.Collection;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.calendar.induction.CalendarEngine;
import com.pw.dome.calendar.induction.CalendarShopVisit;
import com.pw.dome.calendar.inductionplanning.InductionPlanningCalendarEngine;
import com.pw.dome.calendar.inductionplanning.InductionPlanningCalendarVisitSummary;
import com.pw.dome.calendar.inductionplanning.InductionPlanningEngine;
import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.engine.EngineEntity;
import com.pw.dome.engine.type.EngineTypeEntity;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

//	@Mapping(target = "customerName", source = "engine.customer.name")
//	@Mapping(target = "customerShortName", source = "engine.customer.shortName")
//	@Mapping(target = "engineGroupID", source = "engine.groupID")
//	@Mapping(target = "engineModelID", source = "engine.modelID")
//	@Mapping(target = "moduleName", source = "engine.module.moduleName")
//	@Mapping(target = "engineTypeName", source = "slot.engineType.name")
//	CalendarEngine toCalendarEngine(EngineEntity engine, SlotEntity slot);

	@Mapping(target = "customerName", source = "engine.customer.name")
	@Mapping(target = "customerShortName", source = "engine.customer.shortName")
	@Mapping(target = "engineGroupID", source = "engine.groupID")
	@Mapping(target = "engineModelID", source = "engine.modelID")
	@Mapping(target = "moduleName", source = "engine.module.moduleName")
	@Mapping(target = "engineTypeName", source = "engineType.name")
	CalendarEngine toCalendarEngine(EngineEntity engine, EngineTypeEntity engineType);

	InductionPlanningCalendarVisitSummary toInductionPlanningCalendarVisitSummary(InductionPlanningEngine ipEngine, Collection<InductionPlanningCalendarEngine> engines);

	@Mapping(target = "dayOfMonth", source = "slot.day")
	@Mapping(target = "engineTypeID", conditionExpression = "java(slot.getShopVisitType() != com.pw.dome.calendar.slots.ShopVisitType.HOLIDAY)")
	@Mapping(target = "engineTypeName", source = "slot.engineType.name", conditionExpression = "java(slot.getShopVisitType() != com.pw.dome.calendar.slots.ShopVisitType.HOLIDAY)")
	CalendarShopVisit toShopVisit(SlotEntity slot, Collection<CalendarEngine> engines);
}
