package com.pw.dome.engine.induction.planning;

import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;

// enumAsRef must be defined here or within @Operation(parameter=@Schema controller method annotation.
@Schema(enumAsRef = true)
public enum InductionMiscKeys {
    @Parameter(description = "User Origanization")
	ADMINORG,
    @Parameter(description = "Engine Category")
    ENGCATEGORY,
    @Parameter(description = "Engine Sales Order")
    @Deprecated
    ENGSALESORDER,
    @Parameter(description = "Engine Sales Order Other")
    ENGSLSORDOTHER,
    @Parameter(description = "Engine Sales Order- PW1")
    ENGSLSORDPW1,
    @Parameter(description = "Engine Sales Order- V2500")
    ENGSLSORDV2500,
    @Parameter(description = "Current Location- All")
	IPCURRLOC,
    @Parameter(description = "EBU Shop- All")
	IPEBUSHOP,
    @Parameter(description = "Investigation Category")
    IPINVCAT,
    @Parameter(description = "LLP Replace- All")
	IPLLPRPLCALL,
    @Parameter(description = "Preliminary Change Reason")
    IPPRELIMCHGRSN,
    @Parameter(description = "SV Classification- All other")
	IPSVCLSOTHER,
    @Parameter(description = "SV Classification- PW1")
	IPSVCLSPW1,
	@Parameter(description = "SV Classification- V2500")
	IPSVCLSV2500,
    @Parameter(description = "Upgrade Eligible- All other")
	IPUPGRADEOTHER,
    @Parameter(description = "Upgrade Eligible- PW1")
	IPUPGRADEPW1,
	@Parameter(description = "Upgrade Eligible- V2500")
	IPUPGRADEV2500,
	@Parameter(description = "Plan Sales Order")
    PLANSALESORDER,
    @Parameter(description = "Visit Category- H")
    VISITCATEGORYH,
    @Parameter(description = "Visit Category- L")
    VISITCATEGORYL,
    @Parameter(description = "Visit Category- M")
    VISITCATEGORYM,
    @Parameter(description = "WIP Category")
    WIPCATEGORY,
    @Parameter(description = "WIP Engine Category")
    WIPENGCATEGORY,
    @Parameter(description = "WIP ShipType")
    WIPSHIPTYPE,
    @Parameter(description = "WIP WS Indicator")
    WIPWSIND;

    public static InductionMiscKeys ofEngineTypeName(String engineTypeName) {
    	if (StringUtils.startsWith(engineTypeName, "PW1")) {
    		return ENGSLSORDPW1;    		
    	} else if (StringUtils.equals(engineTypeName, "V2500")) {
    		return ENGSLSORDV2500;
    	}

    	return ENGSLSORDOTHER;
    }

	public static InductionMiscKeys of(String name) {
		return Stream.of(InductionMiscKeys.values())
                     .filter(s -> s.name().equalsIgnoreCase(name))
                     .findFirst()
                     // Maps to HttpStatus.BAD_REQUEST request status.
                     .orElseThrow(()-> new IllegalArgumentException("Invalid InductionMiscKeys value: " + name));
	}

    @Component
    public static class InductionMiscKeysConverter implements Converter<String, InductionMiscKeys> {

        @Override
        public InductionMiscKeys convert(String value) {
            return InductionMiscKeys.of(value);
        }
    }
}
