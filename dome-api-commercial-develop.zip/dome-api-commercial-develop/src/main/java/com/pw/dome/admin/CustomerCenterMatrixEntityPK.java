package com.pw.dome.admin;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Embeddable
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CustomerCenterMatrixEntityPK implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "EC_ID", insertable = false, updatable = false)
	private String engineCenterId;

	@Column(name = "CUST_ID", insertable = false, updatable = false)
	private String customerId;

	@Column(name = "ENG_TYPE_ID", insertable = false, updatable = false)
	private String engineTypeId;

	@Override
	public int hashCode() {
		return Objects.hash(customerId, engineCenterId, engineTypeId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof CustomerCenterMatrixEntityPK))
			return false;
		CustomerCenterMatrixEntityPK other = (CustomerCenterMatrixEntityPK) obj;
		return Objects.equals(customerId, other.customerId) && Objects.equals(engineCenterId, other.engineCenterId)
				&& Objects.equals(engineTypeId, other.engineTypeId);
	}
}