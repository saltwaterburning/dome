package com.pw.dome.engine.networkmanagement.excel;

interface Consts {

	interface SQL {
		String AND_NOT_DISABLED = " AND cast(nvl(engineAsset.disabled, 0) as int) = 0";

		/**
		 * Select clause part 1 used by management & removal queries.
		 */
		String SELECT_CLAUSE1 =
"""
SELECT contract.accessoryCoverage AS accessoryCoverage,
   CAST(DECODE(contract.refurbPayStructure, '1', 'Y', 'N') AS java.lang.String) AS refurbPayStructure,
   COALESCE(event.removalDate, engTrack.engtrackRemoval) AS actualRemoval,
   contract.description AS contractDescription,
   contract.endDate AS coverageEndDate,
   contract.leaseReturnCoverage AS leaseReturnCoverage,
   contract.leaseReturnDate AS leaseReturnDate,
   contract.llpCoverage AS llpCoverage,
   contract.s1RetrofitCoverage AS s1RetrofitCoverage,
   contract.shippingCoverage AS shippingCoverage,
   contract.subFleet AS contractSubFleet,
   contract.svs AS contractedSvs,
   contract.type AS contractType,
   contract.years AS contractedYears,
   customer.name AS customerName,
   customer.shortName AS operator,
   engTrack.engExternalAssetCompleteDate AS externalAssetComplete,
   engTrack.engineActualCoreAssemblyDate AS actualCoreAssembly,
   engTrack.engineActualShipToCustDate AS actualShipCustomer,
   engTrack.engineExternalCoreAssemblyDate AS externalCoreAssembly,
   engTrack.engineExternalGate1CloseDate AS externalGate1Close,
   engTrack.engineExternalGate3CloseDate AS externalGate3Close,
   engTrack.engineExternalGate3StartDate AS externalGate3Start,
   engTrack.engineExternalInductDate AS externalInduc,
   engTrack.engineExternalReceiptDate AS externalReceipt,
   engTrack.engineExternalReceiveDate AS externalReceiving,
   engTrack.engineExternalShipDate AS externalShip,
   engTrack.engineExternalShipToCustDate AS externalShipCustomer,
   engTrack.engineExternalTestCompleteDate AS externalTestComplete,
   engTrack.engineExternalTestStartDate AS externalTestStart,
   engTrack.enginePlanCoreAssemblyDate AS forecastCoreAssembly,
   engTrack.enginePlanShipToCustDate AS forecastShipCustomer,
   engTrack.engtrackActualGate3Close AS actualGate3Close,
   engTrack.engtrackActualKitComplete AS actualKitComplete,
   engTrack.engtrackActualReceivingDate AS actualReceiving,
   engTrack.engtrackActualTestComplete AS actualTestComplete,
   engTrack.engtrackGate3Act AS actualGate3Start,
   engTrack.engtrackIndDate AS actualInduction,
   engTrack.engtrackPlanEngComplete AS forecastAssetComplete,
   engTrack.engtrackPlanGate3CloseDate AS forecastGate3Close,
   engTrack.engtrackPlanIndDate AS forecastInduction,
   engTrack.engtrackPlanKitComplete AS forecastKitComplete,
   engTrack.engtrackPlanRecDate AS forecastReceipt,
   engTrack.engtrackPlanRemovalDate AS forecastRemoval,
   engTrack.engtrackPlanRevDate AS forecaseReceiving,
   engTrack.engtrackPlanTestStartDate AS forecastTestStart,
   engTrack.engtrackPlnShipDate AS forecastShip,
   engTrack.engtrackRecDate AS actualReceipt,
   engTrack.engtrackShipDate AS actualAssetComplete,
   engTrack.engtrackShipmentDate AS actualShip,
   engTrack.engtrackWorkOrderExtKitComplete AS externalKitComplete,
   engTrack.gate3Plan AS forecastGate3Start,
   engTrack.standardAssemblyDate AS standardCoreAssembly,
   engTrack.standardAssetCompleteDate AS standardAssetComplete,
   engTrack.standardG1CloseDate AS standardGate1Close,
   engTrack.standardG3CloseDate AS standardGate3Close,
   engTrack.standardG3StartDate AS standardGate3Start,
   engTrack.standardInductionDate AS standardInduc,
   engTrack.standardKitDate AS standardKitComplete,
   engTrack.standardReceiptDate AS standardReceipt,
   engTrack.standardReceiveDate AS standardReceiving,
   engTrack.standardRemoveDate AS standardRemove,
   engTrack.standardShipDate AS standardShip,
   engTrack.standardShipToCustDate AS standardShipCustomer,
   engTrack.standardTestCompleteDate AS standardTestComplete,
   engTrack.standardTestStartDate AS standardTestStart,
   engTrack.testDate AS actualTestStart,
   engTrack.testPlanComplete AS forecastTestComplete,
   engine.category AS category,
   engine.csn AS csn,
   engine.cso AS cso,
   engine.engineID AS engineId,
   engine.gate1 AS actualGate1Close,
   engine.gate1Plan AS forecastGate1Close,
   engine.llpCycRemain AS llpCyclesRem,
   engine.parentEsn AS parentEsn,
   engine.priority AS priority,
   engine.purchaseOrder AS salesOrder,
   engine.revenue AS revenue,
   engine.salesOrderType AS orderType,
   engine.shopVisitNum AS shopVisitNumber,
   engine.tsn AS tsn,
   engine.tso AS tso,
   engine.warranty AS engineWarranty,
   engineAsset.disabled AS disabled,
   engineAsset.pwelManaged AS pwelAsset,
   engineAsset.thrust AS thrust,
   engineCenter.name AS maintenanceCenter,
   engineType.name AS engineType,
   event.removalDateRecorded as removalDateRecorded,
   event.removalReason AS removalReason,
""";

	/**
	 * Select clause part 2 used for management query.
	 * Includes Engine & possible EngineEvent columns.
	 */
	String SELECT_MGMT_CLAUSE2 =
"""
   engine.esn AS esn,
   engine.eventId AS eventId,
""";

	/**
	 * Select clause part 2 used for removal query.
	 * Includes Engine & EngineEvent columns.
	 */
	String SELECT_REMOVE_CLAUSE2 =
"""
   event.pk.esn AS esn,
   event.pk.eventId AS eventId,
""";

	/**
	 * Select clause part 3 used by management & removal queries.
	 */
	String SELECT_CLAUSE3 =
"""
   odin.accyDeliveryDate AS accyDelivery,
   odin.actualRecEbuDate AS actualArrivalAtEbu,
   odin.adListDate AS adListDate,
   odin.aimAllocationDate AS aimAllocation,
   odin.cfdFm AS cfdFm,
   odin.comments AS comment,
   odin.contractRemoval AS contractualRemoval,
   odin.currentLocation AS currentLocation,
   odin.customerApprovalDate AS customerApprovalDate,
   odin.ebuShop AS planEbuShop,
   odin.estimatedWorkscope AS estimatedWorkscope,
   odin.investigationCategory as investigationCategory,
   odin.fanBladeMapDate AS fanBladeMapDate,
   odin.fhaEligible AS fhaEligibilityRemoval,
   odin.investigationEngine AS investigationEngine,
   odin.llpDeliveryDate AS llpDelivery,
   odin.llpReplaceType AS llpReplacementType,
   odin.nisDeliveryDate AS nisDelivery,
   odin.powerEngineer AS powerplantEngineer,
   odin.projRecEbuDate AS etaAtEbu,
   odin.rslPO AS rslPo,
   odin.smiNeedDate as smiNeedDate,
   odin.speidPO AS speidPo,
   odin.svClass AS svClassificationCenter,
   odin.tarCheckbox AS tarCheckbox,
   odin.testAtReceipt AS tarDate,
   odin.upgradeEligible AS upgradeEligibility,
   odin.wsDraftCompleteAccyDate AS wsDraftCompleteAccyDate,
   odin.wsDraftCompleteEngDate AS wsDraftCompleteEngDate,
   odin.wsInitiationDate AS wsInitialDate,
   odin.wsOrigReleaseDate AS wsOriginalReleaseDate
""";

	String FROM_MGMT_CLAUSE =
"""
FROM EngineEntity engine
INNER JOIN EngineTrackingEntity engTrack ON engTrack.engtrackId = engine.engineID
LEFT OUTER JOIN EngineAssetEntity engineAsset ON engineAsset.esn = engine.esn
LEFT OUTER JOIN CustomerEntity customer ON customer.customerID = cast(nvl(engine.customerID, engineAsset.operatorID) AS java.lang.String)
AND customer.active = true
LEFT OUTER JOIN OdinEntity odin ON odin.engineId = engine.engineID
LEFT OUTER JOIN EngineGroupEntity engineGroup ON engineGroup.engineGroupID = engine.groupID
LEFT OUTER JOIN EngineCenterEntity engineCenter ON engineCenter.id = odin.maintenanceCenter
LEFT OUTER JOIN EngineEventEntity event ON (event.pk.esn = engine.esn
                                            AND event.pk.eventId = engine.eventId)
LEFT OUTER JOIN EngineContractEntity contract ON contract.esn = engine.esn
LEFT OUTER JOIN SlotEntity slot ON slot.slotID = engine.slotID
LEFT OUTER JOIN EngineTypeEntity engineType ON engineType.engineTypeID = engine.engineTypeId
""";

	String WHERE_MGMT_CLAUSE =
"""
WHERE (
      :ignoreCustId = true
      OR engine.customerID IN (:custIds)
      )
   AND (
      engine.engineTypeId IN (:engTypes)
      )
   AND (
      odin.maintenanceCenter IN (:engCenters)
      )
   AND (
      :ignoreContractType = true
      OR contract.type IN (:contractTypes)
      )
   AND engine.moduleID is null
""" + AND_NOT_DISABLED;

	String ORDER_BY_CLAUSE =
"""
ORDER BY esn, eventId
""";

	String FROM_REMOVED_CLAUSE =
"""
FROM EngineEventEntity event
LEFT OUTER JOIN EngineEntity engine ON engine.esn = event.pk.esn
AND engine.eventId = event.pk.eventId
AND engine.moduleID is null
LEFT OUTER JOIN EngineAssetEntity engineAsset ON engineAsset.esn = event.pk.esn
AND engineAsset.eventId = event.pk.eventId
LEFT OUTER JOIN CustomerEntity customer ON customer.customerID = cast(nvl(engineAsset.operatorID, engine.customerID) AS java.lang.String)
AND customer.active = true
LEFT OUTER JOIN EngineContractEntity contract ON contract.esn = event.pk.esn
LEFT OUTER JOIN EngineTrackingEntity engTrack ON engTrack.engtrackId = engine.engineID
AND engTrack.engtrackShipmentDate is null
LEFT OUTER JOIN OdinEntity odin ON odin.esn = event.pk.esn
AND odin.eventId = event.pk.eventId
LEFT OUTER JOIN SlotEntity s ON s.slotID = cast(nvl(engineAsset.slotId, engine.slotID) AS java.lang.Integer)
LEFT OUTER JOIN EngineCenterEntity engineCenter ON engineCenter.id = odin.maintenanceCenter
LEFT OUTER JOIN EngineTypeEntity engineType ON engineType.engineTypeID = engineAsset.engineTypeID
""";

	String WHERE_REMOVED_CLAUSE =
"""
WHERE event.planned = false
   AND event.shipped = false
   AND (
      engineAsset.engineTypeID IN (:engTypes)
      )
""" + AND_NOT_DISABLED;


	/**
	 * Combine JPQL fragments to complete the query.
	 */
	String NETWORK_MANAGEMENT = SELECT_CLAUSE1 +
			                    SELECT_MGMT_CLAUSE2 +
			                    SELECT_CLAUSE3 +
			                    FROM_MGMT_CLAUSE +
			                    WHERE_MGMT_CLAUSE +
			                    ORDER_BY_CLAUSE;


	/**
	 * Combine JPQL fragments to complete the query.
	 */
	String REMOVED_NETWORK_MANAGEMENT = SELECT_CLAUSE1 +
			                            SELECT_REMOVE_CLAUSE2 +
			                            SELECT_CLAUSE3 +
			                            FROM_REMOVED_CLAUSE +
			                            WHERE_REMOVED_CLAUSE +
			                            ORDER_BY_CLAUSE;
	}
}
