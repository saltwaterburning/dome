package com.pw.dome.calendar.inductionplanning;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Builder
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class InductionPlanningEngine {
	private String category;
	private String categoryCode;
	private int dayOfMonth;
	private String engineCenterCode;
	private String engineCenterID;
	private String engineCenterName;
	private Integer engineID;
	private String esn;
	private Integer shopVisitType;
	private Integer slotCount;
	private Integer slotID;
}
