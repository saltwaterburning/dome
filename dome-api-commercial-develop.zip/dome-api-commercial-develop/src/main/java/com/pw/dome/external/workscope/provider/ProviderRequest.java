package com.pw.dome.external.workscope.provider;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;

/**
 * Request from WST for Provider to creation, update or deletion.
 */
public record ProviderRequest(@NotEmpty List<Provider> data) {

}
