package com.pw.dome.activity;

import static java.util.Objects.isNull;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;

import com.pw.dome.calendar.induction.CalendarEngine;
import com.pw.dome.calendar.induction.CalendarShopVisit;
import com.pw.dome.calendar.slots.ShopVisitType;
import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.engine.EngineEntity;
import com.pw.dome.engine.odin.OdinDTO;
import com.pw.dome.mml.MmlDetails;
import com.pw.dome.mml.MmlEntity;
import com.pw.dome.mml.MmlMonthlyEntity;
import com.pw.dome.mml.MmlQuarterlyEntity;
import com.pw.dome.mml.MmlUpdateRequest;
import com.pw.dome.mml.le.DetailsDTO;
import com.pw.dome.mml.le.LeUpdateRequest;
import com.pw.dome.user.UserProfileResponse;
import com.pw.dome.util.SecurityUtils;
import com.pw.dome.wip.WorkInProgress;
import com.pw.dome.wip.pacing.PacingItemDTO;
import com.pw.dome.wip.smi.SmiRevision;
import com.pw.dome.wip.smi.SmiRevisions;

public class DataUtils {
    /*
     * FIXME- exceptions are bubbling up to request.
     *        test case- EngineServiceImpl.deleteEngineSlot()- DELETE- http://localhost:8080/v1/engines/183
     * FIXME- exceptions are failing the SQL transaction.
     * FIXME- add null checks before referencing object. See toActivityEntityDeleteEngine()
     */
    private static final Boolean TEST_EXCEPTION = false;

    private static final String USER_MAINTENANCE = "User Maintenance";
    private static final String INDUCTION_CALENDAR = "Induction Calendar";
    private static final String INDUCTION_PLANNING = "Induction Planning";
    private static final String WIP = "Work In Progress Management";
    private static final String MML_MONTHLY = "MML Monthly";
    private static final String MML_QUARTERLY = "MML Quarterly";
    private static final String LE_MONTHLY = "LE Monthly";
    private static final String LE_QUARTERLY = "LE Quarterly";
    
    private static final String ADD = "ADD";
    private static final String UPDATE = "UPDATE";
    private static final String DELETE = "DELETE";
    
    private DataUtils() {
        throw new IllegalAccessError();
    }

    static public ActivityEntity toActivityEntity(final UserProfileResponse from, final boolean isAdd) {
        return  ActivityEntity.builder()
        .item(USER_MAINTENANCE)
        .activityDate(LocalDateTime.now())
        .engineCenterId(from.getDefaultEngineCenterID())
        .engineType(from.getDefaultEngineTypeID())
        .userEmail(getUserName())
        .type(isAdd ? ADD : UPDATE)
        .description(String.format("User %s is %s", from.getEmailAddress(), (isAdd ? "created" : "updated")))
        .build();
    }
    
    static public ActivityEntity toActivityEntityCreateSlot(SlotEntity from) {
    	
    	if (from == null ) { // TODO hack!!!
    		from = new SlotEntity();
    	}

    	return  ActivityEntity.builder()
        .item(INDUCTION_CALENDAR)
        .activityDate(LocalDateTime.now())
        .engineCenterId(from.getEngineCenterID())
        .engineType(from.getEngineType() !=null ? from.getEngineType().getName() : null)
        .userEmail(getUserName())
        .type(ADD)
        .description(String.format("Add Shop Visit for date : %s/%s/%s, type : %s", from.getMonth(), from.getDay(), from.getYear(), from.getShopVisitType()))
        .build();
    }
    
    static public ActivityEntity toActivityEntityDeleteSlot(SlotEntity from) {
    	if (from == null) {
    		from = new SlotEntity();
    	}

    	return  ActivityEntity.builder()
        .item(INDUCTION_CALENDAR)
        .activityDate(LocalDateTime.now())
        .engineCenterId(from.getEngineCenterID())
        .engineType(from.getEngineType() !=null ? from.getEngineType().getName() : null)
        .userEmail(getUserName())
        .type(DELETE)
        .description(String.format("Removed Shop Visit for date : %s/%s/%s, type : %s", from.getMonth(), from.getDay(), from.getYear(), from.getShopVisitType()))
        .build();
    }
    
    static public ActivityEntity toActivityEntityUpdateSlot(final SlotEntity from, final ShopVisitType newVisitType) {
        return  ActivityEntity.builder()
        .item(INDUCTION_CALENDAR)
        .activityDate(LocalDateTime.now())
        .engineCenterId(from.getEngineCenterID())
        .engineType(from.getEngineType() !=null ? from.getEngineType().getName() : null)
        .userEmail(getUserName())
        .type(UPDATE)
        .description(String.format("Shop Visit changed for date : %s/%s/%s, from type : %s to type : ", from.getMonth(), from.getDay(), from.getYear(), from.getShopVisitType(), newVisitType))
        .build();
    }
    
    static public ActivityEntity toActivityEntityAddEngine(final SlotEntity slot, final CalendarShopVisit from) {
        
        CalendarEngine engine = null;
        
        if(!CollectionUtils.isEmpty(from.getEngines())){
            engine = from.getEngines().iterator().next();
        }
        return  ActivityEntity.builder()
        .item(INDUCTION_CALENDAR)
        .activityDate(LocalDateTime.now())
        .engineCenterId(slot == null ? null : slot.getEngineCenterID())
        .engineType(from.getEngineTypeName())
        .engineGroup(engine == null ? null : engine.getEngineGroupID())
        .engineModel(engine == null ? null : engine.getEngineModelID())
        .engineModule(engine == null ? null : engine.getModuleName())
        .engineSerialNumber(engine == null ? null : engine.getEsn())
        .customerID(engine == null ? null : engine.getCustomerID())
        .userEmail(getUserName())
        .type(ADD)
        .description(String.format("Engine %s added to Shop Visit for date : %s/%s/%s, type : %s", (engine == null ? null : engine.getEngineID()), slot.getMonth(), slot.getDay(), slot.getYear(), from.getShopVisitType()))
        .build();
    }
    
    static public ActivityEntity toActivityEntityDeleteEngine(final EngineEntity engine, final SlotEntity slot) {
        String dateStr = slot == null ? "" : slot.getMonth() + "/" + slot.getDay() + "/" + slot.getYear();
        ShopVisitType type = slot == null ? null : slot.getShopVisitType();

        if (TEST_EXCEPTION) throw new NullPointerException();

        return  ActivityEntity.builder()
        .item(INDUCTION_CALENDAR)
        .activityDate(LocalDateTime.now())
        .engineCenterId((engine == null ? null : (engine.getSlot() == null ? null : engine.getSlot() .getEngineCenterID())))
        .engineType(engine.getCategory())
        .engineGroup(engine.getGroupID())
        .engineModel(engine.getModelID())
        .engineModule(engine.getModule() == null ? null : engine.getModule().getModuleName())
        .engineSerialNumber(engine.getEsn())
        .customerID(engine.getCustomerID())
        .userEmail(getUserName())
        .type(DELETE)
        .description(String.format("Engine %s removed from Shop Visit for date : %s, type : %s", (engine == null ? null : engine.getEngineID()), dateStr, type))
        .build();
    }
    
    static public ActivityEntity toActivityEntity(SlotEntity slot, CalendarShopVisit response) {
        
        CalendarEngine engine = null;
        
        if(!CollectionUtils.isEmpty(response.getEngines())){
            engine = response.getEngines().iterator().next();
        }
        
        return  ActivityEntity.builder()
        .item(INDUCTION_CALENDAR)
        .activityDate(LocalDateTime.now())
        .engineType(response.getEngineTypeName())
        .engineGroup(engine == null ? null : engine.getEngineGroupID())
        .engineModel(engine == null ? null : engine.getEngineModelID())
        .engineModule(engine == null ? null : engine.getModuleName())
        .engineSerialNumber(engine == null ? null : engine.getEsn())
        .customerID(engine == null ? null : engine.getCustomerID())
        .userEmail(getUserName())
        .type(UPDATE)
        .description(String.format("Engine %s changed slot date to %s/%s/%s", (engine == null ? null : engine.getEngineID()), slot.getMonth(), slot.getDay(), slot.getYear()))
        .build();
    }
    
    static public ActivityEntity toActivityEntity(WorkInProgress response) {
        
        return  ActivityEntity.builder()
        .item(WIP)
        .activityDate(LocalDateTime.now())
        .engineCenterId(response.getEngineCenterId())
        .engineType(response.getEngineTypeName())
        .engineGroup(response.getEngineGroupId())
        .engineModel(response.getEngineModelId())
        .engineSerialNumber(response.getEngineSN())
        .userEmail(getUserName())
        .type(UPDATE)
        .description("WIP Management details updated")
        .build();
    }
    
    static public ActivityEntity toActivityEntity(PacingItemDTO response, Integer pacingId, EngineEntity engine) {
        
        String description = "";
        if(pacingId == null) {
            description = String.format("Pacing item %s is created", response.getPacingId());
        }else {
            description = String.format("Pacing item %s is updated", pacingId);
        }
        
        return  ActivityEntity.builder()
        .item(WIP)
		.activityDate(LocalDateTime.now())
		.engineCenterId((engine == null ? null : (engine.getSlot() == null ? null : engine.getSlot() .getEngineCenterID())))
		.engineType(engine == null ? null : engine.getEngineTypeId())
		.engineGroup(engine == null ? null : engine.getGroupID())						 
        .engineSerialNumber(response.getEngineSN())
        .userEmail(getUserName())
        .type(pacingId == null ? ADD : UPDATE)
        .description(description)
        .build();
        
    }
    
    static public ActivityEntity toActivityEntityPacingId(Integer pacingId) {
        
        return  ActivityEntity.builder()
        .item(WIP)
        .activityDate(LocalDateTime.now())
        .userEmail(getUserName())
        .type(DELETE)
        .description(String.format("Pacing item %s is deleted", pacingId))
        .build();
        
    }
    
    static public ActivityEntity toActivityEntity(OdinDTO from, EngineEntity engine) {
    	if (isNull(engine)) {
    		engine = new EngineEntity();
    	}

    	return  ActivityEntity.builder()
        .item(INDUCTION_PLANNING)
        .activityDate(LocalDateTime.now())
        .engineCenterId((engine == null ? null : (engine.getSlot() == null ? null : engine.getSlot().getEngineCenterID())))
		.engineType(engine == null ? null : engine.getEngineTypeId())
		.engineGroup(engine == null ? null : engine.getGroupID())
		.engineModel(engine == null ? null : engine.getModelID())
        .engineSerialNumber(engine == null ? null : engine.getEsn())
        .userEmail(getUserName())
        .type(UPDATE)
        .description("Induction Planning details updated : " + engine.getEngineID())
        .build();
    }
    
    static public ActivityEntity toActivityEntity(SmiRevisions from, EngineEntity engine) {
        
        String smi = "";
        List<SmiRevision> engineRevisions = from.getEngineRevisions();
        for(SmiRevision revision : engineRevisions) {
            smi = smi + ", " + revision.getSmiId();
        }
        
        return  ActivityEntity.builder()
        .item(WIP)
        .activityDate(LocalDateTime.now())
        .engineCenterId((engine == null ? null : (engine.getSlot() == null ? null : engine.getSlot() .getEngineCenterID())))
		.engineType(engine == null ? null : engine.getEngineTypeId())
		.engineGroup(engine == null ? null : engine.getGroupID())
        .engineSerialNumber(from.getEngineSN())
        .userEmail(getUserName())
        .type(UPDATE)
        .description(String.format("SMI Revisions %s updated", smi))
        .build();
    }
    
    static public ActivityEntity toActivityEntityDeleteSmi(Integer smiId) {
        
        return  ActivityEntity.builder()
        .item(WIP)
        .activityDate(LocalDateTime.now())
        .userEmail(getUserName())
        .type(DELETE)
        .description(String.format("SMI Revision %s is deleted", smiId))
        .build();
        
    }
    
    static public ActivityEntity toActivityEntitySaveMonthlyMml(final MmlUpdateRequest mmlUpdateRequest, MmlMonthlyEntity mml) {
    	Optional<MmlDetails> request = mmlUpdateRequest.getMmlDetails().stream().filter(req -> req.getEngineId().equals(mml.getEngineId())).findFirst();
    	String esn = "";
    	Integer engineId = null;
    	String engGroupId = "";
    	if(request.isPresent()) {
    		engineId = request.get().getEngineId();
    		esn = request.get().getEngineSerialNumber();
    		engGroupId = request.get().getEngineGroupId();
    	}
    	return  ActivityEntity.builder()
        .item(MML_MONTHLY)
        .activityDate(LocalDateTime.now())
        .userEmail(getUserName())
        .type(ADD)
        .engineGroup(engGroupId)
        .engineCenterId(mmlUpdateRequest.getEngineCenterId())
        .engineSerialNumber(esn)
        .description(String.format("MML monthly entity is added for month : %s, year : %s and engineId %s", mmlUpdateRequest.getMonth(), mmlUpdateRequest.getYear(), engineId))
        .build();
    }
    
    static public ActivityEntity toActivityEntityDeleteMonthlyMml(final MmlUpdateRequest mmlUpdateRequest, final List<MmlEntity> existingMmlEntities, Integer mmlEngineIdToDelete) {
    	Optional<MmlEntity> request = existingMmlEntities.stream().filter(req -> req.getEngineId().equals(mmlEngineIdToDelete)).findFirst();
    	String esn = "";
    	String engGroupId = "";
    	if(request.isPresent()) {
    		esn = request.get().getEngineSerialNumber();
    		engGroupId = request.get().getEngineGroupId();
    	}
        return  ActivityEntity.builder()
        .item(MML_MONTHLY)
        .activityDate(LocalDateTime.now())
        .userEmail(getUserName())
        .type(DELETE)
        .engineGroup(engGroupId)
        .engineCenterId(mmlUpdateRequest.getEngineCenterId())
        .engineSerialNumber(esn)
        .description(String.format("MML monthly entity is deleted for month : %s, year : %s and engineId %s", mmlUpdateRequest.getMonth(), mmlUpdateRequest.getYear(), mmlEngineIdToDelete))
        .build();
    }
    
    static public ActivityEntity toActivityEntitySaveQuarterlylyMml(final MmlUpdateRequest mmlUpdateRequest, MmlQuarterlyEntity mml) {
    	Optional<MmlDetails> request = mmlUpdateRequest.getMmlDetails().stream().filter(req -> req.getEngineId().equals(mml.getEngineId())).findFirst();
    	String esn = "";
    	Integer engineId = null;
    	String engGroupId = "";
    	if(request.isPresent()) {
    		engineId = request.get().getEngineId();
    		esn = request.get().getEngineSerialNumber();
    		engGroupId = request.get().getEngineGroupId();
    	}
        
        return  ActivityEntity.builder()
        .item(MML_QUARTERLY)
        .activityDate(LocalDateTime.now())
        .userEmail(getUserName())
        .type(ADD)
        .engineCenterId(mmlUpdateRequest.getEngineCenterId())
        .engineSerialNumber(esn)
        .engineGroup(engGroupId)
        .description(String.format("MML quarterly entity is added for quarter : %s, year : %s and engineId %s", mmlUpdateRequest.getMonth(), mmlUpdateRequest.getYear(), engineId))
        .build();
    }
    
    static public ActivityEntity toActivityEntityDeleteQuarterlyMml(final MmlUpdateRequest mmlUpdateRequest, final List<MmlEntity> existingMmlEntities, Integer mmlEngineIdToDelete) {
    	Optional<MmlEntity> request = existingMmlEntities.stream().filter(req -> req.getEngineId().equals(mmlEngineIdToDelete)).findFirst();
    	String esn = "";
    	String engGroupId = "";
    	if(request.isPresent()) {
    		esn = request.get().getEngineSerialNumber();
    		engGroupId = request.get().getEngineGroupId();
    	}
        
        return  ActivityEntity.builder()
        .item(MML_QUARTERLY)
        .activityDate(LocalDateTime.now())
        .userEmail(getUserName())
        .type(DELETE)
        .engineCenterId(mmlUpdateRequest.getEngineCenterId())
        .engineSerialNumber(esn)
        .engineGroup(engGroupId)
        .description(String.format("MML quarterly entity is deleted for quarter : %s, year : %s and engineId %s", mmlUpdateRequest.getMonth(), mmlUpdateRequest.getYear(), mmlEngineIdToDelete))
        .build();
    }
    
    static public ActivityEntity toActivityEntitySaveMonthlyLe(final LeUpdateRequest request, DetailsDTO leDetail) {
        
        return  ActivityEntity.builder()
        .item(LE_MONTHLY)
        .activityDate(LocalDateTime.now())
        .userEmail(getUserName())
        .type(ADD)
        .engineCenterId(request.getEngineCenterId())
        .engineSerialNumber(leDetail.getEngineSerialNumber())
        .engineGroup(leDetail.getEngineGroupId())
        .description(String.format("LE monthly entity is added added for month : %s, year : %s and engineIds %s", request.getMonth(), request.getYear(), leDetail.getEngineId()))
        .build();
    }
    
    static public ActivityEntity toActivityEntityDeleteMonthlyLe(final LeUpdateRequest request, List<DetailsDTO> lePlanDetails, Integer riskId) {
        Optional<DetailsDTO> detail = lePlanDetails.stream().filter(req -> req.getRiskId() == riskId).findFirst();
    	String esn = "";
    	String engGroupId = "";
    	Integer engineId = null;
    	if(detail.isPresent()) {
    		esn = detail.get().getEngineSerialNumber();
    		engGroupId = detail.get().getEngineGroupId();
    		engineId = detail.get().getEngineId();
    	}
    	
        return  ActivityEntity.builder()
        .item(LE_MONTHLY)
        .activityDate(LocalDateTime.now())
        .userEmail(getUserName())
        .type(DELETE)
        .engineCenterId(request.getEngineCenterId())
        .engineSerialNumber(esn)
        .engineGroup(engGroupId)
        .description(String.format("LE monthly entity is deleted for for month : %s, year : %s and engineId %s", request.getMonth(), request.getYear(), engineId))
        .build();
    }
    
    static public ActivityEntity toActivityEntitySaveQuarterlylyLe(final LeUpdateRequest request, DetailsDTO leDetail) {
        
        return  ActivityEntity.builder()
        .item(LE_QUARTERLY)
        .activityDate(LocalDateTime.now())
        .userEmail(getUserName())
        .type(ADD)
        .engineCenterId(request.getEngineCenterId())
        .engineSerialNumber(leDetail.getEngineSerialNumber())
        .engineGroup(leDetail.getEngineGroupId())
        .description(String.format("LE quarterly entity is added for quarter : %s, year : %s and engineIds %s", request.getMonth(), request.getYear(), leDetail.getEngineId()))
        .build();
    }
    
    static public ActivityEntity toActivityEntityDeleteQuarterlyLe(final LeUpdateRequest request, List<DetailsDTO> lePlanDetails, Integer riskId) {
    	Optional<DetailsDTO> detail = lePlanDetails.stream().filter(req -> req.getRiskId() == riskId).findFirst();
    	String esn = "";
    	String engGroupId = "";
    	Integer engineId = null;
    	if(detail.isPresent()) {
    		esn = detail.get().getEngineSerialNumber();
    		engGroupId = detail.get().getEngineGroupId();
    		engineId = detail.get().getEngineId();
    	}
        
        return  ActivityEntity.builder()
        .item(LE_QUARTERLY)
        .activityDate(LocalDateTime.now())
        .userEmail(getUserName())
        .type(DELETE)
        .engineCenterId(request.getEngineCenterId())
        .engineSerialNumber(esn)
        .engineGroup(engGroupId)
        .description(String.format("LE quarterly entity is deleted for quarter : %s, year : %s and engineId %s", request.getMonth(), request.getYear(), engineId))
        .build();
    }

    private static String getUserName() {
    	return SecurityUtils.getUserEmailAddress();
    }
}
