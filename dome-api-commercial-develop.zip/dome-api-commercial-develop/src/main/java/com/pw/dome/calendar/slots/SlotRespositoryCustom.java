package com.pw.dome.calendar.slots;

import java.util.List;

import com.pw.dome.calendar.inductionplanning.InductionPlanningEngine;

/**
 * @author John De Lello
 */
public interface SlotRespositoryCustom {
	List<InductionPlanningEngine> getInductionPlanningCalendarVisitSummary(String userEmailAddress,
			List<String> engineTypeIds, int month, int year);
}
