package com.pw.dome.external;

import javax.net.ssl.SSLException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import io.netty.resolver.DefaultAddressResolverGroup;
import reactor.netty.http.client.HttpClient;

/**
 * Instantiates a {@code WebClient} which doesn't do SSL verification.
 */
@Component
@Configuration
public class InsecureTrustWebClient {
	// Using Jetty ReactiveStream HttpClient.
//	@Bean
//	public WebClient createWebClient() throws SSLException {
//		SslContextFactory.Client sslContextFactory = new SslContextFactory.Client(true);
//	    HttpClient httpClient = new HttpClient();
//	    httpClient.setSslContextFactory(sslContextFactory);
//	    ClientHttpConnector connector = new JettyClientHttpConnector(httpClient);
//
//	    return WebClient.builder().clientConnector(connector).build();
//	}

	// Using Reactor Netty.
	@Bean
	public WebClient createWebClient() throws SSLException {
	    SslContext sslContext = SslContextBuilder
	            .forClient()
	            .trustManager(InsecureTrustManagerFactory.INSTANCE)
	            .build();
	    HttpClient httpClient = HttpClient.create().resolver(DefaultAddressResolverGroup.INSTANCE).secure(t -> t.sslContext(sslContext));
	    return WebClient.builder().clientConnector(new ReactorClientHttpConnector(httpClient)).build();
	}
}
