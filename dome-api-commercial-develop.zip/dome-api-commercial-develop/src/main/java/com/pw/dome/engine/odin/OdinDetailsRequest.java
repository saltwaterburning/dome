package com.pw.dome.engine.odin;

import jakarta.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request to retrieve the ODIN details on the Induction Planning screen using primary indexes where possible.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
class OdinDetailsRequest {
  private Integer engineAssetId;

  private Integer engineId;

  @NotBlank(message = "{NotBlank.required}")
  private String esn;

  private Integer eventId;

  private Integer odinId;

  private Integer removedEngineId;
}
