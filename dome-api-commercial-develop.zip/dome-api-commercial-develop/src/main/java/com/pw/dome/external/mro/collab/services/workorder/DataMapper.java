package com.pw.dome.external.mro.collab.services.workorder;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.engine.comments.CommentEntity;
import com.pw.dome.external.mro.collab.services.comments.MroComment;
import com.pw.dome.external.mro.collab.services.pacingitems.MroPacingItem;
import com.pw.dome.wip.pacing.PacingItemEntity;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

	@Mapping(target = "logEmail", source = "cmt.logEmail")
	MroComment toMroComment(CommentEntity cmt, MroWorkOrderUpdateRequest request);

	@Mapping(target = "description", source = "entity.partDesc")
	@Mapping(target = "esn", source = "entity.engSN")
	@Mapping(target = "subCategory", source = "entity.subcategory")
	MroPacingItem toMroPacingItem(PacingItemEntity entity, MroWorkOrderUpdateRequest request);
}
