package com.pw.dome.engine.odin;

import static com.pw.dome.engine.odin.Consts.SQL.FIND_WITH_NULL_ARGS;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
/**
 * @author John De Lello
 */
@Repository
public interface EngineOdinRepository extends JpaRepository<OdinEntity, Integer>	
{
    /**
     * Returns matching ODIN record(s) and allowing null parameters.
     * 
     * @param esn may not be nullable
     * @param engineId be nullable
     * @param eventId be nullable
     * 
     * @return matching ODIN record(s)
     */
    @Query(FIND_WITH_NULL_ARGS)
    List<OdinEntity> findByEsnAndEngineIdAndEventId(String esn, Integer engineId, Integer eventId);
}
