package com.pw.dome.admin;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import com.pw.dome.jpa.AbstractEntityWithEmbeddedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "DOME_CUST_CENTER_MATRIX")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
	public class CustomerCenterMatrixEntity extends AbstractEntityWithEmbeddedId<CustomerCenterMatrixEntityPK> {
	@EmbeddedId
	private CustomerCenterMatrixEntityPK pk;

	@Override
	public CustomerCenterMatrixEntityPK getId() {
		return pk;
	}
}
