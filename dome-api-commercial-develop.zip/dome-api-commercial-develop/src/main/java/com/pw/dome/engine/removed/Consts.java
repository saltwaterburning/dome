package com.pw.dome.engine.removed;

import com.pw.dome.engine.phase.EnginePhases;

interface Consts {

	String AND_NOT_DISABLED = " AND cast(nvl(r.engineAsset.disabled, 0) as int) = 0";

	/**
     * Removed Engines/Asset queries.
     * 
     * @see EnginePhases
     * @see <a href="https://sqlformat.org/" target="_blank">SQL Format</a>
     */
    interface SQL {
        /**
         * 
         */
//      @Deprecated // Returns multiple rows.
//        String REMOVED_DETAILS =
//        "SELECT e " +
//        "FROM EngineRemovedEntity e " +
//        "LEFT JOIN FETCH e.engineAsset EngineAssetEntity " +
//        "LEFT JOIN FETCH EngineAssetEntity.operator Customer " +
//        "WHERE e.assetID = ?1" +
//        "  AND UPPER(e.esn) = UPPER(?2)" +
//        "  ORDER BY e.removalEventID";

        String REMOVED_DETAILS_BY_ID =
        "SELECT r " +
        "FROM EngineRemovedEntity r " +
        "LEFT JOIN FETCH r.engineAsset EngineAssetEntity " +
        "LEFT JOIN FETCH EngineAssetEntity.operator CustomerEntity " +
        "WHERE r.removedEngineID = ?1" +
        AND_NOT_DISABLED;
    }
}
