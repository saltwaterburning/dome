/*
 * Provides hosted services for the Workscope Tool.
 */
package com.pw.dome.external.workscope.services;