package com.pw.dome.engine.comments;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/engines/comments")
class CommentsController {
	@Autowired
	private CommentsService commentsSvc;
	
	/**
	 * @api {get} /v1/engines/comments/:engineId Get comments for specified Engine Id sorted by most recently modified first
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/engines/comments/:engineId
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName getEngineComments
     * @apiGroup Engine Comments
     * @apiDescription Returns the comments for specified Engine Id sorted by most recent first
     * @apiSuccess {Object[]} comments The array of comments
     * @apiSuccess {Number} comments.commentId The comments identifier
     * @apiSuccess {String} comments.dateUpdated The comments creation date (Ex: 2019-12-19 10:58:35)
     * @apiSuccess {Boolean} comments.external The external indicator
     * @apiSuccess {String} comments.logEmail The comments created-by user
     * @apiSuccess {String} comments.firstName The first name of the comments created-by user
     * @apiSuccess {String} comments.lastName The last name of the comments created-by user
     * @apiSuccess {String} comments.notes The user comments
     * @apiUse Error
     * @apiUse Error400
     * @apiUse Error401
     * @apiUse Error500
     **/	
    @GetMapping(path = "/{engine-id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<CommentResponse> getEngineComments(
    		@PathVariable(name = "engine-id")
    		Integer engineId) {
    	CommentResponse response = commentsSvc.findByEngId(engineId);
    	return ResponseEntity.ok(response);
    }

    /**
	 * @api {post} /v1/engines/comments/:engineId Create Engine Comments 
     * @apiExample {curl} Example usage: 
     *      curl --request POST
     *           --url http://localhost:8080/v1/engines/comments/:engineId
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName insertEngineComments
     * @apiGroup Engine Comments
     * @apiDescription Returns the saved comments
     * @apiSuccess {Boolean} external The external indicator
     * @apiSuccess {String} notes The user comments
     * @apiUse Error
     * @apiUse Error500
     **/
    @PostMapping(path = "/{engine-id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Comment> insertEngineComments(
    		@PathVariable(name = "engine-id")
    		Integer engineId,
    		@Valid
    		@RequestBody
    		Comment request) {
    	Comment response = commentsSvc.insert(engineId, request);
    	return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/{engine-id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Comment> updateEngineComments(
    		@PathVariable(name = "engine-id")
    		Long engineId,
    		@Valid
    		@RequestBody
    		Comment request) {
    	Comment response = commentsSvc.update(engineId, request);
    	return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/{comment-id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Comment> deleteEngineComment(
    		@PathVariable(name = "comment-id")
    		Long commentId) {
    	commentsSvc.delete(commentId);
    	return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
