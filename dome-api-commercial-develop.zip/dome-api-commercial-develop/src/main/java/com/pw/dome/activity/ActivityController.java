package com.pw.dome.activity;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/actvity")
public class ActivityController {

    @Autowired
    private ActivityService activityService;
    
    @GetMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Activity>> getActivities() {
        List<Activity> response = activityService.findAll();
        return ResponseEntity.ok(response);
    }
    
    @PostMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Activity> addActivity(
            @Valid
            @RequestBody
            Activity request) {
        Activity response = activityService.save(request);
        return ResponseEntity.ok(response);
    }
}
