package com.pw.dome.engine.comments;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pw.dome.exception.BadRequestException;
import com.pw.dome.exception.NotFoundException;
import com.pw.dome.external.mro.collab.client.MroWebClientAsyncService;
import com.pw.dome.util.SecurityUtils;

/**
 * Provides Get, Insert, and Update of comments history.
 */
@Service
public class CommentsService {
	@Autowired
	private CommentsRepo commentsRepo;
	@Autowired
	private MroWebClientAsyncService mroSvc;

	public void delete(Long commentId) {
		if (!commentsRepo.existsById(commentId.intValue())) {
			throw new NotFoundException("Provided commentId doesn't exist.");
		}

		CommentEntity comment = commentsRepo.findById(commentId.intValue()).orElse(null);
		if (Objects.nonNull(comment)) {
		  mroSvc.deleteComment(commentId);
		  commentsRepo.deleteById(commentId.intValue());
		}
	}
	
	public CommentResponse findByEngId(int engineId) {
		List<CommentEntity> comments = commentsRepo.findByEngineIdOrderByDateUpdatedDesc(engineId);
		if (comments.isEmpty()) {
			throw new NotFoundException("No comments for engine Id: " + engineId);
		}
		
		return new CommentResponse(comments.stream().map(s->DataUtils.toComment(s, s.getUser())).collect(Collectors.toList()));
	}

	public Comment insert(int engineId, Comment request) {
		Integer commentId;
		if ((commentId = request.getCommentId()) != null) {
			String msg = String.format("Comment id (%d) not expected for engine Id: %d",
	                                   commentId, engineId);
			throw new BadRequestException(msg);
		}
			
		CommentEntity entity = DataUtils.toCommentEntity(engineId, request);
		entity = commentsRepo.save(entity);
		mroSvc.pushComments(Arrays.asList(entity));
		return DataUtils.toComment(entity, SecurityUtils.getUserProfile());
	}

	public Comment update(long engineId, Comment request) {
		CommentEntity entity;
		Integer commentId = request.getCommentId();

		if ((entity = commentsRepo.findById(commentId).orElse(null)) == null) {
			String msg = String.format("The comment id (%d) wasn't found.", commentId);
			throw new BadRequestException(msg);
		} else if (entity.getEngineId() != engineId) {
			String msg = String.format("Unexpected engine Id (%d) for comment id (%d). Expected engine Id: %d",
					entity.getEngineId(), commentId, engineId);
			throw new BadRequestException(msg);
		}

		entity.setExternal(request.getExternal()); // Only external indicator is modifiable.
		entity.setNotes(Objects.isNull(request.getNotes()) ? "" : request.getNotes());
		entity.setLogEmail(SecurityUtils.getUserEmailAddress());
		entity = commentsRepo.save(entity);

		mroSvc.pushComments(Arrays.asList(entity));

		return DataUtils.toComment(entity, SecurityUtils.getUserProfile());
	}
}
