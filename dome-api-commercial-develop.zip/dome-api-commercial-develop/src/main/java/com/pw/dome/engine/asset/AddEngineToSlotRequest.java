package com.pw.dome.engine.asset;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class AddEngineToSlotRequest {
//	@NotNull
	private String category;

	@NotNull
	@Size(min = 0, max = 6)
	private String customerId;

	private Integer engineAssetID;
//	@NotNull
//	@Size(min = 0, max = 10)
//	private String engineCenterId;
//	@NotNull
//	@Size(min = 0, max = 10)
//	private String engineTypeId;

	// May be null if there is no EngineEventEntity record.
	private Integer eventId;

	private Integer odinId;

	// @NotNull
	private String salesOrderType;

	private Integer slotID;

//	private String subVisitType;
}
