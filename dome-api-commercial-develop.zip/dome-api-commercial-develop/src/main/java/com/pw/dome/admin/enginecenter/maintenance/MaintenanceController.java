package com.pw.dome.admin.enginecenter.maintenance;

import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequestMapping("/v1/admin/engines/management")
//@Slf4j
public class MaintenanceController {
	@Autowired
	private MaintenanceService maintenanceController;

	/**
     * @api {delete} /v1/admin/engines/management/:engineCenterId/:typeId Deletes an engine type from the engine center.
     * @apiExample {curl} Example usage:
     *      curl -X DELETE -H "Authorization: Bearer [token]" 
     *           http://localhost:8080/v1/admin/engines/management/:engineCenterId/:typeId
     * @apiName deleteType
     * @apiGroup Admin
     * @apiDescription Deletes the engine type from teh engine center.
     */
	@DeleteMapping(path = "/{engine-center-id}/{engine-type-id}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<String> deleteType(
    		@PathVariable(name = "engine-center-id")
    		final String ecId,
    		@PathVariable(name = "engine-type-id")
    		final String typeId) {
		maintenanceController.deleteEngineTypeFromEngineCenter(ecId, typeId);
		return new ResponseEntity<String>(NO_CONTENT);
	}

	/**
     * @api {delete} /v1/admin/engines/management/:engineCenterId/:typeId/:groupId Deletes an Engine group.
     * @apiExample {curl} Example usage:
     *      curl -X DELETE -H "Authorization: Bearer [token]" 
     *           http://localhost:8080/v1/admin/engines/management/:engineCenterId/:typeId/:groupId
     * @apiName deleteType
     * @apiGroup Admin
     * @apiDescription Deletes the Engine group.
     */
	@DeleteMapping(path = "/{engine-center-id}/{engine-type-id}/{engine-group-id}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<String> deleteGroup(
    		@PathVariable(name = "engine-center-id")
    		final String ecId,
    		@PathVariable(name = "engine-type-id")
    		final String typeId,
    		@PathVariable(name = "engine-group-id")
    		final String groupId) {
		maintenanceController.deleteEngineGroupFromEngineType(ecId, typeId, groupId);
		return new ResponseEntity<String>(NO_CONTENT);
	}

	/**
     * @api {delete} /v1/admin/engines/management/:engineCenterId/:typeId/:groupId/:modelId Deletes an Engine model.
     * @apiExample {curl} Example usage
     *      curl -X DELETE -H "Authorization: Bearer [token]" 
     *           http://localhost:8080/v1/admin/engines/management/:engineCenterId/:typeId/:groupId/:modelId
     * @apiName deleteModel
     * @apiGroup Admin
     * @apiDescription Deletes the Engine model.
     */
	@DeleteMapping(path = "/{engine-center-id}/{engine-type-id}/{engine-group-id}/{engine-model-id}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<String> deleteModel(
    		@PathVariable(name = "engine-center-id")
    		final String ecId,
    		@PathVariable(name = "engine-type-id")
    		final String typeId,
    		@PathVariable(name = "engine-group-id")
    		final String groupId,
    		@PathVariable(name = "engine-model-id")
    		final String modelId) {
		maintenanceController.deleteEngineModelFromEngineGroup(ecId, typeId, groupId, modelId);
		return new ResponseEntity<String>(NO_CONTENT);
	}

	/**
     * @api {get} /v1/admin/engines/management Get Active Engine Centers
     * @apiExample {curl} Example usage
     *      curl -X GET -H "Authorization: Bearer [token]" 
     *           http://localhost:8080/v1/admin/engines/management
     * @apiName getActiveEngineCenters
     * @apiGroup Admin
     * @apiDescription Returns all Active Engine Centers
     */
	@GetMapping(path = "", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineCentersResponse> getActiveEngineCenters() {
		return ResponseEntity.ok(maintenanceController.getAllEngineCenters());
	}

	/**
     * @api {get} /v1/admin/engines/management/:engineCenterId/:engineTypeId Get Active Engine Groups
     * @apiExample {curl} Example usage
     *      curl -X GET -H "Authorization: Bearer [token]" 
     *           http://localhost:8080/v1/admin/engines/management/:engineCenterId/:engineTypeId
     * @apiName getEngineGroups
     * @apiGroup Admin
     * @apiDescription Returns all Active Engine Groups
     */
	@GetMapping(path = "/{engine-center-id}/{engine-type-id}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineGroupsResponse> getEngineGroups(
    		@PathVariable(name = "engine-center-id")
    		final String ecId,
    		@PathVariable(name = "engine-type-id")
    		final String typeId) {
		return ResponseEntity.ok(maintenanceController.getAllEngineGroups(ecId, typeId));
	}

	/**
     * @api {get} /v1/admin/engines/management/:engineCenterId/:engineTypeId/:engineGroupId Get Active Engine Models
     * @apiExample {curl} Example usage
     *      curl -X GET -H "Authorization: Bearer [token]" 
     *           http://localhost:8080/v1/admin/engines/management/:engineCenterId/:engineTypeId/:engineGroupId
     * @apiName getEngineModels
     * @apiGroup Admin
     * @apiDescription Returns all Active Engine Models
     */
	@GetMapping(path = "/{engine-center-id}/{engine-type-id}/{engine-group-id}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineModelsResponse> getEngineModels(
    		@PathVariable(name = "engine-center-id")
    		final String ecId,
    		@PathVariable(name = "engine-type-id")
    		final String typeId,
    		@PathVariable(name = "engine-group-id")
    		final String groupId) {
		return ResponseEntity.ok(maintenanceController.getAllEngineModels(ecId, typeId, groupId));
	}

	/**
     * @api {get} /v1/admin/engines/management/:engineCenterId Get Active Engine Types
     * @apiExample {curl} Example usage
     *      curl -X GET -H "Authorization: Bearer [token]" 
     *           http://localhost:8080/v1/admin/engines/management/:engineCenterId
     * @apiName getEngineTypes
     * @apiGroup Admin
     * @apiDescription Returns all Active Engine Types
     */
	@GetMapping(path = "/{engine-center-id}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineTypesResponse> getEngineTypes(
    		@PathVariable(name = "engine-center-id")
    		final String ecId) {
		return ResponseEntity.ok(maintenanceController.getAllEngineTypes(ecId));
	}

	/**
	 * @api {post} /v1/admin/engines/management/ Updates or creates the Engine center(s).
	 * @apiExample {curl} Example usage
	 *      curl -X POST -H "Authorization: Bearer [token]" 
	 *           http://localhost:8080/v1/admin/engines/management/
	 * @apiName updateEngineCenters
	 * @apiGroup Admin
	 * @apiDescription Updates the supplied Engine center(s).
	 */
	@PostMapping(path = "", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineCentersResponse> save(
			@Valid
			@RequestBody
			EngineCentersResponse request) {
		return ResponseEntity.ok(maintenanceController.save(request));
	}

	/**
	 * @api {post} /v1/admin/engines/management/:engineCenterId Updates or creates the Engine type(s).
	 * @apiExample {curl} Example usage
	 *      curl -X POST -H "Authorization: Bearer [token]" 
	 *           http://localhost:8080/v1/admin/engines/management/:engineCenterId
	 * @apiName updateEngineTypes
	 * @apiGroup Admin
	 * @apiDescription Updates the supplied Engine type(s).
	 */
	@PostMapping(path = "/{engine-center-id}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineTypesResponse> save(
    		@PathVariable(name = "engine-center-id")
    		final String ecId,
			@Valid
			@RequestBody
			EngineTypesResponse request) {
		return ResponseEntity.ok(maintenanceController.save(ecId, request));
	}

	/**
	 * @api {post} /v1/admin/engines/management/:engineCenterId/:typeId Updates the supplied Engine group(s).
	 * @apiExample {curl} Example usage
	 *      curl -X POST -H "Authorization: Bearer [token]" 
	 *           http://localhost:8080/v1/admin/engines/management/:engineCenterId/:typeId
	 * @apiName updateEngineGroups
	 * @apiGroup Admin
	 * @apiDescription Updates the supplied Engine group(s).
	 */
	@PostMapping(path = "/{engine-center-id}/{engine-type-id}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineGroupsResponse> save(
    		@PathVariable(name = "engine-center-id")
    		final String ecId,
    		@PathVariable(name = "engine-type-id")
    		final String typeId,
			@Valid
			@RequestBody
			EngineGroupsResponse request) {
		return ResponseEntity.ok(maintenanceController.save(ecId, typeId, request));
	}

	/**
	 * @api {post} /v1/admin/engines/management/:engineCenterId/:typeId/:groupId Updates the supplied Engine models(s).
	 * @apiExample {curl} Example usage
	 *      curl -X POST -H "Authorization: Bearer [token]" 
	 *           http://localhost:8080/v1/admin/engines/management/:engineCenterId/:typeId/:groupId
	 * @apiName updateEngineModels
	 * @apiGroup Admin
	 * @apiDescription Updates the supplied Engine models(s).
	 */
	@PostMapping(path = "/{engine-center-id}/{engine-type-id}/{engine-group-id}", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineModelsResponse> save(
    		@PathVariable(name = "engine-center-id")
    		final String ecId,
    		@PathVariable(name = "engine-type-id")
    		final String typeId,
    		@PathVariable(name = "engine-group-id")
    		final String groupId,
			@Valid
			@RequestBody
			EngineModelsResponse request) {
		return ResponseEntity.ok(maintenanceController.save(ecId, typeId, groupId, request));
	}
}
