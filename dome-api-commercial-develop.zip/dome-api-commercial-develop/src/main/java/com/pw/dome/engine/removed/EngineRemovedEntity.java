/**
 * @author John De Lello
 */
package com.pw.dome.engine.removed;

import static org.hibernate.annotations.NotFoundAction.IGNORE;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import org.hibernate.annotations.NaturalId;
import org.hibernate.annotations.NotFound;

import com.pw.dome.engine.asset.EngineAssetEntity;
import com.pw.dome.jpa.AbstractEntityWithNaturalId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "DOME_REMOVED_ENGINES")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EngineRemovedEntity extends AbstractEntityWithNaturalId<Integer> {

	@Id
	@NaturalId
	@Column(name = "REMOVED_ENGINES_ID")
	private Integer removedEngineID;

	@Column(name = "ASSET_ID", insertable = false, updatable = false)
	private int assetID;

    @OneToOne
	@NotFound(action = IGNORE)
	@JoinColumns({
			@JoinColumn(name = "ASSET_ID", referencedColumnName = "ASSET_ID", insertable = false, updatable = false),
			@JoinColumn(name = "ESN", referencedColumnName = "ESN", insertable = false, updatable = false) })
	private EngineAssetEntity engineAsset;

	@Column(name = "ESN", insertable = false, updatable = false)
	private String esn;

	@Column(name = "REMOVAL_DATE")
	private LocalDate removalDate;

	@Column(name = "REMOVAL_DATE_REPORTED")
	private LocalDate removalDateReported;

	@Column(name = "REMOVAL_EVENT_ID")
	private Integer removalEventID;

	@Column(name = "REMOVAL_REASON")
	private String removalReason;

	@Column(name = "THRUST")
	private String thrust;

	@Override
	public Integer getId() {
		return removedEngineID;
	}
}
