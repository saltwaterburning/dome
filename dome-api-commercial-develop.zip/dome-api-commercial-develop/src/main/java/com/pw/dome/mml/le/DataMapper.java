package com.pw.dome.mml.le;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
    DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

//    @Mapping(target = "isOpp", source = "opportunity")
//    List<LeOppMonthEntity> map(List<LeDetails> details);
}
