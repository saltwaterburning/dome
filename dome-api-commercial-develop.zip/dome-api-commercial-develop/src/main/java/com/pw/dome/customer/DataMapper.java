package com.pw.dome.customer;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

	CustomerDTO toDTO(CustomerEntity entity);
	List<CustomerDTO> toDTO(List<CustomerEntity> entity);

	@Mapping(target = "customerIdValue", ignore = true)
	@Mapping(target = "region", ignore = true)
	CustomerEntity toEntity(CustomerDTO dto);

	List<CustomerEntity> toEntity(List<CustomerDTO> dto);

	@Mapping(target = "name", ignore = true)
	@Mapping(target = "shortName", ignore = true)
	void merge(CustomerEntity from, @MappingTarget CustomerEntity to);
}
