package com.pw.dome.induction.removal.records;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.Immutable;

import com.pw.dome.jpa.AbstractEntityWithImmutability;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
//@EntityListeners(PacingItemEntityListener.class)
@Table(name = "DOME_REMOVAL_RECORDS")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Immutable
class RemovalRecordsEntity extends AbstractEntityWithImmutability<Long>  {

	@Id
	@Column(name = "REMOVAL_ID")
	private Long removalId;

	@Column(name = "ATTACHMENT_NAME")
	private String attachmentName;

	@Column(name = "ATTACHMENT_DATE")
	private LocalDate attachmentDate;

	@Column(name = "CONTENTS")
	private String contents;

	@Column(name = "ESN")
	private String esn;

	@Column(name = "EVENT_ID")
	private Integer eventId;

	@Override
	public Long getId() {
		return removalId;
	}  
}
