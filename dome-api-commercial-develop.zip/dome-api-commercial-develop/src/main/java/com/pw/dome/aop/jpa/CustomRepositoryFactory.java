package com.pw.dome.aop.jpa;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.EntityManager;

import org.aopalliance.aop.Advice;
import org.apache.commons.lang3.ClassUtils;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactoryBean;
import org.springframework.data.repository.core.RepositoryInformation;
import org.springframework.data.repository.core.support.RepositoryFactorySupport;
import org.springframework.data.repository.core.support.RepositoryProxyPostProcessor;

import com.pw.dome.aop.AfterMethodsAdvise;
import com.pw.dome.aop.BeforeMethodsAdvise;

/**
 * Add {@link Advice} to a {@link JpaRepository} instance for the purpose of logging CRUD activities.
 * 
 * @param <R>
 * @param <T>
 * @param <I>
 */
final public class CustomRepositoryFactory<R extends JpaRepository<T, I>, T , I extends Serializable> extends JpaRepositoryFactoryBean<R, T, I> {
	@Autowired
    private ApplicationContext applicationContext;

    public CustomRepositoryFactory(Class<? extends R> repositoryInterface) {
        super(repositoryInterface);
    }

    @Override
    protected RepositoryFactorySupport createRepositoryFactory(EntityManager em) {
        RepositoryFactorySupport factory = super.createRepositoryFactory(em);
        factory.addRepositoryProxyPostProcessor(new RepoProxyPostProcessor());
        return factory;
    }

    final class RepoProxyPostProcessor implements RepositoryProxyPostProcessor {
//        final Advice advice;
        public RepoProxyPostProcessor() {
            super();
//            advice = new CrudRepoAdvice(svc);
        }

		@SuppressWarnings({ "unchecked", "rawtypes" })
		@Override
        public void postProcess(ProxyFactory factory, RepositoryInformation repositoryInformation) {
			Class<?> repo = repositoryInformation.getRepositoryInterface();

			String repoKey = repo.getName();
			Set<String> after = new HashSet<>();
			Set<String> before = new HashSet<>();

			for (Class<?> adviser : ClassUtils.getAllInterfaces(repo)) {
            	try {
            		if (AfterMethodsAdvise.class.isAssignableFrom(adviser) && after.add(repoKey)) {
            			AfterMethodsAdvise<?, ?> afterMethodsAdvise = applicationContext.getBean((Class<AfterMethodsAdvise>)adviser);
            			factory.addAdvice(afterMethodsAdvise);
            		}
            		else if (BeforeMethodsAdvise.class.isAssignableFrom(adviser) && before.add(repoKey)) {
            			BeforeMethodsAdvise<?, ?> beforeMethodsAdvise = applicationContext.getBean((Class<BeforeMethodsAdvise>)adviser);
            			factory.addAdvice(beforeMethodsAdvise);
            		}
            	} catch (Exception e) {
            		e.printStackTrace(System.err);
				}
            }
        }
    }
}