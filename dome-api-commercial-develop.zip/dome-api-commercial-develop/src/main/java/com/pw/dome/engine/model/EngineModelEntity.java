package com.pw.dome.engine.model;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.NaturalId;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.pw.dome.jpa.AbstractEntityWithNaturalId;
import com.pw.dome.util.hibernate.BooleanToActiveOrDisabledConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author John De Lello
 */
@Entity
@Table(name="DOME_ENG_MOD_MST")
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EngineModelEntity extends AbstractEntityWithNaturalId<String> {
	@Id
	@NaturalId
	@Column(name="ENG_MOD_ID")
	private String engineModelID;

	@Column(name="ENG_GROUP_ID")
	private String engineGroupID;

	@Column(name = "ENG_MOD_NAME")
	private String name;

	@JsonIgnore
	@Column(name = "ENG_MOD_ACTION", length=1)
	@Convert(converter = BooleanToActiveOrDisabledConverter.class)
	private boolean active;

	@Override
	public String getId() {
		return engineModelID;
	}
}
