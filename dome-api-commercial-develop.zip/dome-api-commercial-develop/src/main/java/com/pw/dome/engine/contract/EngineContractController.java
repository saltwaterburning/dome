package com.pw.dome.engine.contract;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.user.UserProfile;

/**
 * @author John De Lello
 */
@RestController()
@RequestMapping("/v1/engines/contracts")
public class EngineContractController {
	@Autowired
	private EngineContractService engineContractSvc;
	
	/**
	 * @api {get} /v1/engines/contracts/:esn Get Contract Data for Engine
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/engines/contracts/V12008
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName getEngineContractDetail
     * @apiGroup Engine Contracts
     * @apiParam {String} esn The ESN used to get the engine contract for
     * @apiDescription Returns the engine contract details for the specified engine ESN
     * @apiSuccess {String} esn The ESN of the engine
     * @apiSuccess {String} description The contract description
     * @apiSuccess {String} subFleet the sub-fleet of the contract
     * @apiSuccess {String} years The duration of the contract 
     * @apiSuccess {String} svs The SVS of the contract
     * @apiSuccess {String} endDate the end date of the contract 
     * @apiSuccess {String} leaseReturnDate the lease return date of the contract 
     * @apiSuccess {String} refurbPayStructure The refurb pay structure of the contract 
     * @apiSuccess {String} llpCoverage The LLP coverage of the contract 
     * @apiSuccess {String} s1RetrofitCoverage The S1 retrofit coverage of the contract 
     * @apiSuccess {String} leaseReturnCoverage The lease return coverage of the contract 
     * @apiSuccess {String} accessoryCoverage The accessory coverage of the contract 
     * @apiSuccess {String} shippingCoverage The shipping coverage of the contract 
     * @apiUse GetEngineContractDetailSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/	
    @GetMapping(path = "/{esn}", produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<EngineContractResponse>
    getEngineContractDetail(@AuthenticationPrincipal
    		                UserProfile userProfile,
    		                @PathVariable(name = "esn")
                            String esn) {

        EngineContractResponse response = engineContractSvc.findByEsnIgnoreCase(esn);
    	return ResponseEntity.ok(response);
    }

}
