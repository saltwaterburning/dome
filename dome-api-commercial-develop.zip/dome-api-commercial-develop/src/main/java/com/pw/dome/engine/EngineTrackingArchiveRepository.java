package com.pw.dome.engine;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EngineTrackingArchiveRepository extends JpaRepository<EngineTrackingArchiveEntity, Long> {
	
}
