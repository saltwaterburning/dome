package com.pw.dome.engine.odin.history;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OdinHistoryRepository extends JpaRepository<OdinHistoryEntity, Integer>	
{
	int deleteByEngineId(int engineId);

	List<OdinHistoryEntity> findByEsnAndEventIdOrderByPrelimInductionDateAsc(String esn, Integer eventId);
}
