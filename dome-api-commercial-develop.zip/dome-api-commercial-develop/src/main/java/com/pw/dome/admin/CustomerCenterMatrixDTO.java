package com.pw.dome.admin;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import lombok.Builder;

@Builder
public record CustomerCenterMatrixDTO (
	@NotNull
	@Size(min = 0, max = 10)
	String engineCenterId,

	@NotNull
	@Size(min = 0, max = 6)
	String customerId,

	@NotNull
	@Size(min = 0, max = 10)
	String engineTypeId) {
		;

}
