package com.pw.dome.external.mro.collab.client;

import java.time.Duration;

import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.server.ResponseStatusException;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

/**
 * @see https://stackoverflow.com/questions/60743614/spring-webclient-how-to-access-response-body-in-case-of-http-errors-4xx-5xx
 */
@Slf4j
public class MroClientResponseHandler {

    /**
     * Translation key for i18n
     */
    public final static String I18N_KEY_ERROR_TECHNICAL_EXCEPTION = "error.technical.exception";

    public static Mono<ResponseStatusException> manageError(ClientResponse clientResponse) {
        try {
            if (clientResponse.statusCode().is4xxClientError()) {
            	MroApiResponse response = clientResponse.bodyToMono(MroApiResponse.class).block(Duration.ofMinutes(5));
            	log.error("MRO Collab error: HttpStatus: {}, ResponseDetails: {}", clientResponse.statusCode(), response, clientResponse);
            } else { // Case when it's 5xx ClientError
                // User doesn't have to know which technical exception has happened
                return clientResponse.bodyToMono(ExceptionResponseDTO.class).flatMap(response -> {
                    return Mono.error(new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                            I18N_KEY_ERROR_TECHNICAL_EXCEPTION));
                });
            	
            }
    	} catch (Exception e) {
    		log.error(clientResponse.toString(), e);
		}

    	return null;
    }
 
    public static Mono<ResponseStatusException> manageSuccess(ClientResponse clientResponse) {
    	try {
    		MroApiResponse response = clientResponse.bodyToMono(MroApiResponse.class).block(Duration.ofMinutes(5));
    		log.info("MRO Collab response: HttpStatus: {}, ResponseDetails: {}", clientResponse.statusCode(), response, clientResponse);
    	} catch (Exception e) {
    		log.info(clientResponse.toString(), e);
		}

        return Mono.error(new ResponseStatusException(HttpStatus.OK,
                I18N_KEY_ERROR_TECHNICAL_EXCEPTION));
    }
}