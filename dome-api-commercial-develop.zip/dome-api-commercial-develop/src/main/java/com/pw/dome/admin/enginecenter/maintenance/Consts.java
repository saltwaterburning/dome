package com.pw.dome.admin.enginecenter.maintenance;

interface Consts {
	interface SQL {
		/** DELETE from dome_security_engine_center. */
		String DELETE_ENG_GROUP_FROM_ENGINE_SECURITY_CENTER =
		"DELETE from dome_security_engine_center WHERE ec_id = ?1 AND eng_type_id = ?2 AND eng_group_id = ?3";

		/** DELETE from dome_center_type_group. */
		String DELETE_ENG_TYPE_FROM_CENTER_TYPE_GROUP =
		"DELETE from dome_center_type_group WHERE ec_id = ?1 AND eng_type_id = ?2";

		/** */
		String DELETE_ENG_TYPE_FROM_ENG_TYPE_CENTER_MAP =
		"DELETE FROM dome_eng_type_center_map WHERE ec_center_id = ?1 AND ec_type_id = ?2";
		
		String DELETE_ENG_TYPE_FROM_CUSTOMER_TYPE_MAP =
				"DELETE FROM DOME_CUSTOMER_TYPE_MAP WHERE cust_id = ?1 AND eng_type_id = ?2";

		/** DELETE from dome_security_engine_center. */
		String DELETE_ENG_TYPE_FROM_ENGINE_SECURITY_CENTER =
		"DELETE from dome_security_engine_center WHERE ec_id = ?1 AND eng_type_id = ?2";

		/** Selects from dome_eng_type_center_map table. */
		String GET_ENG_TYPES_BY_CENTER_ID =
		"SELECT" +
		"    ec_type_id" +
		" FROM" +
		"    dome_eng_type_center_map" +
		" WHERE" +
		"    ec_center_id = ?";
		
		/** Selects from DOME_CUSTOMER_TYPE_MAP table. */
		String GET_ENG_TYPES_BY_CUSTOMER_ID =
		"SELECT" +
		"    eng_type_id" +
		" FROM" +
		"    DOME_CUSTOMER_TYPE_MAP" +
		" WHERE" +
		"    CUST_ID = ?";

		/** Conditionally INSERT row into dome_eng_type_center_map table. */
		// Alternatively use Oracle MERGE.
		String INSERT_INTO_ENG_TYPE_CENTER_MAP =
		"INSERT INTO dome_eng_type_center_map (ec_center_id, ec_type_id)" + 
		" SELECT ?1, ?2" + 
		" FROM DUAL" + 
		" WHERE NOT EXISTS (SELECT NULL from dome_eng_type_center_map WHERE ec_center_id = ?1 AND ec_type_id = ?2)";
		
		String INSERT_INTO_CUSTOMER_TYPE_MAP =
				"INSERT INTO DOME_CUSTOMER_TYPE_MAP (cust_id, eng_type_id)" + 
				" SELECT ?1, ?2" + 
				" FROM DUAL" + 
				" WHERE NOT EXISTS (SELECT NULL from DOME_CUSTOMER_TYPE_MAP WHERE cust_id = ?1 AND eng_type_id = ?2)";
	}
	/** Active indicator. */
	String ACTIVE = "A";

	/** Engine Center Id prefix. */
	String EC_ID_PREFIX = "EC";
	/** Engine Group Id prefix. */
	String EG_ID_PREFIX = "EG";
	/** Engine Module Id prefix. */
	String EM_ID_PREFIX = "EM";
	/** Engine Type Id prefix. */
	String ET_ID_PREFIX = "ET";

	/** Inactive indicator. */
	boolean INACTIVE = false;
}
