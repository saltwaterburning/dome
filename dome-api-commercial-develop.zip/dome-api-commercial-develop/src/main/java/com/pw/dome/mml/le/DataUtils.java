package com.pw.dome.mml.le;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.BooleanUtils;

class DataUtils {
    static List<LeQuarterlyEntity> LeQuarterlyEntity(LeUpdateRequest request, List<DetailsDTO> leDetails) {
        return leDetails.stream()
                        .map(dto->LeQuarterlyEntity.builder().engineId(dto.getEngineId())
                                                             .id(dto.getRiskId())
                                                             .leMarket(request.getLeMarket())
                                                             .leType(request.getLeType())
                                                             .monthQtr(request.getMonth())
                                                             .year(request.getYear())
                                                             // Handle null risk values
                                                             .risk(BooleanUtils.toBoolean(dto.getRisk()))
                                                             .build()).collect(Collectors.toList());
    }

    static List<LeMonthlyEntity> toLeMonthlyEntity(LeUpdateRequest request, List<DetailsDTO> leDetails) {
        return leDetails.stream()
                        .map(dto->LeMonthlyEntity.builder().engineId(dto.getEngineId())
                                                           .id(dto.getRiskId())
                                                           .leMarket(request.getLeMarket())
                                                           .leType(request.getLeType())
                                                           .monthQtr(request.getMonth())
                                                           .year(request.getYear())
                                                           // Handle null risk values
                                                           .risk(BooleanUtils.toBoolean(dto.getRisk()))
                                                           .build()).collect(Collectors.toList());
    }

    static List<LeMonthlyOpportunityEntity> toLeMonthlyOpportunityEntity(LeUpdateRequest request, List<DetailsDTO> toAdd) {
        return toAdd.stream()
                    .map(dto->LeMonthlyOpportunityEntity.builder()
                                                        .engineId(dto.getEngineId())
                                                        .leMarket(request.getLeMarket())
                                                        .leType(request.getLeType())
                                                        .opportunity(dto.getOpportunity())
                                                        .build()).collect(Collectors.toList());
    }

    static List<LeQuarterlyOpportunityEntity> toLeQuarterlyOpportunityEntity(LeUpdateRequest request, List<DetailsDTO> toAdd) {
        return toAdd.stream()
                    .map(dto->LeQuarterlyOpportunityEntity.builder().engineId(dto.getEngineId())
                                                                    .leMarket(request.getLeMarket())
                                                                    .leType(request.getLeType())
                                                                    .opportunity(dto.getOpportunity())
                                                                    .build()).collect(Collectors.toList());
    }
}
