package com.pw.dome.mml.le;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.pw.dome.jpa.AbstractEntityWithGeneratedId;
import com.pw.dome.mml.PlanMarket;
import com.pw.dome.mml.PlanType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_LE_OPP_QTR")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
class LeQuarterlyOpportunityEntity extends AbstractEntityWithGeneratedId<Integer> {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOME_LE_OPP_QTR_SEQ")
    @SequenceGenerator(sequenceName = "DOME_LE_OPP_QTR_SEQ", allocationSize = 1, name = "DOME_LE_OPP_QTR_SEQ")
    @Column(name="LE_QTR_ID")
    private Integer id;
    
    @Column(name="LE_MARKET", nullable = false)
    @Enumerated
    private PlanMarket leMarket;
    
    @Column(name="LE_TYPE", nullable = false)
    @Enumerated
    private PlanType leType;
    
    @Column(name="LE_ENG_ID", nullable = false)
    private int engineId;
    
    @Column(name="LE_IS_OPP", nullable = false)
    private boolean opportunity;
}
