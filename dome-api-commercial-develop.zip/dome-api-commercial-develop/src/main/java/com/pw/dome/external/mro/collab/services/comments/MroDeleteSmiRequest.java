package com.pw.dome.external.mro.collab.services.comments;

import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public record MroDeleteSmiRequest(@Size(min = 1, max = 20)
                                  String esn,
                                  @Positive
                                  Integer eventId) {
}
