package com.pw.dome.mml;

interface Consts {
	String SHIPPED_DAYS = "14";
}
