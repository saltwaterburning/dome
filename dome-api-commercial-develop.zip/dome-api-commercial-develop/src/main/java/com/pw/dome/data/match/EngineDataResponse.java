package com.pw.dome.data.match;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EngineDataResponse {
    @NotEmpty(message = "{NotEmpty.required}")
    @Valid
	private List<EngineData> engines;
}
