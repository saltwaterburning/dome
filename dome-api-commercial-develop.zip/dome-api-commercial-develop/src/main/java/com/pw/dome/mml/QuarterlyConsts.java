package com.pw.dome.mml;

import static com.pw.dome.mml.Consts.SHIPPED_DAYS;

interface QuarterlyConsts {
	interface SQL {
		 String AND_NOT_DISABLED = " AND cast(nvl(engineAsset.disabled, 0) as int) = 0 ";

		 String BASE_SELECT_SQL = "SELECT DISTINCT cast(:planMonth as string) as month, "
				 + "engine.engineID as engineId, "
				 + "engineCenter.name as engineCenterName, "
				 + "engineGroup.name as engineGroupName, "
				 + "engineGroup.engineGroupID as engineGroupId, "
				 + "engine.category as engineCategory, "
				 + "engine.esn as engineSerialNumber, "
				 + "customer.name as customerName, ";

		 String SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH = "SELECT mmlQuarterlyEntity.engineId "
				 + "FROM MmlQuarterlyEntity mmlQuarterlyEntity "
				 + "INNER JOIN EngineEntity engine ON engine.engineID = mmlQuarterlyEntity.engineId "
				 + "LEFT OUTER JOIN EngineAssetEntity engineAsset ON engineAsset.assetID = engine.assetID "
				 + "WHERE mmlQuarterlyEntity.planType = :planType AND "
				 + "mmlQuarterlyEntity.planMarket = :planMarket  AND "
				 + "(mmlQuarterlyEntity.planYear > year(local_date) "
				 + "   OR (mmlQuarterlyEntity.planYear = :planYear AND mmlQuarterlyEntity.month >= month(local_date))) "
				 + AND_NOT_DISABLED;

		 String AND_INDUCTION_COLS =
"""
engTrack.engtrackRecDate as actualReceipentDate,
engTrack.engtrackPlanIndDate as planInductionDate
""";
	       
	       String AND_REV_COLS =
"""
engTrack.gate3Plan as planInductionDate,
engTrack.enginePlanCoreAssemblyDate as actualReceipentDate       													
""";
	       
	       String AND_SHIP_COLS = "engTrack.engtrackPlanEngComplete as planInductionDate, "
						+ "engTrack.enginePlanCoreAssemblyDate as actualReceipentDate ";

	   		String BASE_FROM =
"""
FROM CustomerEntity customer,
     EngineCenterEntity engineCenter,
     EngineGroupEntity engineGroup,
     EngineTrackingEntity engTrack,     
     SlotEntity slot
INNER JOIN MmlQuarterlyEntity mmlQuarterlyEntity ON mmlQuarterlyEntity.planMarket = :planMarket
AND mmlQuarterlyEntity.month = :planMonth
AND mmlQuarterlyEntity.planType = :planType
AND mmlQuarterlyEntity.planYear = :planYear
INNER JOIN EngineEntity engine ON engine.engineID = mmlQuarterlyEntity.engineId
AND UPPER(engine.esn) NOT IN ('CLOSED',
                              'FREE',
                              'LOST',
                              'RESV',
                              'XXXXXX')
AND engine.groupID in (:engineGroupIds)
LEFT OUTER JOIN EngineAssetEntity engineAsset ON engineAsset.assetID = engine.assetID
""";

	   		String BASE_FROM_NOT_IN =
"""
FROM CustomerEntity customer,
     EngineCenterEntity engineCenter,
     EngineGroupEntity engineGroup,
     EngineTrackingEntity engTrack,     
     SlotEntity slot
INNER JOIN EngineEntity engine ON engine.engineID NOT IN (""" + SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH + ") "
+
"""
AND engine.groupID in (:engineGroupIds)
AND UPPER(engine.esn) NOT IN ('CLOSED',
                              'FREE',
                              'LOST',
                              'RESV',
                              'XXXXXX')
LEFT OUTER JOIN EngineAssetEntity engineAsset ON engineAsset.assetID = engine.assetID
WHERE customer.customerID = engine.customerID
AND customer.active = true
AND engineCenter.id = :ecid
AND engineGroup.engineGroupID = engine.groupID
AND engTrack.engtrackId = engine.engineID
AND slot.engineCenterID = engineCenter.id
AND slot.slotID = engine.slotID
""" + AND_NOT_DISABLED;

	   		String BASE_WHERE = "WHERE engine.customerID = customer.customerID "
					+ "AND engine.engineID = engTrack.engtrackId "
						+ "AND engineCenter.id = :ecid "
						+ "AND slot.engineCenterID = engineCenter.id "
						+ "AND engine.groupID = engineGroup.engineGroupID "
						+ "AND engine.slotID = slot.slotID "
						+ AND_NOT_DISABLED;
     
	       String AND_SHIPPED = "AND (engTrack.engtrackShipmentDate is null OR "
					+ "engTrack.engtrackShipmentDate > (local_date - " + SHIPPED_DAYS + " day)) ";
	       
//	       String WHERE_AND = "AND engine.engineID = mmlQuarterlyEntity.engineId "
//	       													+ "AND mmlQuarterlyEntity.month = :planMonth "
//	       													+ "AND mmlQuarterlyEntity.planYear = :planYear ";
	       
	       String ORDER_BY_PLAN_TRACK =
"""
ORDER BY engTrack.engtrackPlanIndDate,
         engTrack.engtrackRecDate
""";
	       
	       String ORDER_BY_SHIP =
"""
ORDER BY engTrack.engtrackPlanEngComplete,
         engTrack.enginePlanCoreAssemblyDate
""";
	       
	       String ORDER_BY_REV =
"""
ORDER BY engTrack.gate3Plan,
         engTrack.enginePlanCoreAssemblyDate
""";
	       
	       String QUARTERLY_MML_INDUCTION_DATA =
	    		   BASE_SELECT_SQL +
	    		   AND_INDUCTION_COLS +
	    		   BASE_FROM +
	    		   BASE_WHERE +
	    		   ORDER_BY_PLAN_TRACK;
	       
	       String QUARTERLY_MML_REVENUE_DATA =
	    		   BASE_SELECT_SQL +
	    		   AND_REV_COLS + 
	    		   BASE_FROM +
	    		   BASE_WHERE +
	    		   ORDER_BY_REV;

	       String QUARTERLY_MML_SHIPMENT_DATA =
	    		   BASE_SELECT_SQL +
	    		   AND_SHIP_COLS + 
	    		   BASE_FROM +
	    		   BASE_WHERE +
	    		   ORDER_BY_SHIP;

	       String QUARTERLY_MML_PLAN_INDUCTION_DATA =
	    		   BASE_SELECT_SQL +
	    		   AND_INDUCTION_COLS + 
	    		   BASE_FROM_NOT_IN +
	    		   AND_SHIPPED +
	    		   ORDER_BY_PLAN_TRACK;

	       String QUARTERLY_MML_PLAN_REVENUE_DATA =
	    		   BASE_SELECT_SQL +
	    		   AND_REV_COLS + 
	    		   BASE_FROM_NOT_IN +
	    		   AND_SHIPPED +
	    		   ORDER_BY_REV;

	       String QUARTERLY_MML_PLAN_SHIPMENT_DATA =
	    		   BASE_SELECT_SQL +
	    		   AND_SHIP_COLS +
	    		   BASE_FROM_NOT_IN +
	    		   AND_SHIPPED +
	    		   ORDER_BY_SHIP;
	 }

}
