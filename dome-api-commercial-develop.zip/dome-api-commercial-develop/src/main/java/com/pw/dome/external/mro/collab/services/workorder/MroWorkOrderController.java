package com.pw.dome.external.mro.collab.services.workorder;

import static com.pw.dome.external.mro.collab.services.workorder.Consts.BAD_DELETE_REQUEST_ALL;
import static com.pw.dome.external.mro.collab.services.workorder.Consts.BAD_DELETE_REQUEST_NULL;
import static com.pw.dome.external.mro.collab.services.workorder.Consts.BAD_UPDATE_REQUEST_ALL;
import static com.pw.dome.external.mro.collab.services.workorder.Consts.BAD_UPDATE_REQUEST_NULL;
import static com.pw.dome.external.mro.collab.services.workorder.Consts.ESN_NO_MATCH;
import static com.pw.dome.external.mro.collab.services.workorder.Consts.EVENT_ID_NO_MATCH;
import static com.pw.dome.external.mro.collab.services.workorder.Consts.SHOP_CODE_NO_MATCH;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.common.oas.BaseRESTfulResource;
import com.pw.dome.exception.ErrorResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/v1/mro-collab")
@Tag(name = BaseRESTfulResource.Tags.MRO)
@Validated
@Deprecated
class MroWorkOrderController extends BaseRESTfulResource {

  @Autowired
  private MroWorkOrderService mroService;

  @Operation(description = "Updates the matching EngineTracking record with the MRO work order.")
  @ApiResponses(value = {@ApiResponse(responseCode = OK, description = "WorkOrder updated for matching EngineTracking record."),
      // When using validation...
      @ApiResponse(responseCode = BAD_REQUEST, description = Descriptions.BAD_REQUEST,
          content = {@Content(
              examples = {
                  @ExampleObject(name = "All request values fail validation.", summary = "All request values made to fail validation.",
                      value = BAD_UPDATE_REQUEST_ALL),
                  @ExampleObject(name = "One request value fails validation.",
                      summary = "One request value is null and fails validation.", value = BAD_UPDATE_REQUEST_NULL)},
              schema = @Schema(implementation = ErrorResponse.class))}),
      // When throwing NotFoundException
      @ApiResponse(responseCode = NOT_FOUND, description = Descriptions.NOT_FOUND,
          content = {@Content(
              examples = {
                  @ExampleObject(name = "ESN doesn't match.", summary = "Error response when request ESN not matched.",
                      value = ESN_NO_MATCH),
                  @ExampleObject(name = "ShopCode doesn't match.", summary = "Error response when request ShopCode not matched.",
                      value = SHOP_CODE_NO_MATCH)},
              schema = @Schema(implementation = ErrorResponse.class))})})
  @PostMapping(path = "/workorder", produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<String> updateWorkOrderFromMRO(@io.swagger.v3.oas.annotations.parameters.RequestBody(
      required = true) @RequestBody @Valid MroWorkOrderUpdateRequest request) {
    return ResponseEntity.ok(mroService.updateWorkOrder(request));
  }

  @Operation(description = "Deletes the matching EngineTracking MRO work order.")
  @ApiResponses(value = {@ApiResponse(responseCode = NO_CONTENT, description = "WorkOrder dropped for matching EngineTracking record."),
      // When using validation...
      @ApiResponse(responseCode = BAD_REQUEST, description = Descriptions.BAD_REQUEST,
          content = {@Content(
              examples = {
                  @ExampleObject(name = "All request values fail validation.", summary = "All request values made to fail validation.",
                      value = BAD_DELETE_REQUEST_ALL),
                  @ExampleObject(name = "One request value fails validation.",
                      summary = "One request value is null and fails validation.", value = BAD_DELETE_REQUEST_NULL)},
              schema = @Schema(implementation = ErrorResponse.class))}),
      // When throwing NotFoundException
      @ApiResponse(responseCode = NOT_FOUND, description = Descriptions.NOT_FOUND,
          content = {@Content(
              examples = {
                  @ExampleObject(name = "EventId doesn't match.", summary = "Error response when request EventId not matched.",
                      value = EVENT_ID_NO_MATCH),
                  @ExampleObject(name = "ShopCode doesn't match.", summary = "Error response when request ShopCode not matched.",
                      value = SHOP_CODE_NO_MATCH)},
              schema = @Schema(implementation = ErrorResponse.class))})})
  @DeleteMapping(path = "/workorder", produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<?> deleteWorkOrderFromMRO(@io.swagger.v3.oas.annotations.parameters.RequestBody(
      required = true) @RequestBody @Valid MroWorkOrderDeleteRequest request) {
    mroService.deleteWorkOrder(request);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }
}
