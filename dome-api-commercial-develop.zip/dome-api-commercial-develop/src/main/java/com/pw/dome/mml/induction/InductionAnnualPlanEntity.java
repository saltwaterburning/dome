package com.pw.dome.mml.induction;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.pw.dome.jpa.AbstractEntityWithGeneratedId;
import com.pw.dome.mml.PlanMarket;
import com.pw.dome.mml.PlanType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "DOME_PLAN")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class InductionAnnualPlanEntity extends AbstractEntityWithGeneratedId<Integer> {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dome_plan_seq")
    @SequenceGenerator(sequenceName = "dome_plan_seq", allocationSize = 1, name = "dome_plan_seq")
    @Column(name = "plan_id")
    private Integer planId;

    @Column(name = "plan_ec_id")
    private String engCenterId;

    @Column(name = "plan_eng_group_id")
    private String engGroupId;

    @Column(name = "plan_category")
    private String category;

    @Column(name = "plan_type")
    @Enumerated
    private PlanType planType;

    @Column(name = "plan_year")
    private int planYear;

    @Column(name = "plan_month")
    private int planMonth;

    @Column(name = "plan_counter")
    private int planCounter;

    @Column(name = "plan_market")
    @Enumerated
    private PlanMarket planMarket;

    @Column(name = "plan_sales_order_type")
    private String salesOrderType;

    @Override
    public Integer getId() {
        return planId;
    }
}
