package com.pw.dome.engine.odin.reports;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.report.excel.ReportConstants;

@RestController()
@RequestMapping("/v1/engines/odin/reports")
class OdinReportsController {

	private final OdinReportsService reportsService;

	@Autowired
	public OdinReportsController(OdinReportsService reportsService) {
		this.reportsService = reportsService;
	}

	@PostMapping()
	public ResponseEntity<InputStreamResource> getWipStatusReport(
			@RequestBody
			@Valid
			final OdinRequest request)
			throws IOException {
		ByteArrayInputStream inputStream = reportsService.odinReport(request);
		return ResponseEntity.ok()
				             .contentType(ReportConstants.EXCEL_MEDIA_TYPE)
				             .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=odin-report.xlsx")
				             .body(new InputStreamResource(inputStream));
	}
}
