package com.pw.dome.engine;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.calendar.induction.CalendarEngine;
import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.engine.asset.AddEngineToSlotRequest;
import com.pw.dome.engine.asset.AddToSlotByCustomerRequest;
import com.pw.dome.engine.asset.EngineAssetEntity;
import com.pw.dome.engine.events.EngineEventEntity;
import com.pw.dome.engine.events.EngineEventEntityPK;
import com.pw.dome.engine.manual.AddManualEngineToSlotRequest;
import com.pw.dome.engine.odin.history.OdinHistoryEntity;
import com.pw.dome.engine.type.EngineTypeEntity;
import com.pw.dome.user.UserProfile;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

//	@Mapping(target = "customerName", source = "engine.customer.name")
//	@Mapping(target = "customerShortName", source = "engine.customer.shortName")
//	@Mapping(target = "engineGroupID", source = "engine.groupID")
//	@Mapping(target = "engineModelID", source = "engine.modelID")
//	@Mapping(target = "moduleName", source = "engine.module.moduleName")
//	@Mapping(target = "engineTypeName", source = "slot.engineType.name")
//	CalendarEngine toCalendarEngine(EngineEntity engine, SlotEntity slot);

	@Mapping(target = "customerName", source = "engine.customer.name")
	@Mapping(target = "customerShortName", source = "engine.customer.shortName")
	@Mapping(target = "engineGroupID", source = "engine.groupID")
	@Mapping(target = "engineModelID", source = "engine.modelID")
	@Mapping(target = "moduleName", source = "engine.module.moduleName")
	@Mapping(target = "engineTypeName", source = "engineType.name")
	CalendarEngine toCalendarEngine(EngineEntity engine, EngineTypeEntity engineType);

//	@Mapping(target = "esn", source = "pk.esn")
//	@Mapping(target = "eventId", source = "pk.eventId")
	@Mapping(target = "pk", source = "pk")
	@Mapping(target = "isShopVisit", ignore = true)
	@Mapping(target = "maintenanceType", ignore = true)
	@Mapping(target = "operator", ignore = true)
	@Mapping(target = "operatorCode", source = "engAsset.operatorID")
	@Mapping(target = "planned", constant = "true")
	@Mapping(target = "removalReason", ignore = true)
	@Mapping(target = "shipped", ignore = true)
	@Mapping(target = "shopCode", ignore = true)
	@Mapping(target = "shopName", ignore = true)
	@Mapping(target = "removalDateRecorded", ignore = true)
	@Mapping(target = "slotId", source = "request.slotID")
	EngineEventEntity toEngineEntity(EngineEventEntityPK pk, AddEngineToSlotRequest request, EngineAssetEntity engAsset);

	@Mapping(target = "subVisitType", ignore = true)
	@Mapping(target = "csn", ignore = true)
	@Mapping(target = "cso", ignore = true)
	@Mapping(target = "customer", ignore = true)
	@Mapping(target = "customerID", source = "request.customerId")
	@Mapping(target = "engineID", ignore = true)
	@Mapping(target = "engineTrackingEntity", ignore = true)
	@Mapping(target = "engineTypeId", source = "asset.engineTypeID")
	@Mapping(target = "eventId", source = "request.eventId")
	@Mapping(target = "gate1", ignore = true)
	@Mapping(target = "gate1Plan", ignore = true)
	@Mapping(target = "groupID", source = "asset.engineGroupID")
	@Mapping(target = "llpCycRemain", ignore = true)
	@Mapping(target = "modelID", source = "asset.engineModelID")
	@Mapping(target = "module", ignore = true)
	@Mapping(target = "moduleID", ignore = true)
	@Mapping(target = "notifyNum", ignore = true)
	@Mapping(target = "parentEsn", ignore = true)
	@Mapping(target = "priority", ignore = true)
	@Mapping(target = "purchaseOrder", ignore = true)
	@Mapping(target = "removalReason", ignore = true)
	@Mapping(target = "salesOrderNum", ignore = true)
	@Mapping(target = "shopVisitNum", ignore = true)
	@Mapping(target = "slot", ignore = true)
	@Mapping(target = "tsn", ignore = true)
	@Mapping(target = "tso", ignore = true)
	@Mapping(target = "updateDate", ignore = true)
	@Mapping(target = "user", ignore = true)
	@Mapping(target = "warranty", ignore = true)
	EngineEntity toEngine(EngineAssetEntity asset, String logEmail, boolean manualEngine, AddEngineToSlotRequest request, boolean revenue, String shipmentType);

	@Mapping(target = "subVisitType", ignore = true)
	@Mapping(target = "assetID", ignore = true)
	@Mapping(target = "csn", ignore = true)
	@Mapping(target = "cso", ignore = true)
	@Mapping(target = "customer", ignore = true)
	@Mapping(target = "engineID", ignore = true)
	@Mapping(target = "engineTrackingEntity", ignore = true)
	@Mapping(target = "eventId", ignore = true)
	@Mapping(target = "gate1", ignore = true)
	@Mapping(target = "gate1Plan", ignore = true)
	@Mapping(target = "groupID", source = "request.engineGroupID")
	@Mapping(target = "llpCycRemain", ignore = true)
//	@Mapping(target = "logEmail", ignore = true)
	@Mapping(target = "manualEngine", constant = "true")
	@Mapping(target = "modelID", source = "request.engineModelID")
	@Mapping(target = "module", ignore = true)
	@Mapping(target = "moduleID", ignore = true)
	@Mapping(target = "notifyNum", ignore = true)
	@Mapping(target = "parentEsn", ignore = true)
	@Mapping(target = "priority", ignore = true)
	@Mapping(target = "purchaseOrder", ignore = true)
	@Mapping(target = "removalReason", ignore = true)
	@Mapping(target = "revenue", ignore = true)
	@Mapping(target = "salesOrderNum", ignore = true)
	@Mapping(target = "shipmentType", source = "shipmentType")
	@Mapping(target = "shopVisitNum", ignore = true)
	@Mapping(target = "slot", ignore = true)
	@Mapping(target = "tsn", ignore = true)
	@Mapping(target = "tso", ignore = true)
	@Mapping(target = "updateDate", ignore = true)
	@Mapping(target = "user", ignore = true)
	@Mapping(target = "warranty", ignore = true)
	EngineEntity toEngine(AddManualEngineToSlotRequest request, int slotID, String engineTypeId, String logEmail, String shipmentType);

	@Mapping(target = "subVisitType", ignore = true)
	@Mapping(target = "assetID", ignore = true)
	@Mapping(target = "csn", ignore = true)
	@Mapping(target = "cso", ignore = true)
	@Mapping(target = "customer", ignore = true)
	@Mapping(target = "engineID", ignore = true)
	@Mapping(target = "engineTrackingEntity", ignore = true)
	@Mapping(target = "esn", source = "esn")
	@Mapping(target = "eventId", ignore = true)
	@Mapping(target = "gate1", ignore = true)
	@Mapping(target = "gate1Plan", ignore = true)
	@Mapping(target = "groupID", source = "request.engineGroupID")
	@Mapping(target = "llpCycRemain", ignore = true)
	@Mapping(target = "manualEngine", constant = "false")
	@Mapping(target = "modelID", source = "request.engineModelID")
	@Mapping(target = "module", ignore = true)
	@Mapping(target = "moduleID", ignore = true)
	@Mapping(target = "notifyNum", ignore = true)
	@Mapping(target = "parentEsn", ignore = true)
	@Mapping(target = "priority", ignore = true)
	@Mapping(target = "purchaseOrder", ignore = true)
	@Mapping(target = "removalReason", ignore = true)
	@Mapping(target = "revenue", ignore = true)
	@Mapping(target = "salesOrderNum", ignore = true)
	@Mapping(target = "shopVisitNum", ignore = true)
	@Mapping(target = "slot", ignore = true)
	@Mapping(target = "tsn", ignore = true)
	@Mapping(target = "tso", ignore = true)
	@Mapping(target = "updateDate", ignore = true)
	@Mapping(target = "user", ignore = true)
	@Mapping(target = "warranty", ignore = true)
	EngineEntity toEngine(AddToSlotByCustomerRequest request, int slotID, String engineTypeId, String esn, String logEmail, String shipmentType);

	@Mapping(target = "odinHistId", ignore = true)
	@Mapping(target = "updateDate", expression = "java(java.time.LocalDate.now())")
	@Mapping(source = "slot.caldate", target = "prelimInductionDate")
	@Mapping(source = "request.changeReason", target = "changeReason")
	@Mapping(source = "request.notes", target = "notes")
	@Mapping(source = "userProfile.emailAddress", target = "logEmail")
	@Mapping(source = "engine.engineID", target = "engineId")
	@Mapping(source = "engine.eventId", target = "eventId")
	@Mapping(source = "engine.esn", target = "esn")
	OdinHistoryEntity toOdinHistory(final EngineEntity engine, final UserProfile userProfile, final UpdateEngineSlotRequest request, final SlotEntity slot);

	@Mapping(target = "assetID", ignore = true)
	@Mapping(target = "csn", ignore = true)
	@Mapping(target = "cso", ignore = true)
	@Mapping(target = "customer", ignore = true)
	@Mapping(target = "customerID", source = "customerId")
	@Mapping(target = "engineID", source = "engineID")
	@Mapping(target = "engineTrackingEntity", ignore = true)
	@Mapping(target = "engineTypeId", ignore = true)
	@Mapping(target = "esn", ignore = true)
	@Mapping(target = "eventId", ignore = true)
	@Mapping(target = "gate1", ignore = true)
	@Mapping(target = "gate1Plan", ignore = true)
	@Mapping(target = "groupID", source = "engineGroupID")
	@Mapping(target = "llpCycRemain", ignore = true)
	@Mapping(target = "logEmail", ignore = true)
	@Mapping(target = "manualEngine", ignore = true)
	@Mapping(target = "modelID", source = "engineModelID")
	@Mapping(target = "module", ignore = true)
	@Mapping(target = "moduleID", ignore = true)
	@Mapping(target = "notifyNum", ignore = true)
	@Mapping(target = "parentEsn", ignore = true)
	@Mapping(target = "priority", ignore = true)
	@Mapping(target = "purchaseOrder", ignore = true)
	@Mapping(target = "removalReason", ignore = true)
	@Mapping(target = "revenue", ignore = true)
	@Mapping(target = "salesOrderNum", ignore = true)
	@Mapping(target = "shipmentType", ignore = true)
	@Mapping(target = "shopVisitNum", ignore = true)
	@Mapping(target = "slot", ignore = true)
	@Mapping(target = "slotID", ignore = true)
	@Mapping(target = "tsn", ignore = true)
	@Mapping(target = "tso", ignore = true)
	@Mapping(target = "updateDate", ignore = true)
	@Mapping(target = "user", ignore = true)
	@Mapping(target = "warranty", ignore = true)
	EngineEntity mutateEngineEntity(EngineDTO dto, @MappingTarget EngineEntity entity);

	@Mapping(target = "customerId", source =  "customerID")
	@Mapping(target = "engineGroupID", source = "groupID")
	@Mapping(target = "engineModelID", source = "modelID")
	EngineDTO toEngineDTO(EngineEntity entity);
}
