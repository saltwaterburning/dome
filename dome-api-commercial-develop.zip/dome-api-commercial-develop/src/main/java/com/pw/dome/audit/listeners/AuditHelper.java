package com.pw.dome.audit.listeners;

import com.pw.dome.audit.AUDIT_TYPES;
import com.pw.dome.audit.AuditEvent;
import com.pw.dome.audit.AuditItem;
import com.pw.dome.audit.AuditItems;
import com.pw.dome.calendar.slots.SlotEntity;

public class AuditHelper {

  public static AuditEvent addShopVisit(SlotEntity slot) {
    String desc = String.format("Add Shop Visit for date: %d-%d-%d, type : %s",
        slot.getYear(),
        slot.getMonth(),
        slot.getDay(),
        slot.getShopVisitType());
    AUDIT_TYPES auditType = slot.isNew() ? AUDIT_TYPES.ADD : AUDIT_TYPES.UPDATE;
    return toAudit(slot, AuditItems.INDUCTION_PLANNING, auditType, desc);
  }

  public static AuditEvent deleteShopVisit(SlotEntity slot) {
    AUDIT_TYPES auditType = AUDIT_TYPES.DELETE;
    String desc = String.format("Remove Shop Visit for date: %d-%d-%d, type : %s",
        slot.getYear(),
        slot.getMonth(),
        slot.getDay(),
        slot.getShopVisitType());
    return toAudit(slot, AuditItems.INDUCTION_PLANNING, auditType, desc);
  }

  public static AuditEvent updateShopVisit(SlotEntity slot) {
    String desc = String.format("Update Shop Visit for date: %d-%d-%d, type : %s",
        slot.getYear(),
        slot.getMonth(),
        slot.getDay(),	
        slot.getShopVisitType());
    AUDIT_TYPES auditType = slot.isNew() ? AUDIT_TYPES.ADD : AUDIT_TYPES.UPDATE;
    return toAudit(slot, AuditItems.INDUCTION_PLANNING, auditType, desc);
  }

  private static AuditEvent toAudit(SlotEntity slot, AuditItem item, AUDIT_TYPES type, String desc) {

    return AuditEvent.builder()
        .customerID(null)
        .description(desc)
        .engineCenterId(slot.getEngineCenterID())
        .engineGroup(null)
        .engineModel(null)
        .engineModule(null)
        .engineType(slot.getEngineType() != null ? slot.getEngineType().getName() : null)
        .item(item)
        .type(type)
        .build();
  }
}
