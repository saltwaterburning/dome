package com.pw.dome.external.mro.collab.client;

import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ARijos
 *
 *{

                   "workorder":"27F-456908345984(CEC)",

                   "actualAssetCompleteDate":"01/01/2021",

                   "actualCoreAssemblyDate":"01/01/2021",

                   "actualGate1CloseDate":"01/01/2021",

                   "actualGate3CloseDate":"01/01/2021",

                   "actualGate3CompleteDate":"01/01/2021",

                   "actualGate3StartDate":"01/01/2021",

                   "actualInductDate":"01/01/2021",

                   "actualKitCompleteDate":"01/01/2021",

                   "actualReceiptDate":"01/01/2021",

                   "actualReceiveDate":"01/01/2021",

                   "actualRemovalDate":"01/01/2021",

                   "actualShipDate":"01/01/2021",

                   "actualShipToCustDate":"01/01/2021",

                   "actualTestCompleteDate":"01/01/2021",

                   "actualTestStartDate":"01/01/2021",

                   "contractDate":"01/01/2021",

                   "externalAssetCompleteDate":"01/01/2021",

                   "externalContractDate":"01/01/2021",

                   "externalCoreAssemblyDate":"01/01/2021",

                   "externalGate1CloseDate":"01/01/2021",

                   "externalGate3CloseDate":"01/01/2021",

                   "externalGate3StartDate":"01/01/2021",

                   "externalInductDate":"01/01/2021",

                   "externalKitCompleteDate":"01/01/2021",

                   "externalReceiptDate":"01/01/2021",

                   "externalReceiveDate":"01/01/2021",

                   "externalShipDate":"01/01/2021",

                   "externalShipToCustDate":"01/01/2021",

                   "externalTestCompleteDate":"01/01/2021",

                   "externalTestStartDate":"01/01/2021",

                   "planAssetCompleteDate":"01/01/2021",

                   "planCoreAssemblyDate":"01/01/2021",

                   "planGate1CloseDate":"01/01/2021",

                   "planGate3CloseDate":"01/01/2021",

                   "planGate3StartDate":"01/01/2021",

                   "planInductDate":"01/01/2021",

                   "planKitCompleteDate":"01/01/2021",

                   "planReceiptDate":"01/01/2021",

                   "planReceiveDate":"01/01/2021",

                   "planRemovalDate":"01/01/2021",

                   "planShipDate":"01/01/2021",

                   "planShipToCustDate":"01/01/2021",

                   "planTestCompleteDate":"01/01/2021",

                   "planTestStartDate":"01/01/2021",

                   }'
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MroGateInfo {
	// Extra audit fields per Chuck on 5/14/2021
	private Integer engineEventId;
	private Integer engineId;
	private String engineSN;
	private String mroShopCode;

	// As per MRO API doc
	@NotBlank
	private String workorder;
	private LocalDate actualAssetCompleteDate;
	private LocalDate actualCoreAssemblyDate;
	private LocalDate actualGate1CloseDate;

	private LocalDate actualGate3CloseDate;
	// Removed per Check on 5/14/2021
//	private LocalDate actualGate3CompleteDate;
	private LocalDate actualGate3StartDate;
	private LocalDate actualInductDate;
	private LocalDate actualKitCompleteDate;
	private LocalDate actualReceiptDate;
	private LocalDate actualReceiveDate;
	private LocalDate actualRemovalDate;
	private LocalDate actualShipDate;
	private LocalDate actualShipToCustDate;
	private LocalDate actualTestCompleteDate;
	private LocalDate actualTestStartDate;

	private LocalDate contractDate;

	private LocalDate externalAssetCompleteDate;
	private LocalDate externalContractDate;
	private LocalDate externalCoreAssemblyDate;
	private LocalDate externalGate1CloseDate;
	private LocalDate externalGate3CloseDate;
	private LocalDate externalGate3StartDate;
	private LocalDate externalInductDate;
	private LocalDate externalKitCompleteDate;
	private LocalDate externalReceiptDate;
	private LocalDate externalReceiveDate;
	private LocalDate externalShipDate;
	private LocalDate externalShipToCustDate;
	private LocalDate externalTestCompleteDate;
	private LocalDate externalTestStartDate;

	private LocalDate planAssetCompleteDate;
	private LocalDate planCoreAssemblyDate;
	private LocalDate planGate1CloseDate;
	private LocalDate planGate3CloseDate;
	private LocalDate planGate3StartDate;
	private LocalDate planInductDate;
	private LocalDate planKitCompleteDate;
	private LocalDate planReceiptDate;
	private LocalDate planReceiveDate;
	private LocalDate planRemovalDate;
	private LocalDate planShipDate;
	private LocalDate planShipToCustDate;
	private LocalDate planTestCompleteDate;
	private LocalDate planTestStartDate;
}
