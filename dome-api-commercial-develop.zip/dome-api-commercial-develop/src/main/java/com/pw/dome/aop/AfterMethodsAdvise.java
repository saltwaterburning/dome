package com.pw.dome.aop;

import org.springframework.aop.AfterAdvice;

import com.pw.dome.aop.jpa.CustomRepositoryFactory;

/**
 * Marker interface used to inject advise invoked after the matching JPA method(s).
 * Simply create a marker interface (empty) as an extension of this one.
 * Then implement JpaRepository method(s) in the subclass by adding the return object as the methods first argument.
 * 
 * <p><code>
 * Example JPA Method:
 *   List<EngineEntity> getEnginesBySlotID(Integer slotID);
 * </code></p>
 * <p><code>
 * Example Implemented Return Advise:
 *   getEnginesBySlotID(List<EngineEntity>, Integer slotID);
 * </code></p>
 * 
 * @see CustomRepositoryFactory
 */
public interface AfterMethodsAdvise<T, ID> extends AfterAdvice {

}
