package com.pw.dome.engine.parts;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.NaturalId;

import com.pw.dome.jpa.AbstractEntityWithNaturalId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_ODM_PARTS")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Immutable
public class OdmPartsEntity extends AbstractEntityWithNaturalId<String> {
	@Id
	@NaturalId
	@Column(name="PART_NUMBER")
	private String partNumber;

	@Column(name="PART_DESCRIPTION")
	private String partDescription;

	@Override
	public String getId() {
		return partNumber;
	}
}
