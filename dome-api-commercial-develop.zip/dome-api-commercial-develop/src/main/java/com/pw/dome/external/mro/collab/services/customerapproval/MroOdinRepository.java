package com.pw.dome.external.mro.collab.services.customerapproval;

import static com.pw.dome.external.mro.collab.services.customerapproval.Consts.SQL.GET_ODIN;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pw.dome.engine.odin.OdinEntity;

@Repository
public interface MroOdinRepository extends JpaRepository<OdinEntity, Integer> {
  @Query(GET_ODIN)
  Optional<OdinEntity> findOdin(@Param("esn") String esn,
		                        @Param("eventId") Integer eventId,
		                        @Param("mroShopCode") String mroShopCode,
		                        @Param("mroWorkOrder") String mroWorkOrder);
}
