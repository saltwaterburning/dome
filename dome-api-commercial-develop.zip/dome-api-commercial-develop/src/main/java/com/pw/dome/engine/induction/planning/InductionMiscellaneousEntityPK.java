package com.pw.dome.engine.induction.planning;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Embeddable
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class InductionMiscellaneousEntityPK implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="FIELD_SEQ")
	private Integer fieldSeq;

	@Column(name="KEY_FIELD")
	private String key;

	@Override
	public int hashCode() {
		return Objects.hash(fieldSeq, key);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof InductionMiscellaneousEntityPK))
			return false;
		InductionMiscellaneousEntityPK other = (InductionMiscellaneousEntityPK) obj;
		return Objects.equals(fieldSeq, other.fieldSeq) && Objects.equals(key, other.key);
	}
}