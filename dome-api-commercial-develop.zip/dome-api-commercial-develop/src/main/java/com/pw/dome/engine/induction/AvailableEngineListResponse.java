 /**
 * 
 */
package com.pw.dome.engine.induction;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class AvailableEngineListResponse {
	private List<AvailableEngine> engines;
}

