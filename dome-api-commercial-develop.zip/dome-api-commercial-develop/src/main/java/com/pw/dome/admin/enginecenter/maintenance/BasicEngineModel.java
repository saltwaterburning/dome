package com.pw.dome.admin.enginecenter.maintenance;

import static com.pw.dome.admin.enginecenter.maintenance.Consts.EM_ID_PREFIX;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
final class BasicEngineModel {
	@NotNull(message = "{NotNull.required}")
	private boolean active;
	@Pattern(regexp = "^" + EM_ID_PREFIX + "\\d{1,8}$")
	@Size(min = 3, max = 10)
	private String modelId;
	@NotNull(message = "{NotNull.required}")
	@Size(min = 1, max = 100)
	private String modelName;
}
