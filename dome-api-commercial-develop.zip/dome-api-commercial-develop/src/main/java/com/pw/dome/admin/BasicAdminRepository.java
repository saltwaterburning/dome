package com.pw.dome.admin;

import static com.pw.dome.admin.Consts.SQL.GET_ALL_ENGINE_CENTERS;
import static com.pw.dome.admin.Consts.SQL.GET_ALL_ENGINE_CENTERS_AND_MATCHING_ENGINE_GROUPS;
import static com.pw.dome.admin.Consts.SQL.GET_ALL_ENGINE_CENTERS_AND_MATCHING_ENGINE_GROUPS_EXCEPT;
import static com.pw.dome.admin.Consts.SQL.GET_ALL_ENGINE_GROUPS;
import static com.pw.dome.admin.Consts.SQL.GET_OPERATORS_LIST;
import static com.pw.dome.admin.Consts.SQL.GET_OPERATOR_CENTER_LIST;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.pw.dome.user.UserProfileEngineCenter;
import com.pw.dome.user.UserProfileEngineGroup;

@Repository
class BasicAdminRepository implements CustomAdminRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public void create(Object entity) {
        entityManager.persist(entity);
    }

    @Override
    public List<UserProfileEngineCenter> getAllEngineCenters() {
        Query query = entityManager.createNativeQuery(GET_ALL_ENGINE_CENTERS);
        @SuppressWarnings("unchecked")
        List<Object[]> qryResults = query.getResultList();

        List<UserProfileEngineCenter> response = new ArrayList<>(qryResults.size());

        for (Object[] row : qryResults) {
            UserProfileEngineCenter upec =
                UserProfileEngineCenter.builder()
                    .engineCenterID((String) row[0])
                    .engineCenterName((String) row[1])
                    .build();
            response.add(upec);
        }
        return response;
    }

    @Override
    public List<UserProfileEngineCenter> getAllEngineCentersAndGroups(String filterEngGroupName) {
        Query query = entityManager.createNativeQuery(GET_ALL_ENGINE_CENTERS_AND_MATCHING_ENGINE_GROUPS_EXCEPT);
        query.setParameter("filterEngGroupName", filterEngGroupName);
        @SuppressWarnings("unchecked")
        List<Object[]> qryResults = query.getResultList();
        return buildResponse(qryResults);
    }

    @Override
    public List<UserProfileEngineCenter> getAllEngineCentersAndGroups() {
        Query query = entityManager.createNativeQuery(GET_ALL_ENGINE_CENTERS_AND_MATCHING_ENGINE_GROUPS);
        @SuppressWarnings("unchecked")
        List<Object[]> qryResults = query.getResultList();
        return buildResponse(qryResults);
    }

    private List<UserProfileEngineCenter> buildResponse(List<Object[]> qryResults) {
        List<UserProfileEngineCenter> response = new ArrayList<>(qryResults.size());
        UserProfileEngineCenter upec = null;
        String prevEcId = null;

        for (Object[] row : qryResults) {
            final String ecId = (String) row[0];

            if (!StringUtils.equals(ecId,
                                    prevEcId)) {
                upec = UserProfileEngineCenter.builder()
                    .engineCenterID((String) row[0])
                    .engineCenterName((String) row[1])
                    .build();
                response.add(upec);
            }
            UserProfileEngineGroup upeg =
                UserProfileEngineGroup.builder()
                    .engineGroupID((String) row[2])
                    .engineGroupName((String) row[3])
                    .engineTypeID((String) row[4])
                    .engineTypeName((String) row[5])
                    .build();
            upec.addEngineGroup(upeg);
            prevEcId = ecId;
        }

        return response;
    }
    
    @Override
    public List<UserProfileEngineGroup> getAllEngineGroups() {
        Query query = entityManager.createNativeQuery(GET_ALL_ENGINE_GROUPS);
        @SuppressWarnings("unchecked")
        List<Object[]> qryResults = query.getResultList();

        List<UserProfileEngineGroup> response = new ArrayList<>(qryResults.size());

        for (Object[] row : qryResults) {
            UserProfileEngineGroup userInfo =
                UserProfileEngineGroup.builder()
                    .engineGroupID((String) row[0])
                    .engineGroupName((String) row[1])
                    .engineTypeID((String) row[2])
                    .engineTypeName((String) row[3])
                    .build();
            response.add(userInfo);
        }
        return response;
    }

    public void update(Object entity) {
        entityManager.merge(entity);
    }

	@Override
	public List<Operator> getOperators() {
		Query query = entityManager.createNativeQuery(GET_OPERATORS_LIST);
        @SuppressWarnings("unchecked")
        List<Object[]> qryResults = query.getResultList();

        List<Operator> response = new ArrayList<>(qryResults.size());

        for (Object[] row : qryResults) {
        	Operator userInfo = Operator.builder()
                .customerId((String) row[0])
                .customerName((String) row[1])
                .customerShortName((String) row[2])
                .engineTypeId((String) row[3])
                .engineTypeName((String) row[4])
                .build();
            response.add(userInfo);
        }
        return response;
	}
    
	@Override
	public List<OperatorEngineCenter> getOperatorEngineCenters(){
		Query query = entityManager.createNativeQuery(GET_OPERATOR_CENTER_LIST);
        @SuppressWarnings("unchecked")
        List<Object[]> qryResults = query.getResultList();

        List<OperatorEngineCenter> response = new ArrayList<>(qryResults.size());

        for (Object[] row : qryResults) {
        	OperatorEngineCenter oec = OperatorEngineCenter.builder()
                .engineCenterId((String) row[0])
                .engineCenterName((String) row[1])
                .engineTypeId((String) row[2])
                .engineTypeName((String) row[3])
                .build();
            response.add(oec);
        }
        return response;
	}
    
}
