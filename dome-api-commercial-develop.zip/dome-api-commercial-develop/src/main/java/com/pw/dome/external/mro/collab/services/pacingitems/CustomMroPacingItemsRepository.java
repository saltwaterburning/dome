package com.pw.dome.external.mro.collab.services.pacingitems;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

interface CustomMroPacingItemsRepository {
	@Query(Consts.SQL.GET_ALL)
	List<MroPacingItem> getAll();
}
