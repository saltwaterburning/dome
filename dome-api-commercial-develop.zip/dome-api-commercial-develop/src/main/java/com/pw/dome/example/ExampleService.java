package com.pw.dome.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.pw.dome.exception.NotFoundException;

import lombok.extern.slf4j.Slf4j;

/**
 * Example service.
 */
@Service
@Slf4j // Use additional logging sparingly to avoid logging spam.
class ExampleService {

	public ExampleRequestAndResponse getIt(String esn, String workOrder) {
		boolean throwNotFound = false;

		if (throwNotFound) {
			// Create concise message.
			String msg = String.format("Unable to find matching example; esn=%s, workOrder=%s.", esn, workOrder);
			// Logging not usually need since logging of all requests with detailed request and response information can be enabled in profile
			// Instead enable in your Spring Boot profile.
//			  request-logging:
//				    logToDatabase: true
//				    logToFile: true
			log.warn("Fetch failed: {}", msg);
			throw new NotFoundException(msg);
		}

		return new ExampleRequestAndResponse();
	}

	public List<String> getItAll() {
		List<String> list = new ArrayList<>();
		
		// Etc...

		return list;
	}
}
