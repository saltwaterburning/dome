package com.pw.dome.calendar.induction;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Getter 
@Setter 
@NoArgsConstructor 
@ToString
public class CalendarRequest {
	private String userEmailID;
	private int year;
	private int month;
	private String engineCenterID;
	private String engineTypeID;
}
