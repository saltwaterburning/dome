package com.pw.dome.enginecenter;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author John De Lello
 */
public interface SecurityEngineCenterRespository extends CustomSecurityEngineCenterRespository, JpaRepository<SecurityEngineCenterEntity, Long> {
	Long deleteSecurityEngineCentersByEmailAddressIgnoreCase(final String emailAddress);
	List<SecurityEngineCenterEntity> getSecurityEngineCentersByEmailAddressIgnoreCase(final String emailAddress);
}
