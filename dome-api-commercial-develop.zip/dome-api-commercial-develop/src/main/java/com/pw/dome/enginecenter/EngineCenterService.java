package com.pw.dome.enginecenter;

/**
 * @author John De Lello
 */
public interface EngineCenterService {
	EngineCenterEntity getEngineCenterByID(final String engineCenterID);
}
