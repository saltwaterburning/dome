package com.pw.dome.engine.events;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import com.pw.dome.jpa.AbstractEntityWithEmbeddedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "DOME_ENGINE_EVENTS")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EngineEventEntity extends AbstractEntityWithEmbeddedId<EngineEventEntityPK> {

	@EmbeddedId
	private EngineEventEntityPK pk;

	@Column(name = "SHOP_VISIT_FLAG")
	private boolean isShopVisit;

	@Column(name = "MAINTENANCE_TYPE")
	private String maintenanceType;

	@Column(name = "OPERATOR")
	private String operator;

	@Column(name = "OPERATOR_CODE")
	private String operatorCode;

	@Column(name = "IS_PLANNED")
	private boolean planned;

	@Column(name = "REMOVAL_DATE")
	private LocalDate removalDate;

	@Column(name = "REMOVAL_DATE_RECORDED")
	private LocalDate removalDateRecorded;

	@Column(name = "REMOVAL_REASON")
	private String removalReason;

	@Column(name = "IS_SHIPPED")
	private boolean shipped;

	@Column(name = "SHOP_CODE")
	private String shopCode;

	@Column(name = "SHOP_NAME")
	private String shopName;

	@Column(name = "SLOT_ID")
	private Integer slotId;

	@Override
	public EngineEventEntityPK getId() {
		return pk;
	}
}
