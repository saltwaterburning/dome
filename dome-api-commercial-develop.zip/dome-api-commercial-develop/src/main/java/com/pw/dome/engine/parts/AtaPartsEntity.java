package com.pw.dome.engine.parts;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.NaturalId;

import com.pw.dome.jpa.AbstractEntityWithNaturalId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_ATA_PARTS")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Immutable
public class AtaPartsEntity extends AbstractEntityWithNaturalId<String> {
	@Id
	@NaturalId
	@Column(name="ATA")
	private String ata;

	@Column(name="PART_NUMBER")
	private String partNumber;

	@Column(name="ENG_TYPE_ID")
	private String engineTypeId;

	@Column(name="ENG_GROUP_ID")
	private String engineGroupId;

	@Column(name="DESCRIPTION")
	private String description;

	@Override
	public String getId() {
		return ata;
	}
}
