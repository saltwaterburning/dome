/**
 * Provides administrative resources.
 */
package com.pw.dome.admin;