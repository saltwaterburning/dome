package com.pw.dome.mml.le;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
interface LeMonthlyOpportunityRepository extends JpaRepository<LeMonthlyOpportunityEntity, Integer> {
    int deleteByIdIn(List<Integer> ids);
}
