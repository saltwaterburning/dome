package com.pw.dome.engine.odin.reports;


import java.time.LocalDate;
import java.util.List;

import lombok.Builder;


@Builder(toBuilder = true)
public record OdinRequest (
		 List<String> contractTypes,
		 List<String> engineTypes,
		 LocalDate fromDate,
		 LocalDate toDate){}