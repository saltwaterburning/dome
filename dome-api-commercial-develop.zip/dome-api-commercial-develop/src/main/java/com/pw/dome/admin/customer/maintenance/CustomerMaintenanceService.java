package com.pw.dome.admin.customer.maintenance;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.customer.CustomerDTO;
import com.pw.dome.customer.CustomerEntity;
import com.pw.dome.customer.CustomerRepository;
import com.pw.dome.exception.BadRequestException;
import com.pw.dome.exception.NotFoundException;

@Service
public class CustomerMaintenanceService {

	@Autowired
	private CustomerRepository custRepo;

	@Transactional
	public List<CustomerDTO>  updateCustomers(List<CustomerDTO> customers) {
		DataMapper mapper = DataMapper.INSTANCE;
		List<CustomerDTO> response = new ArrayList<>();
		CustomerEntity existingEntity;

		for (CustomerDTO dto: customers) {
			CustomerEntity entity = mapper.toEntity(dto);
			String str;

			if (entity.isNew()) {
				if (custRepo.existsByName(str = entity.getName())) {
					String msg = String.format("Customer with Name \"%s\" already exists", str);
					throw new BadRequestException(msg);
				} else if (custRepo.existsByShortName(str = entity.getShortName())) {
					String msg = String.format("Customer with ShortName \"%s\" already exists", str);
					throw new BadRequestException(msg);
				}

				Long customerId = custRepo.getNextSeqVal();
				entity.setCustomerID(customerId.toString());
			} else {
				String err = String.format("Existing customer not found. Customer Id: %s", entity.getCustomerID());
				existingEntity = custRepo.findById(entity.getCustomerID()).orElseThrow(() -> new NotFoundException(err));
				// Name change?
				if (!StringUtils.equals(str = entity.getName(), existingEntity.getName()) && custRepo.existsByName(str)) {
					String msg = String.format("Customer with Name \"%s\" already exists", str);
					throw new BadRequestException(msg);
				}
				// Shortname change?
				if (!StringUtils.equals(str = entity.getShortName(), existingEntity.getShortName()) && custRepo.existsByShortName(str)) {
					String msg = String.format("Customer with ShortName \"%s\" already exists", str);
					throw new BadRequestException(msg);
				}

				mapper.merge(existingEntity, entity);
			}

			entity = custRepo.save(entity);
			CustomerDTO responseDTO = mapper.toDTO(entity);
			response.add(responseDTO);
		}

		custRepo.flush();
		return response;
	}
}
