package com.pw.dome.admin.enginecenter.maintenance;

import static com.pw.dome.admin.enginecenter.maintenance.Consts.SQL.DELETE_ENG_GROUP_FROM_ENGINE_SECURITY_CENTER;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.SQL.DELETE_ENG_TYPE_FROM_CENTER_TYPE_GROUP;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.SQL.DELETE_ENG_TYPE_FROM_CUSTOMER_TYPE_MAP;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.SQL.DELETE_ENG_TYPE_FROM_ENGINE_SECURITY_CENTER;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.SQL.DELETE_ENG_TYPE_FROM_ENG_TYPE_CENTER_MAP;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.SQL.GET_ENG_TYPES_BY_CENTER_ID;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.SQL.GET_ENG_TYPES_BY_CUSTOMER_ID;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.SQL.INSERT_INTO_CUSTOMER_TYPE_MAP;
import static com.pw.dome.admin.enginecenter.maintenance.Consts.SQL.INSERT_INTO_ENG_TYPE_CENTER_MAP;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class BasicMaintenanceRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public int deleteEngGroupFromEngSecurityCenter(String centerId, String typeId, String groupId) {
    	return execute(DELETE_ENG_GROUP_FROM_ENGINE_SECURITY_CENTER, centerId, typeId, groupId);
    }

    public int deleteEngTypeFromEngCenterTypeGroup(String centerId, String typeId, String groupId) {
    	return execute(DELETE_ENG_TYPE_FROM_CENTER_TYPE_GROUP, centerId, typeId, groupId);
    }

    public int deleteEngTypeFromEngSecurityCenter(String centerId, String typeId) {
    	return execute(DELETE_ENG_TYPE_FROM_ENGINE_SECURITY_CENTER, centerId, typeId);
    }

    public int deleteEngTypeFromEngTypeCenterMap(String centerId, String typeId) {
    	return execute(DELETE_ENG_TYPE_FROM_ENG_TYPE_CENTER_MAP, centerId, typeId);
    }
    
    public int deleteEngTypeFromCustomerTypeMap(String customerId, String typeId) {
    	return execute(DELETE_ENG_TYPE_FROM_CUSTOMER_TYPE_MAP, customerId, typeId);
    }

    public int deleteEngTypeFromEngSecurityCenter(String centerId, String typeId, String groupId) {
    	return execute(DELETE_ENG_TYPE_FROM_ENGINE_SECURITY_CENTER, centerId, typeId, groupId);
    }

    private int execute(String sql, String arg1, String arg2) {
    	return execute(sql, arg1, arg2, null);
    }

    private int execute(String sql, String arg1, String arg2, String arg3) {
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter(1, arg1);
        if (arg2 != null) {
            query.setParameter(2, arg2);
            if (arg3 != null) {
                query.setParameter(3, arg3);
            }
        }

        return query.executeUpdate();
    }

	public void flush() {
    	entityManager.flush();
    }

    @Transactional(readOnly = true)
    public Set<String> getEngineTypeByCenter(String centerId) {
        Query query = entityManager.createNativeQuery(GET_ENG_TYPES_BY_CENTER_ID);
        @SuppressWarnings("unchecked")
        List<String> qryResults = query.setParameter(1, centerId)
        		                       .getResultList();
        return new HashSet<>(qryResults);
    }
    
    @Transactional(readOnly = true)
    public Set<String> getEngineTypeByCutomer(String customerId) {
        Query query = entityManager.createNativeQuery(GET_ENG_TYPES_BY_CUSTOMER_ID);
        @SuppressWarnings("unchecked")
        List<String> qryResults = query.setParameter(1, customerId)
        		                       .getResultList();
        return new HashSet<>(qryResults);
    }
    
    

    /**
	 * INSERT row into dome_eng_type_center_map table if not already present.
	 * 
	 * @param centerId EngineCenter Id
	 * @param typeId EngineType Id
	 * @return inserted row count
	 */
	public int insertIntoEngTypeCenterMap(String centerId, String typeId) {
        Query query = entityManager.createNativeQuery(INSERT_INTO_ENG_TYPE_CENTER_MAP);
        return query.setParameter(1, centerId)
                    .setParameter(2, typeId)
        	        .executeUpdate();
    }
	
	public int insertIntoCustomerEngineTypeMap(String customerId, String typeId) {
        Query query = entityManager.createNativeQuery(INSERT_INTO_CUSTOMER_TYPE_MAP);
        return query.setParameter(1, customerId)
                    .setParameter(2, typeId)
        	        .executeUpdate();
    }
}
