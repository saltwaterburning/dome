package com.pw.dome.admin.misc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
class AdminMiscService {
	@Autowired
	private AdminMiscRepository repo;

	@Transactional(readOnly = true)
	List<AdminUser> getAdminUsers() {
		return repo.getAdminUsers();
	}
}
