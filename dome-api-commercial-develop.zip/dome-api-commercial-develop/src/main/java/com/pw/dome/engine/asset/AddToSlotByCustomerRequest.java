package com.pw.dome.engine.asset;

import jakarta.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class AddToSlotByCustomerRequest {
	@NotNull
	private String customerID;
	private String engineGroupID;
	private String engineModelID;
	private String category;
	private String salesOrderType;
}
