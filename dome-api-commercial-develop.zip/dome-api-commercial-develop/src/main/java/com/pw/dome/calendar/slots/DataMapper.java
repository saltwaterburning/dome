package com.pw.dome.calendar.slots;

import java.time.LocalDate;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.engine.EngineEntity;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
  DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

  @Mapping(target = "engineTypeName", source = "slot.engineType.name")
  CreateSlotResponse toCreateResponse(SlotEntity slot);

  @Mapping(target = "engineTypeName", source = "slot.engineType.name")
  GetSlotResponse toGetResponse(SlotEntity slot, List<EngineEntity> engines);

  /**
   * Contains conditionExpression to set engineTypeID only if request isn't ShopVisitType.HOLIDAY.
   * 
   * @param request
   * @param caldate
   * @return
   */
  @Mapping(target = "engineType", ignore = true)
  @Mapping(target = "engineTypeID", conditionExpression = "java(request.getShopVisitType() != com.pw.dome.calendar.slots.ShopVisitType.HOLIDAY)", source = "request.engineTypeID")
  @Mapping(target = "slotID", ignore = true)
  @Mapping(target = "month", source = "request.month")
  @Mapping(target = "year", source = "request.year")
  SlotEntity toNewSlot(CreateSlotRequest request, LocalDate caldate);

  @Mapping(target = "customerName", source = "customer.name")
  @Mapping(target = "customerShortName", source = "customer.shortName")
  @Mapping(target = "engineGroupID", source = "groupID")
  @Mapping(target = "engineModelID", source = "modelID")
  SlotEngine toSlotEngine(EngineEntity entity);
}
