package com.pw.dome.aop;

import org.springframework.aop.BeforeAdvice;

import com.pw.dome.aop.jpa.CustomRepositoryFactory;

/**
 * Marker interface used to inject advise invoked prior to the matching JPA method(s).
 * Simply create a marker interface (empty) as an extension of this one.
 * Then implement JpaRepository method(s) in the subclass.
 * 
 * @see CustomRepositoryFactory
 */
public interface BeforeMethodsAdvise<T, ID> extends BeforeAdvice {

}
