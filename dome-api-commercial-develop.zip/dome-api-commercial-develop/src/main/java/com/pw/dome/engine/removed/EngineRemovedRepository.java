package com.pw.dome.engine.removed;

import static com.pw.dome.engine.removed.Consts.SQL.REMOVED_DETAILS_BY_ID;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * @author John De Lello
 */
@Repository
public interface EngineRemovedRepository extends JpaRepository<EngineRemovedEntity, Integer> {
	
// }, EngineRemovedRepositoryAfterMethods, EngineRemovedRepositoryBeforeMethods {

	List<EngineRemovedEntity> findByEsn(String esn);

	@Query(value = REMOVED_DETAILS_BY_ID)
	EngineRemovedEntity getEngineRemovedDetails(int removedEnginesId);
}
