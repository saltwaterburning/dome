package com.pw.dome.external.workscope;

import static com.pw.dome.external.mro.ValidationUtil.validate;

import java.util.Objects;

import jakarta.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.pw.dome.external.RemoteServicesWebClient;
import com.pw.dome.external.workscope.provider.Provider;
import com.pw.dome.external.workscope.provider.ProviderRequest;
import com.pw.dome.external.workscope.shopvisit.WstShopVisitRequest;
import com.pw.dome.web.requestlogging.RequestLoggingService;
import com.pw.dome.wip.WorkInProgress;

/**
 * Workshop Tool request handler implementation.
 */
@Service
abstract class WstWebClientAbstractService {
	@Autowired
	private ConfigWorkscopeApi config;
	@Autowired
	private WstDbRepo repo;
	@Autowired
	private Validator validator;
	@Autowired
	@Lazy
	@Qualifier("WST")
	private RemoteServicesWebClient webClient;

	@Bean("WST")
	RemoteServicesWebClient createWebClient(ConfigWorkscopeApi config, RequestLoggingService loggingSvc) {
		return new RemoteServicesWebClient(this.getClass(), config, loggingSvc);
	}

	void doDeleteProviders(ProviderRequest request) {
		Objects.requireNonNull(request);

		validate(validator, request);

		for (Provider provider : request.data()) {
			webClient.postRequest(provider, config.getDeleteProviderUri());
		}
	}

	void doPushProviders(ProviderRequest request) {
		Objects.requireNonNull(request);
		validate(validator, request);

		webClient.postRequest(request, config.getPushProviderUri());
	}

	void doPushShopVisitDetails(WorkInProgress wip) {
		Objects.requireNonNull(wip);

		String svClassification = repo.getOdinSvClassification(wip.getEngineSN(), wip.getEngineEventId());
		WstShopVisitRequest request = DataMapper.INSTANCE.toMroGateInfo(wip, svClassification);
		validate(validator, request);

		webClient.postRequest(request, config.getPushShopVisitDetailsUri());
	}
}
