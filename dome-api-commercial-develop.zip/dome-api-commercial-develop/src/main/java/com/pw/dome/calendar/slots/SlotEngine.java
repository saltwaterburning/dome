package com.pw.dome.calendar.slots;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class SlotEngine {
	private String customerID;
	private String customerName;
	private String customerShortName;
	private String engineGroupID;
	private int engineID;
	private String engineModelID;
	private String esn;
}
