package com.pw.dome.engine.tracking;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author John De Lello
 */

@Service
public class EngineTrackingServiceImpl implements EngineTrackingService {

	@Autowired
	EngineTrackingRepository engineTrackingRepo;

	@Override
	@Transactional
	public EngineTrackingEntity save(final EngineTrackingEntity engineTracking) {
		EngineTrackingEntity engineTrackingNew =  engineTrackingRepo.saveAndFlush(engineTracking);
		return engineTrackingNew;
	}

	@Override
	@Transactional(readOnly = true)
	public EngineTrackingEntity getEngineTrackingByID(final int engineID) {
		return engineTrackingRepo.findById(engineID).orElse(null);	
	}

	@Override
	@Transactional
	public void delete(final EngineTrackingEntity engineTracking) {
		engineTrackingRepo.delete(engineTracking);
	}
	
	

}
