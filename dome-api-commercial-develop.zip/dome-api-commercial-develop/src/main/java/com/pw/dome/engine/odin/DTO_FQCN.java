package com.pw.dome.engine.odin;

import org.springframework.data.jpa.repository.Query;

/**
 * Fully Classified Class Name constants used by JPQL Constructor Expressions.
 * The {@link Query}.value must be a constant expression.
 */
public interface DTO_FQCN {
    String DTO_NAME = "com.pw.dome.engine.odin.OdinDTO";
    String BASE_DTO_NAME = "com.pw.dome.engine.odin.OdinBaseDTO";
}
