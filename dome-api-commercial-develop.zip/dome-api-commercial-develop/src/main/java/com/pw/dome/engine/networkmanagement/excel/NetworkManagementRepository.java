package com.pw.dome.engine.networkmanagement.excel;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pw.dome.engine.EngineEntity;

@Repository
interface NetworkManagementRepository extends CustomRepository, JpaRepository<EngineEntity, Integer> {

//	@Query(NETWORK_MANAGEMENT)
//	List<NetworkManagement> getNetworkManagementData(
//			@Param("ignoreEngCenter")
//			boolean ignoreEngCenter,
//			@Param("engCenter")
//			List<String> engCenter, 
//			@Param("ignoreEngType")
//			boolean ignoreEngType,
//			@Param("engType")
//			List<String> engType, 
//			@Param("ignoreCustId")
//			boolean ignoreCustId,
//			@Param("custId")
//			List<String> custId,
//			@Param("ignoreContractType")
//			boolean ignoreContractType,
//			@Param("contractType")
//			List<String> contractType);
//
//	@Query(REMOVED_NETWORK_MANAGEMENT)
//	List<NetworkManagement> getRemovedNetworkManagementData(
//			@Param("ignoreEngType")
//			boolean ignoreEngType,
//			@Param("engType")
//			final List<String> engType);
}
