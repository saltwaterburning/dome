package com.pw.dome.calendar;

import java.util.List;

import lombok.Builder;

@Builder
public record CalendarRequest(List<String> engineTypeIds, int month, int year) {

}
