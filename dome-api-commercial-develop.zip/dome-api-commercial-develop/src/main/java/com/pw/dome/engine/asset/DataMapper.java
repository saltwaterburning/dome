package com.pw.dome.engine.asset;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.calendar.slots.SlotEntity;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

	@Mapping(target = "engineTypeID", source = "asset.engineTypeID")
	@Mapping(target = "operatorName", source = "asset.operator.name")
	@Mapping(target = "status", ignore = true)
	@Mapping(target = "visitType", source = "slot.shopVisitType")
	EngineAssetResponse toResponse(EngineAssetEntity asset, SlotEntity slot);
}
