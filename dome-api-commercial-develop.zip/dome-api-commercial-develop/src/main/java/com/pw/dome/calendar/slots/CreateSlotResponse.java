package com.pw.dome.calendar.slots;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class CreateSlotResponse{
	private int day;
	private String engineCenterID;
	private String engineTypeID;
	private String engineTypeName;
	private int month;
	private ShopVisitType shopVisitType;
	private int slotCount;
	private int slotID;
	private int year;
}
