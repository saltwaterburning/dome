package com.pw.dome.mml;


import static com.pw.dome.mml.QuarterlyConsts.SQL.QUARTERLY_MML_INDUCTION_DATA;
import static com.pw.dome.mml.QuarterlyConsts.SQL.QUARTERLY_MML_PLAN_INDUCTION_DATA;
import static com.pw.dome.mml.QuarterlyConsts.SQL.QUARTERLY_MML_PLAN_REVENUE_DATA;
import static com.pw.dome.mml.QuarterlyConsts.SQL.QUARTERLY_MML_PLAN_SHIPMENT_DATA;
import static com.pw.dome.mml.QuarterlyConsts.SQL.QUARTERLY_MML_REVENUE_DATA;
import static com.pw.dome.mml.QuarterlyConsts.SQL.QUARTERLY_MML_SHIPMENT_DATA;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
interface MmlQuarterlyRepository extends JpaRepository<MmlQuarterlyEntity, Integer> {
    
    // Quarterly MML Induction Data
	@Query(QUARTERLY_MML_INDUCTION_DATA)
    List<MmlEntity> getMmlQuarterlyInductionData(@Param("planMonth") final int planMonth,
    											 @Param("planYear") final int planYear, 
    											 @Param("ecid") final String ecid, 
    											 @Param("engineGroupIds") final List<String> engineGroups, 
    											 @Param("planType") final PlanType planType, 
    											 @Param("planMarket") final PlanMarket planMarket);
	// Quarterly MML Revenue Data
	@Query(QUARTERLY_MML_REVENUE_DATA)
    List<MmlEntity> getMmlQuarterlyRevenueData(@Param("planMonth") final int planMonth, 
                                               @Param("planYear") final int planYear, 
                                               @Param("ecid") final String ecid, 
                                               @Param("engineGroupIds") final List<String> engineGroups, 
                                               @Param("planType") final PlanType planType, 
                                               @Param("planMarket") final PlanMarket planMarket);

    // Quarterly MML Shipment Data
	@Query(QUARTERLY_MML_SHIPMENT_DATA)
    List<MmlEntity> getMmlQuarterlyShipmentData(@Param("planMonth") final int planMonth, 
                                                @Param("planYear") final int planYear, 
                                                @Param("ecid") final String ecid, 
                                                @Param("engineGroupIds") final List<String> engineGroups, 
                                                @Param("planType") final PlanType planType, 
                                                @Param("planMarket") final PlanMarket planMarket);

    // Quarterly MML Plan Induction Data
	@Query(QUARTERLY_MML_PLAN_INDUCTION_DATA)
    List<MmlEntity> getMmlQuarterlyPlanInductionData(@Param("ecid") final String ecid, 
                                                     @Param("engineGroupIds") final List<String> engineGroups, 
                                                     @Param("planType") final PlanType planType, 
                                                     @Param("planMarket") final PlanMarket planMarket, 
                                                     @Param("planMonth") final int planMonth, 
                                                     @Param("planYear") final int planYear);

    // Quarterly Plan MML Revenue Data
	@Query(QUARTERLY_MML_PLAN_REVENUE_DATA)
    List<MmlEntity> getMmlQuarterlyPlanRevenueData(@Param("ecid") final String ecid, 
                                                   @Param("engineGroupIds") final List<String> engineGroups, 
                                                   @Param("planType") final PlanType planType, 
                                                   @Param("planMarket") final PlanMarket planMarket, 
                                                   @Param("planMonth") final int planMonth, 
                                                   @Param("planYear") final int planYear);

    // Quarterly Plan MML Shipment Data
	@Query(QUARTERLY_MML_PLAN_SHIPMENT_DATA)
    List<MmlEntity> getMmlQuarterlyPlanShipmentData(@Param("ecid") final String ecid, 
                                                    @Param("engineGroupIds") final List<String> engineGroups, 
                                                    @Param("planType") final PlanType planType, 
                                                    @Param("planMarket") final PlanMarket planMarket, 
                                                    @Param("planMonth") final int planMonth, 
                                                    @Param("planYear") final int planYear);	

    @Modifying
    @Query(value="DELETE from MmlQuarterlyEntity mmlQuarterlyEntity where planMarket = :planMarket and planType = :planType and mmlQuarterlyEntity.engineId in :engineIds")
    Integer deleteByEngineIds(@Param("planMarket") final PlanMarket planMarket, @Param("planType") final PlanType planType, @Param("engineIds") final List<Integer> engineIds);
    
    @Modifying
    @Query(value="DELETE from MmlQuarterlyEntity mmlQuarterlyEntity where mmlQuarterlyEntity.engineId = :engineId")
    Integer deleteByEngineId(@Param("engineId")Integer engineId);
}
