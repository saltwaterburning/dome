package com.pw.dome.engine.asset;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author John De Lello
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Operator {
	private String operatorID;
	private String operatorName;
}
