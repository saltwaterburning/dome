package com.pw.dome.induction.removal.records;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequestMapping("/v1/induction")
class RemovalRecordsController {
	@Autowired
	private RemovalRecordsService removalRecordsService;

	@PostMapping(path = "/removal-records", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<RemovalRecordsResponse> getRemovalRecords(
			@Valid
    		@RequestBody
    		final RemovalRecordsRequest request) {
		RemovalRecordsResponse response = removalRecordsService.findRemovalRecords(request);
		return ResponseEntity.ok(response);
	}
}
