package com.pw.dome.external.workscope;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.admin.enginecenter.maintenance.BasicEngineCenter;
import com.pw.dome.external.workscope.provider.Provider;
import com.pw.dome.external.workscope.shopvisit.WstShopVisitRequest;
import com.pw.dome.wip.WorkInProgress;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

	@Mapping(target = "actualAssetCompleteDate", source = "wip.engineActualAssetCompleteDate")
	@Mapping(target = "actualCoreAssemblyDate", source = "wip.engineActualCoreAssemblyDate")
	@Mapping(target = "actualGate1CloseDate", source = "wip.engineActualGate1CloseDate")
	@Mapping(target = "actualGate3CloseDate", source = "wip.engineActualGate3CloseDate")
	@Mapping(target = "actualGate3CompleteDate", source = "wip.engineActualGate3CompleteDate")
	@Mapping(target = "actualGate3StartDate", source = "wip.engineActualGate3StartDate")
	@Mapping(target = "actualInductDate", source = "wip.engineActualInductDate")
	@Mapping(target = "actualKitCompleteDate", source = "wip.engineActualKitCompleteDate")
	@Mapping(target = "actualReceiptDate", source = "wip.engineActualReceiptDate")
	@Mapping(target = "actualReceiveDate", source = "wip.engineActualReceiveDate")
	@Mapping(target = "actualRemovalDate", source = "wip.engineActualRemovalDate")
	@Mapping(target = "actualShipDate", source = "wip.engineActualShipDate")
	@Mapping(target = "actualShipToCustDate", source = "wip.engineActualShipToCustDate")
	@Mapping(target = "actualTestCompleteDate", source = "wip.engineActualTestCompleteDate")
	@Mapping(target = "actualTestStartDate", source = "wip.engineActualTestStartDate")
	@Mapping(target = "contractDate", source = "wip.engineContractDate")
	@Mapping(target = "esn", source = "wip.engineSN")
	@Mapping(target = "eventId", source = "wip.engineEventId")
	@Mapping(target = "externalAssetCompleteDate", source = "wip.engExternalAssetCompleteDate")
	@Mapping(target = "externalContractDate", source = "wip.engineExternalContractDate")
	@Mapping(target = "externalCoreAssemblyDate", source = "wip.engineExternalCoreAssemblyDate")
	@Mapping(target = "externalGate1CloseDate", source = "wip.engineExternalGate1CloseDate")
	@Mapping(target = "externalGate3CloseDate", source = "wip.engineExternalGate3CloseDate")
	@Mapping(target = "externalGate3StartDate", source = "wip.engineExternalGate3StartDate")
	@Mapping(target = "externalInductDate", source = "wip.engineExternalInductDate")
	@Mapping(target = "externalKitCompleteDate", source = "wip.engineExternalKitCompleteDate")
	@Mapping(target = "externalReceiptDate", source = "wip.engineExternalReceiptDate")
	@Mapping(target = "externalReceiveDate", source = "wip.engineExternalReceiveDate")
	@Mapping(target = "externalShipDate", source = "wip.engineExternalShipDate")
	@Mapping(target = "externalShipToCustDate", source = "wip.engineExternalShipToCustDate")
	@Mapping(target = "externalTestCompleteDate", source = "wip.engineExternalTestCompleteDate")
	@Mapping(target = "externalTestStartDate", source = "wip.engineExternalTestStartDate")
	@Mapping(target = "operator", source = "wip.engineOperator")
	@Mapping(target = "planAssetCompleteDate", source = "wip.enginePlanAssetCompleteDate")
	@Mapping(target = "planCoreAssemblyDate", source = "wip.enginePlanCoreAssemblyDate")
	@Mapping(target = "planGate1CloseDate", source = "wip.enginePlanGate1CloseDate")
	@Mapping(target = "planGate3CloseDate", source = "wip.enginePlanGate3CloseDate")
	@Mapping(target = "planGate3StartDate", source = "wip.enginePlanGate3StartDate")
	@Mapping(target = "planInductDate", source = "wip.enginePlanInductDate")
	@Mapping(target = "planKitCompleteDate", source = "wip.enginePlanKitCompleteDate")
	@Mapping(target = "planReceiptDate", source = "wip.enginePlanReceiptDate")
	@Mapping(target = "planReceiveDate", source = "wip.enginePlanReceiveDate")
	@Mapping(target = "planRemovalDate", source = "wip.enginePlanRemovalDate")
	@Mapping(target = "planShipDate", source = "wip.enginePlanShipDate")
	@Mapping(target = "planShipToCustDate", source = "wip.enginePlanShipToCustDate")
	@Mapping(target = "planTestCompleteDate", source = "wip.enginePlanTestCompleteDate")
	@Mapping(target = "planTestStartDate", source = "wip.enginePlanTestStartDate")
	@Mapping(target = "provider", source = "wip.mroShopCode")
	@Mapping(target = "smiNumber", source = "wip.workOrder")
	WstShopVisitRequest toMroGateInfo(WorkInProgress wip, String svClassification);

	@Mapping(target = "providerCode", source = "centerId")
	@Mapping(target = "providerName", source = "centerName")
	Provider toProvider(BasicEngineCenter ec);

	List<Provider> toProvider(List<BasicEngineCenter> ec);
}
