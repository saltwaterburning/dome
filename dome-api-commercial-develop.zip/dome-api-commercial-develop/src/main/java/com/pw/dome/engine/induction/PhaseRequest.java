package com.pw.dome.engine.induction;

import static java.util.Objects.nonNull;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.pw.dome.engine.phase.EnginePhases;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;

@Builder(toBuilder = true)
public record PhaseRequest(@NotEmpty List<@NotNull String> engineTypeIds, @NotNull EnginePhases phase, String esn) {
	@AssertTrue(message = "An ESN is required")
	public boolean isEsn() {
		return !(nonNull(phase) && phase.searchRequiresEsn() && StringUtils.isBlank(esn));
	}
}
