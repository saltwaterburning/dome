package com.pw.dome.engine.odin;

import java.time.LocalDate;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * DTO which adds {@code preliminaryInductionDates} to the {@link OdinBaseDTO}.
  */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Schema(description = "ODIN Data Model")
@SuperBuilder
public class OdinDTO extends OdinBaseDTO {
    private String investigationCategory;

    // ESN + eventId
    // OdinHistoryEntity.prelimInductionDate
    private List<PreliminaryIndDateReason> preliminaryInductionDates;

    private LocalDate slotUpdatedDate;
    private String slotUpdatedUserFirstName;
    private String slotUpdatedUserLastName;

    private LocalDate smiNeedDate;
}

