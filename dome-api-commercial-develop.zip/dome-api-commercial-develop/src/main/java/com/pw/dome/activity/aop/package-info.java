/**
 * Provides activity logging aspect to JPA CRUD operations.
 */
package com.pw.dome.activity.aop;