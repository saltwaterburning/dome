package com.pw.dome.external.mro.collab.client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class MroCollabResponse {
	private Boolean Data;
	private String Exception;
	private Integer StatusCode;
}
