package com.pw.dome.aop;

import java.util.Objects;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pw.dome.activity.ActivityEntity;
import com.pw.dome.activity.ActivityService;
import com.pw.dome.activity.DataUtils;
import com.pw.dome.calendar.induction.CalendarShopVisit;
import com.pw.dome.calendar.slots.SlotEntity;
import com.pw.dome.calendar.slots.SlotRepository;
import com.pw.dome.calendar.slots.UpdateSlotRequest;
import com.pw.dome.engine.EngineEntity;
import com.pw.dome.engine.EngineRepository;
import com.pw.dome.engine.asset.AddEngineToSlotRequest;
import com.pw.dome.engine.odin.OdinDTO;
import com.pw.dome.user.UserProfileResponse;
import com.pw.dome.wip.WorkInProgress;
import com.pw.dome.wip.pacing.PacingItemDTO;
import com.pw.dome.wip.smi.SmiResponse;
import com.pw.dome.wip.smi.SmiRevisions;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
// TODO move to another package
public class DomeActivityLoggingAspect {

	@Autowired
	private ActivityService activityService;

	@Autowired
	private SlotRepository slotRepo;

	@Autowired
	private EngineRepository engineRepo;

	// Account Management : User Create
	@Around("execution(* com.pw.dome.admin.AdminService.create*(..)))")
	public Object saveActivityForUserCreate(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		UserProfileResponse request = (UserProfileResponse) signatureArgs[0];

		Object result = proceedingJoinPoint.proceed();

		log.debug("Intercepted AdminService.save");
		saveActivity(DataUtils.toActivityEntity((UserProfileResponse) request, true));

		return result;
	}

	// Account Management : User Update
	@Around("execution(* com.pw.dome.admin.AdminService.update*(..)))")
	public Object saveActivityForUserUpdate(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		UserProfileResponse request = (UserProfileResponse) signatureArgs[0];

		Object result = proceedingJoinPoint.proceed();

		log.debug("Intercepted AdminService.update");
		saveActivity(DataUtils.toActivityEntity((UserProfileResponse) request, false));

		return result;
	}

	// Induction Calendar : Create SlotEntity
	// Replaced with entity listener
	@Around("execution(* com.pw.dome.calendar.slots.SlotService.createSlot*(..)))")
	public Object saveActivityForCreateSlot(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object result = proceedingJoinPoint.proceed();

		log.debug("Intercepted SlotService.createSlot");

		saveActivity(DataUtils.toActivityEntityCreateSlot((SlotEntity) result));

		return result;
	}

	// Induction Calendar : Delete SlotEntity
	// Replaced with entity listener
	@Around("execution(* com.pw.dome.calendar.slots.SlotService.deleteSlot*(..)))")
	public Object saveActivityForDeleteSlot(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		int slotID = (int) signatureArgs[1];
		SlotEntity slot = slotRepo.findById(slotID).orElse(null);

		Object result = proceedingJoinPoint.proceed();

		log.debug("Intercepted SlotService.deleteSlot");

		saveActivity(DataUtils.toActivityEntityDeleteSlot((SlotEntity) slot));

		return result;
	}

	// Induction Calendar : Update SlotEntity
	// Replaced with entity listener
	@Around("execution(* com.pw.dome.calendar.slots.SlotService.updateSlot*(..)))")
	public Object saveActivityForUpdateSlot(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		int slotID = (int) signatureArgs[1];
		UpdateSlotRequest updateSlotRequest = (UpdateSlotRequest) signatureArgs[2];

		SlotEntity slot = slotRepo.findById(slotID).orElse(null);

		Object result = proceedingJoinPoint.proceed();

		log.debug("Intercepted SlotService.deleteSlot");

		saveActivity(DataUtils.toActivityEntityUpdateSlot((SlotEntity) slot, updateSlotRequest.getShopVisitType()));

		return result;
	}

	// Induction Calendar : Add Engine
	@Around("execution(* com.pw.dome.engine.EngineService.addToSlotByCustomer*(..)))")
	public Object saveActivityForAddEngine(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		int slotID = (int) signatureArgs[1];

		Object result = proceedingJoinPoint.proceed();

		log.debug("Intercepted EngineService.addToSlotByCustomer");

		SlotEntity slot = slotRepo.findById(slotID).orElse(null);
		saveActivity(DataUtils.toActivityEntityAddEngine(slot, (CalendarShopVisit) result));

		return result;
	}

	@Around("execution(* com.pw.dome.engine.EngineService.addEngineAssetToSlotByEngine*(..)))")
	public Object saveActivityForAddEngineToSlot(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		AddEngineToSlotRequest request = (AddEngineToSlotRequest) signatureArgs[1];

		Object result = proceedingJoinPoint.proceed();

		log.debug("Intercepted EngineService.addEngineAssetToSlotByEngine");

		SlotEntity slot = slotRepo.findById(request.getSlotID()).orElse(null);
		saveActivity(DataUtils.toActivityEntityAddEngine(slot, (CalendarShopVisit) result));

		return result;
	}

	// FIXME- Now using BeforeCRUDAdvise
	// Induction Calendar : Delete Engine
//    @Around("execution(* com.pw.dome.engine.EngineService.deleteEngine*(..)))")
//    public Object saveActivityForDeleteEngine(ProceedingJoinPoint proceedingJoinPoint) throws Throwable 
//    {
//        Object[] signatureArgs = proceedingJoinPoint.getArgs();
//        int engineID = (int) signatureArgs[1];
//        EngineEntity engine = engineRepo.findById(engineID).orElse(null);
//        
//        Object result = proceedingJoinPoint.proceed(); 
//        
//        log.debug("Intercepted EngineService.deleteEngine");
//        
//        
//        final int slotID = engine.getSlot() != null ? engine.getSlot().getSlotID() : -1;
//        
//        SlotEntity slot = slotRepo.findById(slotID).orElse(null);
//        saveActivity(DataUtils.toActivityEntityDeleteEngine(engine, slot));
//
//        return result;
//    }

	// Induction Calendar : Update Engine SlotEntity
	@Around("execution(* com.pw.dome.engine.EngineService.updateEngineSlot*(..)))")
	public Object saveActivityForUpdateEngineSlot(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		int newSlotID = signatureArgs[2] != null ? ((int) signatureArgs[2]) : 0;
		SlotEntity slot = slotRepo.findById(newSlotID).orElse(null);

		Object result = proceedingJoinPoint.proceed();

		log.debug("Intercepted EngineService.updateEngineSlot");
		saveActivity(DataUtils.toActivityEntity(slot, (CalendarShopVisit) result));

		return result;
	}

	// Induction Planning : Save Engine OID Details
	@Around("execution(* com.pw.dome.engine.odin.EngineOdinService.saveEngineOdinDetails*(..)))")
	public Object saveActivityForSaveEngineOdinDetails(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		OdinDTO request = ((OdinDTO) signatureArgs[0]);

		Object result = proceedingJoinPoint.proceed();

		Integer engId = ((OdinDTO) result).getEngineId();
		EngineEntity engine = null;
		if (Objects.nonNull(engId)) {
			engine = engineRepo.findById(engId).orElse(null);
		}

		log.debug("Intercepted EngineService.updateEngineSlot");
		saveActivity(DataUtils.toActivityEntity(request, engine));

		return result;
	}

	// WIP Service : Save WIP Details
	@Around("execution(* com.pw.dome.wip.WipService.save(..)))")
	public Object saveActivityForUpdateWip(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object result = proceedingJoinPoint.proceed();

		log.debug("Intercepted WipService.save");
		saveActivity(DataUtils.toActivityEntity((WorkInProgress) result));

		return result;
	}

	// WIP Service : Save / update Pacing Item
	@Around("execution(* com.pw.dome.wip.pacing.PacingService.save*(..)))")
	public Object saveActivityForPacingItem(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		PacingItemDTO request = ((PacingItemDTO) signatureArgs[0]);

		Object result = proceedingJoinPoint.proceed();

		Integer engId = ((PacingItemDTO) result).getEngineId();
		EngineEntity engine = null;
		if (Objects.nonNull(engId)) {
			engine = engineRepo.findById(engId).orElse(null);
		}

		log.debug("Intercepted PacingService.save");
		saveActivity(DataUtils.toActivityEntity((PacingItemDTO) result, request.getPacingId(), engine));

		return result;
	}

	// WIP Service : Delete Pacing Item
	@Around("execution(* com.pw.dome.wip.pacing.PacingService.deleteById*(..)))")
	public Object saveActivityForDeletePacingItem(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		Integer pacingId = ((Integer) signatureArgs[0]);

		Object result = proceedingJoinPoint.proceed();

		log.debug("Intercepted PacingService.deleteById");
		saveActivity(DataUtils.toActivityEntityPacingId(pacingId));

		return result;
	}

	// SMI Revisions Service : Update
	@Around("execution(* com.pw.dome.wip.smi.SmiService.save*(..)))")
	public Object saveActivityForSaveSmiService(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		SmiResponse smiResponse = ((SmiResponse) signatureArgs[0]);

		Object result = proceedingJoinPoint.proceed();

		Integer engId = ((SmiResponse) result).getEngineId();
		EngineEntity engine = null;
		if (Objects.nonNull(engId)) {
			engine = engineRepo.findById(engId).orElse(null);
		}

		log.debug("Intercepted SmiService.save");
		for (SmiRevisions revision : smiResponse.getSmiRevisions()) {
			saveActivity(DataUtils.toActivityEntity(revision, engine));
		}

		return result;
	}

	// SMI Revisions Service : Delete
	@Around("execution(* com.pw.dome.wip.smi.SmiService.deleteById*(..)))")
	public Object saveActivityForDeleteSmiService(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		Object[] signatureArgs = proceedingJoinPoint.getArgs();
		Integer smiId = ((Integer) signatureArgs[0]);

		Object result = proceedingJoinPoint.proceed();

		log.debug("Intercepted SmiService.deleteById");
		saveActivity(DataUtils.toActivityEntityDeleteSmi(smiId));

		return result;
	}

	private void saveActivity(ActivityEntity request) {
		try {
			log.debug("Saving data to acitivity table");
			activityService.saveActivity(request);
		} catch (Exception e) {
			// Swallow the exception so it won't cause any service failure
			log.error("Error occured while saving data to acitvity table. Exception : " + e);
		}
	}

}
