package com.pw.dome.admin;

import java.util.List;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.pw.dome.enginecenter.SecurityEngineCenterEntity;
import com.pw.dome.user.UserProfile;
import com.pw.dome.user.UserProfileResponse;
import com.pw.dome.user.request.UserProfileUpdateEntity;

@Mapper(unmappedTargetPolicy = ReportingPolicy.ERROR)
interface DataMapper {
	DataMapper INSTANCE = Mappers.getMapper(DataMapper.class);

	List<CustomerCenterMatrixEntity> toEntities(List<CustomerCenterMatrixDTO> ccm);
	List<CustomerCenterMatrixDTO> toDTOs(List<CustomerCenterMatrixEntity> ccm);

	@Mapping(target = "customerId", source = "pk.customerId")
	@Mapping(target = "engineCenterId", source = "pk.engineCenterId")
	@Mapping(target = "engineTypeId", source = "pk.engineTypeId")
	CustomerCenterMatrixDTO toDTO(CustomerCenterMatrixEntity ccm);

	@InheritInverseConfiguration
	CustomerCenterMatrixEntity toEntity(CustomerCenterMatrixDTO dto);

	/**
	 * Sets status to APPROVED and updateDate to LocalDateTime.now().
	 * @param request
	 * @return
	 */
	@Mapping(target = "justification", source = "businessJustification")
	@Mapping(target = "lastLogin", ignore = true)
	@Mapping(target = "roleId", source = "securityRole")
	@Mapping(target = "updateDate", expression = "java(java.time.LocalDateTime.now())")
	@Mapping(target = "updateUser", source = "emailAddress")
	@Mapping(target = "userNetManagement", source = "netManagement")
	@Mapping(target = "userRCM", source = "rcm")
	@Mapping(target = "status", defaultExpression = "java(ProfileStatus.APPROVED)")
	UserProfile toUserProfile(UserProfileResponse request);

	/**
	 * Sets status to APPROVED and updateDate to LocalDateTime.now().
	 * @param request
	 * @return
	 */
	@Mapping(target = "justification", source = "businessJustification")
	@Mapping(target = "roleId", source = "securityRole")
	@Mapping(target = "updateDate", expression = "java(java.time.LocalDateTime.now())")
	@Mapping(target = "updateUser", source = "emailAddress")
	@Mapping(target = "userNetManagement", source = "netManagement")
	@Mapping(target = "userRCM", source = "rcm")
	@Mapping(target = "status", defaultExpression = "java(ProfileStatus.APPROVED)")
	UserProfileUpdateEntity toUserProfileUpdateEntity(UserProfileResponse request);

	/**
     * Copy to the destination object while preserving its unique {@code id}.
     * 
     * @param from source object
     * @param to destination object
     * @return the destination object (to)
     */
	@Mapping(target="id", ignore = true)
	SecurityEngineCenterEntity copy(SecurityEngineCenterEntity from, @MappingTarget SecurityEngineCenterEntity to);
}
