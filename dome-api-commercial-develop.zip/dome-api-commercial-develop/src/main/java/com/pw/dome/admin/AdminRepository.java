package com.pw.dome.admin;

import static com.pw.dome.admin.Consts.SQL.GET_APPROVED_USERS;
import static com.pw.dome.admin.Consts.SQL.GET_PENDING_USER_APPROVALS;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pw.dome.user.UserProfile;

@Repository
public interface AdminRepository extends JpaRepository<UserProfile, String> {
    boolean existsByEmailAddressIgnoreCase(String email);

    @Query(GET_PENDING_USER_APPROVALS)
    List<UserInfo> getPendingUsers();

    @Query(GET_APPROVED_USERS)
    List<UserInfo> getApprovedUsers();
}
