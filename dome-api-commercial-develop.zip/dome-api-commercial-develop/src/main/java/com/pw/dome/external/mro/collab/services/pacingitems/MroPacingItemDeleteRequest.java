package com.pw.dome.external.mro.collab.services.pacingitems;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * JSON LocalDate encoding format defined in {@code DateFormatConfig}.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "PacingItem delete request schema.")
class MroPacingItemDeleteRequest {
	@NotNull
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Integer engineId;

	@Size(min = 1, max = 20)
    @NotBlank
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String esn;

	@Min(1)
    @NotNull
    @NotBlank
	private Integer eventId;

	@Size(min = 1, max = 10)
    @NotBlank
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String mroShopCode;

	@Size(min = 1, max = 25)
    @NotBlank
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "Named SMI in MRO system.")
	private String mroWorkOrder;

	@NotBlank
	@Size(min = 0, max = 20)
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String category;

    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private LocalDate closeDate;

    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private LocalDate commitDate;

    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private LocalDate datReceivedDate;

    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private LocalDate datShipOutDate;

	@Size(min = 0, max = 50)
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String description;

//	@PositiveOrZero
    @Schema(required = false, description = "")
	private Integer dollarsSaved;

	@NotBlank
	@Size(min = 1, max = 10)
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String engineSN;

	/**
	 * ESC flag must be {@link Boolean} type for change detection.
	 * Change detection uses getters boolean type uses 'is' instead.
	 */
	@NotNull
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Boolean escItem;

    @Schema(required = false, description = "")
	private int holdDaysApproved;

    @Schema(required = false, description = "")
	private LocalDateTime logDateTime;

    @Schema(required = false, description = "")
	private LocalDate needDate;

	@Size(min = 0, max = 2000)
    @Schema(required = false, description = "")
	private String notes;

	@NotNull
    @Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Integer pacingId;

	@Size(min = 0, max = 20)
    @Schema(required = false, description = "")
	private String partId;

	@Size(min = 0, max = 20)
    @Schema(required = false, description = "")
	private String purchaseOrder;

    @Schema(required = false, description = "")
	private LocalDate startDate;

	@Size(min = 0, max = 20)
    @Schema(required = false, description = "")
	private String subCategory;

	@Size(min = 0, max = 20)
    @Schema(required = false, description = "")
	private String uniqueId;

    @Schema(required = false, description = "")
	private LocalDate vendorInDate;

	@Size(min = 0, max = 30)
    @Schema(required = false, description = "")
	private String vendorName;

    @Schema(required = false, description = "")
	private LocalDate vendorOutDate;

	@Size(min = 0, max = 20)
    @Schema(required = false, description = "")
	private String wsInd;
}
