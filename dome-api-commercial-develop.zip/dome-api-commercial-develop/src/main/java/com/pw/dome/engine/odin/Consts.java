package com.pw.dome.engine.odin;

interface Consts {
	String CURRENT_LOCATION_DAT = "DAT";
	String CURRENT_LOCATION_EBU = "EBU";
	String EBU_SHOP = "JALEC";

  interface SQL {
    String FIND_WITH_NULL_ARGS =
"""
SELECT e
FROM OdinEntity e
WHERE ?1 = e.esn
  AND ((?2 is null
        AND e.engineId is null)
       OR ?2 = e.engineId)
  AND ((?3 is null
        AND e.eventId is null)
       OR ?3 = e.eventId)
ORDER BY e.odinId DESC
""";
  }
}
