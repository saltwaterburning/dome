package com.pw.dome.engine.asset;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.calendar.induction.CalendarShopVisit;
import com.pw.dome.engine.EngineService;
import com.pw.dome.user.UserProfile;


@RestController()
@RequestMapping("/v1/engines/assets")
@Validated
public class EngineAssetController {
	@Autowired
	private EngineAssetService engineAssetSvc;
	@Autowired
	private EngineService engineSvc;

    @GetMapping(path = "/available/{slotID}/{esn}", produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<EngineAssetListResponse> getEngineAsssetList(
    		@NotNull
    		@AuthenticationPrincipal
    		UserProfile userProfile,
    		@NotNull
    		@PathVariable(name = "slotID")
    		Integer slotID,
    		@NotBlank
    		@PathVariable(name = "esn")
    		String esn) {

    	List<EngineAssetResponse> engines = engineAssetSvc.findAvailableEnginesBySlotIDAndEsn(userProfile, slotID, esn);
    	return ResponseEntity.ok(EngineAssetListResponse.builder().engines(engines).build());
    }
    
    @PostMapping
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE"})
    public ResponseEntity<CalendarShopVisit> addEngineToSlotByEngine(
    		@NotNull
    		@AuthenticationPrincipal UserProfile userProfile,
    		@Valid
    		@RequestBody
    		AddEngineToSlotRequest addEngineToSlotRequest) {

    	CalendarShopVisit calendarShopVisit = engineSvc.addEngineAssetToSlotByEngine(userProfile, addEngineToSlotRequest);
    	return new ResponseEntity<CalendarShopVisit>(calendarShopVisit, HttpStatus.OK);
    }

    @RequestMapping(value = "/customer/{slotID}", method = RequestMethod.POST)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE"})
    public ResponseEntity<CalendarShopVisit> addToSlotByCustomer(
    		@NotNull
    		@AuthenticationPrincipal UserProfile userProfile,
    		@NotNull
    		@PathVariable("slotID")
    		Integer slotID,
    		@NotNull
    		@Valid
    		@RequestBody
    		AddToSlotByCustomerRequest addToSlotByCustomerRequest) {

    	CalendarShopVisit calendarShopVisit = engineSvc.addToSlotByCustomer(userProfile, slotID, addToSlotByCustomerRequest);
    	return new ResponseEntity<CalendarShopVisit>(calendarShopVisit, HttpStatus.OK);
    }
}
