package com.pw.dome.mml.le;

import org.springframework.data.jpa.repository.Query;

/**
 * Fully Classified Class Name constants used by JPQL Constructor Expressions.
 * The {@link Query}.value must be a constant expression.
 */
interface DTO_FQCN {
    String DTO_NAME = "com.pw.dome.mml.le.DetailsDTO";
}
