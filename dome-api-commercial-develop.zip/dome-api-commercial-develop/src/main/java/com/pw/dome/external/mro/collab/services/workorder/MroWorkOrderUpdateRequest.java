package com.pw.dome.external.mro.collab.services.workorder;

import java.time.LocalDateTime;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.pw.dome.external.mro.MROConsts;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "Update work order schema.")
public class MroWorkOrderUpdateRequest {
	@Size(min = 1, max = 20)
	@NotBlank
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String esn;

	@Min(1)
	@NotNull
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Integer eventId;

	@Size(min = 1, max = 10)
	@NotBlank
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String mroShopCode;

	@Size(min = 1, max = 25)
	@NotBlank
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "Named SMI in MRO.")
	private String mroWorkOrder;

  // Needed only for unit testing...
	@JsonFormat(pattern = MROConsts.ISO_8601_FORMAT)
	@NotNull
  @Schema(requiredMode = RequiredMode.REQUIRED, description = "Strict ISO 8601 Format (yyyy-MM-dd'T'HH:mm:ss) - \"2023-12-12T23:12:12\" or Relaxed ISO 8601 Format (yyyy-MM-dd HH:mm:ss) - \"2023-12-12 23:12:12\"")
	private LocalDateTime publishedDateTime;
}
