package com.pw.dome.calendar.inductionplanning;

import java.util.Collection;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Builder
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class InductionPlanningCalendarVisitSummary {
	private String engineCenterCode;
	private String engineCenterID;
	private String engineCenterName;
	private Collection<InductionPlanningCalendarEngine> engines;
	private Integer shopVisitType;
	private int slotCount;
	private int slotID;
}
