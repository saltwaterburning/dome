package com.pw.dome.engine.group;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import com.pw.dome.user.UserProfile;
import com.pw.dome.web.authorization.SecurityService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author John De Lello
 */
@Slf4j
@Service
public class EngineGroupServiceImpl implements EngineGroupService {

	@Autowired
	private SecurityService securityService; 
	
	@Autowired
	private EngineGroupRepository engineGroupRepo;

	@Override
	public List<EngineGroupEntity> getEngineGroups(final UserProfile userProfile, final String engineCenterID, final String engineTypeID) {
		if(userProfile == null) {
			throw new IllegalArgumentException("No valid user profile was specified. Unable to get engine groups list.");
		}
		
		if(StringUtils.isEmpty(engineCenterID)) {
			throw new IllegalArgumentException("No valid Engine Center ID was specified. Unable to get engine groups list.");
		}
		
		if(StringUtils.isEmpty(engineTypeID)) {
			throw new IllegalArgumentException("No valid Engine Type ID was specified. Unable to get engine groups list.");
		}
		
    	boolean isAllowable = securityService.isAllowableEngineCenter(userProfile, engineCenterID);
		
    	if(!isAllowable) {
			log.error("User does not have access to engineCenterID [{}]", engineCenterID);
			throw new AccessDeniedException("User does not have access to engineCenterID [" + engineCenterID + "]. Unable to get engine group list.");
    	}
    	
		return engineGroupRepo.getEngineGroups(userProfile.getEmailAddress(), engineCenterID, engineTypeID);
	}

	@Override
	public List<EngineGroupEntity> getEngineGroups(final UserProfile userProfile, final String engineCenterID) {
		if(userProfile == null) {
			throw new IllegalArgumentException("No valid user profile was specified. Unable to get engine groups list.");
		}
		
    	boolean isAllowable = securityService.isAllowableEngineCenter(userProfile, engineCenterID);
		
    	if(!isAllowable) {
			log.error("User does not have access to engineCenterID [{}]", engineCenterID);
			throw new AccessDeniedException("User does not have access to engineCenterID [" + engineCenterID + "]. Unable to get engine group list.");
    	}		
    	
		return engineGroupRepo.getEngineGroups(userProfile.getEmailAddress(), engineCenterID);
	}
}
