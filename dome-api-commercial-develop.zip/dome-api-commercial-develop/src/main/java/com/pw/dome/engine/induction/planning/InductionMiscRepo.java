package com.pw.dome.engine.induction.planning;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
interface InductionMiscRepo extends JpaRepository<InductionMiscellaneousEntity, InductionMiscellaneousEntityPK> {
	List<InductionMiscellaneousEntity> findByIdKeyOrderByValue(String key);
	List<InductionMiscellaneousEntity> findByIdKeyOrderByIdFieldSeq(String key);
}
