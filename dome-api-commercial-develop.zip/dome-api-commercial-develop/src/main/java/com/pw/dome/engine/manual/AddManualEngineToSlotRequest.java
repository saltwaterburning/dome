package com.pw.dome.engine.manual;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class AddManualEngineToSlotRequest {
	private String category;
	private String customerID;
	private String engineGroupID;
	private String engineModelID;
	private String engineTypeId;
	private String esn;
	private String salesOrderType;
//	private String subVisitType;
}
