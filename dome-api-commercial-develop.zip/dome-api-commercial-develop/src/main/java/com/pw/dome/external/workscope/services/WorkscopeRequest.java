package com.pw.dome.external.workscope.services;

import java.time.LocalDateTime;

import jakarta.annotation.Nullable;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Request from WST for workscope creation, update or deletion.
 */
public record WorkscopeRequest(
		@NotBlank
		String esn,
		@NotBlank
		String operator,
		@NotBlank
		String provider,
		@NotBlank
		String svClassification,
		@NotNull
		Integer eventId,
		@NotBlank
		String smiNumber,
		@Nullable
		LocalDateTime wSInitiationDateTime,
		@Nullable
		LocalDateTime wSPublishedDateTime,
		@NotBlank
		String wSCreatedBy) {

}
