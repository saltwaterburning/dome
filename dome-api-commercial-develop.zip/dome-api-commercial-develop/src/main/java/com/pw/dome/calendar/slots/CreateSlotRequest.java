package com.pw.dome.calendar.slots;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Range;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class CreateSlotRequest {
//	@Min(message = "{slot.day.validation}", value = 1)
//	@Max(message = "{slot.day.validation}", value = 31)
	@NotNull(message = "{NotNull.required}")
	private Integer day;

//	@Pattern(message = "{slot.ec.validation}", regexp = "^EC\\d{1,10}$")
	@NotNull(message = "{NotNull.required}")
	private String engineCenterID;

	@Pattern(message = "{slot.et.validation}", regexp = "^ET\\d{1,10}$")
	@NotNull(message = "{NotNull.required}")
	private String engineTypeID;

//	@Min(message = "{slot.month.validation}", value = 1)
//	@Max(message = "{slot.month.validation}", value = 12)
	@NotNull(message = "{NotNull.required}")
	private Integer month;

	@NotNull(message = "{NotNull.required}")
	private ShopVisitType shopVisitType;

    @Range(min = 0, max = 9)
	private Integer slotCount;

//	@Min(message = "{slot.year.validation}", value = 2010)
//	@Max(message = "{slot.year.validation}", value = 2100)
	@NotNull(message = "{NotNull.required}")
	private Integer year;
}
