package com.pw.dome.engine.odin;

import java.time.LocalDate;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import org.springframework.lang.Nullable;

import com.pw.dome.report.OdinReportService;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * Base DTO used by {@link OdinReportService} not needing {@code preliminaryInductionDates}.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
//@Builder(builderMethodName = "baseBuilder", toBuilder = true)
@Schema(description = "ODIN Data Model")
@SuperBuilder
public class OdinBaseDTO {
    // OdinEntity.getAccyDeliveryDate()
    private LocalDate accyDeliveryDate;
    // OdinEntity.getActualRecEbuDate()
    private LocalDate actualRecEbuDate;
    // EngineTrackingEntity.getEngtrackRecDate()
    private LocalDate actualRecEcDate;
    // OdinEntity.getAdListDate()
    private LocalDate adListDate;
    // OdinEntity.getAimAllocationDate()
    private LocalDate aimAllocationDate;
    // EngineAssetEntity.getAssetID()
    private Integer assetId;
// TODO Uncomment after UI completed.
//	@NotNull(message = "{NotNull.required}")
    // OdinEntity.isBer()
    private Boolean ber;
    @Size(max = 50)
    // OdinEntity.getCfdFm()
    private String cfdFm;
    @Size(max = 40)
    // OdinHistoryEntity.getChangeReason()
    private String changeReason;
    @Size(max = 4000)
    // OdinEntity.getComments()
    private String comments;
    // EngineTrackingEntity.getEngtrackIndDate()
    private LocalDate committedInductionDate;
    // OdinEntity.isContractRemoval()
    private boolean contractRemoval;
    // EngineAssetEntity.getContractType()
    private String contractType;
    // EngineAssetEntity.getCsn()
    private Integer csn;
    // EngineAssetEntity.getCso()
    private Integer cso;
    @Size(max = 50)
    // OdinEntity.getCurrentLocation()
    private String currentLocation;
    // OdinEntity.getCustomerApprovalDate()
    private LocalDate customerApprovalDate;
    private boolean disabled;
    @Size(max = 50)
    // OdinEntity.getEbuShop()
    private String ebuShop;
    private Boolean eData;
    // EngineRemoved.getRemovalDateReported()
    private LocalDate engineActualReceiptDate;
    // @NotNull(message = "{NotNull.required}")
    // OdinEntity.getEngineId()
    private Integer engineId;
    // EngineAssetEntity.getEngineModelName()
    private String engineModelName;

    @Size(max = 10)
    @NotNull(message = "{NotNull.required}")
    // EngineAssetEntity.getEsn()
    private String esn;
    // ODIN.estimatedWorkscope
    private String estimatedWorkscope;
    // @NotNull(message = "{NotNull.required}")
    // EngineAssetEntity.getEventId()
    private Integer eventId;
    // OdinEntity.getFanBladeMapDate()
    private LocalDate fanBladeMapDate;
    // OdinEntity.isFhaEligible()
    private boolean fhaEligible;

    // OdinEntity.isInvestigationEngine()
    private boolean investigationEngine;
    // EngineAssetEntity.getLlpCycRemain()
    private Integer llpCycRemain;
    // OdinEntity.getLlpDeliveryDate()
    private LocalDate llpDeliveryDate;
    @Size(max = 50)
    // OdinEntity.getLlpReplaceType()
    private String llpReplacementType;
    @Size(max = 10)
    // Should be same size as DOME_ENGINE_CENTER.EC_ID(10).
    // OdinEntity.getMaintenanceCenter()
    private String maintenanceCenter;
    @Size(max = 40)
    // EngineCenterEntity.getName()
    private String maintenanceCenterName;
//	private LocalDate enginePlanReceiptDate;
    // OdinEntity.getNisDeliveryDate()
    private LocalDate nisDeliveryDate;
    // OdinEntity.getOdinId()
    private Integer odinId;

    // TODO Uncomment after UI completed.
//	@NotNull(message = "{NotNull.required}")
    // OdinEntity.isOnHold()
    private Boolean onHold;
    // EngineAssetEntity.getOperatorShortName()
    private String operatorName;
    // EngineTrackingEntity.getEngtrackIsopportunity()
    private Integer opportunity;
    @Size(max = 50)
    // OdinEntity.getPowerEngineer()
    private String powerEngineer;
    // EngineTrackingEntity.getEngtrackPlanIndDate()
    private LocalDate preliminaryInductionDate;
    // ESN + eventId
    // Get from List<OdinHistoryEntity>
//    private List<LocalDate> preliminaryInductionDates;
    // OdinEntity.getProjRecEbuDate()
    private LocalDate projRecEbuDate;
    // EngineTrackingEntity.getEngtrackPlanRecDate()
    private LocalDate projRecEcDate;
    // OdinEntity.isPwelAsset()
    private boolean pwelAsset;
    // EngineRemoved.getRemovalDate()
    private LocalDate removalActualDate;
    // EngineRemoved.getRemovalReason()
    private String removalReason;
    // EngineRemoved.getRemovalDateReported()
    private LocalDate removalRecordedDate;
    // EngineRemoved.GetRemovedEngineID()
    private Integer removedEngineId;
    @Size(max = 50)
    // OdinEntity.getRslPO()
    private String rslPO;
    @Nullable
    @Parameter(description = "The engine slot date or null if not slotted.")
    // SlotEntity.getCaldate()
    private LocalDate slotDate;

    @Size(max = 50)
    // OdinEntity.getSpeidPO()
    private String speidPO;
    @Size(max = 50)
    // OdinEntity.getSvClass()
    private String svClassification;

    // OdinEntity.tarCheckbox()
    private boolean tarCheckbox;
    // private LocalDate scheduledInductionDate;
    // OdinEntity.getTestAtReceipt()
    private LocalDate testAtReceipt;
    // EngineAssetEntity.getThrust()
    private String thrust;
    // EngineAssetEntity.getTsn()
    private Integer tsn;
    // EngineAssetEntity.getTso()
    private Integer tso;
    @Size(max = 50)
    // OdinEntity.getUpgradeEligible()
    private String upgradeEligibility;
    // TODO Uncomment after UI completed.
//	@NotNull(message = "{NotNull.required}")
    // OdinEntity.isWarranty()
    private Boolean warranty;
    @Size(max = 25)
    // EngineTrackingEntity.getEngtrackWorkOrder()
    private String workOrder;
    // OdinEntity.getWsDraftCompleteAccyDate()
    private LocalDate wsDraftCompleteAccyDate;
    // OdinEntity.getWsDraftCompleteEngDate()
    private LocalDate wsDraftCompleteEngDate;
    // OdinEntity.getWsInitiationDate()
    private LocalDate wsInitiationDate;
    // OdinEntity.wsOrigReleaseDate
    private LocalDate wsOrigReleaseDate;
}
