package com.pw.dome.external.mro.collab.services.pacingitems;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pw.dome.wip.pacing.PacingItemEntity;

interface MroPacingItemsRepository extends CustomMroPacingItemsRepository, JpaRepository<PacingItemEntity, Integer> {
	;
}
