package com.pw.dome.calendar.inductionplanning;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.calendar.CalendarRequest;
import com.pw.dome.calendar.CalendarService;
import com.pw.dome.user.UserProfile;

import lombok.extern.slf4j.Slf4j;

/**
 * @author John De Lello
 */
@RestController
@RequestMapping("/v1/calendars/inductionplanning")
@Slf4j
public class InductionPlanningCalendarController {
	@Autowired
	private CalendarService calService;
	
    /**
     * @api {get} /v1/calendars/inductionplanning/:engineTypeID/:month/:year Get Induction Planning Calendar
     * @apiExample {curl} Example usage: 
     *         curl --request GET
     *              --url http://localhost:8080/v1/calendars/inductionplanning/ET718/7/2019
     *              --header 'authorization: Bearer [jwt]'
     *              --header 'content-type: application/json'
     * @apiName getInductionPlanningCalendar
     * @apiGroup Calendars
     * @apiParam {String} engineTypeID The Engine Type ID to get the calendar for
     * @apiParam {Number} month The month to get the calendar for
     * @apiParam {Number} year The year to get the calendar for
     * @apiParam {String} [engineCenterID] The optional Engine Center ID to use for filtering
     * @apiDescription Returns the induction planning calendar for the requested engine type ID, month, and year.
     * @apiSuccess {String} calendarName The calendar name
     * @apiSuccess {String} cal The cal of the induction calendar
     * @apiSuccess {String} year The year of the induction calendar
     * @apiSuccess {String} month The month of the induction calendar
     * @apiSuccess {String} engineTypeID The Engine Type ID of the induction calendar
     * @apiSuccess {String} engineTypeName The Engine Type Name of the induction calendar
     * @apiSuccess {Object[]} days An array of 42 objects used to generate the induction calendar 
     * @apiSuccess {Boolean} days.validDate Whether this day is a valid calendar date for the current month year combination
     * @apiSuccess {Number} days.boxNumber Indicates the box number for this item. Valid values are 0-41
     * @apiSuccess {Number} days.day Indicates the day of the month for this item. If it is not a valid date location, this will be 0.
     * @apiSuccess {Object[]} days.shopVisitsSummary An array of Engine Type Summaries for the day
     * @apiSuccess {Number} days.shopVisitsSummary.slotID The SlotEntity ID of the summarized entry
     * @apiSuccess {Number} days.shopVisitsSummary.engineCenterID The Engine Center ID
     * @apiSuccess {Number} days.shopVisitsSummary.engineCenterCode The Engine Center Code
     * @apiSuccess {Number} days.shopVisitsSummary.engineCenterName The Engine Center Name
     * @apiSuccess {String} days.shopVisitsSummary.shopVisitType The shop visit type
     * @apiSuccess {Object[]} [days.shopVisitsByEngineType.engines] An array of associated engines to this slot
     * @apiSuccess {Number} days.shopVisitsByEngineType.engines.engineID The ID for the engine
     * @apiSuccess {String} [days.shopVisitsByEngineType.engines.esn] The serial number for the engine
     * @apiUse InductionPlanningCalendarSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     */
	@PostMapping
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
	public ResponseEntity<InductionPlanningCalendar> getInductionPlanningCalendar(@AuthenticationPrincipal UserProfile userProfile,
			                                                 @RequestBody
			                                                 CalendarRequest request) {
		log.debug("Enter getInductionPlanningCalendar");
		
		InductionPlanningCalendar inductionPlanningCalendar = calService.getInductionPlanningCalendar(userProfile, request);
		
		return new ResponseEntity<InductionPlanningCalendar>(inductionPlanningCalendar, HttpStatus.OK);
	}

	
    }
