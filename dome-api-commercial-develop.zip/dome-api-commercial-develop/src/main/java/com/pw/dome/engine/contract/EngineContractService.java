package com.pw.dome.engine.contract;

/**
 * @author John De Lello
 */
public interface EngineContractService {
	EngineContractResponse findByEsnIgnoreCase(final String esn);
}
