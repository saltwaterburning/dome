package com.pw.dome.engine.phase;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController()
@RequestMapping("/v1/engines/phases")
public class EnginePhaseController {
	@Autowired
	private EnginePhaseService enginePhaseService;

	/**
	 * @api {get} /v1/engines/phases Get All Phases
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/engines/phases
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName getEnginePhases
     * @apiGroup Engine Phases
     * @apiDescription Returns a list of engine phases 
     * @apiSuccess {Object[]} enginePhases An array engine phases 
     * @apiSuccess {String} enginePhases.enginePhaseID The engine phase ID
     * @apiSuccess {String} enginePhases.name The engine phase name
     * @apiUse GetEnginePhasesSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/
    @GetMapping(produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<EnginePhaseListResponse> getEnginePhases(){
    	
		List<EnginePhaseEntity> phases = enginePhaseService.getEnginePhases();
    	
    	return ResponseEntity.ok(EnginePhaseListResponse.builder().enginePhases(phases).build());
    }
}
