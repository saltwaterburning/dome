package com.pw.dome.engine.asset;

import com.pw.dome.engine.phase.EnginePhases;

interface Consts {
	String AND_NOT_DISABLED = " AND cast(nvl(ea.disabled, 0) as int) = 0";

	/**
     * Asset queries.
     * 
     * @see EnginePhases
     * @see <a href="https://sqlformat.org/" target="_blank">SQL Format</a>
     */
    interface SQL {
        String ENGINES_AVAILABLE =
        "SELECT ea " +
        "FROM EngineAssetEntity ea " +
        "LEFT JOIN FETCH ea.operator CustomerEntity " +
        "WHERE ea.engineTypeID = ?1 " +
        "  AND UPPER(ea.esn) LIKE UPPER(?2)" +
        AND_NOT_DISABLED;
    }
}
