package com.pw.dome.admin;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerCenterMatrixRepository extends JpaRepository<CustomerCenterMatrixEntity, CustomerCenterMatrixEntityPK> {
//	CustomerCenterMatrix findByCustomerIdAndEngineCenterIdAndEngineTypeId(final String customerId, final String engineCenterId, final String engineTypeId);
}
