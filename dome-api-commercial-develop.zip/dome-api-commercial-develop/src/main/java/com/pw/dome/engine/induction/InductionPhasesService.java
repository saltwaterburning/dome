package com.pw.dome.engine.induction;

import static com.pw.dome.engine.induction.Consts.SLOW_SQL_THRESHOLD_MILLIS;
import static com.pw.dome.engine.induction.Consts.SQL.ALL_SEARCHES;
import static com.pw.dome.engine.phase.EnginePhases.ALL;
import static com.pw.dome.util.QueryUtils.isAllOrAny;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.engine.induction.PhaseRequest.PhaseRequestBuilder;
import com.pw.dome.engine.phase.EnginePhases;
import com.pw.dome.engine.removed.EngineRemovedDTO;
import com.pw.dome.exception.NotFoundException;
import com.pw.dome.util.QueryHelper;

import jakarta.persistence.EntityManager;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class InductionPhasesService {
    @Autowired
    private EntityManager em;
    @Autowired
    private InductionPhasesRepository repo;
    @Autowired
    private QueryHelper queryHelper;

    @Transactional(readOnly = true)
    public List<AvailableEngine> getAvailableEngines(final String engineCenterId, final String engTypeId, final String esn) {
      return repo.getAvailableEngines(engineCenterId, engTypeId, esn, ALL.getCode());
    }

    /**
     * Returns 
     * @param request
     * @return
     */
    public List<EngineRemovedDTO> getEngineInPhase(PhaseRequest request) {
    	if (isAllOrAny(request.engineTypeIds())) {
    		PhaseRequestBuilder builder = PhaseRequest.builder();
    		List<String> userTypes = queryHelper.getUserEngineTypes(request.engineTypeIds());
    		builder.engineTypeIds(userTypes).phase(request.phase()).esn(request.esn());
    		request = builder.build();
    	}
 
    	List<EngineRemovedDTO> results = getEnginePhase(request);
    	return results;
    }

    @Transactional(readOnly = true)
    private List<EngineRemovedDTO> getEnginePhase(final PhaseRequest request) {
      final EnginePhases enginePhase = request.phase();
      final List<String> engineTypeIds = request.engineTypeIds();
      final String esn = request.esn();
      Long rowNumberOffset = 0L;
      List <EngineRemovedDTO> engineDTOs;
      StopWatch stopWatch = new StopWatch();

      stopWatch.start();
      switch (enginePhase) {
      case ALL:
    	  engineDTOs = new ArrayList<>(256);
    	  for (PhaseQuery search : ALL_SEARCHES) {
    		  String query = search.query();
    		  String phaseCode = search.phase().getCode();
    		  @SuppressWarnings("unchecked")
    		  List<EngineRemovedDTO> subResults = em.createQuery(query)
    		  .setParameter("engineTypeIds", engineTypeIds)
    		  .setParameter("esn", esn)
    		  .setParameter("phaseCode", phaseCode)
    		  .setParameter("rowNumOffset", rowNumberOffset)
    		  .getResultList();

    		  if (CollectionUtils.isNotEmpty(subResults)) {
    			  engineDTOs.addAll(subResults);
    			  rowNumberOffset += subResults.size();
    		  }
    	  }
    	  break;
      case COMPLETE:
    	  engineDTOs = repo.getPhaseComplete(rowNumberOffset, engineTypeIds, esn, enginePhase.getCode());
    	  break;
      case INACTIVE:
    	  engineDTOs = repo.getPhaseInactive(rowNumberOffset, engineTypeIds, enginePhase.getCode());
    	  break;
      case REMOVED_ENG:
    	  engineDTOs = repo.getPhaseREMOVED(rowNumberOffset, engineTypeIds, enginePhase.getCode());
    	  break;
      case SCHEDULED:
    	  engineDTOs = repo.getPhaseSCHEDULED(rowNumberOffset, engineTypeIds, enginePhase.getCode());
    	  break;
      case WIP:
    	  engineDTOs = repo.getPhaseWIP(rowNumberOffset, engineTypeIds, enginePhase.getCode());
    	  break;
      default:
    	  throw new NotFoundException("Invalid engine phase: " + enginePhase);
      }

      long etMillis;
      if ((etMillis = stopWatch.getTime()) > SLOW_SQL_THRESHOLD_MILLIS) {
    	  log.warn("Slow query- ET: {}ms, Phase: {}, EngTypes: {}, ESN: {}", etMillis, enginePhase.name(), engineTypeIds, esn);
      }

      // TODO- correct me. See SortingUtils
      Collections.sort(engineDTOs,
    		  Comparator.comparing(EngineRemovedDTO::preliminaryInductionDate, Comparator.nullsFirst(Comparator.naturalOrder()))
    		  .thenComparing(Comparator.comparing(EngineRemovedDTO::removalDate, Comparator.nullsFirst(Comparator.naturalOrder())))
    		  .thenComparing(Comparator.comparing(EngineRemovedDTO::operatorName, Comparator.nullsFirst(Comparator.naturalOrder())))
    		  );

		return engineDTOs;
	}
}
