package com.pw.dome.engine.type;

import java.util.List;

import com.pw.dome.user.UserProfile;

/**
 * @author John De Lello
 */
public interface EngineTypeService {
	
	List<EngineTypeEntity> getAllEngineTypes();
	
	String getEngineTypeNameByID(final String engineTypeID);

	EngineTypeEntity getEngineTypeByID(final String engineTypeID);

	List<EngineTypeEntity> getEngineTypes(final UserProfile userProfile, final String engineCenterID);

	List<EngineTypeEntity> getEngineTypes(final UserProfile userProfile, final String engineCenterID, final String engineGroupID);
}
