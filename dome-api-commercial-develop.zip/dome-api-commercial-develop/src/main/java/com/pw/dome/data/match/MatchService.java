package com.pw.dome.data.match;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.engine.EngineEntity;
import com.pw.dome.engine.EngineRepository;
import com.pw.dome.exception.BadRequestException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
class MatchService {
	@Autowired
	private EngineRepository engRepo;

	@Autowired
	private MatchRepository repo;

	@Transactional(readOnly = true)
	public EngineDataResponse getMatchedData(String engineCenter, String engineType, String engineSN) {
		if (StringUtils.isNotBlank(engineSN)) {
			return new EngineDataResponse(repo.getMatchedData(engineSN));
		} else {
			return new EngineDataResponse(repo.getMatchedData(engineCenter, engineType));			
		}
	}

	@Transactional(readOnly = true)
	public EngineDataResponse getUnmatchedData(String engineCenter, String engineType, String engineSN) {
		if (StringUtils.isNotBlank(engineSN)) {
			return new EngineDataResponse(repo.getUnmatchedData(engineSN));
		} else {
			return new EngineDataResponse(repo.getUnmatchedData(engineCenter, engineType));			
		}
	}


	@Transactional
	public EngineData setMatched(EngineData engineData) {
		int cnt;
		/*for (EngineData data : request.getEngines()) {
			int engId = data.getEngineIdSeq();
			String notifyNum = data.getNotifyNum();
			String salesOrderNum = data.getSalesOrderNum();
			cnt = engRepo.setMatched(engId, notifyNum, data.getSalesOrderNum());
			log.debug("Engine data matched for {} rows in dome_engine table; engId={}, notifyNum={}, salesOrderNum={}", cnt, engId, notifyNum, salesOrderNum);
			if (cnt == 0) {
				EngineEntity engine;
				if ((engine = engRepo.findById(engId).orElse(null)) == null) {
					throw new BadRequestException("Invalid engine ID passed: " + engId);
				} else {
					data.setNotifyNum(engine.getNotifyNum());
					data.setSalesOrderNum(engine.getSalesOrderNum());
				}
			}
		}*/
		int engId = engineData.getEngineIdSeq();
		String notifyNum = engineData.getNotifyNum();
		String salesOrderNum = engineData.getSalesOrderNum();
		cnt = engRepo.setMatched(engId, notifyNum, engineData.getSalesOrderNum());
		log.debug("Engine data matched for {} rows in dome_engine table; engId={}, notifyNum={}, salesOrderNum={}", cnt, engId, notifyNum, salesOrderNum);
		if (cnt == 0) {
			EngineEntity engine;
			if ((engine = engRepo.findById(engId).orElse(null)) == null) {
				throw new BadRequestException("Invalid engine ID passed: " + engId);
			} else {
				engineData.setNotifyNum(engine.getNotifyNum());
				engineData.setSalesOrderNum(engine.getSalesOrderNum());
			}
		}

		return engineData;
	}


	@Transactional
	public EngineData setUnmatched(EngineData engineData) {
		int cnt;
		/*for (EngineData data : request.getEngines()) {
			int engId = data.getEngineIdSeq();
			cnt = engRepo.setUnmatched(engId);
			log.debug("Engine data unmatched for {} rows in dome_engine table; engId={}", cnt, engId);
			if (cnt > 0) {
				data.setNotifyNum(null);
				data.setSalesOrderNum(null);
			}
		}*/
		int engId = engineData.getEngineIdSeq();
		cnt = engRepo.setUnmatched(engId);
		log.debug("Engine data unmatched for {} rows in dome_engine table; engId={}", cnt, engId);
		if (cnt > 0) {
			engineData.setNotifyNum(null);
			engineData.setSalesOrderNum(null);
		}

		return engineData;
	}
	
	@Transactional(readOnly = true)
	public EngineDataResponse getMatchedEngineData() {

		return new EngineDataResponse(repo.getMatchedData());
	}

	@Transactional(readOnly = true)
	public EngineDataResponse getUnmatchedEngineData() {
		return new EngineDataResponse(repo.getUnmatchedData());
	}
	
	@Transactional
	public int setMatchedEngine(int engId, String salesorderNo, String notificationNo) {
		int cnt;
		cnt = engRepo.setMatched(engId, notificationNo, salesorderNo);
		log.debug("Engine data matched for {} rows in dome_engine table; engId={}, notifyNum={}, salesOrderNum={}", cnt, engId, notificationNo, salesorderNo);
		if (cnt == 0 && !engRepo.existsById(engId)) {
			throw new BadRequestException("Invalid engine ID passed: " + engId);
		}


		return engId;
	}
	@Transactional
	public int setUmatchedEngine(int engId) {
		int cnt;
		cnt = engRepo.setUnmatched(engId);
		log.debug("Engine data unmatched for {} rows in dome_engine table; engId={}", cnt, engId);
		if (cnt == 0 && !engRepo.existsById(engId)) {
			throw new BadRequestException("Invalid engine ID passed: " + engId);
		}

		return engId;
	}
}
