package com.pw.dome.engine.comments;

import static com.pw.dome.engine.comments.Consts.SQL.GET_MRO_COMMENTS;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CommentsRepo extends JpaRepository<CommentEntity, Integer> {

	/**
	 * Returns comments history with most recent comments first.
	 * 
	 * @param engineId the engine identifier
	 * @return the comments history
	 */
	List<CommentEntity> findByEngineIdOrderByDateUpdatedDesc(final int engineId);

	boolean existsCommentEntityByEngineId(Integer engineId);

	@Query(GET_MRO_COMMENTS)
	List<CommentEntity> findAllMroComments();
}
