package com.pw.dome.engine;

interface Consts {
	String NORTH_AMERICA = "North America";
	boolean ENGINE_REVENUE_DEFAULT = false;
    String DEFAULT_SHIPMENT_TYPE = "S";
    String DELETE_ENG_SLOT_REASON = "Removed from Slot.";
    /* Single space since Oracle internally changes empty string to NULL values. */
    String INVESTIGATION_CATEGORY_DEFAULT = " ";
}
