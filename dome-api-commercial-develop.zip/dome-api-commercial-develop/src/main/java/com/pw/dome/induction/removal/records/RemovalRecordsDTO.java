package com.pw.dome.induction.removal.records;

import java.time.LocalDate;

import lombok.Builder;

@Builder
record RemovalRecordsDTO(
	LocalDate attachmentDate,
	String attachmentName,
	String contents,
	String esn,
	Integer eventId) {
}
