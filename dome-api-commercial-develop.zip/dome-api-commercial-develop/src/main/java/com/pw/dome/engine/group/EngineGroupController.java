package com.pw.dome.engine.group;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.user.UserProfile;


@RestController()
@RequestMapping("/v1/engines/groups")
public class EngineGroupController {
	@Autowired
	private EngineGroupService engineGroupService;

	/**
	 * @api {get} /v1/engines/groups/:engineCenterID Get All Groups
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/engines/groups/EC1
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName getEngineGroups
     * @apiGroup Engine Groups
     * @apiParam {String} engineCenterID The engine center ID to get engine groups for
     * @apiDescription Returns a list of engine groups that are available for the current user and engine center
     * @apiSuccess {Object[]} engineGroups An array engine groups 
     * @apiSuccess {Number} engineGroups.engineGroupID The engine group ID
     * @apiSuccess {Number} engineGroups.engineTypeID The engine type ID of the engine group
     * @apiSuccess {String} engineGroups.name The engine group name
     * @apiUse GetEngineGroupsSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/
    @GetMapping(path = "/{engineCenterID}", produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<EngineGroupListResponse> getEngineGroups(@AuthenticationPrincipal UserProfile userProfile,
    		                                                       @PathVariable(name = "engineCenterID") String engineCenterID){
    	
		List<EngineGroupEntity> groups =  engineGroupService.getEngineGroups(userProfile, engineCenterID);
    	
    	return ResponseEntity.ok(EngineGroupListResponse.builder().engineGroups(groups).build());
    }

	/**
	 * @api {get} /v1/engines/groups/:engineCenterID/:engineTypeID Get Groups for Engine Type
     * @apiExample {curl} Example usage: 
     *      curl --request GET
     *           --url http://localhost:8080/v1/engines/groups/EC1/ET720
     *           --header 'Authorization: Bearer [jwt]'           
     * @apiName getEngineGroupsByEngineType
     * @apiGroup Engine Groups
     * @apiParam {String} engineCenterID The engine center ID to get engine groups for
     * @apiParam {String} engineTypeID The engine type ID to get engine groups for
     * @apiDescription Returns a list of engine groups that are available for the current user and engine center and engine type
     * @apiSuccess {Object[]} engineGroups An array engine groups 
     * @apiSuccess {Number} engineGroups.engineGroupID The engine group ID
     * @apiSuccess {Number} engineGroups.engineTypeID The engine type ID of the engine group
     * @apiSuccess {String} engineGroups.name The engine group name
     * @apiUse GetEngineGroupsSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/
    @GetMapping(path = "/{engineCenterID}/{engineTypeID}", produces = APPLICATION_JSON_VALUE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE", "ROLE_READ"})
    public ResponseEntity<EngineGroupListResponse> getEngineGroupsByEngineType(@AuthenticationPrincipal UserProfile userProfile,
    		                                                                   @PathVariable(name = "engineCenterID") String engineCenterID,
   		                                                                       @PathVariable(name = "engineTypeID") String engineTypeID){
    	
		List<EngineGroupEntity> groups =  engineGroupService.getEngineGroups(userProfile, engineCenterID, engineTypeID);
    	
    	return ResponseEntity.ok(EngineGroupListResponse.builder().engineGroups(groups).build());
    }    
}
