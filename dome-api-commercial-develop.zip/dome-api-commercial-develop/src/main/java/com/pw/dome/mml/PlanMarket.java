package com.pw.dome.mml;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Enumeration of plan markets.
 * This enum has annotations to direct JSON processing
 * and a nested class to handle JPA conversions.
 * 
 * @see PlanMarketJpaConverter
 */
// This enum could of been implemented without using an associated
// converter if the DB column was numeric which it should be.
public enum PlanMarket {
	COMMERCIAL,
	AFTERMARKET;


    /**
     * Creates a {@code PlanMarket} instance from an integer value.
     * No validation is performed. A null is returned if the value is not in range.
     * Use {@code jakarta.validation.constraints.NotNull} annotation on DTOs for client request validation.
     * 
     * @param value PlanMarket integer
     * @return a {@code PlanMarket} instance
     * 
     * @see JsonCreator
     */
    // JsonCreator annotation indicates how to unmarshall a JSON String into this enum instance for client requests.
    // Otherwise PlanMarket.values()[value] be used by default for unmarshalling.
    @JsonCreator
    public static PlanMarket of(int value) {
    	switch (value) {
		case 0:
			return COMMERCIAL;
		case 1:
			return AFTERMARKET;
		default:
			return null;
		}
    }

    /**
     * Returns the market type integer value.
     * @return the  market type integer value
     * 
     * @see JsonValue
     */
    // JsonValue annotation indicates how to marshall this enum instance into a JSON String for client requests.
    // The name() will otherwise be used by default for marshalling.
    @JsonValue
    public int getValue() {
        return ordinal();
    }

    @Component
    public static class PlanMarketConverter implements Converter<String, PlanMarket> {

        @Override
        public PlanMarket convert(String value) {
            return PlanMarket.of(Integer.valueOf(value));
        }
    }
}
