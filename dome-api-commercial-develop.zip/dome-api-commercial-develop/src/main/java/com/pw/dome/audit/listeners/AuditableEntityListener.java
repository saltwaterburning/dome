package com.pw.dome.audit.listeners;

import org.springframework.data.domain.Persistable;

import com.pw.dome.audit.AuditItem;

/*
 * CHECK- exceptions are bubbling up to request.
 *        test case- EngineServiceImpl.deleteEngineSlot()- DELETE- http://localhost:8080/v1/engines/183
 * CHECK- exceptions are failing the SQL transaction.
 * CHECK- add null checks before referencing object. See toActivityEntityDeleteEngine()
 */

/**
 *
 * @param <T>
 */
public interface AuditableEntityListener<T extends Persistable<?>> {

  AuditItem getAuditItem();

  void onPrePersist(T entity);

  void onPreRemove(T entity);

  void onPreUpdate(T entity);
}
