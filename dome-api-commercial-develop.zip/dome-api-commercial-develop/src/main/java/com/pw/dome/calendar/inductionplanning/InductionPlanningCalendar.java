package com.pw.dome.calendar.inductionplanning;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class InductionPlanningCalendar {
	private String calendarName;
	private String calYYMM;
	private Collection<InductionPlanningCalendarDay> days;
	private List<String> engineTypeIds;
	private List<String> engineTypeNames;
	private int month;
	private int year;

	public void addDay(InductionPlanningCalendarDay day) {
		if (days == null) {
			days = new ArrayList<>();
		}

		days.add(day);
	}
}
