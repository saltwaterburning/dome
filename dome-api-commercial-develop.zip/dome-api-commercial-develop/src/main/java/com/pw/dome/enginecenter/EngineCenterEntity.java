package com.pw.dome.enginecenter;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.NaturalId;

import com.pw.dome.jpa.AbstractEntityWithNaturalId;
import com.pw.dome.util.hibernate.BooleanToActiveOrDisabledConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author John De Lello
 */
@Entity
@Table(name="DOME_ENGINE_CENTER")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EngineCenterEntity extends AbstractEntityWithNaturalId<String> {

	@Id
	@NaturalId
	@Column(name="EC_ID")
    private String id;

	@Column(name="EC_ACTION", length=1)
	@Convert(converter = BooleanToActiveOrDisabledConverter.class)
    private boolean active;

	@Column(name="EC_NAME")
	private String name;

	//Non V2500 Code
	@Column(name="EC_EDATA_ID")
	private String eDataCode;

	//V2500 Code
	@Column(name="EC_VDATA_ID")
	private String vDataCode;

	@Column(name="PW_IAE_ID")
	private String iaeCode;

	// Moved to DOME_ENGINE_CENTER_SHOPCD TABLE.
//	@Column(name="EC_SHOP_CODE")
//	private String shopCode;

	@Column(name="EC_LOCATION")
	private String location;

	@Column(name="EC_PLANT_CODE")
	private String plantCOde;
}
