package com.pw.dome.aop;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.apache.commons.lang3.Validate;

abstract class AbstractMethodsAdvice<T, ID> {
	private static Map<String, String> PRIMITIVES_MAP = new HashMap<String, String>();
	static {
		PRIMITIVES_MAP.put("byte", Byte.class.getName());
		PRIMITIVES_MAP.put("short", Short.class.getName());
		PRIMITIVES_MAP.put("int", Integer.class.getName());
		PRIMITIVES_MAP.put("long", Long.class.getName());
		PRIMITIVES_MAP.put("float", Float.class.getName());
		PRIMITIVES_MAP.put("double", Double.class.getName());
		PRIMITIVES_MAP.put("boolean", Boolean.class.getName());
		PRIMITIVES_MAP.put("char", Character.class.getName());
	}

	// Position of parameters T and ID.
	private final static Integer ID_PARAMETERIZED_ARG_NUMBER = 1;
	private final static Integer T_PARAMETERIZED_ARG_NUMBER = 0;

	// Parameterized names.
	private final static String ID_TYPE_NAME = "ID";
	private final static String S_TYPE_NAME = "S";
	private final static String T_TYPE_NAME = "T";

	private final Class<?>[] parameterizedTypes;

	AbstractMethodsAdvice() {
		ParameterizedType superclass = (ParameterizedType) getClass().getGenericSuperclass();
		Type[] paramTypes = superclass.getActualTypeArguments();
		Validate.isTrue(paramTypes.length == 2, "Expecting 2 Parameterized Types (T & ID)");

		parameterizedTypes = new Class<?>[2];
		parameterizedTypes[T_PARAMETERIZED_ARG_NUMBER] = (Class<?>) paramTypes[T_PARAMETERIZED_ARG_NUMBER];
		parameterizedTypes[ID_PARAMETERIZED_ARG_NUMBER] = (Class<?>) paramTypes[ID_PARAMETERIZED_ARG_NUMBER];
	}

	/**
	 * Returns a method signature using the {@code Method} parameter types. The types will be erased if generics is used.
	 * 
	 * @param repoMethod
	 * @return a method signature using the {@code Method} parameter types
	 * 
	 * @see Parameter
	 */
	String getMethodSignature(Method repoMethod) {
		StringBuilder buffy = new StringBuilder();
		buffy.append(repoMethod.getName()).append("(");
		int len = buffy.length();
		Stream.of(repoMethod.getParameters()).forEach(s->buffy.append(buffy.length() > len ? ", " : "").append(s.getType().getName()));
		buffy.append(")");

		return buffy.toString();
	}

	/**
	 * Returns a method signature using the actual types provided for T and ID.
	 * 
	 * @param repoMethod
	 * @return a method signature using the actual types provided for T and ID
	 */
	String getParameterizedMethodSignature(Method repoMethod) throws Exception {
		StringBuilder buffy = new StringBuilder();
		buffy.append(repoMethod.getName()).append("(");
		int len = buffy.length();
		Class<?>[] parameterTypes = getParameterizedTypes(repoMethod);
		Stream.of(parameterTypes).forEach(s->buffy.append(buffy.length() > len ? ", " : "").append(s.getName()));
		buffy.append(")");

		return buffy.toString();
	}

	/**
	 * Returns a method signature using the actual types provided for T and ID.
	 * 
	 * @param repoMethod
	 * @return a method signature using the actual types provided for T and ID
	 */
	String getParameterizedReturnMethodSignature(Method repoMethod) throws Exception {
		StringBuilder buffy = new StringBuilder();
		buffy.append(repoMethod.getName()).append("(");
		buffy.append(repoMethod.getReturnType().getName());
		Class<?>[] parameterTypes = getParameterizedTypes(repoMethod);
		Stream.of(parameterTypes).forEach(s->buffy.append(", ").append(s.getName()));
		buffy.append(")");

		return buffy.toString();
	}

	/**
	 * Returns type array of [Class&lt;T&gt;, Class&lt;ID&gt;].
	 * 
	 * @param method
	 * @return type array of [Class&lt;T&gt;, Class&lt;ID&gt;]
	 */
	private Class<?>[] getParameterizedTypes(Method method) throws Exception {
		List<Class<?>> list = new ArrayList<>();

		for (Type type : method.getGenericParameterTypes()) {
			switch (type.getTypeName()) {
			case ID_TYPE_NAME:
				list.add(parameterizedTypes[ID_PARAMETERIZED_ARG_NUMBER]);
				break;

			case S_TYPE_NAME:
			case T_TYPE_NAME:
				list.add(parameterizedTypes[T_PARAMETERIZED_ARG_NUMBER]);
				break;

			default:
				String className = type.getTypeName();
				String wrapper;
				if ((wrapper = PRIMITIVES_MAP.get(className)) != null) {
					className = wrapper;
				}
				Class<?> clazz = getClass().getClassLoader().loadClass(className);
				list.add(clazz);
//				throw new IllegalArgumentException("Unexpected Argument TypeName: " + type.getTypeName());
			}
		}

		Class<?>[] array = new Class<?>[list.size()];
		list.toArray(array);

		return array;
	}
	
	/**
	 * Returns a method signature using the {@code Method} parameter types. The types will be erased if generics is used.
	 * 
	 * @param repoMethod
	 * @return a method signature using the {@code Method} parameter types
	 * 
	 * @see Parameter
	 */
	String getReturnMethodSignature(Method repoMethod) {
		StringBuilder buffy = new StringBuilder();
		buffy.append(repoMethod.getName()).append("(");
		buffy.append(repoMethod.getReturnType().getName());
		Stream.of(repoMethod.getParameters()).forEach(s->buffy.append(", ").append(s.getType().getName()));
		buffy.append(")");

		return buffy.toString();
	}
}
