package com.pw.dome.admin.enginecenter.maintenance;

import static com.pw.dome.admin.enginecenter.maintenance.Consts.EC_ID_PREFIX;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
final public class BasicEngineCenter {
	@NotNull(message = "{NotNull.required}")
	private boolean active;
	@NotNull(message = "{NotNull.required}")
	@Pattern(regexp = "^" + EC_ID_PREFIX + "\\d{1,8}$")
	@Size(min = 3, max = 10)
	private String centerId;
	@NotNull(message = "{NotNull.required}")
	@Size(min = 1, max = 40)
    private String centerName;
}
