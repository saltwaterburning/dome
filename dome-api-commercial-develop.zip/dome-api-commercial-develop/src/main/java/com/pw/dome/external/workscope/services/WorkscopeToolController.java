package com.pw.dome.external.workscope.services;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.common.oas.BaseRESTfulResource;
import com.pw.dome.exception.ErrorResponse;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/v1/workscopetool")
@Tag(name = BaseRESTfulResource.Tags.WS)
@Validated
class WorkscopeToolController extends BaseRESTfulResource {

	@Autowired
	private WorkscopeToolService wstService;

	@PostMapping(path = "/pushworkscopedate", produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<ErrorResponse> updateWorkscopeFromWST(
			@RequestBody
			@Valid
			WorkscopeRequest request) {
		return ResponseEntity.ok(wstService.updateWorkscopeFromWST(request));
	}
}
