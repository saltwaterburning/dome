package com.pw.dome.module;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import com.pw.dome.jpa.AbstractEntityWithEmbeddedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_MODULE_ASSETS")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ModuleAssetEntity extends AbstractEntityWithEmbeddedId<ModuleAssetEntityPK> {
	
	@EmbeddedId
    private ModuleAssetEntityPK moduleAssetEntityPK;

	@Column(name="ENGINE_MODULE")
    private String moduleName;
    
    @Column(name="SLOT_ID")
    private Integer slotID;

	@Override
	public ModuleAssetEntityPK getId() {
		return moduleAssetEntityPK;
	}
}
