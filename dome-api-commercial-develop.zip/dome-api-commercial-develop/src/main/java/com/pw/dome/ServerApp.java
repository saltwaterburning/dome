package com.pw.dome;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.HttpMethod;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.firewall.StrictHttpFirewall;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.pw.dome.aop.jpa.CustomRepositoryFactory;

/**
 * @author John De Lello
 */
//@EnableAspectJAutoProxy
@EnableAsync
@EnableJpaRepositories(repositoryFactoryBeanClass = CustomRepositoryFactory.class)
@EnableScheduling
@EnableTransactionManagement
@SpringBootApplication
public class ServerApp {
	public static void main(String[] args) {
		SpringApplication.run(ServerApp.class, args);
	}

//	@Configuration
//	public class HypersistenceConfiguration {
//
//		// See https://vladmihalcea.com/hypersistence-optimizer/docs/user-guide/
//		@Configuration
//		public class HypersistenceConfiguratio {
//			@Bean
//			public HypersistenceOptimizer hypersistenceOptimizer(EntityManagerFactory entityManagerFactory) {
//				return new HypersistenceOptimizer(new JpaConfig(entityManagerFactory)
//						.setProperties(Map.of(Config.Property.MAX_EVENT_SIZE, 10000)));
//			}
//		}
//
//	}

	@Configuration
	public class WebConfiguration implements WebMvcConfigurer {

		@Override
		public void configurePathMatch(PathMatchConfigurer configurer) {
			configurer.setUseTrailingSlashMatch(true);
		}
	}

	@Bean
	public StrictHttpFirewall httpFirewall() {
		StrictHttpFirewall firewall = new StrictHttpFirewall();
		List<String> allowedHttpMethods = Stream.of(HttpMethod.values()).map(s -> s.name())
				.collect(Collectors.toList());
		allowedHttpMethods.add("PROPFIND");
		firewall.setAllowedHttpMethods(allowedHttpMethods);
		return firewall;
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}
}
