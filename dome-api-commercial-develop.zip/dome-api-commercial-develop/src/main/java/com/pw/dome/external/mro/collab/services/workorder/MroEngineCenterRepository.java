package com.pw.dome.external.mro.collab.services.workorder;

import static com.pw.dome.external.mro.collab.services.workorder.Consts.SQL.COUNT_QUERY;
import static com.pw.dome.external.mro.collab.services.workorder.Consts.SQL.DELETE_QUERY;
import static com.pw.dome.external.mro.collab.services.workorder.Consts.SQL.GET_ENG_ID;
import static com.pw.dome.external.mro.collab.services.workorder.Consts.SQL.GET_SLOTTED_SHOP_CODES_QUERY;
import static com.pw.dome.external.mro.collab.services.workorder.Consts.SQL.UPDATE_QUERY;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
interface MroEngineCenterRepository extends JpaRepository<MroEngineCenterEntity, String> {
	boolean existsByMroEcShopCode(String mroEcShopCode);

	Optional<MroEngineCenterEntity> findByMroEcShopCode(String mroEcShopCode);

	@Query(GET_SLOTTED_SHOP_CODES_QUERY)
	List<SlottedShopCodesDTO> getSlottedShopCodes(@Param("esn") String esn,
			@Param("eventId") Integer eventId);
	/**
	 * Sets EngineTrackingEntity.engtrackWorkOrder to NULL on matching record.
	 * 
	 * @param esn
	 * @param eventId
	 * @param mroShopCode
	 * @return the number of records updated
	 */
	@Modifying
	@Query(DELETE_QUERY)
	int deleteWorkOrder(@Param("esn") String esn, @Param("eventId") Integer eventId,
			@Param("mroShopCode") String mroShopCode);

	@Query(COUNT_QUERY)
	int findRowCount(@Param("esn") String esn, @Param("eventId") Integer eventId,
			@Param("mroShopCode") String mroShopCode);

	@Modifying
	@Query(UPDATE_QUERY)
	int updateWorkOrder(@Param("esn") String esn, @Param("eventId") Integer eventId,
			@Param("mroShopCode") String mroShopCode, @Param("mroWorkOrder") String mroWorkOrder);

	@Query(GET_ENG_ID)
	Integer findEngineTrackingId(@Param("esn") String esn,
			@Param("eventId") Integer eventId, @Param("mroShopCode") String mroShopCode);
}
