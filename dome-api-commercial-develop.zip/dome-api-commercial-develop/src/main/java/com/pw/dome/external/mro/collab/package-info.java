/*
 * Provides MRO (maintenance, repair and operations) collaboration services.
 */
package com.pw.dome.external.mro.collab;