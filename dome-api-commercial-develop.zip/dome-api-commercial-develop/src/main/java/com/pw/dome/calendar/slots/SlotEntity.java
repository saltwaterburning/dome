package com.pw.dome.calendar.slots;

import static java.util.Objects.isNull;
import static org.hibernate.annotations.NotFoundAction.IGNORE;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import org.hibernate.annotations.NotFound;

import com.pw.dome.engine.type.EngineTypeEntity;
import com.pw.dome.jpa.AbstractEntityWithGeneratedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author John De Lello
 */
@Entity
@Table(name = "DOME_SLOTTING")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SlotEntity extends AbstractEntityWithGeneratedId<Integer> {
  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DOME_SLOT_SEQ")
  @SequenceGenerator(sequenceName = "DOME_SLOT_SEQ", allocationSize = 1, name = "DOME_SLOT_SEQ")
  @Column(name = "SLOT_ID")
  private Integer slotID;

  @Column(name = "SP_DATE")
  private LocalDate caldate;

  @Column(name = "SP_DAY")
  private int day;

  @Column(name = "SP_EC_ID")
  private String engineCenterID;

  @OneToOne
  @NotFound(action = IGNORE)
  @JoinColumn(name = "SP_ENG_TYPE", insertable = false, updatable = false)
  private EngineTypeEntity engineType;

  @Column(name = "SP_ENG_TYPE")
  private String engineTypeID;

  @Column(name = "SP_MONTH")
  private int month;

  @Column(name = "SP_SLOT_TYPE")
  @Enumerated(EnumType.ORDINAL)
  private ShopVisitType shopVisitType;

//	@Column(name="SP_SUBSHOPVISIT")
//	private String subVisitType;

  @Column(name = "SP_YEAR")
  private int year;

  @Column(name = "SP_SLOT_COUNT")
  private Integer slotCount;

  @Override
  public Integer getId() {
    return slotID;
  }

  @Override
  public boolean isNew() {
    return isNull(slotID);
  }
}
