package com.pw.dome.engine.odin;

import java.time.LocalDate;
import java.util.List;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class EngineOdinUpdateRequestResponse {
	private LocalDate accyDeliveryDate;

	private LocalDate actualRecEbuDate;

	private LocalDate actualRecEcDate;

	@JsonFormat
	private LocalDate adListDate;

	private LocalDate aimAllocationDate;

	private Integer assetId;

	@Size(max = 4000)
	private String comments;

	private LocalDate committedInductionDate;

	@Size(max = 1)
	private String contractRemoval;

	@Size(max = 50)
	private String currentLocation;

	private LocalDate customerApprovalDate;

	@Size(max = 10)
	private String ebuShop;

	private LocalDate engineActualReceiptDate;

	// @NotNull(message = "{NotNull.required}")
	private Integer engineId;

	@Size(max = 10)
	@NotNull(message = "{NotNull.required}")
	private String esn;

	// @NotNull(message = "{NotNull.required}")
	private Integer eventId;

//	private LocalDate enginePlanReceiptDate;

	private LocalDate fanBladeMapDate;

	@Size(max = 1)
	private String fhaEligible;

	@Size(max = 1)
	private String investigationEngine;

	private LocalDate llpDeliveryDate;

	@Size(max = 50)
	private String llpReplacementType;

	@Size(max = 50)
	private String maintenanceCenter;

	private LocalDate nisDeliveryDate;

	private Integer odinId;

	@Size(max = 50)
	private String powerEngineer;

	private LocalDate preliminaryInductionDate;

	// ESN + eventId
	private List<LocalDate> preliminaryInductionDates;

	private LocalDate projRecEbuDate;

	private LocalDate projRecEcDate;

	private LocalDate removalActualDate;

	private LocalDate removalRecordedDate;

	@Size(max = 50)
	private String rslPO;

	//private LocalDate scheduledInductionDate;

	@Size(max = 50)
	private String speidPO;

	@Size(max = 50)
	private String svClassification;

	@Size(max = 50)
	private String upgradeEligibility;

	@Size(max = 20)
	private String workOrder;

	private LocalDate wsDraftCompleteAccyDate;

	private LocalDate wsDraftCompleteEngDate;

	private LocalDate wsInitiationDate;

	private LocalDate wsOrigReleaseDate;
}
