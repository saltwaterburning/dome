package com.pw.dome.contract;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController()
@RequestMapping("/v1/engine/contract-types")
class ContractsController {
	@Autowired
	private ContractService svc;

	@GetMapping()
    public ResponseEntity<ContractListResponse> getEngineContractTypes() {
		ContractListResponse response = svc.getContractTypes();
    	
    	return new ResponseEntity<ContractListResponse>(response, HttpStatus.OK);
    }
}
