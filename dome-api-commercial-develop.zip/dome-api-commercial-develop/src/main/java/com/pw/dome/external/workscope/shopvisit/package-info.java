/**
 * Provides workshop tool shopvisit services.
 */
package com.pw.dome.external.workscope.shopvisit;