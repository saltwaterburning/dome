package com.pw.dome.mml.le;

import static com.pw.dome.mml.le.DTO_FQCN.DTO_NAME;

interface Consts {
	String SHIPPED_DAYS = "14";
	
    /**
     * MML LE/plan queries.
     * Note that most of monthly/quarterly queries are identical.
     * Plan queries use {@code engine.engineID NOT IN} clause from LE_MONTHLY_SUBSELECT or LE_QUARTERLY_SUBSELECT.
     * Non-plan queries use {@code engine.engineID IN} clause from LE_MONTHLY_SUBSELECT or LE_QUARTERLY_SUBSELECT.
     * 
     * @see DetailsDTO
     * @see <a href="https://sqlformat.org/" target="_blank">SQL Format</a>
     */
   interface SQL {
       /**
        * JPQL Constructor Expression.
        */
       String NEW_DTO =
       " NEW " + DTO_NAME +
       "(engTrack.engtrackRecDate," +
       " customer.name," +
       " engine.category," +
       " engineCenter.name," +
       " engineGroup.engineGroupID," +
       " engineGroup.name," +
       " engine.engineID," +
       " engine.esn," +
       " opp.opportunity," +
       " opp.id," +
       " engTrack.engtrackPlanIndDate," +
       " leEntity.risk," +
       " leEntity.id)";

       /**
        * JPQL Constructor Expression.
        */
       String NEW_DTO_REVENUE =
       " NEW " + DTO_NAME +
       "(engTrack.enginePlanCoreAssemblyDate," +
       " customer.name," +
       " engine.category," +
       " engineCenter.name," +
       " engineGroup.engineGroupID," +
       " engineGroup.name," +
       " engine.engineID," +
       " engine.esn," +
       " opp.opportunity," +
       " opp.id," +
       " engTrack.gate3Plan," +
       " leEntity.risk," +
       " leEntity.id)";

       /**
        * JPQL Constructor Expression.
        */
       String NEW_DTO_SHIPMENT =
       " NEW " + DTO_NAME +
       "(engTrack.enginePlanCoreAssemblyDate," +
       " customer.name," +
       " engine.category," +
       " engineCenter.name," +
       " engineGroup.engineGroupID," +
       " engineGroup.name," +
       " engine.engineID," +
       " engine.esn," +
       " opp.opportunity," +
       " opp.id," +
       " engTrack.engtrackPlanEngComplete," +
       " leEntity.risk," +
       " leEntity.id)";
       
       
       
//       "    (SELECT le.engineId" +
//       "     FROM LeMonthlyEntity le" +
//       "     WHERE le.monthQtr = :month" +
//       "       AND le.year = :year" +
//       "       AND le.leMarket = :planMarket" +
//       "       AND le.leType = :planType ) " +

       
       
       /**
        * SELECT and FROM common to all monthly queries.
        */
       String SELECT_FROM_MONTHLY_BASE =
"""
FROM CustomerEntity customer,
     EngineCenterEntity engineCenter,
     EngineTrackingEntity engTrack,
     SlotEntity slot
LEFT OUTER JOIN EngineGroupEntity engineGroup ON engineGroup.active = true
AND engineGroup.engineGroupID IN (:engGroupIds)
LEFT OUTER JOIN EngineEntity engine ON engine.groupID = engineGroup.engineGroupID
AND engine.slotID is not null
AND UPPER(engine.esn) NOT IN ('CLOSED',
                              'FREE',
                              'LOST',
                              'RESV',
                              'XXXXXX')
LEFT OUTER JOIN LeMonthlyEntity leEntity ON leEntity.engineId = engine.engineID
AND leEntity.leMarket = :planMarket
AND leEntity.leType = :planType
AND leEntity.monthQtr = :month
AND leEntity.year = :year
LEFT OUTER JOIN LeMonthlyOpportunityEntity opp ON opp.engineId = engine.engineID
AND opp.leMarket = :planMarket
AND opp.leType = :planType
""";

       String SELECT_FROM_MONTHLY =
       "SELECT" + NEW_DTO + SELECT_FROM_MONTHLY_BASE;

       String SELECT_FROM_MONTHLY_REVENUE =
       "SELECT" + NEW_DTO_REVENUE + SELECT_FROM_MONTHLY_BASE;
       
       String SELECT_FROM_MONTHLY_SHIPMENT =
    	       "SELECT" + NEW_DTO_SHIPMENT + SELECT_FROM_MONTHLY_BASE;

       String SELECT_FROM_QUARTERLY_BASE =
    		   
       "FROM CustomerEntity customer," +
       "     EngineCenterEntity engineCenter," +
       "     EngineGroupEntity engineGroup," +
       "     EngineTrackingEntity engTrack," +
       "     SlotEntity slot" +
       " LEFT OUTER JOIN EngineEntity engine ON engine.groupID IN (:engGroupIds)" +
       "  LEFT OUTER JOIN" +
       "    LeQuarterlyEntity leEntity" +
       "    ON leEntity.engineId = engine.engineID" +
       "    AND leEntity.leMarket = :planMarket" +
       "    AND leEntity.leType = :planType  " +
       "    AND leEntity.monthQtr = :quarter" +
       "    AND leEntity.year = :year" +
       "  LEFT OUTER JOIN" +
       "    LeQuarterlyOpportunityEntity opp" +
       "    ON opp.engineId = engine.engineID" +
       "    AND opp.leMarket = :planMarket" +
       "    AND opp.leType = :planType ";

       /**
        * SELECT and FROM common to all quarterly queries.
        */
       String SELECT_FROM_QUARTERLY =
       "SELECT" + NEW_DTO + SELECT_FROM_QUARTERLY_BASE;

       String SELECT_FROM_QUARTERLY_REVENUE =
       "SELECT" + NEW_DTO_REVENUE + SELECT_FROM_QUARTERLY_BASE;
       
       String SELECT_FROM_QUARTERLY_SHIPMENT =
    	       "SELECT" + NEW_DTO_SHIPMENT + SELECT_FROM_QUARTERLY_BASE;

    /**
     * Initial WHERE clause for all queries.
     */
    String WHERE_CLAUSE =
"""
WHERE customer.customerID = engine.customerID
  AND customer.active = true
  AND engineCenter.id = :engCenterId
  AND engineCenter.active = true
  AND engineCenter.id = slot.engineCenterID
  AND engineGroup.engineGroupID = engine.groupID
  AND engineGroup.active = true
  AND engTrack.engtrackId = engine.engineID
  AND slot.engineCenterID = engineCenter.id
  AND slot.slotID = engine.slotID
""";
    
    /**
     * Use this part of query only for plan data.
     * engTrack.engtrackShipmentDate is null OR engTrack.engtrackShipmentDate > local_date - 7
     */
    String ENGINES_SHIPPED_WHERE =  "  AND (engTrack.engtrackShipmentDate is null" +
    	    "       OR engTrack.engtrackShipmentDate > (local_date - " + SHIPPED_DAYS + " day))" ;
    /**
     * EngineId subselect from LeMonthlyEntity with ORDER BY clause.
     */
    String LE_MONTHLY_SUBSELECT =
    "    (SELECT le.engineId" +
    "     FROM LeMonthlyEntity le" +
    "     WHERE le.monthQtr = :month" +
    "       AND le.year = :year" +
    "       AND le.leMarket = :planMarket" +
    "       AND le.leType = :planType ) " +
    "  AND slot.engineCenterID = engineCenter.id ";
    
    String ORDER_BY_IND_TRACK_DATE = " ORDER BY engTrack.engtrackPlanIndDate, engTrack.engtrackRecDate";
    
    String SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH = 
    	    "    (SELECT le.engineId" +
    	    "     FROM LeMonthlyEntity le" +
    	    "     WHERE le.leMarket = :planMarket" +
    	    "       AND le.leType = :planType  " +
    	    "       AND (le.year > extract(year from local_date) " +
    	    "                OR (le.year = :year AND le.monthQtr >= extract(month from local_date))))  " + 
    	    "  AND slot.engineCenterID = engineCenter.id ";
//    String SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH = 
//    	    "    (SELECT le.engineId" +
//    	    "     FROM LeMonthlyEntity le" +
//    	    "     WHERE le.leMarket = :planMarket" +
//    	    "       AND le.leType = :planType  " +
//    	    "       AND (le.year > extract(year from local_date) " +
//    	    "                OR (le.year = :year AND le.monthQtr >= extract(month from local_date))))  " + 
//    	    "  AND slot.engineCenterID = engineCenter.id ";
    
    /**
     * EngineId subselect from LeQuarterlyEntity with ORDER BY clause.
     */
    String LE_QUARTERLY_SUBSELECT =
    "    (SELECT le.engineId" +
    "     FROM LeQuarterlyEntity le" +
    "     WHERE le.monthQtr = :quarter" +
    "       AND le.year = :year" +
    "       AND le.leType = :planType" +
    "       AND le.leMarket = :planMarket ) ";

    String ORDER_BY_REVENUE =  " ORDER BY engTrack.gate3Plan, engTrack.enginePlanCoreAssemblyDate";
    
    String ORDER_BY_SHIPMENT =  " ORDER BY engTrack.engtrackPlanEngComplete, engTrack.enginePlanCoreAssemblyDate";
    
    String ORDER_BY_SHIP_ASSEMBLY_DATE =  " ORDER BY engTrack.engtrackPlnShipDate, engTrack.enginePlanCoreAssemblyDate";
    
    /**
     * @see LeMonthlyRepository#getLeMonthlyInductionData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
     */
    String MONTHLY_LATEST_ESTIMATE_INDUCTION_DATA =
       SELECT_FROM_MONTHLY +
       WHERE_CLAUSE +
       ORDER_BY_IND_TRACK_DATE;

    /** zzz
     * @see LeMonthlyRepository#getLeMonthlyPlanInductionData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
     */
    String MONTHLY_LATEST_ESTIMATE_PLAN_INDUCTION_DATA =
       SELECT_FROM_MONTHLY +
       WHERE_CLAUSE +
       ENGINES_SHIPPED_WHERE +
       "  AND engine.engineID NOT IN" +
       SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH + 
       ORDER_BY_IND_TRACK_DATE;

    /**
     * @see LeMonthlyRepository#getLeMonthlyPlanShipmentData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
     */
    String MONTHLY_LATEST_ESTIMATE_PLAN_SHIPMENT_DATA =
       SELECT_FROM_MONTHLY_SHIPMENT +
       WHERE_CLAUSE +
       ENGINES_SHIPPED_WHERE +
       "  AND engine.engineID NOT IN" +
       SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH + 
       ORDER_BY_SHIPMENT;

    /**
     * @see LeMonthlyRepository#getLeMonthlyPlanRevenueData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
     * xxxyyy
     */
    String MONTHLY_LATEST_ESTIMATE_PLAN_REVENUE_DATA =
       SELECT_FROM_MONTHLY_REVENUE +
       WHERE_CLAUSE +
       ENGINES_SHIPPED_WHERE +
       "  AND engine.engineID NOT IN" +
       SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH + 
       ORDER_BY_REVENUE;
    
    /**
     * @see LeMonthlyRepository#getLeMonthlyRevenueData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
     */
    String MONTHLY_LATEST_ESTIMATE_REVENUE_DATA =
       SELECT_FROM_MONTHLY_REVENUE +
       WHERE_CLAUSE +
       "  AND engine.engineID IN" +
       LE_MONTHLY_SUBSELECT + 
       ORDER_BY_REVENUE;
    
    /**
     * @see LeMonthlyRepository#getLeMonthlyShipmenteData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
     */
    String MONTHLY_LATEST_ESTIMATE_SHIPMENT_DATA =
       SELECT_FROM_MONTHLY_SHIPMENT +
       WHERE_CLAUSE +
       "  AND engine.engineID IN" +
       LE_MONTHLY_SUBSELECT + 
       ORDER_BY_SHIPMENT;

    /**
     * @see LeQuarterlyRepository#getLeQuarterlyInductionData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
     */
    String QUARTERLY_LATEST_ESTIMATE_INDUCTION_DATA =
       SELECT_FROM_QUARTERLY +
       WHERE_CLAUSE +
       "  AND engine.engineID IN" +
       LE_QUARTERLY_SUBSELECT + 
       ORDER_BY_SHIP_ASSEMBLY_DATE;

    /**
     * @see LeQuarterlyRepository#getLeQuarterlyPlanInductionData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
     */
    String QUARTERLY_LATEST_ESTIMATE_PLAN_INDUCTION_DATA =
       SELECT_FROM_QUARTERLY +
       WHERE_CLAUSE +
       ENGINES_SHIPPED_WHERE +
       "  AND engine.engineID NOT IN" +
       SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH + 
       ORDER_BY_SHIP_ASSEMBLY_DATE;

    /**
     * @see LeQuarterlyRepository#getLeQuarterlyPlanRevenueData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
     */
    String QUARTERLY_LATEST_ESTIMATE_PLAN_REVENUE_DATA =
       SELECT_FROM_QUARTERLY_REVENUE +
       WHERE_CLAUSE +
       ENGINES_SHIPPED_WHERE +
       "  AND engine.engineID NOT IN" +
       SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH + 
       ORDER_BY_REVENUE;
    
    /**
     * @see LeQuarterlyRepository#getLeQuarterlyPlanShipmentData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
     */
    String QUARTERLY_LATEST_ESTIMATE_PLAN_SHIPMENT_DATA =
       SELECT_FROM_QUARTERLY_SHIPMENT +
       WHERE_CLAUSE +
       ENGINES_SHIPPED_WHERE +
       "  AND engine.engineID NOT IN" +
       SELECT_ENGINE_ID_NOT_IN_FUTURE_MONTH + 
       ORDER_BY_SHIPMENT;

    /**
     * @see LeQuarterlyRepository#getLeQuarterlyRevenueData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
     */
    String QUARTERLY_LATEST_ESTIMATE_REVENUE_DATA =
       SELECT_FROM_QUARTERLY_REVENUE +
       WHERE_CLAUSE +
       "  AND engine.engineID IN" +
       LE_QUARTERLY_SUBSELECT + 
       ORDER_BY_REVENUE;
   
   /**
    * @see LeQuarterlyRepository#getLeQuarterlyShipmentData(String, String, int, int, com.pw.dome.mml.PlanMarket, com.pw.dome.mml.PlanType)
    */
   String QUARTERLY_LATEST_ESTIMATE_SHIPMENT_DATA =
      SELECT_FROM_QUARTERLY_SHIPMENT +
      WHERE_CLAUSE +
      "  AND engine.engineID IN" +
      LE_QUARTERLY_SUBSELECT + 
      ORDER_BY_SHIPMENT;
   }
}