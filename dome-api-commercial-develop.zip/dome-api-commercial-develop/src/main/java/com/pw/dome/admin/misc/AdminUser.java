package com.pw.dome.admin.misc;

import lombok.Builder;

@Builder
record AdminUser(String name, String email, String organization) {

}
