package com.pw.dome.calendar.slots;

import static com.pw.dome.calendar.slots.BusinessRules.getEngineCenterCode;
import static com.pw.dome.calendar.slots.Consts.SQL.GET_IP_CALENDAR_VISITS;
import static com.pw.dome.calendar.slots.ShopVisitType.HOLIDAY;
import static com.pw.dome.calendar.slots.ShopVisitType.NEW;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import jakarta.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pw.dome.calendar.inductionplanning.InductionPlanningEngine;
import com.pw.dome.engine.induction.planning.InductionMiscKeys;
import com.pw.dome.engine.induction.planning.InductionMiscService;
import com.pw.dome.engine.induction.planning.InductionMiscShortValueDTO;

/**
 * @author John De Lello
 */
@Repository
@Transactional
public class SlotRepositoryImpl implements SlotRespositoryCustom {
	@Autowired
	private InductionMiscService svc;
	@Autowired
	private NamedParameterJdbcTemplate template;

	private static final List<Integer> SLOT_TYPES =
			Arrays.asList(HOLIDAY.getValue(), NEW.getValue());

	private static final Map<String, String> CATEGORY_CODES = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

	@PostConstruct
	void init() {
		List<InductionMiscShortValueDTO> shortValues = svc.getInductionShortValue(InductionMiscKeys.WIPENGCATEGORY);
		shortValues.stream().forEach(s -> CATEGORY_CODES.put(s.getValueField(), s.getShortField()));
	}

	public List<InductionPlanningEngine> getInductionPlanningCalendarVisitSummary(final String userEmailAddress,
			final List<String> engineTypeIds, final int month, final int year) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("slotTypes", SLOT_TYPES)
		      .addValue("userEmailAddress", userEmailAddress)
		      .addValue("engineTypeIds", engineTypeIds)
		      .addValue("month", month)
		      .addValue("year", year);
		return template.query(GET_IP_CALENDAR_VISITS, params, new RowMapper<InductionPlanningEngine>() {

			@Override
			public InductionPlanningEngine mapRow(ResultSet rs, int rowNum) throws SQLException {
				String eData = rs.getString("eData");
				String vData = rs.getString("vData");
				String engineTypeId = rs.getString("engineTypeId");
				String engineCenterCode = getEngineCenterCode(engineTypeId, eData, vData);

				String key;
				return InductionPlanningEngine.builder()
						                      .category(key = rs.getString("category"))
						                      .categoryCode(StringUtils.isBlank(key) ? "" : CATEGORY_CODES.get(key))
						                      .dayOfMonth(rs.getInt("dayOfMonth"))
						                      .engineCenterCode(engineCenterCode)
						                      .engineCenterID(rs.getString("engineCenterID"))
						                      .engineCenterName(rs.getString("engineCenterName"))
						                      .engineID(rs.getInt("engineID"))
						                      .esn(rs.getString("esn"))
						                      .shopVisitType(rs.getInt("shopVisitType"))
						                      .slotCount(rs.getInt("slotCount"))
						                      .slotID(rs.getInt("slotID"))
						                      .build();
			}
		});
	}
}
