package com.pw.dome.example;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Example DTO.
 * 
 * Note that required = true needs to be set for not-blank params.
 * 
 * Annotations recognized by springdoc-openapi are @NotNull, @Min, @Max, and @Size
 * When using @Blank set required = true for @Schema annotation.
 * 
 * @see <a href="https://springdoc.org/">Spingdoc OpenAPI</a>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "Example DTO schema.")
class ExampleRequestAndResponse {
  @Size(min = 1, max = 20)
  @NotBlank(message = "{NotBlank.required}")
  @Schema(required = true, description = "")
  private String esn;

  @Min(1)
  @NotBlank(message = "{NotBlank.required}")
  @Schema(required = true, description = "")
  private Integer eventId;

  @Size(min = 1, max = 10)
  @NotBlank(message = "{NotBlank.required}")
  @Schema(required = true, description = "")
  private String mroShopCode;

  @Size(min = 1, max = 25)
  @NotBlank(message = "{NotBlank.required}")
  @Schema(required = true, description = "Named SMI in MRO system.")
  private String mroWorkOrder;
}
