package com.pw.dome.admin.enginecenter.maintenance;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
final class BasicEngineType {
	@NotNull(message = "{NotNull.required}")
	private boolean active;
	@NotNull(message = "{NotNull.required}")
	private boolean inEngineCenter;
	@NotNull(message = "{NotNull.required}")
	private boolean assignedToCustomer;
	//@Pattern(regexp = "^" + ET_ID_PREFIX + "\\d{1,8}$")
	//@Size(min = 3, max = 10)
	//Reason to comment validation: When user wants to create a new engineType this field will be blank
	private String typeId;
	@NotNull(message = "{NotNull.required}")
	@Size(min = 1, max = 100)
	private String typeName;
	@NotNull(message = "{NotNull.required}")
	private boolean eagleData;
}
