package com.pw.dome.engine.phase;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

/**
 * @author John De Lello
 */
@Service
public class EnginePhasesServiceImpl implements EnginePhaseService {
	@Autowired
	private EnginePhaseRepository enginePhaseRepo;

	@Override
	public List<EnginePhaseEntity> getEnginePhases() {
		Sort sort = Sort.by(Sort.Direction.ASC, "displayRank");
		return enginePhaseRepo.findAll(sort);
	}

}
