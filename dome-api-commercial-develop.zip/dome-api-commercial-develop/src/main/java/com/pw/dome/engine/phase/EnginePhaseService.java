package com.pw.dome.engine.phase;

import java.util.List;

/**
 * @author John De Lello
 */
public interface EnginePhaseService {
	List<EnginePhaseEntity> getEnginePhases();
}
