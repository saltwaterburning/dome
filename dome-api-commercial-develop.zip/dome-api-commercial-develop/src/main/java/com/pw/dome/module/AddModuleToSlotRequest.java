package com.pw.dome.module;

import jakarta.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author John De Lello
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class AddModuleToSlotRequest {
	@NotBlank
	private String category;
	@NotBlank
	private String customerID;
	@NotBlank
	private String engineTypeId;
	@NotBlank
	private String esn;
	@NotBlank
	private String subVisitType; 
}
