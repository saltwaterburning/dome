package com.pw.dome.mml.le;

import static com.pw.dome.mml.le.Consts.SQL.QUARTERLY_LATEST_ESTIMATE_INDUCTION_DATA;
import static com.pw.dome.mml.le.Consts.SQL.QUARTERLY_LATEST_ESTIMATE_PLAN_INDUCTION_DATA;
import static com.pw.dome.mml.le.Consts.SQL.QUARTERLY_LATEST_ESTIMATE_PLAN_REVENUE_DATA;
import static com.pw.dome.mml.le.Consts.SQL.QUARTERLY_LATEST_ESTIMATE_PLAN_SHIPMENT_DATA;
import static com.pw.dome.mml.le.Consts.SQL.QUARTERLY_LATEST_ESTIMATE_REVENUE_DATA;
import static com.pw.dome.mml.le.Consts.SQL.QUARTERLY_LATEST_ESTIMATE_SHIPMENT_DATA;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pw.dome.mml.PlanMarket;
import com.pw.dome.mml.PlanType;

@Repository
interface LeQuarterlyRepository extends JpaRepository<LeQuarterlyEntity, Integer> {
    int deleteByIdIn(List<Integer> ids);

    @Modifying
    @Query(value = "DELETE from LeQuarterlyEntity leQuarterlyEntity where leQuarterlyEntity.engineId = ?1")
    Integer deleteByEngineId(Integer engineId);

    @Modifying
    @Query(value = "DELETE from LeQuarterlyEntity leQuarterlyEntity where leQuarterlyEntity.engineId in ?1")
    Integer deleteByEngineIds(List<Integer> engineIds);

    @Query(QUARTERLY_LATEST_ESTIMATE_INDUCTION_DATA)
    List<DetailsDTO> getLeQuarterlyInductionData(@Param("engCenterId") final String engineCenterId,
                                                 @Param("engGroupIds") final List<String> engineGroups,
                                                 @Param("quarter") final int leQtr,
                                                 @Param("year") final int leYear,
                                                 @Param("planMarket") final PlanMarket planMarket,
                                                 @Param("planType") final PlanType planType);

    @Query(QUARTERLY_LATEST_ESTIMATE_PLAN_INDUCTION_DATA)
    List<DetailsDTO> getLeQuarterlyPlanInductionData(@Param("engCenterId") final String engineCenterId,
                                                     @Param("engGroupIds") final List<String> engineGroups,
                                                     @Param("quarter") final int leQtr,
                                                     @Param("year") final int leYear,
                                                     @Param("planMarket") final PlanMarket planMarket,
                                                     @Param("planType") final PlanType planType);

    @Query(QUARTERLY_LATEST_ESTIMATE_PLAN_REVENUE_DATA)
    List<DetailsDTO> getLeQuarterlyPlanRevenueData(@Param("engCenterId") final String engineCenterId,
                                                   @Param("engGroupIds") final List<String> engineGroups,
                                                   @Param("quarter") final int leQtr,
                                                   @Param("year") final int leYear,
                                                   @Param("planMarket") final PlanMarket planMarket,
                                                   @Param("planType") final PlanType planType);
    
    @Query(QUARTERLY_LATEST_ESTIMATE_PLAN_SHIPMENT_DATA)
    List<DetailsDTO> getLeQuarterlyPlanShipmentData(@Param("engCenterId") final String engineCenterId,
                                                    @Param("engGroupIds") final List<String> engineGroups,
                                                    @Param("quarter") final int leQtr,
                                                    @Param("year") final int leYear,
                                                    @Param("planMarket") final PlanMarket planMarket,
                                                    @Param("planType") final PlanType planType);

    @Query(QUARTERLY_LATEST_ESTIMATE_REVENUE_DATA)
    List<DetailsDTO> getLeQuarterlyRevenueData(@Param("engCenterId") final String engineCenterId,
                                               @Param("engGroupIds") final List<String> engineGroups,
                                               @Param("quarter") final int leQtr,
                                               @Param("year") final int leYear,
                                               @Param("planMarket") final PlanMarket planMarket,
                                               @Param("planType") final PlanType planType);

    @Query(QUARTERLY_LATEST_ESTIMATE_SHIPMENT_DATA)
    List<DetailsDTO> getLeQuarterlyShipmentData(@Param("engCenterId") final String engineCenterId,
                                                @Param("engGroupIds") final List<String> engineGroups,
                                                @Param("quarter") final int leQtr,
                                                @Param("year") final int leYear,
                                                @Param("planMarket") final PlanMarket planMarket,
                                                @Param("planType") final PlanType planType);

    @Modifying
    @Query("update LeQuarterlyEntity leQuarterlyEntity set leQuarterlyEntity.risk = :risk where leQuarterlyEntity.engineId = :engineId")
    int updateRiskByEngineId(@Param("risk") boolean risk, @Param("engineId") Integer engineId);
}
