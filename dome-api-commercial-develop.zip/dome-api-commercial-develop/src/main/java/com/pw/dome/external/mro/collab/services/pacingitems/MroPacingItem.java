package com.pw.dome.external.mro.collab.services.pacingitems;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.pw.dome.external.mro.MROConsts;
import com.pw.dome.util.validators.EitherOr;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Fields required by DOME:
 * category
 * engineId
 * escItem
 * esn
 * logDateTime
 * pacingId
 * partId OR uniqueId
 *
 * Fields required by MRO:
 * eventId
 * mroShopCode
 * mroWorkOrder
 */
@Data
@NoArgsConstructor
//@AllArgsConstructor
@Builder
@Schema(description = "PacingItem DTO schema.")
@EitherOr(first = "partId", second = "uniqueId", message = "Either partId OR uniqueId must be supplied.")
public class MroPacingItem {

	public MroPacingItem(String category,
			LocalDate closeDate,
			LocalDate commitDate,
			LocalDate datReceivedDate,
			LocalDate datShipOutDate,
			String description,
			Integer dollarsSaved,
			Integer engineId,
			Boolean escItem,
			String esn,
			Integer eventId,
			int holdDaysApproved,
			LocalDateTime logDateTime,
			String mroShopCode,
			String mroWorkOrder,
			LocalDate needDate,
			String notes,
			Integer pacingId,
			String partId,
			String purchaseOrder,
			LocalDate startDate,
			String subCategory,
			String uniqueId,
			LocalDate vendorInDate,
			String vendorName,
			LocalDate vendorOutDate,
			String wsInd) {
		super();
		this.category = category;
		this.closeDate = closeDate;
		this.commitDate = commitDate;
		this.datReceivedDate = datReceivedDate;
		this.datShipOutDate = datShipOutDate;
		this.description = description;
		this.dollarsSaved = dollarsSaved == null ? 0 : dollarsSaved;
		this.engineId = engineId;
		this.escItem = escItem;
		this.esn = esn;
		this.eventId = eventId;
		this.holdDaysApproved = holdDaysApproved;
		this.logDateTime = logDateTime;
		this.mroShopCode = mroShopCode;
		this.mroWorkOrder = mroWorkOrder;
		this.needDate = needDate;
		this.notes = notes;
		this.pacingId = pacingId;
		this.partId = partId;
		this.purchaseOrder = purchaseOrder;
		this.startDate = startDate;
		this.subCategory = subCategory;
		this.uniqueId = uniqueId;
		this.vendorInDate = vendorInDate;
		this.vendorName = vendorName;
		this.vendorOutDate = vendorOutDate;
		this.wsInd = wsInd;
	}

	@NotBlank
	@Size(min = 1, max = 20)
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String category;

	@JsonFormat(pattern = MROConsts.ISO_DATE_FORMAT)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private LocalDate closeDate;

	@JsonFormat(pattern = MROConsts.ISO_DATE_FORMAT)
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private LocalDate commitDate;

	@JsonFormat(pattern = MROConsts.ISO_DATE_FORMAT)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private LocalDate datReceivedDate;

	@JsonFormat(pattern = MROConsts.ISO_DATE_FORMAT)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private LocalDate datShipOutDate;

	@Size(min = 0, max = 50)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private String description;

	// @PositiveOrZero
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private Integer dollarsSaved;

	@NotNull
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Integer engineId;

	/**
	 * ESC flag must be {@link Boolean} type for change detection. Change detection
	 * uses getters boolean type uses 'is' instead.
	 */
	@NotNull
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Boolean escItem;

	@Size(min = 1, max = 20)
	@NotBlank
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String esn;

	@NotNull
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Integer eventId;

	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private int holdDaysApproved;

	@JsonFormat(pattern = MROConsts.ISO_8601_VARIATION_FORMAT)
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	@NotNull
	private LocalDateTime logDateTime;

	@Size(min = 1, max = 10)
	@NotBlank
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private String mroShopCode;

	@Size(min = 1, max = 25)
	@NotBlank
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "Named SMI in MRO system.")
	private String mroWorkOrder;

	@JsonFormat(pattern = MROConsts.ISO_DATE_FORMAT)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private LocalDate needDate;

	@Size(min = 0, max = 2000)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private String notes;

	@NotNull
	@Schema(requiredMode = RequiredMode.REQUIRED, description = "")
	private Integer pacingId;

	@Size(min = 0, max = 50)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private String partId;

	@Size(min = 0, max = 40)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private String purchaseOrder;

	@JsonFormat(pattern = MROConsts.ISO_DATE_FORMAT)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private LocalDate startDate;

	@Size(min = 0, max = 20)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private String subCategory;

	@Size(min = 0, max = 50)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private String uniqueId;

	@JsonFormat(pattern = MROConsts.ISO_DATE_FORMAT)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private LocalDate vendorInDate;

	@Size(min = 0, max = 30)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private String vendorName;

	@JsonFormat(pattern = MROConsts.ISO_DATE_FORMAT)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private LocalDate vendorOutDate;

	@Size(min = 0, max = 20)
	@Schema(requiredMode = RequiredMode.NOT_REQUIRED, description = "")
	private String wsInd;
}
