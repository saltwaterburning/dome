package com.pw.dome.external.mro.collab.services.workorder;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.NaturalId;

import com.pw.dome.jpa.AbstractEntityWithNaturalId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The DOME_ENGINE_CENTER_SHOPCD table maps DOME Engine Center Id to the MRO EC
 * Shop Code.
 */
@Entity
@Table(name = "DOME_ENGINE_CENTER_SHOPCD")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Immutable
class MroEngineCenterEntity extends AbstractEntityWithNaturalId<String> {
	@Id
	@NaturalId
	@Column(name = "EC_ID")
	private String ecId;

	@Column(name = "EC_SHOP_CODE")
	private String mroEcShopCode;

	@Override
	public String getId() {
		return ecId;
	}
}
