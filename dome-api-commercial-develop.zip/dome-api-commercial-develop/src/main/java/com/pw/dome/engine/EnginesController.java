package com.pw.dome.engine;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pw.dome.calendar.induction.CalendarShopVisit;
import com.pw.dome.user.UserProfile;


@RestController()
@RequestMapping("/v1/engines")
@Validated
public class EnginesController {
	@Autowired
	private EngineService engineSvc;
	
	/**
	 * @api {put} /v1/engines/slot/:engineID/:newSlotID Update Engine SlotEntity
     * @apiExample {curl} Example usage: 
     *      curl -X PUT -H "Authorization: Bearer [token]" 
     *           http://localhost:8080/v1/engines/slot/:engineID/:newSlotID 
     * @apiName updateEngineSlot
     * @apiGroup Engines
     * @apiParam {Number} engineID The Engine ID to modify the slot for
     * @apiParam {Number} newSlotID The new slot ID to put the engine in
     * @apiDescription Attempts to update the slot ID of the engine
     * @apiSuccess {Number} slotID The ID of the slot the engine was moved to
     * @apiSuccess {Number} shopVisitType The slot type assigned to this slot
     * @apiSuccess {String} subShopVisitType The code indicator of the sub slot type
     * @apiSuccess {String} engineTypeID The Engine Type ID for this slot
     * @apiSuccess {String} engineTypeName The Engine Type Name for this slot
     * @apiSuccess {Object[]} engines An array of associated engines to this slot
     * @apiSuccess {Number} engines.engineID The ID for the engine
     * @apiSuccess {String} engines.esn The serial number for the engine
     * @apiSuccess {Number} engines.engineGroupID The group ID for the engine
     * @apiSuccess {Number} engines.engineModelID The model ID for the engine
     * @apiSuccess {Number} [engines.moduleID] The module ID. Will always be null when adding engine
     * @apiSuccess {String} engines.customerID The Customer ID for the engine
     * @apiSuccess {String} engines.customerShortName The customer short name
     * @apiSuccess {String} engines.customerShortName The Customer short Name for the engine
     * @apiSuccess {String} engines.customerName The Customer Name for the engine
     * @apiUse AddToSlotSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500
     **/
    @RequestMapping(value = "/slot/{engineID}/{newSlotID}", method = RequestMethod.PUT)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE"})
    public ResponseEntity<CalendarShopVisit> updateEngineSlot(
    		@AuthenticationPrincipal
    		UserProfile userProfile,
    		@PathVariable(name = "engineID")
    		Integer engineID,
    		@PathVariable(name = "newSlotID")
    		Integer newSlotID,
    		@RequestBody
    		@Valid
    		UpdateEngineSlotRequest request) {
    	CalendarShopVisit calendarShopVisit= engineSvc.updateEngineSlot(userProfile, engineID, newSlotID, request);
    	
    	return new ResponseEntity<CalendarShopVisit>(calendarShopVisit, HttpStatus.OK);
    }
    
	/**
	 * @api {put} /v1/engines/esn/:engineID/:newRemovedEngineID Update Engine ESN
     * @apiExample {curl} Example usage: 
     *      curl -X PUT -H "Authorization: Bearer [token]" 
     *           http://localhost:8080/v1/engines/esn/:engineID/:newRemovedEngineID 
     * @apiName updateEngineEsn
     * @apiGroup Engines
     * @apiParam {Number} engineID The Engine ID to modify the slot for
     * @apiParam {Number} newRemovedEngineID The new removedEngineID to use for getting ESN and other data to update engine with. This removed engine cannot already be slotted
     * @apiDescription Attempts to update the ESN of the engine. The current ESN of the engine must be XXXXXX or an BadRequest will be thrown.
     * @apiSuccess {Number} slotID The ID of the slot the engine is in
     * @apiSuccess {Number} shopVisitType The slot type assigned to this slot
     * @apiSuccess {String} subShopVisitType The code indicator of the sub slot type
     * @apiSuccess {String} engineTypeID The Engine Type ID for this slot
     * @apiSuccess {String} engineTypeName The Engine Type Name for this slot
     * @apiSuccess {Object[]} engines An array of associated engines to this slot
     * @apiSuccess {Number} engines.engineID The ID for the engine
     * @apiSuccess {String} engines.esn The serial number for the engine
     * @apiSuccess {Number} engines.engineGroupID The group ID for the engine
     * @apiSuccess {Number} engines.engineModelID The model ID for the engine
     * @apiSuccess {Number} [engines.moduleID] The module ID. Will always be null when adding engine
     * @apiSuccess {String} engines.customerID The Customer ID for the engine
     * @apiSuccess {String} engines.customerShortName The customer short name
     * @apiSuccess {String} engines.customerName The Customer Name for the engine
     * @apiUse AddToSlotSuccessResponse
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401
     * @apiUse Error500 
     **/
    @RequestMapping(value = "/esn/{engineID}/{newRemovedEngineID}", method = RequestMethod.PUT)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE"})
    public ResponseEntity<CalendarShopVisit> updateEngineEsn(
    		@AuthenticationPrincipal
    		UserProfile userProfile,
    		@PathVariable(name = "engineID")
    		Integer engineID,
    		@PathVariable(name = "newRemovedEngineID")
    		Integer newRemovedEngineID) {
    	
    	CalendarShopVisit calendarShopVisit= engineSvc.updateEngineEsn(userProfile, engineID, newRemovedEngineID);
    	
    	return new ResponseEntity<CalendarShopVisit>(calendarShopVisit, HttpStatus.OK);
    	
    }
    
    /**
     * @api {delete} /v1/engines/:engineID Remove Engine
     * @apiExample {curl} Example usage: 
     *       curl --request DELETE 
     *            --url http://localhost:8080/v1/engines/12345
     *            --header 'authorization: Bearer [jwt]'
     * @apiName deleteEngine
     * @apiGroup Engines
     * @apiParam {Number} engineID The engine ID to remove
     * @apiDescription Removes the engine ID from all slotting and returns the ID back to eligibility for slotting again.
     * @apiSuccessExample  {json} Sample Success-Response:
     *         HTTP/1.1 200 OK 
     * @apiUse Error     
     * @apiUse Error400 
     * @apiUse Error401    
     * @apiUse Error500 
     */
	@RequestMapping(value = "/{engineID}", method = RequestMethod.DELETE)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE"})
	public ResponseEntity<?> deleteEngine(@AuthenticationPrincipal UserProfile userProfile, 
			                                            @PathVariable("engineID") int engineID) {

		engineSvc.deleteSlottedEngine(userProfile, engineID);
		return new ResponseEntity<>(null, HttpStatus.OK);
	}    

	@RequestMapping(method = RequestMethod.POST)
	@Secured({"ROLE_ADMINISTRATOR", "ROLE_READWRITE"})
	public ResponseEntity<?> editEngine(
			@AuthenticationPrincipal
			UserProfile userProfile,
    		@RequestBody
    		@Valid
    		EngineDTO engine) {

		EngineDTO dto = engineSvc.editEngine(userProfile, engine);
		return new ResponseEntity<>(dto, HttpStatus.OK);
	}
}
