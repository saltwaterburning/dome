package com.pw.dome.admin.misc;

interface Consts {

	interface SQL {
		String GET_ADMINS =
"""
SELECT trim(LOG_FIRSTNAME)||' '||trim(LOG_LASTNAME) AS "name",
       LOG_EMAIL AS "email",
       LOG_ORGANIZATION AS "organization"
FROM DOME_LOGIN
WHERE LOG_ROLEID = 'Administrator'
  AND LOG_STATUS = 'APPROVED'
ORDER BY LOG_LASTNAME
""";
	}
}
