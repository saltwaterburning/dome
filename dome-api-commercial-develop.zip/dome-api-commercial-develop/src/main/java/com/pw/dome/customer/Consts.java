package com.pw.dome.customer;

interface Consts {

	interface SQL {
		/**
		 * Returns Customers data for given user.
	     */
		String GET_CUSTOMERS_QUERY =
"""
SELECT c
FROM CustomerEntity c,
     CustomerCenterMatrixEntity ccm,
     SecurityEngineCenterEntity sec,
     EngineCenterEntity ec
WHERE c.active = true
  AND c.customerID = ccm.pk.customerId
  AND ccm.pk.engineCenterId = ec.id
  AND ec.active = true
  AND sec.emailAddress = :email
  AND sec.engineCenterId = ec.id
ORDER BY c.name
""";
				
	}
}
