package com.pw.dome.customer;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import org.hibernate.annotations.Immutable;

import com.pw.dome.jpa.AbstractEntityWithEmbeddedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_CUSTOMER_TYPE_MAP")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Immutable
public class CustomerTypeMapEntity extends AbstractEntityWithEmbeddedId<CustomerTypeMapEntityPK> {

	@EmbeddedId
	private CustomerTypeMapEntityPK id;
}
