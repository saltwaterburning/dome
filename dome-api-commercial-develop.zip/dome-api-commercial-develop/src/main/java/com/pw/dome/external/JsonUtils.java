package com.pw.dome.external;

import java.time.format.DateTimeFormatter;

import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;


/**
 *
 */
public class JsonUtils {
	private static ObjectMapper MAPPER = Jackson2ObjectMapperBuilder.json()
			                                                        .featuresToEnable(SerializationFeature.INDENT_OUTPUT)
			                                                        .serializers(new LocalDateSerializer(DateTimeFormatter.ofPattern("MM/dd/yyyy")))
			                                                        .build();

	static {
		MAPPER.setSerializationInclusion(Include.ALWAYS);
	}

	/**
	 * How to use existing JsonDateTimeFormatConfig and eliminate MAPPER???
	 * 
	 * @param obj
	 * @return
	 */
	public static String toJSON(Object obj) {
		try {
			return MAPPER.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static <T> T toObject(String content, Class<T> valueType) {
		try {
			return MAPPER.readValue(content, valueType);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
