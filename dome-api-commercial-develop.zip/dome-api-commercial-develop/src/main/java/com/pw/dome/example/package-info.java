/**
 * Coding examples.
 */
package com.pw.dome.example;