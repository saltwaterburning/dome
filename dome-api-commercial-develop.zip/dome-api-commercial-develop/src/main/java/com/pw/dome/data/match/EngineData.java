package com.pw.dome.data.match;

import static com.pw.dome.data.match.Consts.NOTIFY_NUMBER_COLUMN_SIZE;
import static com.pw.dome.data.match.Consts.SALES_ORDER_NO_COLUMN_SIZE;

import java.time.LocalDate;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * JSON LocalDate encoding format defined in {@code JsonDateTimeFormatConfig}.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EngineData {
	private LocalDate engineInductDate;
	private LocalDate engineReceiveDate;
	private LocalDate engineShipDate;
	private LocalDate slotDate;

	private String engineCenterName;
	private String engineCenterId;
	private String engineModel;
	private String engineGroupId;
	private String engineOperator;
	private String engineSN;
	private String customerName;
	private String engtrackRecDate;
	@Size(min = 0, max = NOTIFY_NUMBER_COLUMN_SIZE)
	private String notifyNum;

	@Size(min = 0, max = SALES_ORDER_NO_COLUMN_SIZE)
	private String salesOrderNum;

	@JsonIgnore
	private String engActivity;
	@JsonIgnore
	private String engActivityDate;
	@JsonIgnore
	private int engActivitySequenceNum;

	@NotNull(message = "{NotNull.required}")
	private int engineIdSeq;
}
