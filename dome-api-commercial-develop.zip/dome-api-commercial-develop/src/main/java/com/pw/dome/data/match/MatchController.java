package com.pw.dome.data.match;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;

@Controller
@RequestMapping("/v1/engine/data")
//@Slf4j
class MatchController {
	@Autowired
	private MatchService matchService;

	/**
     * @api {get} /v1/engine/data/matches/:engineCenter/:engineType or /v1/engine/data/matches/:engineSN Get matched data (old version)
     * @apiExample {curl} Example usage: 
     *      curl -X GET -H "Authorization: Bearer [jwt]" 
     *           http://localhost:8080/v1/engine/data/matches
     * @apiName getMatchedData
     * @apiGroup Engine Data Match
     * @apiParam {String} engine-center The engine center Id
     * @apiParam {String} engine-type The engine type Id
     * @apiParam {String} engine-sn The engine serial number
     * @apiDescription Returns all matched data
     * @apiSuccess {Object[]} engines A engine array 
     * @apiSuccess {String} engines.engineActualInductDate The induction date
     * @apiSuccess {String} engines.engineActualReceiveDate The receive date 
     * @apiSuccess {String} engines.engineActualShipDate The ship date 
     * @apiSuccess {String} engines.engineCenterId The EC Id 
     * @apiSuccess {String} engines.engineCenterName The EC name 
     * @apiSuccess {String} engines.engineModel The engine model Id 
     * @apiSuccess {String} engines.engineOperator The customer name 
     * @apiSuccess {String} engines.engineSN The engine serial number 
     * @apiSuccess {String} engines.engineTypeId The engine type Id 
     * @apiSuccess {String} engines.notifyNumber The notify number 
     * @apiSuccess {String} engines.salesOrderNum The sales order number 
     * @apiSuccess {Number} engines.engineIdSeq The dome_engine table sequence Id 
     * @apiSuccess {Number} engines.slotId The slot Id 
     * @apiUse MatchedUnmatchedSuccessResponse
     * @apiUse Error
     */
	@GetMapping(path = {"/matches/{engine-center}/{engine-type}", "/matches/{engine-sn}"},  produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineDataResponse> getMatchedData(
			@PathVariable(name = "engine-center", required = false)
			final String engineCenter,
			@PathVariable(name = "engine-type", required = false)
			final String engineType,
			@PathVariable(name = "engine-sn", required = false)
			final String engineSN) {
		return ResponseEntity.ok(matchService.getMatchedData(engineCenter, engineType, engineSN));
	}
	
	
	/**
     * @api {get} /v1/engine/data/unmatches/:engineCenter/:engineType or /v1/engine/data/matches/:engineSN Get unmatched data
     * @apiExample {curl} Example usage: 
     *      curl -X GET -H "Authorization: Bearer [jwt]" 
     *           http://localhost:8080/v1/engine/data/unmatches/:engineCenter/:engineType
     * @apiName getUnmatchedData
     * @apiGroup Engine Data Match
     * @apiParam {String} engine-center The engine center Id
     * @apiParam {String} engine-type The engine type Id
     * @apiParam {String} engine-sn The engine serial number
     * @apiDescription Returns all unmatched data
     * @apiSuccess {Object[]} engines A engine array 
     * @apiSuccess {String} engines.engineActualInductDate The induction date
     * @apiSuccess {String} engines.engineActualReceiveDate The receive date 
     * @apiSuccess {String} engines.engineActualShipDate The ship date 
     * @apiSuccess {String} engines.engineCenterId The EC Id 
     * @apiSuccess {String} engines.engineCenterName The EC name 
     * @apiSuccess {String} engines.engineModel The engine model Id 
     * @apiSuccess {String} engines.engineOperator The customer name 
     * @apiSuccess {String} engines.engineSN The engine serial number 
     * @apiSuccess {String} engines.engineTypeId The engine type Id 
     * @apiSuccess {String} engines.notifyNumber The notify number 
     * @apiSuccess {String} engines.salesOrderNum The sales order number 
     * @apiSuccess {Number} engines.engineIdSeq The dome_engine table sequence Id 
     * @apiSuccess {Number} engines.slotId The slot Id 
     * @apiUse MatchedUnmatchedSuccessResponse
     * @apiUse Error
     */
	@GetMapping(path = {"/unmatches/{engine-center}/{engine-type}", "/unmatches/{engine-sn}"},  produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineDataResponse> getUnmatchedData(
			@PathVariable(name = "engine-center", required = false)
			final String engineCenter,
			@PathVariable(name = "engine-type", required = false)
			final String engineType,
			@PathVariable(name = "engine-sn", required = false)
			final String engineSN) {
		return ResponseEntity.ok(matchService.getUnmatchedData(engineCenter, engineType, engineSN));
	}
	

	/**
     * @api {post} /v1/engine/data/unmatches Sets matched data to unmatched
     * @apiExample {curl} Example usage:
     *       curl --request POST
     *            --url http://localhost:8080/v1/engine/data/unmatches
     *            --header 'authorization: Bearer [jwt]'
     *            --header 'content-type: application/json'
     *            --data '{}'
     * @apiName updateUnmatchedData
     * @apiGroup Engine Data Match
     * @apiParam {engineData} an Engine
     * @apiDescription Sets matched data to unmatched
     * @apiSuccess {EngineData} unmatched engine
     * @apiSuccess {String} engines.engineActualInductDate The induction date
     * @apiSuccess {String} engines.engineActualReceiveDate The receive date 
     * @apiSuccess {String} engines.engineActualShipDate The ship date 
     * @apiSuccess {String} engines.engineCenterId The EC Id 
     * @apiSuccess {String} engines.engineCenterName The EC name 
     * @apiSuccess {String} engines.engineModel The engine model Id 
     * @apiSuccess {String} engines.engineOperator The customer name 
     * @apiSuccess {String} engines.engineSN The engine serial number 
     * @apiSuccess {String} engines.engineTypeId The engine type Id 
     * @apiSuccess {String} engines.notifyNumber The notify number 
     * @apiSuccess {String} engines.salesOrderNum The sales order number 
     * @apiSuccess {Number} engines.engineIdSeq The dome_engine table sequence Id 
     * @apiSuccess {Number} engines.slotId The slot Id 
     * @apiUse MatchedUnmatchedSuccessResponse
     * @apiUse Error
     */
	@PostMapping(path = {"/unmatches"},  produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineData> updateUnmatchedData(
			@Valid
			@RequestBody
			final EngineData request) {
		return ResponseEntity.ok(matchService.setUnmatched(request));
	}

	/**
     * @api {post} /v1/engine/data/matches Sets unmatched data to matched
     * @apiExample {curl} Example usage:
     *       curl --request POST
     *            --url http://localhost:8080/v1/engine/data/matches
     *            --header 'authorization: Bearer [jwt]'
     *            --header 'content-type: application/json'
     *            --data '{}'
     * @apiName updateMatchedData
     * @apiGroup Engine Data Match
     * @apiParam {engineData} an Engine
     * @apiDescription Sets unmatched data to matched
     * @apiSuccess  {EngineData} unmatched engine
     * @apiSuccess {String} engines.engineActualInductDate The induction date
     * @apiSuccess {String} engines.engineActualReceiveDate The receive date 
     * @apiSuccess {String} engines.engineActualShipDate The ship date 
     * @apiSuccess {String} engines.engineCenterId The EC Id 
     * @apiSuccess {String} engines.engineCenterName The EC name 
     * @apiSuccess {String} engines.engineModel The engine model Id 
     * @apiSuccess {String} engines.engineOperator The customer name 
     * @apiSuccess {String} engines.engineSN The engine serial number 
     * @apiSuccess {String} engines.engineTypeId The engine type Id 
     * @apiSuccess {String} engines.notifyNumber The notify number 
     * @apiSuccess {String} engines.salesOrderNum The sales order number 
     * @apiSuccess {Number} engines.engineIdSeq The dome_engine table sequence Id 
     * @apiSuccess {Number} engines.slotId The slot Id 
     * @apiUse MatchedUnmatchedSuccessResponse
     * @apiUse Error
     */
	@PostMapping(path = {"/matches"})
	public ResponseEntity<EngineData> updateMatchedData(
			@Valid
			@RequestBody
	        @Parameter(description = "Engine Data",
            required = true,
            schema = @Schema(implementation = EngineData.class))
			final EngineData request) {
		return ResponseEntity.ok(matchService.setMatched(request));
	}
	
	/**
     * @api {post} /v1/engine/data/matches/:engId/:salesOrderNo/:notificatonNo Sets unmatched data to matched
     * @apiExample {curl} Example usage:
     *       curl --request POST
     *            --url http://localhost:8080/v1/engine/data/matches/:engId/:salesOrderNo/:notificationNo
     *            --header 'authorization: Bearer [jwt]'
     *            --header 'content-type: application/json'
     *            --data '{}'
     * @apiName updateMatchedEngineData
     * @apiGroup Engine Data Match
     * @apiParam {Object[]} engines An engine array
     * @apiDescription Sets unmatched data to matched
     * @apiSuccess {Object[]} engines A engine array 
     * @apiSuccess {String} engines.engineActualInductDate The induction date
     * @apiSuccess {String} engines.engineActualReceiveDate The receive date 
     * @apiSuccess {String} engines.engineActualShipDate The ship date 
     * @apiSuccess {String} engines.engineCenterId The EC Id 
     * @apiSuccess {String} engines.engineCenterName The EC name 
     * @apiSuccess {String} engines.engineModel The engine model Id 
     * @apiSuccess {String} engines.engineOperator The customer name 
     * @apiSuccess {String} engines.engineSN The engine serial number 
     * @apiSuccess {String} engines.engineTypeId The engine type Id 
     * @apiSuccess {String} engines.notifyNumber The notify number 
     * @apiSuccess {String} engines.salesOrderNum The sales order number 
     * @apiSuccess {Number} engines.engineIdSeq The dome_engine table sequence Id 
     * @apiSuccess {Number} engines.slotId The slot Id 
     * @apiUse MatchedUnmatchedSuccessResponse
     * @apiUse Error
     */
	@PostMapping(path = {"/matches/{engine-id}/{salesorder-no}/{notification-no}"})
	
	public ResponseEntity<Integer> updateMatchedEngineData(
			@PathVariable(name = "engine-id", required = true)
			final int  engId,			
			@PathVariable(name = "salesorder-no", required = true)
			final String salesOrderNo,
			@PathVariable(name = "notification-no", required = true)
			final String notificationNo) {
		Integer engineId = (matchService.setMatchedEngine(engId, salesOrderNo, notificationNo));
		 return ResponseEntity.ok(engineId);
		
	}
	
	/**
     * @api {post} /v1/engine/data/unmatches/{engine-id} Sets matched data to unmatched
     * @apiExample {curl} Example usage:
     *       curl --request POST
     *            --url http://localhost:8080/v1/engine/data/unmatches/{engine-id}
     *            --header 'authorization: Bearer [jwt]'
     *            --header 'content-type: application/json'
     *            --data '{}'
     * @apiName updateUnmatchedData
     * @apiGroup Engine Data Match
     * @apiParam {Object[]} engines An engine array
     * @apiDescription Sets umatched data to unmatched
     * @apiSuccess {Object[]} engines A engine array
     * @apiSuccess {String} engines.engineActualInductDate The induction date
     * @apiSuccess {String} engines.engineActualReceiveDate The receive date 
     * @apiSuccess {String} engines.engineActualShipDate The ship date 
     * @apiSuccess {String} engines.engineCenterId The EC Id 
     * @apiSuccess {String} engines.engineCenterName The EC name 
     * @apiSuccess {String} engines.engineModel The engine model Id 
     * @apiSuccess {String} engines.engineOperator The customer name 
     * @apiSuccess {String} engines.engineSN The engine serial number 
     * @apiSuccess {String} engines.engineTypeId The engine type Id 
     * @apiSuccess {String} engines.notifyNumber The notify number 
     * @apiSuccess {String} engines.salesOrderNum The sales order number 
     * @apiSuccess {Number} engines.engineIdSeq The dome_engine table sequence Id 
     * @apiSuccess {Number} engines.slotId The slot Id 
     * @apiUse MatchedUnmatchedSuccessResponse
     * @apiUse Error
     */
	@PostMapping(path = {"/unmatches/{engine-id}"})
	public ResponseEntity<Integer> updateUnmatchedEngineData(
			@PathVariable(name = "engine-id", required = true)
			final int  engId) {
		Integer engineId = (matchService.setUmatchedEngine(engId));
		 return ResponseEntity.ok(engineId);

	}
	
	
	/**
     * @api {get} /v1/engine/data/matches
     * @apiExample {curl} Example usage: 
     *      curl -X GET -H "Authorization: Bearer [jwt]" 
     *           http://localhost:8080/v1/engine/data/matches
     * @apiName getMatchedData
     * @apiGroup Engine Data Match
     * @apiParam {String} engine-center The engine center Id
     * @apiParam {String} engine-type The engine type Id
     * @apiParam {String} engine-sn The engine serial number
     * @apiDescription Returns all matched data
     * @apiSuccess {Object[]} engines A engine array 
     * @apiSuccess {String} engines.engineActualInductDate The induction date
     * @apiSuccess {String} engines.engineActualReceiveDate The receive date 
     * @apiSuccess {String} engines.engineActualShipDate The ship date 
     * @apiSuccess {String} engines.engineCenterId The EC Id 
     * @apiSuccess {String} engines.engineCenterName The EC name 
     * @apiSuccess {String} engines.engineModel The engine model Id 
     * @apiSuccess {String} engines.engineOperator The customer name 
     * @apiSuccess {String} engines.engineSN The engine serial number 
     * @apiSuccess {String} engines.engineTypeId The engine type Id 
     * @apiSuccess {String} engines.notifyNumber The notify number 
     * @apiSuccess {String} engines.salesOrderNum The sales order number 
     * @apiSuccess {Number} engines.engineIdSeq The dome_engine table sequence Id 
     * @apiSuccess {Number} engines.slotId The slot Id 
     * @apiUse MatchedUnmatchedSuccessResponse
     * @apiUse Error
     */
	@GetMapping(path = {"/matches"},  produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineDataResponse> getMatchedEngineData() {
		return ResponseEntity.ok(matchService.getMatchedEngineData());
	}
	
	/**
     * @api {get} /v1/engine/data/unmatches/:engineCenter/:engineType or /v1/engine/data/matches/:engineSN Get unmatched data
     * @apiExample {curl} Example usage: 
     *      curl -X GET -H "Authorization: Bearer [jwt]" 
     *           http://localhost:8080/v1/engine/data/unmatches/:engineCenter/:engineType
     * @apiName getUnmatchedData
     * @apiGroup Engine Data Match
     * @apiParam {String} engine-center The engine center Id
     * @apiParam {String} engine-type The engine type Id
     * @apiParam {String} engine-sn The engine serial number
     * @apiDescription Returns all unmatched data
     * @apiSuccess {Object[]} engines A engine array 
     * @apiSuccess {String} engines.engineActualInductDate The induction date
     * @apiSuccess {String} engines.engineActualReceiveDate The receive date 
     * @apiSuccess {String} engines.engineActualShipDate The ship date 
     * @apiSuccess {String} engines.engineCenterId The EC Id 
     * @apiSuccess {String} engines.engineCenterName The EC name 
     * @apiSuccess {String} engines.engineModel The engine model Id 
     * @apiSuccess {String} engines.engineOperator The customer name 
     * @apiSuccess {String} engines.engineSN The engine serial number 
     * @apiSuccess {String} engines.engineTypeId The engine type Id 
     * @apiSuccess {String} engines.notifyNumber The notify number 
     * @apiSuccess {String} engines.salesOrderNum The sales order number 
     * @apiSuccess {Number} engines.engineIdSeq The dome_engine table sequence Id 
     * @apiSuccess {Number} engines.slotId The slot Id 
     * @apiUse MatchedUnmatchedSuccessResponse
     * @apiUse Error
     */
	@GetMapping(path = {"/unmatches"},  produces = APPLICATION_JSON_VALUE)
	public ResponseEntity<EngineDataResponse> getUnmatchedEngineData(
			) {
		return ResponseEntity.ok(matchService.getUnmatchedEngineData());
	}

	



}
