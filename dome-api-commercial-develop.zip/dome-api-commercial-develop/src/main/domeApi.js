    /**
     * @apiDefine 200Generic
     * @apiSuccessExample  {json} Success-Response:
     *      HTTP/1.1 200 OK
     *           {
     *             "code": 0,
     *             "message": "Success"
     *           }
     **/


    /**
     * @apiDefine Error
     * @apiError {String} [errorCode] Error code. If present will contain either the error message string code (see XXXXXX) or the string representation of the HTTP code.
     * @apiError {Array} [errors] An array of strings containing specific error messages.
     **/
    
    /**
     * @apiDefine Error400
     * @apiErrorExample  {json} Sample 400 Response:
     *      HTTP/1.1 400 Bad Request
     *          {
     *               "errorCode": "400",
     *               "errors": [
     *                  "No valid user profile was specified. Unable to generate calendar."
     *               ]
     *          }
     */

    /**
     * @apiDefine Error404
     * @apiErrorExample  {json} Sample 404 Response:
     *      HTTP/1.1 404 Bad Request
     *          {
     *               "errorCode": "404",
     *               "errors": [
     *                  "Slot ID [12345] was not found. Unable to perform update."
     *               ]
     *          }
     */

    /**
     * @apiDefine Error409
     * @apiErrorExample  {json} Sample 409 Response:
     *      HTTP/1.1 409 Conflict
     *          {
     *               "errorCode": "409",
     *               "errors": [
     *                  "A slot already exists for EngineCenter [EC41] Day [13] Month [7] Year [2019] EngineType [ET719] SlotType [2]"
     *               ]
     *          }
     */

	/**
     * @apiDefine Error500
     * @apiErrorExample  {json} Sample 500 Response:
     *      HTTP/1.1 500 Internal Server Error
     *          {
     *               "errorCode": "500",
     *               "errors": [
     *                  "could not extract ResultSet; SQL [n/a]; nested exception is org.hibernate.exception.SQLGrammarException: could not extract ResultSet"
     *               ]
     *          }
     */
    
    /**
     * @apiDefine Error401
     * @apiErrorExample  {json} Sample 401 Response:
     *      HTTP/1.1 401 Unauthorized
     *          {
     *               "errorCode": "invalid_request",
     *               "errors": [
     *                  "JWT has expired."
     *               ]
     *          }
     **/
     
    /**
     * @apiDefine Error403
     * @apiErrorExample  {json} Sample 403 Response:
     *      HTTP/1.1 403 Forbidden
     *          {
     *               "errorCode": "403",
     *               "errors": [
     *                  "User does not have access to Engine Center XXXXXX."
     *               ]
     *          }
     **/

    /**
     * @apiDefine CalendarSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *         {
     *              "calYYMM": "201907",
     *              "year": 2019,
     *              "month": 7,
     *              "engineCenterID": "EC41",
     *              "engineCenterName": "MTU Hannover",
     *              "days": [
     *                {
     *                  "validDate": false,
     *                  "boxNumber": 0,
     *                  "day": 0,
     *                  "shopVisitsByEngineType": null
     *                },
     *                {
     *                  "validDate": true,
     *                  "boxNumber": 1,
     *                  "day": 1,
     *                  "shopVisitsByEngineType": null
     *                },
     *                {
     *                  "validDate": true,
     *                  "boxNumber": 13,
     *                  "day": 13,
     *                  "shopVisitsByEngineType": [
     *                      {
     *                           "slotID": 12345,
     *                           "shopVisitType": 2,
     *                           "subShopVisitType": "3P",
     *                           "engineTypeID": "ET719",
     *                           "engineTypeName": null,
     *                           "engines": [
     *                             {
     *                                 "engineID": 100273179,
     *                                 "engineGroupID": "EG754",
     *                                 "engineModelID": "EM1006",
     *                                 "esn": "770494",
     *                                 "moduleID": null,
     *                                 "moduleName": null,
     *                                 "customerID": "3165",
     *                                 "customerShortName": "AAL",
     *                                 "customerName": "China West Air",
     *                                 "manualEngine": false
     *                             }
     *                           ]
     *                      }
     *             ]
     *           }
     *
     *         ]
     *       }	
	 **/

    /**
     * @apiDefine UserProfileSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *        "emailAddress": "john.delello@pw.utc.com",
     *        "firstName": "John",
     *        "lastName": "De Lello",
     *        "defaultEngineCenterID": "EC41",
     *        "defaultEngineTypeID": "ET719",
     *        "defaultLoadPage": "Calendar",
     *        "securityRole": "ReadWrite",
     *        "rcm": true,
     *        "netManagement": false
     *        "userEngineCenters": [
     *            {
     *                "engineCenterID": "EC1",
     *                "engineCenterName": "Columbus",
     *                "engineGroups": [
     *                    {
     *                        "engineTypeID": "ET718",
     *                        "engineTypeName": "PW1000",
     *                        "engineGroupID": "EG1374",
     *                        "engineGroupName": "PW1500G"
     *                    }
     *                ]
     *            }
     *        ]
     *     }
	 **/

    /**
     * @apiDefine CalendarCreateSlotSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *        "slotID": 12345,
     *        "engineCenterID": "EC41",
     *        "day": 13,
     *        "month": 7,
     *        "year": 2019,
     *        "engineTypeID": "ET718",
     *        "engineTypeName": "PW1000",
     *        "shopVisitType": 2,
     *        "subShopVisitType": "3P"
     *     }
	 **/

    /**
     * @apiDefine GetAvailableEnginesSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     * {
     *     "engines": [
     *       [
     *           {
     *             "assetID": 587,
     *             "engineAssetID": 11301,
     *             "esn": "V20064",
     *             "removalDate": "06/04/2019",
     *             "status": "Removed",
     *             "thrust": "68k",
     *             "visitType": 3,
     *             "engineModelID": "EM103",
     *             "engineModelName": "PW4168A",
     *             "engineTypeID": "ET662",
     *             "engineTypename": "PW4000-100"
     *             "engineGroupID": "EG228",
     *             "engineGroupName": "PW4000-100"
     *             "operatorID": "10524",
     *             "operatorName": "Eurowings Europe GmbH",
     *             "customerShortName": "EWE"
     *           }
     *         ]
     *       
     **/

    /**
     * @apiDefine InductionPlanningCalendarSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *         {
     *              "calendarName": "Induction Planning Calendar",
     *              "calYYMM": "201907",
     *              "year": 2019,
     *              "month": 7,
     *              "engineTypeID": "ET720",
     *              "engineTypeName": "V2500",
     *              "days": [
     *                {
     *                  "validDate": false,
     *                  "boxNumber": 0,
     *                  "day": 0,
     *                  "shopVisitsSummary": null
     *                },
     *                {
     *                  "validDate": true,
     *                  "boxNumber": 1,
     *                  "day": 1,
     *                  "shopVisitsSummary": null
     *                },
     *                {
     *                  "validDate": true,
     *                  "boxNumber": 13,
     *                  "day": 13,
     *                  "shopVisitsSummary": [
     *                      {
     *                         "slotID": 12345,
     *                         "engineCenterID": "EC1",
     *                         "engineCenterCode": "EGG",
     *                         "engineCenterName": "Columbus",
     *                         "shopVisitType": 2,
     *                         "engines": [
     *                           {
     *                             "engineID": 85644,
     *                             "esn": "V123456"
     *                           }
     *                           {
     *                             "engineID": 88547,
     *                             "esn": "XXXXXX"
     *                           }
     *                         ]
     *                      },
     *                      {
     *                         "slotID": 28001,
     *                         "engineCenterID": "EC3",
     *                         "engineCenterCode": "CHS",
     *                         "engineCenterName": "Cheshire",
     *                         "shopVisitType": 2,
     *                         "engines": [
     *                           {
     *                             "engineID": 95647,
     *                             "esn": "V123456"
     *                           }
     *                           {
     *                             "engineID": 123456,
     *                             "esn": "V48543"
     *                           }
     *                         ]
     *                      }
     *                  ]
     *                }
     *
     *           ]
     *       }	
	 **/

    /**
     * @apiDefine AddToSlotSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *        "slotID": 12345,
     *        "shopVisitType": 2,
     *        "subShopVisitType": "3P",
     *        "engineTypeID": "ET719",
     *        "engineTypeName": null,
     *        "engines": [
     *          {
     *              "engineID": 100273179,
     *              "esn": "770494",
     *              "engineGroupID": "EG1234",
     *              "engineModelID": "EM1234",
     *              "engineModuleID": null,
     *              "engineModuleName": null,	
     *              "customerID": "3165",
     *              "customerShortName": "CWA",
     *              "customerName": "China West Air",
     *              "manualEngine": false,
     *              "category": "L",
     *              "salesOrderttype": "FMP"
     *          }
     *         ]
     *     }
	 **/
 
    /**
     * @apiDefine GetCustomersSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *       "customers": [
     *         {
     *           "customerID": "3184",
     *           "name": "orange2fly Airlines S.A.",
     *           "shortName": "OTF",
     *           "region": null
     *         },
     *         {
     *           "customerID": "2953",
     *           "name": "flyLAL Charters",
     *           "shortName": "LIL",
     *           "region": "Europe, Africa, Middle East"
     *         }          
     *     }
	 **/

    /**
     * @apiDefine GetSlotSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *        "slotID": 12345,
     *        "engineCenterID": "EC41",
     *        "day": 13,
     *        "month": 7,
     *        "year": 2019,
     *        "engineTypeID": "ET718",
     *        "engineTypeName": "PW1000",
     *        "shopVisitType": 2,
     *        "subShopVisitType": "3P"
     *        "engines": [
     *          {
     *              "engineID": 100273179,
     *               "esn": "770494",
     *               "customerID": "3165",
     *               "customerName": "China West Air"
     *          }
     *        ]
     *     }
	 **/

    /**
     * @apiDefine GetEngineGroupsSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *       "engineGroups": [
     *         {
     *           "engineGroupID": "EG231",
     *           "engineTypeID": "ET720",
     *           "name": "V2500"
     *         },
     *         {
     *           "engineGroupID": "EG874",
     *           "engineTypeID": "ET720",
     *           "name": "V2500-A1"
     *         },
     *       ]
     *     }
	 **/

    /**
     * @apiDefine GetEngineModelsSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *       "engineModels": [
     *         {
     *           "engineModelID": "EM45",
     *           "engineGroupID": "EG1",
     *           "name": "JT8D-1"
     *         },
     *         {
     *           "engineModelID": "EM965",
     *           "engineGroupID": "EG1",
     *           "name": "JT8D-11"
     *         },
     *       ]
     *     }
	 **/

    /**
     * @apiDefine GetEngineTypesSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *       "engineTypes": [
     *         {
     *           "engineTypeID": "ET720",
     *           "name": "V2500",
     *           "edata": true
     *         },
     *         {
     *           "engineTypeID": "ET736",
     *           "name": "PW1900G"
     *           "edata": false
     *         },
     *       ]
     *     }
	 **/

    /**
     * @apiDefine GetEnginePhasesSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *       "enginePhases": [
     *         {
     *           "enginePhaseID": 1,
     *           "name": "Induction Process"
     *         },
     *         {
     *           "enginePhaseID": 2,
     *           "name": "Allocated Awaiting Final Paperwork"
     *         },
     *       ]
     *     }
	 **/

    /**
     * @apiDefine GetEngineTypeDetailSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *         {
     *           "engineTypeID": "ET720",
     *           "name": "V2500",
     *           "edata": true
     *         }
	 **/


    /**
     * @apiDefine GetRemovedEnginesSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     * {
     *     "engines": [
     *       [
     *           {
     *             "removedEnginesID": 11301,
     *             "removedEventID": 32423,
     *             "removalDate": "09/24/2019",
     *             "assetID": 587,
     *             "esn": "V20064",
     *             "thrust": "68k",
     *             "operatorID": "1655",
     *             "operatorName": "Eurowings Europe GmbH",
     *             "operatorShortName": "EWE",
     *             "engineModelID": "EM95",
     *             "engineModelName": "PW4158",
     *             "preliminaryInductionDate": null
     *           }
     *         ]
     *       
     **/

    /**
     * @apiDefine GetEnginesRemovedDetailSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *         {
     *            "engineAssetID": 6619,
     *            "assetID": 281714,
     *            "odinID": 99726,
     *            "esn": "V10621",
     *            "operatorID": "1656",
     *            "operatorName": "US Airways",
     *            "operatorShortName": "USA",
     *            "thrust": "24K",
     *            "engineModelID": "EM2236",
     *            "engineModelName": "V2524-S2",
     *            "tsn": 58560,
     *            "csn": 25387,
     *            "tso": 24980,
     *            "cso": 12680,
     *            "llpCycRemain": 7321,
     *            "removalReason": "EGT Over AMM Limit Above Idle",
     *            "removalDateActual": "07/27/2019",
     *            "removalDateRecorded": "07/26/2019",
     *            "speidPO": null,
     *            "rslPO": null,
     *            "aimAllocationDate": "07/31/2019",
     *            "wsInitiationDate": "08/06/2019",
     *            "wsDraftCompleteEngDate": "08/08/2019",
     *            "wsDraftCompleteAccyDate": "08/09/2019",
     *            "customerApprovalDate": "08/09/2019",
     *            "wsOrigReleaseDate": "08/09/2019",
     *            "scheduledInductionDate": null,
     *            "llpDeliveryDate": "08/06/2019",
     *            "accyDeliveryDate": "08/09/2019",
     *            "nisDeliveryDate": "08/06/2019",
     *            "comments": "(6/30) Potential option for MTU-C; pending FM input.\n(6/31) Customer opted against MTU-C; (T) RRIN",
     *            "currentLocation": "08/13/2019",
     *            "ebuShop": null,
     *            "maintenanceCenter": "RR Inchinnan",
     *            "svClassification": "HSR-Med",
     *            "llpReplacementType": "Stub Life",
     *            "upgradeEligibility": "None",
     *            "contractRemoval": "N",
     *            "investigationEngine": "N",
     *            "fhaEligible": "N"
     *            "comments": "this is my comment",
     *            "ebuShop": null,
     *            "currentLocation": null,
     *            "fanBladeMapDate": "9/16/2019",
     *            "adListDate": "9/19/2019",
     *            "powerEngineer": "10/01/2019",
     *            "projRecEbu": "10/01/2019",
     *            "actualRecEbu": "10/05/2019"                 
     *          }
     *       
     **/


    /**
     * @apiDefine GetEngineContractDetailSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *         {
     *           "esn": "V12008",
     *           "description": "BAW_FHA_2015",
     *           "subFleet": "BAW - 2015 Fleet 1",
     *           "years": "16 Years",
     *           "svs": "N/A",
     *           "endDate": "12/31/2033",
     *           "leaseReturnDate": null,
     *           "refurbPayStructure": "1",
     *           "llpCoverage": "No",
     *           "s1RetrofitCoverage": "No",
     *           "leaseReturnCoverage": "No",
     *           "accessoryCoverage": "Yes",
     *           "shippingCoverage": "Yes"
     *         }
     *         
     **/

/**
     * @apiDefine SaveOdinDetailsSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *         {
     *            "odinID": 4050,
     *            "eventID": 10003016,
     *            "esn": "735060",
     *            "engineID": 12345,
     *            "maintenanceCenter": "KAL",
     *            "svClassification": "Misc.",
     *            "llpReplacementType": "Expiry",
     *            "upgradeEligibility": "None",
     *            "speidPO": "TAM-FMP-735060-1508",
     *            "rslPO": "XXM-FMP-735060-1508",
     *            "aimAllocationDate": "09/16/2015",
     *            "llpDeliveryDate": "09/16/2015",
     *            "accyDeliveryDate": "09/16/2015",
     *            "nisDeliveryDate": "09/16/2015",
     *            "wsInitiationDate": "09/15/2015",
     *            "wsDraftCompleteEngDate": "09/16/2015",
     *            "wsDraftCompleteAccyDate": "09/16/2015",
     *            "customerApprovalDate": "09/17/2015",
     *            "wsOrigReleaseDate": "09/17/2015",
     *            "scheduledInductionDate": "09/22/2015",
     *            "contractRemoval": "N",
     *            "investigationEngine": "N",
     *            "fhaEligible": "N",
     *            "comments": "Tenative date from email",
     *            "ebuShop": "CEC",
     *            "currentLocation": "09/22/2015",
     *            "fanBladeMapDate": "9/16/2019",
     *            "adListDate": "9/19/2019",
     *            "powerEngineer": "10/01/2019",
     *            "projRecEbu": "10/01/2019",
     *            "actualRecEbu": "10/05/2019"       
     *         }      
     **/

    /**
     * @apiDefine GetModulesListSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *         {
     *           "modules": [
     *             {
     *               "moduleID": 1,
     *               "moduleName": "HPC"
     *             },
     *             {
     *               "moduleID": 2,
     *               "moduleName": "LPC"
     *             }
     *           ]
     *         }
	 **/

    /**
     * @apiDefine SmiRevisionsSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *         {
     *           "smiRevisions": [
     *             {
     *               "engId": 100273697,
     *               "engineSN": "V15119",
     *               "engineRevisions": [
     *                 {
     *                   "smiId": 200,
     *                   "smiRev": "1",
     *                   "smiRevDate": "08/10/2019",
     *                   "smiDesc": "Our first SMI Rev",
     *                   "moduleGroups": [
     *                     {
     *                       "mgbID": 144,
     *                       "mgb": "ENGINE",
     *                       "mgbValue": "Rev=1, ID=144"
     *                     },
     *                     {
     *                       "mgbID": 145,
     *                       "mgb": "LPC",
     *                       "mgbValue": null
     *                     }
     *                   ]
     *                 }
     *               ]
     *             }
     *           ]
     *         }
	 **/

    /**
     * @apiDefine MatchedUnmatchedSuccessResponse
     * @apiSuccessExample  {json} Sample Success-Response:
     *     HTTP/1.1 200 OK
     *         {
     *           "engines": [
     *             {
     *               "engineActualInductDate": "12/21/2121",
     *               "engineActualReceiveDate": "12/21/2121",
     *               "engineActualShipDate": "12/21/2121",
     *               "engineCenterId": "EC182",
     *               "engineCenterName": "Turkey",
     *               "engineModelId": "EM925",
     *               "engineOperator": "INTERNATIONAL AERO ENGINES AG",
     *               "engineSN": "V15602",
     *               "engineTypeId": "ET720",
     *               "notifyNumber": "000417019865",
     *               "salesOrderNum": "EV15602-01",
     *               "engineIdSeq": 100272497,
     *               "slotId": 8327
     *             }
     *           ]
     *         }
     **/
