package com.pw.dome.engine;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;

import com.pw.dome.user.UserProfile;
import com.pw.dome.util.SecurityUtils;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class EngineRepositoryAdviseTest {

	@Autowired
	private EngineRepositoryBeforeMethodsAdvise advise;

	@Autowired
	private EngineRepository repo;

	private static MockedStatic<SecurityUtils> utils;
	
	@BeforeAll
	public static void init() {
		UserProfile userProfile = Mockito.mock(UserProfile.class);
		userProfile.setUserRCM(false);
		
		utils = Mockito.mockStatic(SecurityUtils.class);
		
		utils.when(SecurityUtils::getUserProfile).thenReturn(userProfile);
		// TODO move to properties file as this will change
		utils.when(SecurityUtils::getUserEmailAddress).thenReturn("chuck.marco@prattwhitney.com");
	}

	/**
	 * JPA would reject null engine deletion before this advise.
	 */
	@Test
	public void testDeleteNullEngine() {
		advise.delete((EngineEntity)null);
	}

	@Test
	public void testDeleteEngine() {
		List<Integer> ids = repo.getAllIds();
		assertThat(ids).isNotEmpty();
		EngineEntity entity = repo.findById(ids.get(0)).orElse(null);
		assertThat(entity).isNotNull();
		advise.delete(entity);
	}
}
