package com.pw.dome.user;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.dao.DataIntegrityViolationException;

import com.pw.dome.util.SecurityUtils;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class UserRepositoryTest {

	@Autowired
	private UserRepository repo;
	
	private static MockedStatic<SecurityUtils> utils;
	
	@BeforeAll
	public static void init() {
		UserProfile userProfile = Mockito.mock(UserProfile.class);
		userProfile.setUserRCM(false);
		
		utils = Mockito.mockStatic(SecurityUtils.class);
		
		utils.when(SecurityUtils::getUserProfile).thenReturn(userProfile);
		utils.when(SecurityUtils::getUserEmailAddress).thenReturn("chuck.marco@prattwhitney.com");
	}

	/**
	 * JPA would save user profile with emailAddress in lower case.
	 */
	@Test
	public void testUserCreationSaveLowerCase() {
		UserProfile user = getUserProfile();
	    repo.saveAndFlush(user);
	    Optional<UserProfile> savedUser = repo.findByEmailAddressIgnoreCase(user.getEmailAddress());
	    assertThat(savedUser.isPresent()).isTrue();
	    
	    //assert that the user profile is saved with lower case.
	    assertThat(savedUser.get().getEmailAddress()).isEqualTo(user.getEmailAddress().toLowerCase());
	    repo.delete(savedUser.get());
	}
	
	/**
	 * JPA would save user profile with emailAddress in lower case and stops creating duplicate record.
	 */
	@Test
	public void testDuplicateRecordNotCreated() {
		UserProfile user = getUserProfile();
		repo.saveAndFlush(user);
	    
		assertThrows(DataIntegrityViolationException.class, () -> {
			 UserProfile duplcateUser = getDuplicateUserProfile();
			 repo.saveAndFlush(duplcateUser);
		}, "DataIntegrityViolationException was expected");
	    
		Optional<UserProfile> savedUser = repo.findByEmailAddressIgnoreCase(user.getEmailAddress());
	    assertThat(savedUser.isPresent()).isTrue();
	    //assert that the user profile is saved with lower case.
	    assertThat(savedUser.get().getEmailAddress()).isEqualTo(user.getEmailAddress().toLowerCase());
	    repo.delete(savedUser.get());
	}
	
	private UserProfile getUserProfile() {
		return UserProfile.builder()
		.emailAddress("vinayTest@GMAIL.com")
		.defaultEngineCenterID(null)
		.defaultEngineTypeID(null)
		.defaultLoadPage(null)
		.firstName("vinay")
		.lastName("valupadasu")
		.roleId("ReadWrite")
		.status(null)
		.updateUser(null)
		.updateDate(null)
	    .justification(null)
	    .comments(null)
		.userNetManagement(false)
		.userRCM(true)
		.build();
	}
	
	private UserProfile getDuplicateUserProfile() {
		return UserProfile.builder()
		.emailAddress("VINAYTEST@gmail.com")
		.defaultEngineCenterID(null)
		.defaultEngineTypeID(null)
		.defaultLoadPage(null)
		.firstName("vinay")
		.lastName("valupadasu")
		.roleId("ReadWrite")
		.status(null)
		.updateUser(null)
		.updateDate(null)
	    .justification(null)
	    .comments(null)
		.userNetManagement(false)
		.userRCM(true)
		.build();
	}
}
