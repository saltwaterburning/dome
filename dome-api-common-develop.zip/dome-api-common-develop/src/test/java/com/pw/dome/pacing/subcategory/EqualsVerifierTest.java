package com.pw.dome.pacing.subcategory;

import org.junit.jupiter.api.Test;

import nl.jqno.equalsverifier.EqualsVerifier;

class EqualsVerifierTest {

	@Test
	void testEqualsAndHashCodeMethods() {
		EqualsVerifier.forClass(PacingSubcategoryEntityPK.class).verify();
	}
}
