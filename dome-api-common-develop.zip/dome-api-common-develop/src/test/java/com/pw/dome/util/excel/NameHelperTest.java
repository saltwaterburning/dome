package com.pw.dome.util.excel;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;

import org.apache.poi.ss.usermodel.Name;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.Test;

class NameHelperTest {

	@Test
	void testEncodingAndDecoding() throws IOException {
		String badName = "abc!@#$%^&*()_+={}[]\\<>?,./|xyz";

		Workbook poiWorkbook = WorkbookFactory.create(true);
		Name namedRange = poiWorkbook.createName();

		assertThrows(IllegalArgumentException.class, () -> {
			namedRange.setNameName(badName);
		}, "Expected IllegalArgumentException.");

		String goodName = NameHelper.encode(badName);
		namedRange.setNameName(goodName);

	    String badName2 = NameHelper.decode(goodName);

	    assertThat(badName2).isEqualTo(badName);
	}

	@Test
	void testNormalize() throws IOException {
		String badName = "abc!@#$%^&*()_+={}[]\\<>?,./|xyz";

		Workbook poiWorkbook = WorkbookFactory.create(true);
		Name namedRange = poiWorkbook.createName();

		assertThrows(IllegalArgumentException.class, () -> {
			namedRange.setNameName(badName);
		}, "Expected IllegalArgumentException.");

		String goodName = NameHelper.normalize(badName);
		namedRange.setNameName(goodName);
	}
}
