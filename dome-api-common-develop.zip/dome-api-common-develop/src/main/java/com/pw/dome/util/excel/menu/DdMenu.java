package com.pw.dome.util.excel.menu;

import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.Validate;

import com.pw.dome.util.excel.ExcelWorkbook;

import lombok.Builder;

/**
 * Provides drop-down menu details consisting of the menu name (Excel header) and menu item(s). A
 * drop-down menu is also known as drop-down list, drop menu, pull-down list or pick-list.
 * 
 * @see ExcelWorkbook#createDropDownMenus(boolean, java.util.List)
 */
@Builder
public record DdMenu(String name, List<String> items) {
  public DdMenu {
    Validate.notBlank(name);
    Objects.requireNonNull(items);
  }
}
