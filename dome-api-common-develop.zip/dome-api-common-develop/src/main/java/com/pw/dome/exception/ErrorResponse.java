package com.pw.dome.exception;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author John De Lello
 */
@Data
@AllArgsConstructor
@Schema(description = "Application response schema.")
public class ErrorResponse {
	@Schema(description = "The HttpStatus name (e.g., NOT_FOUND).")
//    private final HttpStatus status;
    private String status;
	@Schema(description = "The HttpStatus value  (e.g., 404).")
    private int statusCode;
	@Schema(description = "The HttpStatus Reason Phrase  (e.g., NOT FOUND).")
    private String reason;
	@Schema(description = "Application message.")
    private String message;
	@Schema(description = "Chain of application error messages.")
    private List<String> errors;

	public ErrorResponse() {}

    public ErrorResponse(HttpStatus status, String message) {
        this.status = status.name();
        this.statusCode = status.value();
        this.reason = status.getReasonPhrase();
        this.message = message;
        errors = Arrays.asList(message);
    }

    public ErrorResponse(HttpStatus status, String message, String error) {
        this.status = status.name();
        this.statusCode = status.value();
        this.reason = status.getReasonPhrase();
        this.message = message;
        errors = Arrays.asList(error);
    }

    public ErrorResponse(HttpStatus status, String message, List<String> errors) {
        this.status = status.name();
        this.statusCode = status.value();
        this.reason = status.getReasonPhrase();
        this.message = message;
        this.errors = errors;
    }
}
