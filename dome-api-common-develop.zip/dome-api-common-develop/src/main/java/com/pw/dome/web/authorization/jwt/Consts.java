package com.pw.dome.web.authorization.jwt;

interface Consts {

	// The authentication scheme is case sensitive.
	// See https://datatracker.ietf.org/doc/html/rfc6750#section-2.1
	String BEARER_AUTHENTICATION_SCHEME = "Bearer ";

	String[] EXCLUDED_ENDPOINTS = new String[] { "/v1/auth/jwt" };

	// Base64 encoding of '{' for HEADER section is 'ey'.
	String JWT_HEADER_FIRST_CHARS = "ey";

	// Followed by '.ey' for beginning of PAYLOAD section.
	String JWT_PAYLOAD_FIRST_CHARS = ".ey";

}
