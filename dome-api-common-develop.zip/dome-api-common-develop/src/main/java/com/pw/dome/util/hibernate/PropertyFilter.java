package com.pw.dome.util.hibernate;

public interface PropertyFilter {

    Object filter(String name, Object value);
}
