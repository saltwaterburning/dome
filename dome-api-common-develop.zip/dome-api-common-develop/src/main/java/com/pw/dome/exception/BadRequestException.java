package com.pw.dome.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpStatusCodeException;

/**
 * @author John De Lello
 */
final public class BadRequestException extends HttpStatusCodeException {
	private static final long serialVersionUID = 6259841862148108152L;

	public BadRequestException(String message) {
		super(HttpStatus.BAD_REQUEST, message);
	}
}
