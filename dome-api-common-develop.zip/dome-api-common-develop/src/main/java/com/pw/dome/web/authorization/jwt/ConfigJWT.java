package com.pw.dome.web.authorization.jwt;

import jakarta.validation.constraints.NotNull;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import lombok.Data;

@Configuration
@ConfigurationProperties(prefix = "dome.security")
@Data
@Validated
public class ConfigJWT {
  @NotNull
  private String[] jwtAudience;
  @NotNull
  private Long jwtTokenExpireMinutes;
  @NotNull
  private String jwtTokenSecretKey;
}
