package com.pw.dome.web.authorization.jwt;

import static com.pw.dome.web.authorization.jwt.Consts.BEARER_AUTHENTICATION_SCHEME;
import static com.pw.dome.web.authorization.jwt.Consts.JWT_HEADER_FIRST_CHARS;
import static com.pw.dome.web.authorization.jwt.Consts.JWT_PAYLOAD_FIRST_CHARS;
import static jakarta.ws.rs.core.HttpHeaders.AUTHORIZATION;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collection;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;

import lombok.extern.slf4j.Slf4j;

/**
 * @see <a href="https://github.com/auth0/java-jwt/blob/master/EXAMPLES.md#datetime-claim-validation">JWT Validation</a>
 */
@Component
@Slf4j
public class AuthorizationTokenProvider {
	private final static String ISSUER = "DOME Security";

	@Autowired
	private ConfigJWT securityConfig;
	@Autowired
	private UserDetailsService userDetailsService;

	public String createToken(final String userEmailAddress, final Collection<? extends GrantedAuthority> collection) {
		try {
			String[] audience = securityConfig.getJwtAudience();
			Instant issuedAt = Instant.now();
			Instant expiresAt = issuedAt.plusSeconds(TimeUnit.MINUTES.toSeconds(securityConfig.getJwtTokenExpireMinutes()));
			String[] roles = collection.stream().map(auth -> auth.getAuthority()).toArray(String[]::new);
			String secret = securityConfig.getJwtTokenSecretKey();

			Algorithm secretAlgorithm = Algorithm.HMAC512(secret);

			String token = JWT.create() //
					.withArrayClaim("roles", roles) //
					.withAudience(audience) //
					.withExpiresAt(expiresAt) //
					.withIssuedAt(issuedAt) //
					.withIssuer(ISSUER) //
					.withNotBefore(issuedAt) //
					.withSubject(userEmailAddress) //
					.sign(secretAlgorithm);

			return token;
		} catch (IllegalArgumentException | JWTCreationException ex) {
			throw new JWTVerificationException(ex.getMessage(), ex);
		}
	}

	public Authentication getUserAuthentication(final String jwt) {
		DecodedJWT decodedJWT = decodeAndValidateJWT(jwt);
		String userName = decodedJWT.getSubject();

		// Throws UsernameNotFoundException
		UserDetails userDetails = userDetailsService.loadUserByUsername(userName);

		return new UsernamePasswordAuthenticationToken(userDetails, "", userDetails.getAuthorities());
	}

	public String getBearerToken(HttpServletRequest req) {
		String authHeader = req.getHeader(AUTHORIZATION);
		if (StringUtils.isBlank(authHeader)) {
			throw new JWTVerificationException("The Authorization header isn't set.");
		}
		else if (!authHeader.startsWith(BEARER_AUTHENTICATION_SCHEME)) {
			throw new JWTVerificationException("Authorization header requires Bearer authentication scheme.");
		}

		String jwt = authHeader.substring(7);
		if (StringUtils.isBlank(jwt)) {
			throw new JWTVerificationException("The Bearer JWT is blank.");
		} else if (!jwt.startsWith(JWT_HEADER_FIRST_CHARS)) {
			throw new JWTVerificationException("The JWT header part is invalid.");
		} else if (!jwt.contains(JWT_PAYLOAD_FIRST_CHARS)) {
			throw new JWTVerificationException("The JWT payload part is invalid.");
		}

		return jwt;
	}

	public boolean validateToken(final String jwt) {
		DecodedJWT decodedJWT =  decodeAndValidateJWT(jwt);
		return Objects.nonNull(decodedJWT);
	}

	private DecodedJWT decodeAndValidateJWT(final String jwt) {
		try {
			String secret = securityConfig.getJwtTokenSecretKey();
			Algorithm algorithm = Algorithm.HMAC512(secret);
//			String[] audience = securityConfig.getJwtAudience();

			JWTVerifier verifier = JWT.require(algorithm) //
//					.withAnyOfAudience(audience) //
					.withIssuer(ISSUER) //
					.build();

			DecodedJWT decodedJWT = verifier.verify(jwt);
			return decodedJWT;
		} catch (TokenExpiredException e) {
			log.info("JWT expired at {} Now: {}", e.getMessage(), LocalDateTime.now(ZoneOffset.UTC));
			// The message is used by UI to issue new JWT request.
			throw new JWTVerificationException("JWT Token has expired. Request a new token.");
		} catch (JWTVerificationException ex) {
			throw ex;
		} catch (Exception ex) {
			throw new JWTVerificationException(ex.getMessage(), ex);
		}
	}
}
