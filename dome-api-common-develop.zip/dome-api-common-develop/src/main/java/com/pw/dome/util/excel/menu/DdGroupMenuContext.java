package com.pw.dome.util.excel.menu;

import jakarta.validation.constraints.NotBlank;

import org.apache.commons.lang3.Validate;

import com.pw.dome.util.excel.ExcelWorkbook;

import lombok.Getter;
import lombok.Setter;

/**
 * Provides information obtained upon creation of drop-down menus. Used to create dependent
 * drop-down menus.
 *
 * @see DdGroupMenuReference
 * @see ExcelWorkbook#createDropDownMenus(boolean, java.util.List)
 * @see ExcelWorkbook#createDropDownMenus(boolean, java.util.List...)
 */
public class DdGroupMenuContext {
  @Getter
  @Setter
  private String cellAddress;

  @Getter
  @NotBlank
  private final String groupName;

  @Getter
  @NotBlank
  private final int maxGroupNameLength;

  @Getter
  @NotBlank
  private final int maxItemNameLength;

  @Getter
  @Setter
  private String sheetname;

  /**
   * The {@code groupName} is a unique name created by combining the {@link DdMenu#name()}s.
   * 
   * @param groupName a unique name created by combining the {@link DdMenu#name()}s
   */
  public DdGroupMenuContext(String groupName, int maxGroupNameLength, int maxItemNameLength) {
    Validate.notBlank(this.groupName = groupName);
    this.maxGroupNameLength = maxGroupNameLength;
    this.maxItemNameLength = maxItemNameLength;
  }
}
