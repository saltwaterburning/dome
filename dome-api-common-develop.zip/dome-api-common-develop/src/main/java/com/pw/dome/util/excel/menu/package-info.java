/*
 * Provides support for drop-down lists (DDL).
 */
package com.pw.dome.util.excel.menu;