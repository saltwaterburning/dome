package com.pw.dome.web.requestlogging;

import jakarta.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RestRequestLogCleanupTask {
	@Autowired
	private ConfigRequestLogging config;
	@Autowired
	private RequestLoggingService requestLoggingService;
	
	@Scheduled(cron="${dome.request-logging.restRequestLogCleanupTaskCron}")
	public void doRestRequestLogCleanup() {
		log.debug("******* Starting REST Request log table cleanup.");
		requestLoggingService.doRestRequestLogCleanup();
	}
	
	@PostConstruct
	void init() {
		String cronSchedule = config.getRestRequestLogCleanupTaskCron();
		log.debug("Cron: [{}]",  cronSchedule);
	}
}
