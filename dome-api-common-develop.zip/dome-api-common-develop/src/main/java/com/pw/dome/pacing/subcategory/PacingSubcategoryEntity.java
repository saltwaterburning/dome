package com.pw.dome.pacing.subcategory;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import org.hibernate.annotations.Immutable;

import com.pw.dome.jpa.AbstractEntityWithEmbeddedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_PACING_SUBCATEGORY")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Immutable
class PacingSubcategoryEntity extends AbstractEntityWithEmbeddedId<PacingSubcategoryEntityPK> {
	@EmbeddedId
	private PacingSubcategoryEntityPK id;

	@Column(name="FIELD_SEQ")
	private Integer fieldSeq;

	@Override
	public PacingSubcategoryEntityPK getId() {
		return id;
	}
}