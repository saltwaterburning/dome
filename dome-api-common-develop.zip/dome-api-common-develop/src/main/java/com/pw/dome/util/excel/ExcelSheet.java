package com.pw.dome.util.excel;

import java.util.stream.IntStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;

/**
 * Simple Excel Spreadsheet fluent wrapper leveraging Apache POI. This wrapper is instantiated by
 * {@link ExcelWorkbook}.
 * 
 * @See ExcelWorkbook
 */
public final class ExcelSheet extends AbstractExcelSheet {

  /**
   * Constructor.
   * 
   * @param workbook
   * @param sheet
   */
  ExcelSheet(ExcelWorkbook workbook, XSSFSheet sheet) {
    this(workbook, sheet, new CellStyle());
  }

  /**
   * Constructor with default cell style.
   * 
   * @param workbook
   * @param sheet
   * @param cellStyle default style to be applied to all {@link CellValues}
   */
  ExcelSheet(ExcelWorkbook workbook, XSSFSheet sheet, CellStyle cellStyle) {
    super(workbook, sheet, cellStyle);
  }

  /**
   * Apply auto sizing.
   * 
   * @return this
   */
  public ExcelSheet withAutoSizedColumns() {
    autoSizeAll();
    return this;
  }

  /**
   * Apply auto sizing to the selected columns.
   * 
   * @param columns
   * 
   * @return this
   */
  public ExcelSheet withAutoSizedColumns(int... columns) {
    autoSize(columns);
    return this;
  }

  /**
   * Apply auto sizing to the selected row (1 based).
   * 
   * @param rowNumber
   * 
   * @return this
   */
  public ExcelSheet withAutoSizedColumnsAtRow(int rowNumber) {
    autoSizeColumnsAtRow(rowNumber);
    return this;
  }

  /**
   * Apply row auto sizing.
   * 
   * @param rowNumber
   * @return
   */
  public ExcelSheet withAutoSizedRow(int rowNumber) {
    autoSizeRow(rowNumber);
    return this;
  }

  /**
   * Inserts cell value(s) at the current row applying the given style.
   * 
   * @param cellStyle
   * @param values
   * @return this
   */
  public ExcelSheet withCells(CellStyle cellStyle, CellValues values) {
    setCellValues(cellStyle, values);
    return this;
  }

  /**
   * Inserts cell value(s) at the current row. The cell style used will be that set in the
   * {@link CellValues} if any. The default row style passed by {@link #withNextRow(CellStyle)} if
   * any, will be used next. The default sheet style passed to the constructor, if any, will be used
   * otherwise.
   * 
   * @param values
   * @return this
   */
  public ExcelSheet withCells(CellValues values) {
    setCellValues(values);
    return this;
  }

  /**
   * Sets the spreadsheet row position to the passed row number.
   * 
   * @param rowNumber
   * @return this
   */
  public ExcelSheet withColumn(int columnNumber) {
    setCurrentColumn(columnNumber);
    return this;
  }

  /**
   * Creates a split (freezepane). Any existing freezepane or split pane is overwritten.
   * <p>
   * If both colSplit and rowSplit are zero then the existing freeze pane is removed
   * </p>
   * 
   * @param colSplit Horizontal position of split.
   * @param rowSplit Vertical position of split.
   */
  public ExcelSheet withFreezePane(int colSplit, int rowSplit) {
    createFreezePane(colSplit, rowSplit);
    return this;
  }

  /**
   * Creates a split (freezepane). Any existing freezepane or split pane is overwritten.
   * <p>
   * If both colSplit and rowSplit are zero then the existing freeze pane is removed
   * </p>
   * 
   * @param colSplit       Horizontal position of split.
   * @param rowSplit       Vertical position of split.
   * @param leftmostColumn Left column visible in right pane.
   * @param topRow         Top row visible in bottom pane
   */
  public ExcelSheet withFreezePane(int colSplit, int rowSplit, int leftmostColumn, int topRow) {
    createFreezePane(colSplit, rowSplit, leftmostColumn, topRow);
    return this;
  }

  /**
   * Sets a spreadsheet merged region.
   * 
   * @param firstCol
   * @param firstRow
   * @param lastCol
   * @param lastRow
   * @return this
   */
  public ExcelSheet withMergedRegion(int firstCol, int firstRow, int lastCol, int lastRow) {
    addMergedRegion(firstCol, firstRow, lastCol, lastRow);
    return this;
  }

  /**
   * Increments the row position for data entry.
   * 
   * @return this
   */
  public ExcelSheet withNextRow() {
    addNewRow();
    return this;
  }

  /**
   * Increments the row position for data entry. Also sets the default style for the row. The the
   * row style can be overridden by the {@link CellValues} style.
   * 
   * @return this
   */
  public ExcelSheet withNextRow(CellStyle rowStyle) {
    addNewRow(rowStyle);
    return this;
  }

  /**
   * Increments the row position for data entry by the passed count.
   * 
   * @param cnt
   * @return this
   */
  public ExcelSheet withNextRow(int cnt) {
    IntStream.range(0, cnt).forEach(i -> addNewRow());
    return this;
  }

  /**
   * Protects sheet with password.
   * 
   * @param password
   * @return
   */
  public ExcelSheet withPassword(String password) {
    protectSheet(password);
    return this;
  }

  /**
   * Adds a picture to the current sheet spanning the specified rows and columns.
   * 
   * @param image
   * @param firstCol
   * @param firstRow
   * @param lastCol
   * @param lastRow
   * @return
   */
  public ExcelSheet withPicture(String image,
      int firstCol,
      int firstRow,
      int lastCol,
      int lastRow) {
    addPicture(image, firstCol, firstRow, lastCol, lastRow);
    return this;
  }

  /**
   * Sets the spreadsheet row position to the passed row number. Also sets the default style for the
   * row.
   * 
   * @param rowStyle
   * @param rowNumber
   * @return this
   */
  public ExcelSheet withRow(CellStyle rowStyle, int rowNumber) {
    setCurrentRow(rowStyle, rowNumber);
    return this;
  }

  /**
   * Sets the spreadsheet row position to the passed row number.
   * 
   * @param rowNumber
   * @return this
   */
  public ExcelSheet withRow(int rowNumber) {
    setCurrentRow(rowNumber - 1);
    return this;
  }

  /**
   * Sets a page break at the current row.
   * 
   * @return this
   */
  public ExcelSheet withRowBreak() {
    setRowBreak();
    return this;
  }

  /**
   * Sets a page break at the passed row.
   * 
   * @param rowNum
   * @return this
   */
  public ExcelSheet withRowBreak(int rowNum) {
    setRowBreak(rowNum);
    return this;
  }

  /**
   * Sets the current spreadsheet row height.
   * 
   * @param height
   * @return this
   */
  public ExcelSheet withRowHeight(short height) {
    setRowHeight(height);
    return this;
  }
}