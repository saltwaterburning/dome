package com.pw.dome.util.hibernate;

import static java.util.Objects.nonNull;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

/**
 * JPA entity attribute converter used to covert a string to/from a boolean value.
 * An action {@code String} value of "Active" is true and a value of "Inactive" is false.
 * 
 * @see BooleanToActiveOrDisabledConverter
 */
@Converter(autoApply = false) // Can't be true since other boolean columns rely on other AttributeConverters.
public final class BooleanToActiveOrInactiveConverter implements AttributeConverter<Boolean, String> {

	private static final String ACTIVE = "Active";
	private static final String INACTIVE = "Inactive";

	@Override
	public String convertToDatabaseColumn(Boolean value) {
		return (nonNull(value) && value) ? ACTIVE : INACTIVE;
	}

	@Override
	public Boolean convertToEntityAttribute(String value) {
		return ACTIVE.equalsIgnoreCase(value);
	}
}