package com.pw.dome.util.converters;

import java.sql.Time;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.beanutils.ConversionException;

public final class LocalTimeConverter extends AbstractDateTimeConverter {
	
	public LocalTimeConverter() {
		super();
		init();
	}

	public LocalTimeConverter(Object defaultValue) {
		super(defaultValue);
		init();
	}

	private void init() {
		setFormatter(DateTimeFormatter.ISO_TIME);
	}

    @Override
    protected <T> T convertToType(Class<T> type, Object value) throws Throwable {
    	final Class<?> sourceType = value.getClass();

    	if (sourceType.equals(Time.class)) {
    		return type.cast(((Time)value).toLocalTime());
    	} else if (sourceType.equals(String.class)) {
    		LocalTime localTime = LocalTime.parse((String)value, getFormatter());
    		return type.cast(localTime);
    	}

    	final String msg = getClass().getName() + " does not support '" + sourceType.getName() + "' to '"
    			+ type.getName() + "' conversion.";

    	throw new ConversionException(msg);
    }

    @Override
    protected Class<?> getDefaultType() {
        return LocalTime.class;
    }
}
