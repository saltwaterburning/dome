package com.pw.dome.util.excel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@AllArgsConstructor
@Data
@Builder
class ComboBoxInfo {
  private String[] itemsList;
  private Object value;
}
