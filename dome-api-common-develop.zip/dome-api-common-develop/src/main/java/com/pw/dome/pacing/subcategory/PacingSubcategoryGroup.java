package com.pw.dome.pacing.subcategory;

import java.util.List;

public record PacingSubcategoryGroup(String category, List<String> subcategories) {

}
