package com.pw.dome.web.authorization;

import jakarta.validation.constraints.NotBlank;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.pw.dome.databind.util.ToLowerCaseConverter;

import lombok.Builder;

@Builder
public record AuthorizationRequest(
		@NotBlank
		@JsonDeserialize(converter = ToLowerCaseConverter.class)
		String userEmailAddress) {
	;
}
