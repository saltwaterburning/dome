package com.pw.dome.report.excel;

import org.springframework.http.MediaType;

/**
 * Global constants used by reporting.
 */
public interface ReportConstants {
  String CLASSIFICATION = "Classification";
  /** DOME Excel date format. */
  String DATE_FORMAT = "yyyy-mm-dd";
  /** ISO 8601 date time format. */
  // "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
  String DATE_TIME_FORMAT = "yyyy-mm-dd h:mm:ss";

  /**
   * P&W legal disclaimer.
   */
  String DISCLAIMER = "This document does not contain any export regulated technical data.";

  // .xls
  // String EXCEL_MIME_TYPE = "application/vnd.ms-excel";
  // .xlsx
  String EXCEL_OPEN_XML_MIME_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  MediaType EXCEL_MEDIA_TYPE = MediaType.valueOf(EXCEL_OPEN_XML_MIME_TYPE);

  /**
   * For Excel report header foreground colors.
   * 
   * @see <a href="https://docraptor.com/excel-colors" target="_blank">Excel '97 (XLS) Supported
   *      Colors</a>
   */
  /**
   * For Excel report header foreground colors.
   * 
   * @see <a href="https://docraptor.com/excel-colors" target="_blank">Excel '97 (XLS) Supported
   *      Colors</a>
   */

  int BLACK = 0x000000;
  int GREEN = 0x92D050;
  int GOLD = 0xFFCC0;
  int LIGHT_BLUE = 0x3366FF;
  int PALE_BLUE = 0x99CCFF;
  int RED = 0xFF0000;
  int TRUE_BLUE = 0x25A2FF;

  /** Used on WIP Screen milestone dates. */
  int WIP_GREEN = 0x008000;
  /** Used on WIP Screen milestone dates. */
  int WIP_LIGHT_GREEN = 0x92E092;
  /** Used on WIP Screen milestone dates. */
  int WIP_RED = 0xFF0000;
  /** Used on WIP Screen milestone dates. */
  int WIP_YELLOW = 0xFFA500;

  String PDF_EXTENSION = "pdf";

  String PRATT_AND_WHITNEY_LOGO_JPG = "images/pw-report-logo.jpg";
  String PRATT_AND_WHITNEY_LOGO_PNG = "images/pratt-whitney-logo-666x405-cropped.png";

  String PROTECT_PASSWORD = "P@ssword";
}
