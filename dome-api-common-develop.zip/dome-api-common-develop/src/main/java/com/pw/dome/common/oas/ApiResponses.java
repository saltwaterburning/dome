package com.pw.dome.common.oas;

/**
 * H
 */
public interface ApiResponses {
	interface Headers {
		
	}
}
