package com.pw.dome.util.excel.menu;

import org.apache.commons.lang3.Validate;

import com.pw.dome.util.excel.ExcelWorkbook;

import lombok.Builder;

/**
 * Provides reference to a drop-down menu to display within an Excel cell. The listName as provided
 * to an associated {@link DdMenu}.
 * 
 * @see DdMenu#name()
 * @see ExcelWorkbook#createDropDownMenus(boolean, java.util.List)
 */
@Builder
public record DdMenuReference(String menuName, String selectedValue) {
  public DdMenuReference {
    Validate.notBlank(menuName);
    // selectedValue is nullable
  }
}
