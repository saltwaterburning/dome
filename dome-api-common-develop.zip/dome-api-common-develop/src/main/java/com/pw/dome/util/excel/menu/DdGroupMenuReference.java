package com.pw.dome.util.excel.menu;

import java.util.Objects;

import com.pw.dome.util.excel.ExcelWorkbook;

import lombok.Builder;

/**
 * Provides reference to a drop-down group menu to display within an Excel cell. The
 * {@link DdGroupMenuContext} is provided when the menu(s) are created.
 * 
 * @see ExcelWorkbook#createDropDownMenus(boolean, java.util.List)
 * @see DdDependentMenuReference
 */
@Builder
public record DdGroupMenuReference(DdGroupMenuContext groupInfo, String selectedValue) {

  public DdGroupMenuReference {
    Objects.requireNonNull(groupInfo);
    // selectedValue is nullable
  }
}
