package com.pw.dome.web.requestlogging;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

import org.hibernate.annotations.ColumnTransformer;
import org.hibernate.annotations.GenericGenerator;

import com.pw.dome.jpa.AbstractEntityWithGeneratedId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="DOME_REQUEST_LOG")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RestRequestLogEntity extends AbstractEntityWithGeneratedId<String> {
	@Id
    @GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name="REQUEST_ID")
	private String requestId;

	@Column(name="ENDPOINT")
	@ColumnTransformer(write = "SUBSTR(?, 0, 250)")
	private String endPoint;

	@Lob
	@Column(name="ERROR_MESSAGE")
	private String errorMessage;
	
	@Column(name="HTTP_METHOD")
	@ColumnTransformer(write = "SUBSTR(?, 0, 10)")
	private String httpMethod;

	@Column(name="HTTP_STATUS_RESPONSE")
	private Integer httpStatusResponse;
	
	@Column(name="LOG_EMAIL")
	@ColumnTransformer(write = "SUBSTR(?, 0, 50)")
	private String logEmail;

	@Column(name="PARMS")
	@ColumnTransformer(write = "SUBSTR(?, 0, 250)")
	private String parms;

	@Column(name="REMOTE_IP")
	@ColumnTransformer(write = "SUBSTR(?, 0, 46)")
	private String remoteIp;
	
	@Column(name="REQUEST_DATE")
	private LocalDateTime requestDate;

	@Lob
	@Column(name="REQUEST_PAYLOAD")
	private String requestPayload;

	@Lob
	@Column(name="RESPONSE_PAYLOAD")
	private String responsePayload;

	@Column(name="RUN_TIME_MSEC")
	private Long runtime;

	@Override
	public String getId() {
		return requestId;
	}
}