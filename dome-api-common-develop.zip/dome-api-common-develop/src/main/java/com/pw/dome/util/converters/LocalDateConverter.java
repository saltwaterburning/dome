package com.pw.dome.util.converters;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.commons.beanutils.ConversionException;

public final class LocalDateConverter extends AbstractDateTimeConverter {
	
	public LocalDateConverter() {
		super();
		init();
	}

	public LocalDateConverter(Object defaultValue) {
		super(defaultValue);
		init();
	}

	private void init() {
		setFormatter(DateTimeFormatter.ISO_LOCAL_DATE);
	}

    @Override
    protected <T> T convertToType(Class<T> type, Object value) throws Throwable {
    	final Class<?> sourceType = value.getClass();

    	if (sourceType.equals(Date.class)) {
    		Instant instant = ((Date)value).toInstant();
    		return type.cast(instant.atZone(ZoneId.systemDefault()).toLocalDate());
    	}
    	else if (sourceType.equals(java.sql.Date.class)) {
    		return type.cast(((java.sql.Date) value).toLocalDate());
    	} else if (sourceType.equals(Timestamp.class)) {
    		return type.cast(new java.sql.Date(((Timestamp)value).getTime()).toLocalDate());
    	} else if (sourceType.equals(String.class)) {
    		return type.cast(LocalDate.parse((String)value, getFormatter()));
    	}

    	final String msg = getClass().getName() + " does not support '" + sourceType.getName() + "' to '"
    			+ type.getName() + "' conversion.";

    	throw new ConversionException(msg);
    }

    @Override
    protected Class<?> getDefaultType() {
        return LocalDate.class;
    }
}
