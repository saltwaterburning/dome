package com.pw.dome.util;

import java.util.Objects;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

public final class CompareUtils {

  /**
   * Returns "fuzzy" equality indication. Compares Excel cell value with a DB entity value.
   * <p>
   * Integer null and 0 values are considered equal. String null and blank ("") values are
   * considered equal.
   * </p>
   * 
   * @param obj1
   * @param obj2
   * @return equality indication
   */
  @SuppressWarnings({ "unchecked", "rawtypes" })
  public static boolean fuzzyEquals(final Object obj1, final Object obj2, final Class<?> clazz) {

    if (Objects.equals(obj1, obj2)) {
      return true;
    }

    boolean equals = true;

    if (Integer.class.isAssignableFrom(clazz)) {
      Integer i1 = (Integer) obj1;
      Integer i2 = (Integer) obj2;
      if (i1 == null) {
        i1 = 0;
      }
      if (i2 == null) {
        i2 = 0;
      }
      equals = ObjectUtils.compare(i1, i2) == 0;
    } else if (String.class.isAssignableFrom(clazz)) {
      String str1 = (String) obj1;
      String str2 = (String) obj2;

      if (!StringUtils.isAllBlank(str1, str2)) { // Eliminate comparing null and "".
        equals = StringUtils.equals(str1, str2);
      }
    } else {
      equals = ObjectUtils.compare((Comparable) obj1, (Comparable) obj2) == 0;
    }

    return equals;
  }
}
