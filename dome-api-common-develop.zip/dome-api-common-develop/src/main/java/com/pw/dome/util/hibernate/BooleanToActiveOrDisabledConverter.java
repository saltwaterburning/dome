package com.pw.dome.util.hibernate;

import static java.util.Objects.nonNull;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

/**
 * JPA entity attribute converter used to covert a string to/from a boolean value.
 * An action {@code String} value of "A" is active (true) and a value of "D" is inactive (false).
 * 
 * @see BooleanToActiveOrInactiveConverter
 */
@Converter(autoApply = false) // Can't be true since other boolean columns rely on other AttributeConverters.
public final class BooleanToActiveOrDisabledConverter implements AttributeConverter<Boolean, String> {

	private static final String ACTIVE = "A";
	private static final String DISABLED = "D";

	@Override
	public String convertToDatabaseColumn(Boolean value) {
		return (nonNull(value) && value) ? ACTIVE : DISABLED;
	}

	@Override
	public Boolean convertToEntityAttribute(String value) {
		return ACTIVE.equalsIgnoreCase(value);
	}
}