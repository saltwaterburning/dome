package com.pw.dome.web.requestlogging;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;

/**
 * @author John De Lello
 */
@Slf4j
@Service
public class RequestLoggingServiceImpl implements RequestLoggingService {
	@Autowired
	private ConfigRequestLogging config;
	@Autowired 
	private RequestLoggingRepository requestLoggingRepository;

	@Override
	@Transactional
	public RestRequestLogEntity save(RestRequestLogEntity requestLog) {
		return requestLoggingRepository.save(requestLog);
	}

	@Override
	@Transactional
	@Modifying
	public int doRestRequestLogCleanup() {
		final long daysToKeepLog = config.getDaysToKeepLog();
		LocalDateTime deleteBeforeDate = LocalDateTime.now().minusDays(daysToKeepLog);
		
		log.info("Deleting REST Requests older than [{}]", deleteBeforeDate);
		int deletedRequests =  requestLoggingRepository.deleteByRequestDateBefore(deleteBeforeDate);
		log.info("Deleted [{}] REST Requests older than [{}]", deletedRequests, deleteBeforeDate);
		
		return deletedRequests;
	}
}
