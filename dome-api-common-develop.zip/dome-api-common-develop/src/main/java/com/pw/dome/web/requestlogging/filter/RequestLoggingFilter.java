package com.pw.dome.web.requestlogging.filter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.filter.CommonsRequestLoggingFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;

import com.pw.dome.web.requestlogging.ConfigRequestLogging;
import com.pw.dome.web.requestlogging.RequestLoggingService;
import com.pw.dome.web.requestlogging.RestRequestLogEntity;

public class RequestLoggingFilter extends CommonsRequestLoggingFilter {
	@Autowired
	private ConfigRequestLogging config;
	@Autowired
	private RequestLoggingService requestLoggingService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		Instant start = Instant.now();
		ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(request, getMaxPayloadLength());

		try {
			super.doFilterInternal(requestWrapper, response, filterChain);
		} finally {
			if (config.isLogToDatabase()) {
				logToDataBase(requestWrapper, response, start);
			}
		}

	}


//	@Transactional
//	Caused by: java.lang.NullPointerException: Cannot invoke "org.apache.commons.logging.Log.isDebugEnabled()" because "this.logger" is null
//	at org.springframework.web.filter.GenericFilterBean.init(GenericFilterBean.java:239) ~[spring-web-6.1.0-RC1.jar:6.1.0-RC1]
	private String logToDataBase(HttpServletRequest request, HttpServletResponse response, Instant start)
	throws UnsupportedEncodingException {

		Instant finish = Instant.now();
		long timeElapsed = Duration.between(start, finish).toMillis();

		RestRequestLogEntity restReqLog=
				RestRequestLogEntity.builder()
					               .endPoint(request.getRequestURI())
					               .errorMessage(null)
					               .httpMethod(request.getMethod())
					               .httpStatusResponse(response.getStatus())
					               .logEmail(request.getRemoteUser())
					               .parms(request.getQueryString())
					               .remoteIp(request.getRemoteAddr())
					               .requestDate(LocalDateTime.now())
					               .requestPayload(getMessagePayload(request))
					               .responsePayload(null)
					               .runtime(timeElapsed)
					               .build();

		restReqLog = requestLoggingService.save(restReqLog);
		return restReqLog.getRequestId();
	}
}
