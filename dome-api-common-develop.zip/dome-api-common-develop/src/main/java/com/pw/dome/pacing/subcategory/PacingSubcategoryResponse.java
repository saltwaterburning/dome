package com.pw.dome.pacing.subcategory;

import java.util.List;

public record PacingSubcategoryResponse(List<String> items) {

}
