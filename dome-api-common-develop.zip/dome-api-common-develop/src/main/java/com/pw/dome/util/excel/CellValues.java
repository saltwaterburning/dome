package com.pw.dome.util.excel;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.stream.IntStream;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.poi.ss.usermodel.RichTextString;

import com.pw.dome.util.excel.menu.DdDependentMenuReference;
import com.pw.dome.util.excel.menu.DdGroupMenuReference;
import com.pw.dome.util.excel.menu.DdMenuReference;

import lombok.Getter;

/**
 * The {@code CellValues} class provides a type-safe value holder with an optional {@link CellStyle}
 * which can be inserted into a row.
 */
@Getter
public final class CellValues {
  /**
   * Represents an empty cell value.
   */
  public static class BlankValue {
    private BlankValue() {
    }
  }
  /**
   * A {@link CellValues} builder with allowable {@code Object} types and optional
   * {@link CellStyle}.
   */
  public static class Builder {
    private final List<CellStyle> styles;
    private final List<Object> values;

    private Builder() {
      styles = new ArrayList<>();
      values = new ArrayList<>();
    }

    /**
     * Adds an empty cell value.
     * 
     * @return this
     */
    public Builder add() {
      styles.add(null);
      values.add(new BlankValue());
      return this;
    }

    /**
     * Adds a value of type {@link Boolean}.
     * 
     * @param value {@link Boolean} type
     * @return this
     */
    public Builder add(boolean value) {
      styles.add(null);
      values.add(value);
      return this;
    }

    /**
     * Adds a value of type {@link Boolean} with a cell ComboBox having the supplied labels.
     * 
     * @param value      {@link Boolean} type
     * @param falseLabel string to display for Boolean.FALSE
     * @param trueLabel  string to display for Boolean.TRUE
     * @return this
     */
    public Builder add(boolean value, String falseLabel, String trueLabel) {
      String[] itemsList = new String[] { falseLabel, trueLabel };
      styles.add(null);
      values.add(new ComboBoxInfo(itemsList, value));
      return this;
    }

    /**
     * Adds a value of type {@link Boolean} displayed as the corresponding {@code String} value.
     * 
     * @param value
     * @param trueString
     * @param falseString
     * @param nullString
     * @return this
     * 
     * @see BooleanUtils#toString(Boolean, String, String, String)
     */
    public Builder add(final Boolean value,
        final String trueString,
        final String falseString,
        final String nullString) {
      styles.add(null);
      if (value == null) {
        values.add(nullString == null ? new BlankValue() : nullString);
      } else {
        values.add(value ? trueString : falseString);
      }
      return this;
    }

    /**
     * Adds a value of type {@link Byte}.
     * 
     * @param value {@link Byte} type
     * @return this
     */
    public Builder add(Byte value) {
      styles.add(null);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link Calendar}.
     * 
     * @param value {@link Calendar} type
     * @return this
     */
    public Builder add(Calendar value) {
      styles.add(null);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds an empty cell value with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @return
     */
    public Builder add(CellStyle cellStyle) {
      styles.add(cellStyle);
      values.add(new BlankValue());
      return this;
    }

    /**
     * Adds a value of type {@link Boolean} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param value
     * @return
     */
    public Builder add(CellStyle cellStyle, boolean value) {
      styles.add(cellStyle);
      values.add(value);
      return this;
    }

    /**
     * Adds a value of type {@link Boolean} with a {@link CellStyle} with a cell ComboBox having the
     * supplied labels.
     * 
     * @param cellStyle
     * @param value
     * @param falseLabel string to display for Boolean.FALSE
     * @param trueLabel  string to display for Boolean.TRUE
     * @return
     */
    public Builder add(CellStyle cellStyle, boolean value, String falseLabel, String trueLabel) {
      String[] itemsList = new String[] { falseLabel, trueLabel };
      styles.add(cellStyle);
      values.add(new ComboBoxInfo(itemsList, value));
      return this;
    }

    /**
     * Adds a value of type {@link Boolean} with the provided {@link CellStyle} displayed as the
     * corresponding {@code String} value.
     * 
     * @param cellStyle
     * @param value
     * @param trueString
     * @param falseString
     * @param nullString
     * @return this
     * 
     * @see BooleanUtils#toString(Boolean, String, String, String)
     */
    public Builder add(CellStyle cellStyle,
        final Boolean value,
        final String trueString,
        final String falseString,
        final String nullString) {
      styles.add(cellStyle);
      if (value == null) {
        values.add(nullString == null ? new BlankValue() : nullString);
      } else {
        values.add(value ? trueString : falseString);
      }
      return this;
    }

    /**
     * Adds a value of type {@link Byte} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param value
     * @return
     */
    public Builder add(CellStyle cellStyle, Byte value) {
      styles.add(cellStyle);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link Calendar} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param value
     * @return
     */
    public Builder add(CellStyle cellStyle, Calendar value) {
      styles.add(cellStyle);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

//        /**
//         * Adds a value of type {@link Date} with a {@link CellStyle}.
//         * 
//         * @param cellStyle
//         * @param value
//         * @return
//         */
//        public Builder add(CellStyle cellStyle, Date value) {
//            styles.add(cellStyle);
//            values.add(value == null ? new BlankValue() : value);
//            return this;
//        }

    /**
     * Adds the CellValues using the supplied {@link CellStyle}.
     * 
     * @return this
     */
    public Builder add(CellStyle cellStyle, CellValues cellValues) {
      cellValues.values.stream().forEach(v -> {
        values.add(v);
        styles.add(cellStyle);
      });
      return this;
    }

    public Builder add(CellStyle cellStyle, DdDependentMenuReference listName) {
      styles.add(cellStyle);
      values.add(listName);
      return this;
    }

    public Builder add(CellStyle cellStyle, DdGroupMenuReference listName) {
      styles.add(cellStyle);
      values.add(listName);
      return this;
    }

    public Builder add(CellStyle cellStyle, DdMenuReference listName) {
      styles.add(cellStyle);
      values.add(listName);
      return this;
    }

    /**
     * Adds a value of type {@link Double} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param value
     * @return
     */
    public Builder add(CellStyle cellStyle, Double value) {
      styles.add(cellStyle);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link Integer} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param value
     * @return
     */
    public Builder add(CellStyle cellStyle, Integer value) {
      styles.add(cellStyle);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link LocalDate} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param value
     * @return
     */
    public Builder add(CellStyle cellStyle, LocalDate value) {
      styles.add(cellStyle);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link LocalDateTime} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param value
     * @return
     */
    public Builder add(CellStyle cellStyle, LocalDateTime value) {
      styles.add(cellStyle);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link Integer} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param value
     * @return
     */
    public Builder add(CellStyle cellStyle, Long value) {
      styles.add(cellStyle);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link RichTextString} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param value
     * @return
     */
    public Builder add(CellStyle cellStyle, RichTextString value) {
      styles.add(cellStyle);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link String} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param value
     * @return
     */
    public Builder add(CellStyle cellStyle, String value) {
      styles.add(cellStyle);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds the CellValues.
     * 
     * @return this
     */
    public Builder add(CellValues cellValues) {
      cellValues.styles.stream().forEach(c -> styles.add(c));
      cellValues.values.stream().forEach(v -> values.add(v));
      return this;
    }

    /**
     * Adds a value of type {@link String} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param itemsList combo box drop-down items
     * @return
     * 
     * @see ExcelWorkbook#createDropDownMenus(boolean, List)
     */
    public Builder add(DdDependentMenuReference listName) {
      styles.add(null);
      values.add(listName);
      return this;
    }

    public Builder add(DdGroupMenuReference listName) {
      styles.add(null);
      values.add(listName);
      return this;
    }

//        /**
//         * Adds a value of type {@link Date}.
//         * 
//         * @param value {@link Date} type
//         * @return this
//         */
//        public Builder add(Date value) {
//            styles.add(null);
//            values.add(value == null ? new BlankValue() : value);
//            return this;
//        }

    /**
     * Adds a value of type {@link String} with a {@link CellStyle}.
     * 
     * @param cellStyle
     * @param itemsList combo box drop-down items
     * @return
     * 
     * @see ExcelWorkbook#createDropDownMenus(boolean, List)
     */
    public Builder add(DdMenuReference listName) {
      styles.add(null);
      values.add(listName);
      return this;
    }

    /**
     * Adds a value of type {@link Double}.
     * 
     * @param value {@link Double} type
     * @return this
     */
    public Builder add(Double value) {
      styles.add(null);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link Integer}.
     * 
     * @param value {@link Calendar} type
     * @return this
     */
    public Builder add(Integer value) {
      styles.add(null);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link LocalDate}.
     * 
     * @param value {@link LocalDate} type
     * @return this
     */
    public Builder add(LocalDate value) {
      styles.add(null);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link LocalDateTime}.
     * 
     * @param value {@link LocalDateTime} type
     * @return this
     */
    public Builder add(LocalDateTime value) {
      styles.add(null);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link RichTextString}.
     * 
     * @param value {@link RichTextString} type
     * @return this
     */
    public Builder add(RichTextString value) {
      styles.add(null);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Adds a value of type {@link String}.
     * 
     * @param value {@link String} type
     * @return this
     */
    public Builder add(String value) {
      styles.add(null);
      values.add(value == null ? new BlankValue() : value);
      return this;
    }

    /**
     * Inserts the given number of empty cells using the supplied style.
     * 
     * @param cellStyle style to apply to each cell
     * @param cnt       number of empty cells to insert.
     * @return this
     */
    public Builder addCells(CellStyle cellStyle, int cnt) {
      IntStream.range(0, cnt).forEach(i -> {
        styles.add(cellStyle);
        values.add(new BlankValue());
      });
      return this;
    }

    /**
     * Inserts the given number of empty cells.
     * 
     * @param cnt number of empty cells to insert.
     * @return this
     */
    public Builder addCells(int cnt) {
      IntStream.range(0, cnt).forEach(i -> {
        styles.add(null);
        values.add(new BlankValue());
      });
      return this;
    }

    /**
     * An initialized {@code CellValues} {@code Object}.
     * 
     * @return initialized {@code CellValues} {@code Object}
     */
    public CellValues build() {
      return new CellValues(styles, values);
    }
  }

  /**
   * Returns a {@link CellValues} builder.
   *
   * @return a {@link CellValues} builder
   */
  public static Builder builder() {
    return new Builder();
  }

  private final List<CellStyle> styles;

  private final List<Object> values;

  private CellValues(List<CellStyle> styles, List<Object> values) {
    this.styles = styles;
    this.values = values;
  }

  /**
   * Sets the {@link CellStyle} for all values.
   * 
   * @param cellStyle
   */
  public void setStyle(CellStyle cellStyle) {
    for (int i = 0; i < styles.size(); ++i) {
      styles.set(i, cellStyle);
    }
  }
}
