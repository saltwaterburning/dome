/**
 * Common for RESTful Services.
 */
package com.pw.dome.common.oas;