package com.pw.dome.util.excel;

import org.apache.poi.ss.usermodel.BorderStyle;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * Defines the {@code Cell} border attributes for each of the four borders. The attributes consist
 * of {@link Colors} and/or @link BorderStyles}.
 */
@AllArgsConstructor
@Data
@Builder
public final class Border {
  private BorderStyles topStyle;
  private BorderStyles bottomStyle;
  private BorderStyles leftStyle;
  private BorderStyles rightStyle;
  private Colors topColor;
  private Colors bottomColor;
  private Colors leftColor;
  private Colors rightColor;

  /**
   * Creates a new {@link Border} with the given {@link BorderStyles}.
   * 
   * @param style used for all border sides
   * @return a new {@link Border} with the given {@link BorderStyles}
   */
  public static Border of(BorderStyles style) {
    return Border.builder()
        .bottomStyle(style)
        .leftStyle(style)
        .rightStyle(style)
        .topStyle(style)
        .build();
  }

  public static enum BorderStyles {
    /**
     * No border (default)
     */
    NONE(0x0),
    /**
     * Thin border
     */
    THIN(0x1),
    /**
     * Medium border
     */
    MEDIUM(0x2),
    /**
     * dash border
     */
    DASHED(0x3),
    /**
     * dot border
     */
    DOTTED(0x4),
    /**
     * Thick border
     */
    THICK(0x5),
    /**
     * double-line border
     */
    DOUBLE(0x6),
    /**
     * hair-line border
     */
    HAIR(0x7),
    /**
     * Medium dashed border
     */
    MEDIUM_DASHED(0x8),
    /**
     * dash-dot border
     */
    DASH_DOT(0x9),
    /**
     * medium dash-dot border
     */
    MEDIUM_DASH_DOT(0xA),
    /**
     * dash-dot-dot border
     */
    DASH_DOT_DOT(0xB),
    /**
     * medium dash-dot-dot border
     */
    MEDIUM_DASH_DOT_DOT(0xC),
    /**
     * slanted dash-dot border
     */
    SLANTED_DASH_DOT(0xD);

    private final short code;

    private BorderStyles(int code) {
      this.code = (short) code;
    }

    public short getCode() {
      return code;
    }

    public BorderStyle valueOf() {
      return BorderStyle.valueOf(getCode());
    }
  }
}
