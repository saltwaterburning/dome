/**
 * Provides a simplified fluent interface for Excel.
 */
package com.pw.dome.util.excel;