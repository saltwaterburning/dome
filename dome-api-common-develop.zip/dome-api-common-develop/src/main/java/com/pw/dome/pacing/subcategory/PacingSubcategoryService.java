package com.pw.dome.pacing.subcategory;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.pw.dome.exception.NotFoundException;

@Service
public class PacingSubcategoryService {
	@Autowired
	private PacingSubcategoryRepo repo;

	/**
	 * {@return an ordered list of unique Pacing categories}
	 */
	public List<String> getAllCategories() {
		List<PacingSubcategoryEntity> entities = repo.findAll(Sort.by("id.category"));

		return entities.stream() //
				.map(s -> s.getId().getCategory()) //
				.distinct() //
				.collect(Collectors.toList());
	}

	/**
	 * {@return an ordered list of Pacing categories and subcategories}
	 */
	public List<PacingSubcategoryDTO> getAllSubcategories() {
		List<PacingSubcategoryEntity> entities = repo.findAll(Sort.by("id.category", "fieldSeq"));

		return entities.stream() //
				.map(s -> new PacingSubcategoryDTO(s.getId().getCategory(), s.getId().getSubcategory())) //
				.collect(Collectors.toList());
	}

	/**
	 * {@return ordered subcategories grouped by category}
	 */
	public PacingSubcategoryGroupResponse getPacingSubcategoryGroups() {
		List<PacingSubcategoryEntity> entities = repo.findAll(Sort.by("id.category"));

		Map<String, List<String>> subcategoryGroupsMap = entities.stream()
				.collect(Collectors.groupingBy(e -> e.getId().getCategory(), //
						TreeMap::new, // maintain sorted order
						Collectors.mapping(x -> x.getId().getSubcategory(), Collectors.toList())));

		// The list ensures sort order is maintained in the client.
		List<PacingSubcategoryGroup> subcategoryGroupsList = subcategoryGroupsMap.entrySet() //
				.stream() // ConcurrentSkipListSet
				.map(s -> new PacingSubcategoryGroup(s.getKey(), sort(s.getValue()))) //
				.collect(Collectors.toList());

		return new PacingSubcategoryGroupResponse(subcategoryGroupsList);
	}

	/**
	 * {@return an ordered list of pacing sub-categories for the given category}
	 * 
	 * @param category which to match
	 */
	public PacingSubcategoryResponse getSubcategories(String category) {
		List<PacingSubcategoryEntity> entities = repo.findAllByIdCategoryOrderByIdSubcategory(category);

		if (entities.isEmpty()) {
			throw new NotFoundException("No match found for category: " + category);
		}

		List<String> response = entities.stream() //
				.map(s -> s.getId().getSubcategory()) //
				.distinct() //
				.collect(Collectors.toList());

		return new PacingSubcategoryResponse(response);
	}

	private List<String> sort(List<String> items) {
		Collections.sort(items);
		return items;
	}
}
