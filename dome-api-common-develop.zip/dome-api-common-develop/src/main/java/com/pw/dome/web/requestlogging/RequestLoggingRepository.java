package com.pw.dome.web.requestlogging;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

/**
 * @author John De Lello
 */    
@Repository
public interface RequestLoggingRepository extends JpaRepository<RestRequestLogEntity, String> {
	@Modifying
//	@Query(value = "DELETE FROM RestRequestLogEntity r WHERE r.requestDate < ?1")
	int deleteByRequestDateBefore(LocalDateTime deleteBeforeDate);
}
