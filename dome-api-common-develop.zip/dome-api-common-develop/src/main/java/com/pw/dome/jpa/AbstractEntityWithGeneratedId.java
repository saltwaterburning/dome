package com.pw.dome.jpa;

import static java.util.Objects.isNull;

import jakarta.persistence.EntityManager;

import org.springframework.data.domain.Persistable;

/**
 * Used for read-write lookup data tables. Any subclasses with a non-unique ID should create a
 * composite key object or override the equals() and hashCode() method using the fields which make
 * the entity unique.
 *
 * @param <ID> the entity identifier type
 * 
 * @see https://www.artima.com/articles/how-to-write-an-equality-method-in-java
 * @see https://thorben-janssen.com/ultimate-guide-to-implementing-equals-and-hashcode-with-hibernate/#Using_a_Generated_Primary_Key
 */
public abstract class AbstractEntityWithGeneratedId<ID> implements Persistable<ID> {
  @Override
  public int hashCode() {
    return getClass().hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Persistable<?> other = (Persistable<?>) obj;
//        return getId() != null ? getId().equals(other.getId()) : other.getId() == null;
    return getId() != null && getId().equals(other.getId());
  }

  /**
   * @see Persistable#getId()
   */
  @Override
  public abstract ID getId();

  /**
   * When true {@link EntityManager#persist(Object)} is invoked. When false
   * {@link EntityManager#merge(Object)} is invoked.
   * 
   * @see Persistable#isNew()
   */
  @Override
  public boolean isNew() {
//		boolean isDetached = isDetached(this);
//		return true;
    return isNull(getId());
  }

  protected boolean isDetached(Persistable<ID> entity) {
    return false;
//	    return entity.getId() != null  // must not be transient
//	        && !em.contains(entity)  // must not be managed now
//	        ;
//	        && em.find(Entity.class, entity.id) != null;  // must not have been removed
  }
}
