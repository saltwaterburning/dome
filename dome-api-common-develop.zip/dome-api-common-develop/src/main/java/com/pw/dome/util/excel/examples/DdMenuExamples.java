package com.pw.dome.util.excel.examples;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.pw.dome.report.excel.CellStyles;
import com.pw.dome.util.excel.CellStyle;
import com.pw.dome.util.excel.CellValues;
import com.pw.dome.util.excel.ExcelSheet;
import com.pw.dome.util.excel.ExcelWorkbook;
import com.pw.dome.util.excel.menu.DdDependentMenuReference;
import com.pw.dome.util.excel.menu.DdGroupMenuContext;
import com.pw.dome.util.excel.menu.DdGroupMenuReference;
import com.pw.dome.util.excel.menu.DdMenu;
import com.pw.dome.util.excel.menu.DdMenuReference;

/**
 * Demonstrates the use of the DOME API to create drop-down menus within Excel.
 * Both independent drop-down menus and dependent (cascading) drop-down menus
 * are shown.
 * 
 * Running this class will create the example Excel file in the /tmp directory.
 */
public class DdMenuExamples {

	public static void main(String[] args) throws IOException {
		boolean hideDropDownListsTab = false; // Hide the DropDownLists Excel tab?
		CellStyle blue = CellStyles.BOLD_BLUE_LEFT;
		CellStyle bold = CellStyles.BOLD_LEFT;
		CellStyle wide = CellStyles.PLAIN_LEFT.toBuilder().columnCharacterWith(11).build();

		ExcelWorkbook workbook = new ExcelWorkbook(true);
		ExcelSheet sheet = workbook.getExcelSheet("Example_Drop-down_Lists");

		// Define 3 drop-down lists...
		List<DdMenu> dropDownLists = new ArrayList<>();
		DdMenu capitols = new DdMenu("Capitals", Arrays.asList("Paris", "Berlin", "Rome"));
		dropDownLists.add(capitols);

		DdMenu countries = new DdMenu("Countries", Arrays.asList("France", "Germany", "Italy"));
		dropDownLists.add(countries);

		DdMenu fruits = new DdMenu("Stone Fruits",
				Arrays.asList("Apricot", "Cherry", "Lychee", "Mango", "Peach", "Plum"));
		dropDownLists.add(fruits);

		// Create 3 drop-down lists in a single group...
		DdGroupMenuContext groupMenuContext = workbook.createDropDownMenus(hideDropDownListsTab, dropDownLists);

		// Use the 3 drop-down lists individually...
		DdMenuReference capitolsRef = DdMenuReference.builder() //
				.menuName(capitols.name()) //
				.selectedValue("Berlin") //
				.build();
		DdMenuReference countriesRef = new DdMenuReference(countries.name(), "Germany");
		DdMenuReference fruitRef = DdMenuReference.builder() //
				.menuName(fruits.name()) //
				.selectedValue("Lychee") //
				.build();

		CellValues values = CellValues.builder() //
				.add(bold, "Use of Individual DDLs...") //
				.add(blue, "Capitols:")
				.add(wide, capitolsRef) //
				.add(blue, "Countries:") //
				.add(countriesRef) // TODO: Add validation of list
																					// details.
				.add(blue, "Fruits:") //
				.add(fruitRef).build();
		sheet.withCells(values);

		// Use the 3 drop-down menus as group->dependent (AKA cascade) menus...
		DdGroupMenuReference groupRef = new DdGroupMenuReference(groupMenuContext, fruits.name());
		DdDependentMenuReference dependentMenu = new DdDependentMenuReference(groupRef, "Mango");

		values = CellValues.builder().add(bold, "Use of Group->Dependant DDLs...").add(blue, "Group Menu: ") // AKA
																												// Category
																												// Menu
				.add(groupRef) // TODO: Add validation of list details.
				.add(blue, "Dependent Menu: ").add(dependentMenu) // TODO: Add validation of list details.
				.build();
		sheet.withNextRow().withNextRow().withCells(values);

		workbook.getSheets().forEach(s -> s.withAutoSizedColumns());
		workbook.saveAsXlsx("/tmp/drop-down-menu-example.xlsx");
	}
}
