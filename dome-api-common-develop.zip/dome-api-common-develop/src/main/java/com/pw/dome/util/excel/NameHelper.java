package com.pw.dome.util.excel;

import org.apache.commons.lang3.StringUtils;

/**
 * See {@link org.apache.poi.xssf.usermodel.XSSFName#setNameName(String)}
 */
class NameHelper {
	private static String allowedSymbols = "_.\\";

	/**
	 * Returns decoded string.
	 * 
	 * @param name
	 * @return decoded string
	 */
	static String decode(String name) {
		StringBuilder buffy = new StringBuilder();
		char[] array = name.toCharArray();

		for (int i = 0; i < array.length; ++i) {
			char ch = array[i];
			if (ch == '\\') {
				String str = StringUtils.substring(name, i, i + 4);
				String hex = StringUtils.substring(str, 2);
				if (str.length() == 4 && str.startsWith("\\x") && isHexadecimal(hex)) {
					int c = Integer.parseInt(hex, 16);
					buffy.append((char) c);
					i += 3;
				} else {
					buffy.append(ch);
				}
			} else {
				buffy.append(ch);
			}
		}

		return buffy.toString();
	}

	/**
	 * Returns string encoded with acceptable name characters. Hexadecimal encoding
	 * is used.
	 * 
	 * @param name
	 * @return string encoded with acceptable name characters
	 */
	static String encode(String name) {

		StringBuilder buffy = new StringBuilder();
		for (char c : name.toCharArray()) {
			if (Character.isLetterOrDigit(c) || allowedSymbols.indexOf(c) != -1) {
				buffy.append(c);
			} else {
				String hex = "\\x" + Integer.toHexString(c & 0xFF);
				buffy.append(hex);
			}
		}
		return buffy.toString();
	}

	private static boolean isHexadecimal(String str) {
		String lower = StringUtils.lowerCase(str);

		if (StringUtils.containsOnly(lower, "0123456789abcdef")) {
			return true;
		}

		return false;
	}

	/**
	 * Returns string encoded with acceptable name characters. Invalid characters
	 * are mapped to a dot.
	 * 
	 * @param name
	 * @return string encoded with acceptable name characters
	 */
	static String normalize(String name) {

		StringBuilder buffy = new StringBuilder();
		for (char c : name.toCharArray()) {
			if (Character.isLetterOrDigit(c) || allowedSymbols.indexOf(c) != -1) {
				buffy.append(c);
			} else {
				buffy.append(".");
			}
		}
		return buffy.toString();
	}
}
