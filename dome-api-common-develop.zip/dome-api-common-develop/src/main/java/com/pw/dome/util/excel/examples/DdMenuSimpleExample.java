package com.pw.dome.util.excel.examples;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.pw.dome.report.excel.CellStyles;
import com.pw.dome.util.excel.CellStyle;
import com.pw.dome.util.excel.CellValues;
import com.pw.dome.util.excel.ExcelSheet;
import com.pw.dome.util.excel.ExcelWorkbook;
import com.pw.dome.util.excel.menu.DdMenu;
import com.pw.dome.util.excel.menu.DdMenuReference;

/**
 * Demonstrates the use of the DOME API to create drop-down menus within Excel. Both independent
 * drop-down lists and dependent (cascading) drop-down lists are shown.
 * 
 * Running this class will create the example Excel file in the /tmp directory.
 */
public class DdMenuSimpleExample {

  public static void main(String[] args) throws IOException {
    boolean hideDropDownListsTab = false; // Hide the DropDownLists Excel tab?
    CellStyle blue = CellStyles.BOLD_BLUE_LEFT;
    CellStyle bold = CellStyles.BOLD_LEFT;

    ExcelWorkbook workbook = new ExcelWorkbook(true);
    ExcelSheet sheet = workbook.getExcelSheet("Example Drop-down List");

    // Define 3 drop-down lists...
    List<DdMenu> dropDownLists = new ArrayList<>();
    DdMenu fruits = new DdMenu("Fruits", Arrays.asList("Apple Tree", "Peach Tree", "Banana", "Orange"));

    dropDownLists.add(fruits);

    // Create drop-down menu...
    workbook.createDropDownMenus(hideDropDownListsTab, dropDownLists);

    // Use the drop-down menu...
    DdMenuReference fruitRef = DdMenuReference.builder()
        .menuName("Fruits")
        .selectedValue("Banana")
        .build();

    CellValues values = CellValues.builder()
        .add(bold, "Use of DropDown Menu...")
        .add(blue, "Fruits:")
        .add(fruitRef)
        .build();
    sheet.withCells(values);

    workbook.getSheets().forEach(s -> s.withAutoSizedColumns());
    workbook.saveAsXlsx("/tmp/drop-down-menu-simple-example.xlsx");
  }

}
