package com.pw.dome.pacing.subcategory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
interface PacingSubcategoryRepo extends JpaRepository<PacingSubcategoryEntity, PacingSubcategoryEntityPK> {
	
	List<PacingSubcategoryEntity> findAllByIdCategoryOrderByIdSubcategory(String category);	
}
