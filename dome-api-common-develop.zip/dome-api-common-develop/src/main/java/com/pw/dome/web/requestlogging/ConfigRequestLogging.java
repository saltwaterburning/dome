package com.pw.dome.web.requestlogging;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import lombok.Data;

@Configuration
@ConfigurationProperties(prefix = "dome.request-logging")
@Data
@Validated
public class ConfigRequestLogging {
    private boolean logToDatabase = true;
    private boolean logToFile = false;
    @Min(1)
    @Max(30)
    private long daysToKeepLog = 14;
    @NotBlank
    private String restRequestLogCleanupTaskCron = "0 0 2 * * ?";
}
