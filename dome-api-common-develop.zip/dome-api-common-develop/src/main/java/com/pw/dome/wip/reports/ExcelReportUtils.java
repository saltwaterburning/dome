package com.pw.dome.wip.reports;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Provides common Excel reporting utilities.
 * 
 * TODO Move to better package.
 */
public final class ExcelReportUtils {
  /**
   * Returns the days between today and the provided date.
   * 
   * @param date typically WIP induction date
   * @return the days between today and the provided date
   */
  public static Integer getDaysSinceToday(LocalDate date) {
    long days = ChronoUnit.DAYS.between(LocalDate.now(), date);
    return (int) Math.abs(days);
  }

  /**
   * Computes turn-around time (TAT) in days between two dates. The order of the arguments isn't
   * important.
   * 
   * @param date1 typically WIP ship date
   * @param date2 typically WIP induction date
   * 
   * @return computed TAT days or null
   */
  public static Integer getTATDays(LocalDate date1, LocalDate date2) {
    if (date1 == null || date2 == null) {
      return null;
    }

    long days = ChronoUnit.DAYS.between(date1, date2);
    return (int) Math.abs(days) + 1;
  }
}
