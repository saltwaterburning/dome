/**
 * 
 */
package com.pw.dome.util.converters;

import java.time.format.DateTimeFormatter;

import org.apache.commons.beanutils.Converter;
import org.apache.commons.beanutils.converters.AbstractConverter;

/**
 * Base implementation for Java 8 Date/Time API converters.
 * 
 * @see Converter
 * @see <a href="https://www.oracle.com/technical-resources/articles/java/jf14-date-time.html">Java SE 8 Date and Time</a>
 */
public abstract class AbstractDateTimeConverter extends AbstractConverter {
	private DateTimeFormatter formatter;

	/**
	 * 
	 */
	public AbstractDateTimeConverter() {
	}

	/**
	 * @param defaultValue
	 */
	public AbstractDateTimeConverter(Object defaultValue) {
		super(defaultValue);
	}

	/**
	 * @return the formatter
	 */
	public DateTimeFormatter getFormatter() {
		return formatter;
	}

	/**
	 * @param formatter the formatter to set
	 */
	public void setFormatter(DateTimeFormatter formatter) {
		this.formatter = formatter;
	}
}
