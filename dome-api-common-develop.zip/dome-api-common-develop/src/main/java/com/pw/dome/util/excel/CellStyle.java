package com.pw.dome.util.excel;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * Apache POI {@link org.apache.poi.ss.usermodel.CellStyle} wrapper containing all possible style
 * attributes.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder(toBuilder = true)
public final class CellStyle {
  private AlignH alignH;
  private AlignV alignV;
  private Border border;
  /** Approximate character width. */
  private Integer columnCharacterWith;
  private Colors fillBackgroundColor;
  private Colors fillForegroundColor;
  /**
   * Defaults to Default to SOLID_FOREGROUND if fillBackgroundColorColor or fillForegroundColorColor
   * is set.
   */
  private FillPattern fillPattern;
  private FontStyle fontStyle;
  private Integer fillBackgroundColorColor;
  private Integer fillForegroundColorColor;
  private Short indentation;
  private Short rotation;
  private String dataFormat;
  private boolean hidden;
  private boolean locked;
  private boolean quotePrefixed;
  private boolean shrinkToFit;
  private boolean wrapText;

  /**
   * @see {@link FillPatternType}
   */
  @Getter
  public static enum FillPattern {
    /** Wide dots */
    ALT_BARS(3),
    /** Large spots */
    BIG_SPOTS(9),
    /** Brick-like layout */
    BRICKS(10),
    /** Diamonds */
    DIAMONDS(16),
    /** Small fine dots */
    FINE_DOTS(2),
    /** Least Dots */
    LEAST_DOTS(18),
    /** Less Dots */
    LESS_DOTS(17),
    /** No background */
    NO_FILL(0),
    /** Solidly filled */
    SOLID_FOREGROUND(1),
    /** Sparse dots */
    SPARSE_DOTS(4),
    /** Squares */
    SQUARES(15),
    /** Thick backward facing diagonals */
    THICK_BACKWARD_DIAG(7),
    /** Thick forward facing diagonals */
    THICK_FORWARD_DIAG(8),
    /** Thick horizontal bands */
    THICK_HORZ_BANDS(5),
    /** Thick vertical bands */
    THICK_VERT_BANDS(6),
    /** Thin backward diagonal */
    THIN_BACKWARD_DIAG(13),
    /** Thin forward diagonal */
    THIN_FORWARD_DIAG(14),
    /** Thin horizontal bands */
    THIN_HORZ_BANDS(11),
    /** Thin vertical bands */
    THIN_VERT_BANDS(12);

    /** Codes are used by ExtendedFormatRecord in HSSF */
    private final short code;

    private FillPattern(int code) {
      this.code = (short) code;
    }

    public FillPatternType valueOf() {
      return FillPatternType.forInt(getCode());
    }
  }

  /**
   * @see {@link HorizontalAlignment}
   */
  @Getter
  public static enum AlignH {
    CENTER(HorizontalAlignment.CENTER),
    CENTER_SELECTION(HorizontalAlignment.CENTER_SELECTION),
    DISTRIBUTED(HorizontalAlignment.DISTRIBUTED),
    FILL(HorizontalAlignment.FILL),
    GENERAL(HorizontalAlignment.GENERAL),
    JUSTIFY(HorizontalAlignment.JUSTIFY),
    LEFT(HorizontalAlignment.LEFT),
    RIGHT(HorizontalAlignment.RIGHT);

    private final HorizontalAlignment alignment;

    private AlignH(HorizontalAlignment alignment) {
      this.alignment = alignment;
    }
  }

  /**
   * @see {@link VerticalAlignment}
   */
  @Getter
  public static enum AlignV {
    BOTTOM(VerticalAlignment.BOTTOM),
    CENTER(VerticalAlignment.CENTER),
    DISTRIBUTED(VerticalAlignment.DISTRIBUTED),
    JUSTIFY(VerticalAlignment.JUSTIFY),
    TOP(VerticalAlignment.TOP);

    private final VerticalAlignment alignment;

    private AlignV(VerticalAlignment alignment) {
      this.alignment = alignment;
    }
  }
}