/**
 * Provides utility classes.
 */
package com.pw.dome.util;