package com.pw.dome.web.requestlogging.filter;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

@Configuration
public class RequestLoggingFilterConfig {

	@Bean
	public CommonsRequestLoggingFilter logFilter() {
		CommonsRequestLoggingFilter filter = new RequestLoggingFilter();

//		filter.setAfterMessagePrefix("AfterProcessed[ ");
//		filter.setAfterMessageSuffix("] AfterProcessed");
//		filter.setBeforeMessagePrefix("BeforeProcessed[ ");
//		filter.setBeforeMessageSuffix(" ]BeforeProcessed");
		filter.setHeaderPredicate(h -> !h.equalsIgnoreCase(AUTHORIZATION));
		filter.setIncludeClientInfo(true);
		filter.setIncludeHeaders(true);
		filter.setIncludePayload(true);
		filter.setIncludeQueryString(true);
		filter.setMaxPayloadLength(8 * 1024);

		return filter;
	}
}