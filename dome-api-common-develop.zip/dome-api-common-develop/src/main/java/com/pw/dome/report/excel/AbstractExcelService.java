package com.pw.dome.report.excel;

import static org.apache.commons.io.FileUtils.ONE_MB;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import com.pw.dome.util.excel.ExcelWorkbook;

public abstract class AbstractExcelService {
  protected static boolean DEBUG = false;

  /**
   * Returns the Excel workbook as a {@code ByteArrayInputStream}. Optionally writes the workbook
   * into local PDF and XLSX files for debugging.
   * 
   * @param workbook Excel spreadsheet
   * @param baseName used as the local filename
   * @return the Excel workbook as a {@code ByteArrayInputStream}
   * @throws IOException upon an error
   */
  protected ByteArrayInputStream writeWorkbook(ExcelWorkbook workbook, String baseName)
      throws IOException {
    ByteArrayInputStream inputByteArray;

    if (DEBUG) {
      try {
        String pathName = "/tmp/" + baseName;
        workbook.saveAsXlsx(pathName + ".xlsx");
      } catch (IOException cause) {
        throw new RuntimeException(cause);
      }
    }

    try (ByteArrayOutputStream outputByteArray = new ByteArrayOutputStream((int) ONE_MB)) {
      workbook.saveAsXlsx(outputByteArray);
      inputByteArray = new ByteArrayInputStream(outputByteArray.toByteArray());
    }

    return inputByteArray;
  }
}
