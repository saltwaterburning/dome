package com.pw.dome.web.authorization;

import lombok.Data;

@Data
public class AuthDTO {
	private String token;
	private String userEmail;
}
