package com.pw.dome.exception;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.NestedRuntimeException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.util.WebUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * Returns {@code ResponseEntity}s with problem details approximating the RFC 7807 format for validation errors resulting from the {@code @Valid} annotation.
 * 
 * <pre>
 * <b>Invalid UserProfileResponse Input</b>
 * {
 *   "emailAddress": "new.user-001@pw.utc.com",
 *   "firstName": "",
 *   "lastName": "",
 *   "defaultEngineCenterID": "EC41",
 *   "defaultEngineTypeID": "ET719",
 *   "defaultLoadPage": "Calendar",
 *   "securityRole": "A",
 *   "rcm": true,
 *   "netManagement": false,
 *   ...
 * }
 * 
 * <b>Error Response</b>
 * {
 *   "status": "BAD_REQUEST",
 *   "message": "Validation failed for argument [0] in public ...
 *   "errors": [
 *     "firstName: The field may not be blank.",
 *     "securityRole: must match regex \"Administrator|Read|ReadWrite\"",
 *     "lastName: The field may not be blank."
 * ]}
 * 
 * </pre>
 *
 * @see <a href="https://blog.restcase.com/rest-api-error-handling-problem-details-response/" target="_blank">REST API Error Handling</a>
 * 
 * @author John De Lello
 */
@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
@Slf4j
public class RestExceptionHandler /* extends ResponseEntityExceptionHandler */ {

	@ExceptionHandler(Throwable.class)
    protected ResponseEntity<Object> handleRestException(Exception exception, WebRequest request) {
    	return handleExceptionInternal(exception, null, null, null, request);
    }
    
    private Throwable getCause(Exception ex) {
        Throwable cause = ex;
        while (cause.getCause() != null) {
            cause = cause.getCause();
        }

        return cause;
    }

    public ResponseEntity<Object> handleExceptionInternal(Exception exception, Object body, HttpHeaders headers, HttpStatus httpStatus, WebRequest request) {
        final Throwable cause = getCause(exception);
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        // TODO- Will this work with any encodings?
        byte[] bites = cause.getMessage() == null ? new byte[]{} : cause.getMessage().getBytes();
    	String exMessage = StringUtils.strip(new String(bites));
    	String clientMessage = exMessage;
    	final List<String> errors = new ArrayList<String>();

    	try {
    	    HttpServletRequest req = ((ServletWebRequest) request).getRequest();
    	    log.debug("Request [{}]", req.getRequestURL());
    	} catch (Exception castEx) {
    	    // prevent ANY errors bubbling up
    		log.error("Unable to cast WebRequest to HttpServletRequest. Error is: {}", castEx.getMessage());
    	}

    	if (cause instanceof AccessDeniedException) {
    	    status = HttpStatus.FORBIDDEN;
        } else if (cause instanceof AuthenticationException) {
            status = HttpStatus.UNAUTHORIZED;
        } else if (cause instanceof HttpStatusCodeException) {
            clientMessage = exMessage = ((HttpStatusCodeException) cause).getStatusText();
            status = HttpStatus.valueOf(((HttpStatusCodeException) cause).getStatusCode().value());
    	} else if (cause instanceof IllegalArgumentException) { // TODO ???
    	    status = HttpStatus.BAD_REQUEST;
        } else if (cause instanceof NestedRuntimeException) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
        } else if (cause instanceof MethodArgumentNotValidException) { // TODO ???
            status = HttpStatus.BAD_REQUEST;
            MethodArgumentNotValidException manvException = (MethodArgumentNotValidException)cause;
            
            for (final FieldError error : manvException.getBindingResult().getFieldErrors()) {
                errors.add(error.getField() + ": " + error.getDefaultMessage());
            }
            for (final ObjectError error : manvException.getBindingResult().getGlobalErrors()) {
                errors.add(error.getObjectName() + ": " + error.getDefaultMessage());
            }
        } else if (cause instanceof NullPointerException) { // TODO ???
            clientMessage = "System error. Unable to process request at this time. NullPointerException";
            log.error("Error: NullPointerException", cause.getClass().getCanonicalName(), cause.getMessage());
    	} else if (cause instanceof RuntimeException) { // TODO ???
    	    log.error("Error: [{}::{}]", cause.getClass().getCanonicalName(), cause.getMessage());
    	} else { // TODO ???
    	    // For all other exceptions, we don't want to send back a stack
    	    // message from the Exception. So make a generic message to send
    	    // back. The full exception message will be contained in the log
    	    clientMessage = "System error. Unable to process request at this time.";
    	    log.error("Error: [{}::{}]", cause.getClass().getCanonicalName(), cause.getMessage());
    	}

    	if (StringUtils.isEmpty(exMessage)) {
    	    exMessage = cause.getClass().getCanonicalName();
    	}

    	if (StringUtils.isEmpty(clientMessage)) {
    	    clientMessage = "System error. Unable to process request at this time.";
    	}

    	StringBuilder logMsg = new StringBuilder().append("****Exception caught...");
    	logMsg.append(" Status [").append(status).append("]");
    	logMsg.append(" Exception Message [").append(exMessage).append("]");
    	logMsg.append(" Client Message [").append(clientMessage).append("]");

    	log.error(logMsg.toString(), cause);

    	if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
			request.setAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE, cause, WebRequest.SCOPE_REQUEST);
			clientMessage = "Unexpected error. Unable to process this request.";
		}

    	ErrorResponse errorResponse = new ErrorResponse(status, clientMessage, errors.isEmpty() ? Arrays.asList(exMessage) : errors);

    	headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_JSON);

//		if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
//			request.setAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE, ex, WebRequest.SCOPE_REQUEST);
//		}
//		return new ResponseEntity<>(body, headers, status);
    	return new ResponseEntity<Object>(errorResponse, headers, status);
    }    
}
