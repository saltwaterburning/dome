package com.pw.dome.util.excel;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

public final class ExcelUtil {
  /**
   * Returns an array of Strings to be used within an Excel cell combo box.
   * 
   * @param list      combo box menu items
   * @param firstItem item to prepend to the returned list unless null
   * @param lastItem  item to append to the returned list unless null
   * @return an array of Strings to be used as an Excel cell combo box
   */
  public static String[] createComboBoxList(final List<String> list,
      String firstItem,
      String lastItem) {
    String[] itemsList;

    if (list.isEmpty()) {
      LinkedList<String> ll = new LinkedList<String>();
      if (firstItem != null) {
        ll.add(firstItem);
      }
      if (lastItem != null) {
        ll.add(lastItem);
      }

      itemsList = new String[ll.size()];
      ll.toArray(itemsList);
    } else {
      // Filter null entries and create LinkedList
      LinkedList<String> ll = list.stream()
//					                    .map(s->s == null ? "" : s)
          .filter(s -> s != null)
          .collect(Collectors.toCollection(LinkedList::new));
      if (firstItem != null && !StringUtils.equals(firstItem, ll.getFirst())) {
        ll.addFirst(firstItem);
      }
      if (lastItem != null && !StringUtils.equals(lastItem, ll.getLast())) {
        ll.addLast(lastItem);
      }
      itemsList = new String[ll.size()];
      ll.toArray(itemsList);
    }

    return itemsList;
  }
}
