package com.pw.dome.util.converters;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.apache.commons.beanutils.ConversionException;
import org.apache.commons.beanutils.ConvertUtilsBean;
import org.apache.commons.beanutils.Converter;
import org.apache.commons.beanutils.converters.AbstractConverter;

/**
 * Provides Java type conversion with added support for the Java 8 Date/Time API.
 * 
 * @see ConvertUtilsBean
 */
public enum ConverterBean {
	INSTANCE;

	private final String PLAN_MARKET = "com.pw.dome.mml.PlanMarket";
	private final String PLAN_MARKET_CONVERTER = "com.pw.dome.util.converters.PlanMarketConverter";
	private final String PLAN_TYPE = "com.pw.dome.mml.PlanType";
	private final String PLAN_TYPE_COVERTER = "com.pw.dome.util.converters.PlanTypeConverter";

	private final ConvertUtilsBean bean;

	private ConverterBean() {
		bean = new ConvertUtilsBean();
		// Register all Apache provided converters with null default values.
		bean.register(false, true, 0);
		// Register Java 8 Date/Time API converters with null default values.
		bean.register(new InstantConverter(null), Instant.class);
		bean.register(new LocalDateConverter(null), LocalDate.class);
		bean.register(new LocalDateTimeConverter(null), LocalDateTime.class);
		bean.register(new LocalTimeConverter(null), LocalTime.class);

		try {
			Class<?> enumClass = Class.forName(PLAN_MARKET);
			Class<?> converterClass = Class.forName(PLAN_MARKET_CONVERTER);
			AbstractConverter converter = (AbstractConverter) converterClass.getConstructor(Object.class).newInstance(new Object[] { null });
			bean.register(converter, enumClass);

			enumClass = Class.forName(PLAN_TYPE);
			converterClass = Class.forName(PLAN_TYPE_COVERTER);
			converter = (AbstractConverter) converterClass.getConstructor(Object.class).newInstance(new Object[] { null });
			bean.register(converter, enumClass);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
     * Convert the value to an object of the specified class (if
     * possible).
     *
	 * @param <T> The returned Class type
     * @param value Value to be converted (may be null)
     * @param targetType Class of the value to be converted to (must not be null)
     * @return The converted value
     *
     * @throws ConversionException if thrown by an underlying Converter
	 * 
	 * @see ConvertUtilsBean#convert(Object, Class)
	 */
	public <T> T convert(Class<T> targetType, Object value) {
		return targetType.cast(bean.convert(value, targetType));
	}

	/**
     * Convert the value to an object of the specified class (if
     * possible).
     *
     * @param value Value to be converted (may be null)
     * @param targetType Class of the value to be converted to (must not be null)
     * @return The converted value
     *
     * @throws ConversionException if thrown by an underlying Converter
	 * 
	 * @see ConvertUtilsBean#convert(Object, Class)
	 */
	public Object convert(final Object value, final Class<?> targetType) {
		return bean.convert(value, targetType);
	}

	public Converter getConverter(final Class<?> targetType) {
		return bean.lookup(targetType);
	}

	/**
     * Convert the specified value to an object of the specified class (if
     * possible).
     *
     * @param value Value to be converted (may be null)
     * @param clazz Java class to be converted to (must not be null)
     * @return The converted value
     *
     * @throws ConversionException if thrown by an underlying Converter
	 * 
	 * @see ConvertUtilsBean#convert(String, Class)
	 */
	public Object convert(final String value, final Class<?> clazz) {
		return bean.convert(value, clazz);
	}

	/**
     * Convert an array of specified values to an array of objects of the
     * specified class (if possible).
     *
     * @param values Array of values to be converted
     * @param clazz Java array or element class to be converted to (must not be null)
     * @return The converted value
     *
     * @throws ConversionException if thrown by an underlying Converter
	 * 
	 * @see ConvertUtilsBean#convert(String[], Class)
	 */
	public Object convert(final String[] values, final Class<?> clazz)  {
		return bean.convert(values, clazz);
	}
}
