package com.pw.dome.util;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static java.util.Objects.isNull;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.query.internal.QueryHelper;

/**
 * Indicates if a request for contains ALL or ANY wildcard indicator. DO NOT use directory for
 * engine centers or engine types.
 * 
 * @see QueryHelper
 */

final public class QueryUtils {
  public static String[] ALL_OR_ANY = { "ALL", "ANY" };

  public static boolean ignoreParam(List<?> params) {
    return isNull(params) || params.isEmpty();
  }

  public static boolean isAllOrAny(String param) {
    return StringUtils.equalsAnyIgnoreCase(param, ALL_OR_ANY);
  }

  public static boolean isAllOrAny(List<String> params) {
    return params.stream().anyMatch(p -> isAllOrAny(p));
  }

  public String ignoreCriteria(String param, String criteria) {
    String ignore = isAllOrAny(criteria) ? TRUE.toString() : FALSE.toString();
    return ignore;
  }

  public String ignoreCriteria(String param, List<String> criteria) {
    String ignore = isAllOrAny(criteria) ? TRUE.toString() : FALSE.toString();
    return ignore;
  }

}
