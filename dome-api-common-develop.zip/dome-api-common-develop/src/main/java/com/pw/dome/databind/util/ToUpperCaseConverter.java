package com.pw.dome.databind.util;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.util.StdConverter;

public class ToUpperCaseConverter extends StdConverter<String, String> {

  @Override
  public String convert(String value) {
    return StringUtils.upperCase(value);
  }
}