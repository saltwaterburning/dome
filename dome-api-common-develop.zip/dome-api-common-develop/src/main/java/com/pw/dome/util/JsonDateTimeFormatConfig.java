package com.pw.dome.util;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.Temporal;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.Module;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;

/**
 * Defines the formats used by JSON serializers/deserializers of Java 8 {@link Temporal} classes.
 *
 * @see {@link LocalDate}
 * @see {@link LocalDateTime}
 * @see {@link LocalTime}
 * @see {@link ObjectMapper}
 */
@Configuration
public class JsonDateTimeFormatConfig {
  private static final String LOCAL_DATE_FORMAT = "MM/dd/yyyy";
  private static final String LOCAL_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
  private static final String TIME_FORMAT = "kk:mm:ss";

  private static final DateTimeFormatter LOCAL_DATE_FORMATTER = DateTimeFormatter
      .ofPattern(LOCAL_DATE_FORMAT);
  private static final DateTimeFormatter LOCAL_DATE_TIME_FORMATTER = DateTimeFormatter
      .ofPattern(LOCAL_DATE_TIME_FORMAT);
  private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern(TIME_FORMAT);

  @Bean
  public Jackson2ObjectMapperBuilderCustomizer jsonCustomizer() {
    return builder -> {
//			builder.simpleDateFormat(JSON_DATE_TIME_FORMAT);
      builder.serializers(new LocalDateSerializer(LOCAL_DATE_FORMATTER));
      builder.serializers(new LocalDateTimeSerializer(LOCAL_DATE_TIME_FORMATTER));
      builder.serializers(new LocalTimeSerializer(TIME_FORMATTER));
    };
  }

  @Bean
  public Module jsonMapperJava8DateTimeModule() {
    SimpleModule module = new SimpleModule();

    module.addDeserializer(LocalDate.class, new JsonDeserializer<LocalDate>() {
      @Override
      public LocalDate deserialize(JsonParser jsonParser,
          DeserializationContext deserializationContext)
          throws IOException {
        // ISO (yyyy-MM-dd) format?
        if (StringUtils.contains(jsonParser.getValueAsString(), "-")) {
          return LocalDate.parse(jsonParser.getValueAsString(), DateTimeFormatter.ISO_LOCAL_DATE);
        }

        // Legacy (MM/dd/yyyy) format.
        return LocalDate.parse(jsonParser.getValueAsString(), LOCAL_DATE_FORMATTER);
      }
    });

    module.addDeserializer(LocalDateTime.class, new JsonDeserializer<LocalDateTime>() {
      @Override
      public LocalDateTime deserialize(JsonParser jsonParser,
          DeserializationContext deserializationContext)
          throws IOException {
        // Relaxed ISO 8601 format?
        if (StringUtils.contains(jsonParser.getValueAsString(), " ")) {
          return LocalDateTime.parse(jsonParser.getValueAsString(), LOCAL_DATE_TIME_FORMATTER);
        }

        // Strict ISO 8601 format.
        return LocalDateTime.parse(jsonParser.getValueAsString(), DateTimeFormatter.ISO_LOCAL_DATE_TIME);
      }
    });

    module.addDeserializer(LocalTime.class, new JsonDeserializer<LocalTime>() {
      @Override
      public LocalTime deserialize(JsonParser jsonParser,
          DeserializationContext deserializationContext)
          throws IOException {
        return LocalTime.parse(jsonParser.getValueAsString(), TIME_FORMATTER);
      }
    });

    return module;
  }
}