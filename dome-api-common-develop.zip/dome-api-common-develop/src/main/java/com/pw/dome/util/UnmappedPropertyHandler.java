package com.pw.dome.util;

import static java.util.concurrent.TimeUnit.MILLISECONDS;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * Logs a warning each time {@link ObjectMapper} is unable to deserialize a JSON property name. This
 * occurs when the POJO is missing the matching property. An unmapped warning is logged no more than
 * once each 60 minutes per property name to minimize excessive logging.
 */
@Slf4j
public class UnmappedPropertyHandler {
  private static int WARN_INTERVAL_MINUTES = 60;
  private static ConcurrentMap<String, String> unmapped = new ConcurrentHashMap<>();
  private static long initialTimeMillis = System.currentTimeMillis();

  public UnmappedPropertyHandler() {
    ;
  }

  @JsonAnyGetter
  public Map<String, String> getUnmapped() {
    return unmapped;
  }

  public boolean hasUnmapped() {
    return !unmapped.isEmpty();
  }

  @JsonAnySetter
  public void setUnmapped(String propertyName, String propertyValue) {
    long currentTimeMillis = System.currentTimeMillis();
    String fqcn = getClass().getName(); // Fully Qualified Class Name
    String key = fqcn + "." + propertyName;

    // Allow same unmapped JSON property warning once per 60 minutes.
    if (unmapped.containsKey(key)
        && MILLISECONDS.toMinutes(currentTimeMillis - initialTimeMillis) >= WARN_INTERVAL_MINUTES) {
      initialTimeMillis = currentTimeMillis;
      unmapped.clear();
    }

    unmapped.computeIfAbsent(key, k -> {
      log.warn("Unmapped JSON property: {}, POJO: {}, Value: \"{}\"",
          propertyName,
          fqcn,
          propertyValue);
      return propertyValue;
    });
  }
}
