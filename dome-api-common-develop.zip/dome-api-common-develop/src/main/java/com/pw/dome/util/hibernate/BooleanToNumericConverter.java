package com.pw.dome.util.hibernate;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import org.springframework.lang.Nullable;

/**
 * Default entity converter applied to all boolean columns unless overridden
 * using the @Convert annotation.
 */
@Converter(autoApply = true) // The default for all boolean columns
public class BooleanToNumericConverter implements AttributeConverter<Boolean, Integer> {

	@Nullable
	@Override
	public Integer convertToDatabaseColumn(Boolean attribute) {
		return isNull(attribute) || !attribute ? 0 : 1;
	}

	@Nullable
	@Override
	public Boolean convertToEntityAttribute(Integer dbData) {
		return nonNull(dbData) && dbData.equals(1) ? TRUE : FALSE;
	}
}
