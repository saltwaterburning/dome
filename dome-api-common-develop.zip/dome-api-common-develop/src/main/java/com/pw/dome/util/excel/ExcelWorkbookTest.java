package com.pw.dome.util.excel;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Calendar;

import org.apache.poi.xssf.usermodel.XSSFRichTextString;

import com.pw.dome.util.excel.CellStyle.AlignH;
import com.pw.dome.util.excel.FontStyle.FontNames;

/**
 *
 * https://products.aspose.com/cells/java https://www.qoppa.com/officeconvert/
 * https://www.tableau.com/asset/excel-and-tableau-beautiful-partnership?utm_campaign=Prospecting-CORE-ALL-ALL-ALL-ALL&utm_medium=Paid+Social&utm_source=Quora&utm_campaign_id=2017049&utm_language=EN&utm_country=USCA&kw={keyword}&adgroup=CTX-Core-Quora&adused=native&matchtype={matchtype}&placement={placement}&creative=&dclid=CMa8m42-iOYCFRSDyAodCoUOoQ
 * https://www.javadocx.com/download_trial
 * 
 */
public class ExcelWorkbookTest {
  private ExcelWorkbook workbook = new ExcelWorkbook();

  public ExcelWorkbookTest() {
    ;
  }

  public void BoldCenterHeaderTest() throws IOException {
    FontStyle boldFont = FontStyle.builder().bold(true).build();
    CellStyle boldStyle = CellStyle.builder().alignH(AlignH.CENTER).fontStyle(boldFont).build();
    CellStyle dateStyle = CellStyle.builder().dataFormat("mm/dd/yy hh:mm").build();
    CellStyle globalStyle = new CellStyle();

    CellValues headerValues = CellValues.builder()
        .add()
        .add("Byte")
        .add("Calendar")
        .add("Date")
        .add("Double")
        .add("LocalDate")
        .add("RichTextString")
        .add("String")
        .build();
    CellValues cellValues = CellValues.builder()
        .add()
        .add(Byte.valueOf("127"))
        .add(dateStyle, Calendar.getInstance())
        .add(Double.MAX_VALUE)
        .add(dateStyle, LocalDate.now())
        .add(new XSSFRichTextString("Rich Text String"))
        .add("Test String")
        .build();

    ExcelSheet sheet = workbook.getExcelSheet("Test1", globalStyle);
    sheet.withCells(boldStyle, headerValues);
    sheet.withNextRow().withCells(cellValues);
    sheet.withAutoSizedColumns();
  }

  public void BoldAlternateColumnRow10Test() throws IOException {
    FontStyle boldFont = FontStyle.builder().bold(true).fontName(FontNames.ARIAL).build();
    CellStyle boldStyle = CellStyle.builder().fontStyle(boldFont).build();
    CellStyle globalStyle = new CellStyle();
    ExcelSheet sheet = workbook.getExcelSheet("Test2", globalStyle);
    String[] values = { "Blank", "Byte", "Calendar", "Date", "Double", "LocalDate",
        "RichTextString", "String" };
    boolean bold = true;
    for (String value : values) {
      sheet.withRow(10)
          .withCells(bold ? boldStyle : globalStyle, CellValues.builder().add(value).build());
      bold = !bold;
    }

    sheet.withAutoSizedColumns();
  }

  public void write(String pathname) throws IOException {
    FileOutputStream stream = new FileOutputStream(new File(pathname));
    workbook.saveAsXlsx(stream);
    stream.close();
  }

//	public static void main(String[] args) throws IOException {
//		ExcelWorkbookTest test = new ExcelWorkbookTest();
//		test.BoldCenterHeaderTest();
//		test.BoldAlternateColumnRow10Test();
//		test.write("/tmp/test.xlsx");
//	}
}
