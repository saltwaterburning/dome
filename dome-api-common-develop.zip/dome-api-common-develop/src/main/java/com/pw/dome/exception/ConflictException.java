package com.pw.dome.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpStatusCodeException;

/**
 * @author John De Lello
 */
final public class ConflictException extends HttpStatusCodeException {
	private static final long serialVersionUID = 6259841862148108152L;

	public ConflictException(String message) {
		super(HttpStatus.CONFLICT, message);
	}
}
