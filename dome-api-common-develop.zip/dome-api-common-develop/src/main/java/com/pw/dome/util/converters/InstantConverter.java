package com.pw.dome.util.converters;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.commons.beanutils.ConversionException;

public final class InstantConverter extends AbstractDateTimeConverter {

	public InstantConverter() {
		super();
		init();
	}

	public InstantConverter(Object defaultValue) {
		super(defaultValue);
		init();
	}

	private void init() {
		// Requires ZoneId.
		setFormatter(DateTimeFormatter.ISO_INSTANT.withZone(ZoneId.systemDefault()));
	}

    @Override
    protected <T> T convertToType(Class<T> type, Object value) throws Throwable {
    	final Class<?> sourceType = value.getClass();

    	if (sourceType.equals(Date.class)) {
    		Instant instant = ((Date)value).toInstant();
    		return type.cast(instant);
    	}
    	else if (sourceType.equals(java.sql.Date.class)) {
    		Instant instant = ((Date)value).toInstant();
    		return type.cast(instant);
    	} else if (sourceType.equals(Timestamp.class)) {
    		Instant instant = ((Date)value).toInstant();
    		return type.cast(instant);
    	} else if (sourceType.equals(String.class)) {
    		ZonedDateTime zdt = ZonedDateTime.parse((String)value, getFormatter());
    		Instant instant = zdt.toInstant();
    		return type.cast(instant);
    	}

    	final String msg = getClass().getName() + " does not support '" + sourceType.getName() + "' to '"
    			+ type.getName() + "' conversion.";

    	throw new ConversionException(msg);
    }

    @Override
    protected Class<?> getDefaultType() {
        return Instant.class;
    }
}
