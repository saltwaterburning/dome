package com.pw.dome.web.requestlogging;

/**
 * @author John De Lello
 */
public interface RequestLoggingService {
	RestRequestLogEntity save(RestRequestLogEntity requestLog);
	int doRestRequestLogCleanup();
}
