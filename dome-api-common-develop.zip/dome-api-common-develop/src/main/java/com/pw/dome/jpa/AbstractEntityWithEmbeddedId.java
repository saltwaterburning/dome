package com.pw.dome.jpa;

import java.util.Objects;

import org.springframework.data.domain.Persistable;

import jakarta.persistence.PostLoad;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Transient;

/**
 * Used for read-write lookup data tables. Any subclasses with a non-unique ID
 * should create a composite key object or override the equals() and hashCode()
 * method using the fields which make the entity unique.
 *
 * @param <ID> the entity identifier type
 * 
 * @see https://www.artima.com/articles/how-to-write-an-equality-method-in-java
 * @see https://thorben-janssen.com/ultimate-guide-to-implementing-equals-and-hashcode-with-hibernate/
 * @see https://thorben-janssen.com/spring-data-jpa-state-detection/
 */
public abstract class AbstractEntityWithEmbeddedId<ID> implements Persistable<ID> {

	@Transient
	private boolean isNew = true;

	@Override
	public boolean isNew() {
		return isNew;
	}

	@PostLoad
	@PrePersist
	void trackNotNew() {
		this.isNew = false;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(getId());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof AbstractEntityWithEmbeddedId)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		AbstractEntityWithEmbeddedId<?> other = (AbstractEntityWithEmbeddedId<?>) obj;
		return getId() != null && getId().equals(other.getId());
	}

	/**
	 * @see Persistable#getId()
	 */
	@Override
	public abstract ID getId();

}
