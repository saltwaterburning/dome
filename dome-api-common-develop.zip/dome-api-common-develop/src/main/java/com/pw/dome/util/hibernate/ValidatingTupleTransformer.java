package com.pw.dome.util.hibernate;

import static java.util.Objects.nonNull;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.beanutils.ConvertUtilsBean;
import org.apache.commons.beanutils.Converter;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.query.TupleTransformer;

import com.pw.dome.util.converters.ConverterBean;

/**
 * Transforms the query row tuples (named values) into the specified JavaBean.
 * This class delegates to {@link ConverterBean} to handle tuple to field value conversion.
 *
 * Validation performed...
 * <ul>
 * <li>The query alias names are not specified multiple times.
 * <li>Every query alias name has a matching JavaBean field.
 * <li>Every JavaBean property has a matching query alias name.
 * </ul>
 * 
 * @see ConvertUtilsBean
 */
public final class ValidatingTupleTransformer<T> implements TupleTransformer<T> {
	private final Map<String, JavaBeanParameters> _fieldParams;
	private final Class<T> _rowClass;
	private final PropertyFilter _tupleFilter;

	private Constructor<T>	_rowConstructor;
	private boolean _validated;

	/**
     * Instantiate the RowTupleTransformer.
     *
     * @param rowClass the JavaBean which to map the row tuples into.
     */
    public ValidatingTupleTransformer(final Class<T> rowClass) {
    	this(rowClass, null);
	}

	/**
     * Instantiate the RowTupleTransformer.
     *
     * @param rowClass the JavaBean which to map the row tuples into.
	 * @param tupleFilter allow tuple filtering
	 */
	public ValidatingTupleTransformer(final Class<T> rowClass, final PropertyFilter tupleFilter) {
		_fieldParams = new ConcurrentHashMap<>();
        this._rowClass = rowClass;
        this._tupleFilter = tupleFilter;
        initialize();
    }

	@Override
	public T transformTuple(final Object[] tuple, final String[] aliases) {
			if (!_validated) {
				validate(aliases);
			}

			Object[] constructorParams = new Object[tuple.length];

			// Initialize constructor parameters with it's matching tuple (named value).
			for (int i = 0; i < aliases.length; i++) {
				String tupleName = aliases[i];
				JavaBeanParameters fieldParam = _fieldParams.get(tupleName);
				Object tupleValue = tuple[i];
			    if (nonNull(_tupleFilter)) {
			    	tupleValue = _tupleFilter.filter(tupleName, tupleValue);
			    }

			    Object fieldValue = fieldParam.convertToFieldValue(tupleValue);
			    int fieldIndex = fieldParam.fieldIndex();
			    constructorParams[fieldIndex] = fieldValue;
			}

		try { // Instantiate JavaBean for query row.
			_rowConstructor.setAccessible(true); // Allow using non-public constructor.
			Object result = _rowConstructor.newInstance(constructorParams);
			return _rowClass.cast(result);
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
				| InvocationTargetException e) {
			throw new IllegalArgumentException(e);
		}
	}

    private void validate(String[] aliases) {
		Set<String> allAliases = new HashSet<>();
		for (String alias : aliases) {
			if (!allAliases.add(alias)) {
				String msg = String.format("The query contains the %s alias multiple times.", alias);
				throw new IllegalArgumentException(msg);
			}
			else if (!_fieldParams.containsKey(alias)) {
				String hint = "";
				String isName = "is" + alias.substring(0, 1).toUpperCase() + alias.substring(1);
				if (_fieldParams.containsKey(isName)) {
					hint = ", try " + isName + ",";
				}
				String msg = String.format("The property for query alias '%s' doesn't exist %s on %s",
						alias, hint, _rowClass.getName());
				throw new IllegalArgumentException(msg);
			}
		}

		if (!Objects.equals(allAliases.size(), _fieldParams.size()) ||
				!CollectionUtils.containsAll(allAliases, _fieldParams.keySet())) {
			Collection<String> fields = CollectionUtils.disjunction(allAliases, _fieldParams.keySet());
			String msg = String.format("The %s bean has unused properties: %s",
					_rowClass.getName(), fields.toString());
			throw new IllegalArgumentException(msg);
		} else {
			_validated = true;
		}
    }

	/**
	 * Extracts metadata from the JavaBean class to enable mapping
	 * the query data to JavaBean properties.
	 */
	private void initialize() {
		Field[] allFields = _rowClass.getDeclaredFields();
		Class<?>[] allConstructorArgs = new Class<?>[allFields.length];

		for (int index = 0; index < allFields.length; ++index) {
			Field field = allFields[index];
			String fieldName = field.getName();
			Class<?> fieldType = field.getType();
			allConstructorArgs[index] = fieldType;
			if (fieldName.startsWith("is")) {
				// boolean isGood- Lombok generates isGood() and setGood(boolean good)
				if (fieldType.isPrimitive() && fieldType.equals(boolean.class)) {
					fieldName = fieldName.substring(2, 3).toLowerCase() + fieldName.substring(3);
				} else {
					; // Boolean isGood- Lombok generates getIsGood() and setIsGood(boolean good)
				}
			}

			Converter fieldConverter =  ConverterBean.INSTANCE.getConverter(fieldType);
			JavaBeanParameters fieldParam = new JavaBeanParameters(index, fieldName, fieldType, fieldConverter);
			_fieldParams.put(fieldName, fieldParam);
		}

		try {
			_rowConstructor = _rowClass.getConstructor(allConstructorArgs);
		} catch (NoSuchMethodException | SecurityException e) {
			throw new IllegalArgumentException(e);
		}
	}
}
