package com.pw.dome.common.oas;

/**
 * 
 */
public interface ApiOperations {
	interface Tags {
		String ADMIN              = "Administration";
		String AUTH               = "Authorization";
        String ENGINES            = "Engines";
        String ENG_ASSETS         = "Engine Assets";
        String ENG_COMMENTS       = "Engine Comments";
        String ENG_CONTRACTS      = "Engine Contracts";
        String ENG_DATA_MATCH     = "Engine Data Match";
        String ENG_GROUPS         = "Engine Groups";
        String ENG_MANUAL         = "Engine Manual";
        String ENG_MODELS         = "Engine Models";
        String ENG_MODULES        = "Engine Modules";
        String ENG_ODIN           = "Engine ODIN";
        String ENG_REMOVED        = "Engine Removed";
        String ENG_TYPES          = "Engine Types";
        String EXAMPLE            = "Example";
		String INDUCTION_CALENDAR = "Induction Calendar";
        String INDUCTION_PLANNING = "Induction Planning";
        String MRO                = "MRO Collab";
        String PW                 = "P&W";
        String REPORTS            = "Reports";
        String SHOP_DATES         = "ShopDates";
        String SLOTS              = "Slotting";
        String SPLASH             = "Splash";
        String VENDORS            = "Vendors";
        String WIP                = "Work In Progress";
        String WS                = "Workscope";
	}
}
