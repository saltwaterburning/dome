package com.pw.dome.report.excel;

import static com.pw.dome.report.excel.ReportConstants.DATE_FORMAT;
import static com.pw.dome.util.excel.CellStyle.AlignH.CENTER;
import static com.pw.dome.util.excel.CellStyle.AlignH.LEFT;

import com.pw.dome.util.excel.Border;
import com.pw.dome.util.excel.Border.BorderStyles;
import com.pw.dome.util.excel.CellStyle;
import com.pw.dome.util.excel.Colors;
import com.pw.dome.util.excel.FontStyle;

/**
 * All {@link CellStyles} are bordered currently.
 *
 */
public interface CellStyles {
  interface NO_BORDER {
    ; // When needed.
  }

  interface FONTS {
    FontStyle BOLD_FONT = FontStyle.builder().bold(true).build();
    FontStyle FONT_DARK_RED = FontStyle.builder().color(Colors.DARK_RED).build();
  }

  CellStyle BOLD_BLUE_CENTERED = CellStyle.builder()
      .alignH(CENTER)
      .border(Border.of(BorderStyles.THIN))
      .fillForegroundColorColor(ReportConstants.TRUE_BLUE)
      .fontStyle(FONTS.BOLD_FONT)
      .build();

  CellStyle BOLD_BLUE_LEFT = CellStyle.builder()
      .alignH(LEFT)
      .border(Border.of(BorderStyles.THIN))
      .fillForegroundColorColor(ReportConstants.TRUE_BLUE)
      .fontStyle(FONTS.BOLD_FONT)
      .build();

  CellStyle BOLD_CENTERED = CellStyle.builder()
      .alignH(CENTER)
      .border(Border.of(BorderStyles.THIN))
      .fontStyle(FONTS.BOLD_FONT)
      .build();

  CellStyle BOLD_LEFT_HEADER = CellStyle.builder()
      .alignH(LEFT)
      .border(Border.of(BorderStyles.THIN))
      .fontStyle(FONTS.BOLD_FONT)
      .wrapText(true)
      .build();

  CellStyle BOLD_CENTERED_DATE = CellStyle.builder()
      .alignH(CENTER)
      .border(Border.of(BorderStyles.THIN))
      .dataFormat(DATE_FORMAT)
      .build();

  CellStyle PLAIN_CENTERED = CellStyle.builder()
      .alignH(CENTER)
      .border(Border.of(BorderStyles.THIN))
      .build();

  CellStyle PLAIN_LEFT = CellStyle.builder()
      .alignH(LEFT)
      .border(Border.of(BorderStyles.THIN))
      .build();

  CellStyle PLAIN_LEFT_DARK_RED = CellStyle.builder()
      .alignH(LEFT)
      .border(Border.of(BorderStyles.THIN))
      .fontStyle(FONTS.FONT_DARK_RED)
      .build();

  CellStyle PLAIN_LEFT_WRAPPED = CellStyle.builder()
      .alignH(LEFT)
      .border(Border.of(BorderStyles.THIN))
      .wrapText(true)
      .build();

  CellStyle PLAIN_CENTER_RED = CellStyle.builder()
      .alignH(CENTER)
      .border(Border.of(BorderStyles.THIN))
      .fillForegroundColorColor(ReportConstants.RED)
      .build();

  CellStyle PLAIN_CENTER_GREEN = CellStyle.builder()
      .alignH(CENTER)
      .border(Border.of(BorderStyles.THIN))
      .fillForegroundColorColor(ReportConstants.GREEN)
      .build();

  CellStyle PLAIN_CENTERED_DATE = CellStyle.builder()
      .alignH(CENTER)
      .border(Border.of(BorderStyles.THIN))
      .dataFormat(DATE_FORMAT)
      .build();

  CellStyle PLAIN_LEFT_DATE = CellStyle.builder()
      .alignH(LEFT)
      .border(Border.of(BorderStyles.THIN))
      .dataFormat(DATE_FORMAT)
      .build();

  CellStyle PLAIN_LEFT_DATE_WRAPPED = CellStyle.builder()
	      .alignH(LEFT)
	      .border(Border.of(BorderStyles.THIN))
	      .dataFormat(DATE_FORMAT)
	      .wrapText(true)
	      .build();

  CellStyle PLAIN_LEFT_DATE_TIME = CellStyle.builder()
      .alignH(LEFT)
      .border(Border.of(BorderStyles.THIN))
      .dataFormat(ReportConstants.DATE_TIME_FORMAT)
      .build();

  CellStyle BOLD_LEFT = CellStyle.builder()
      .alignH(LEFT)
      .border(Border.of(BorderStyles.THIN))
      .fontStyle(FONTS.BOLD_FONT)
      .build();

  /**
   * Typically used for headers since text wrapping is enabled.
   */
  interface HEADERS {
    CellStyle BOLD_CENTERED = CellStyle.builder()
        .alignH(CENTER)
        .border(Border.of(BorderStyles.THIN))
        .fontStyle(FONTS.BOLD_FONT)
        .wrapText(true)
        .build();

    CellStyle BOLD_LEFT = CellStyle.builder()
            .alignH(LEFT)
            .border(Border.of(BorderStyles.THIN))
            .fontStyle(FONTS.BOLD_FONT)
            .wrapText(true)
            .build();

    CellStyle BOLD_CENTERED_BLUE = CellStyle.builder()
        .alignH(CENTER)
        .border(Border.of(BorderStyles.THIN))
        .fillForegroundColorColor(ReportConstants.TRUE_BLUE)
        .fontStyle(FONTS.BOLD_FONT)
        .wrapText(true)
        .build();

    CellStyle BOLD_LEFT_BLUE = CellStyle.builder()
            .alignH(LEFT)
            .border(Border.of(BorderStyles.THIN))
            .fillForegroundColorColor(ReportConstants.TRUE_BLUE)
            .fontStyle(FONTS.BOLD_FONT)
            .wrapText(true)
            .build();
  }
}
