package com.pw.dome.util.excel;

import org.apache.poi.ss.usermodel.IndexedColors;

import lombok.Getter;

/**
 * Apache POI {@link IndexedColors} wrapper.
 */
@Getter
public enum Colors {
  AUTOMATIC(IndexedColors.AUTOMATIC),
  BLACK(IndexedColors.BLACK),
  BLUE(IndexedColors.BLUE),
  BLUE1(IndexedColors.BLUE1),
  BLUE_GREY(IndexedColors.BLUE_GREY),
  BRIGHT_GREEN(IndexedColors.BRIGHT_GREEN),
  CORNFLOWER_BLUE(IndexedColors.CORNFLOWER_BLUE),
  DARK_BLUE(IndexedColors.DARK_BLUE),
  DARK_GREEN(IndexedColors.DARK_GREEN),
  DARK_RED(IndexedColors.DARK_RED),
  LIGHT_BLUE(IndexedColors.LIGHT_BLUE),
  LIGHT_CORNFLOWER_BLUE(IndexedColors.LIGHT_CORNFLOWER_BLUE),
  LIGHT_GREEN(IndexedColors.LIGHT_GREEN),
  LIGHT_TURQUOISE(IndexedColors.LIGHT_TURQUOISE),
  LIGHT_TURQUOISE1(IndexedColors.LIGHT_TURQUOISE1),
  OLIVE_GREEN(IndexedColors.OLIVE_GREEN),
  PALE_BLUE(IndexedColors.PALE_BLUE),
  RED(IndexedColors.RED),
  ROYAL_BLUE(IndexedColors.ROYAL_BLUE),
  SEA_GREEN(IndexedColors.SEA_GREEN),
  SKY_BLUE(IndexedColors.SKY_BLUE),
  TURQUOISE(IndexedColors.TURQUOISE),
  TURQUOISE1(IndexedColors.TURQUOISE1),
  WHITE(IndexedColors.WHITE);

  private final IndexedColors indexedColor;

  private Colors(IndexedColors indexedColor) {
    this.indexedColor = indexedColor;
  }
}
