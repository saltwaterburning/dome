package com.pw.dome.util.excel;

import org.apache.poi.common.usermodel.fonts.FontCharset;
import org.apache.poi.ss.usermodel.Font;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * This class wraps non-exhaustive commonly used font attributes.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public final class FontStyle {
  private boolean bold;
  private Charset charset;
  private Colors color;
  private Integer colorColor;
  private FontNames fontName;

  private Short height;

  private Short heightInPoints;
  private boolean italic;
  private boolean strikeOut;
  private TypeOffset typeOffset;
  private Underline underline;

  @Getter
  public static enum Charset {
    ANSI(FontCharset.ANSI),
    DEFAULT(FontCharset.DEFAULT);

    private final FontCharset fontCharset;

    private Charset(FontCharset fontCharset) {
      this.fontCharset = fontCharset;
    }
  }

  @Getter
  public static enum FontNames {
    ARIAL("Arial"),
    COURIER("Courier"),
    COURIER_NEW("Courier New");

    private final String name;

    private FontNames(String name) {
      this.name = name;
    }
  }

  @Getter
  public static enum TypeOffset {
    NONE(Font.SS_NONE),
    SUB(Font.SS_SUB),
    SUPER(Font.SS_SUPER);

    private final short offset;

    private TypeOffset(short offset) {
      this.offset = offset;
    }
  }

  @Getter
  public static enum Underline {
    DOUBLE(Font.U_DOUBLE),
    DOUBLE_ACCOUNTING(Font.U_DOUBLE_ACCOUNTING),
    NONE(Font.U_NONE),
    SINGLE(Font.U_SINGLE),
    SINGLE_ACCOUNTING(Font.U_SINGLE_ACCOUNTING);

    private final byte value;

    private Underline(byte value) {
      this.value = value;
    }
  }
}