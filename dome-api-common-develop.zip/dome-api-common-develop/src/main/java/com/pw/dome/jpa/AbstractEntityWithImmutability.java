package com.pw.dome.jpa;

import static java.util.Objects.isNull;

import java.util.Objects;

import jakarta.persistence.EntityManager;

import org.springframework.data.domain.Persistable;

/**
 * Used for read-only lookup data tables. The entity should be use the {@code Immutable} annotation.
 * Any subclasses with a non-unique ID should create a composite key object or override the equals()
 * and hashCode() method using the fields which make the entity unique.
 *
 * @param <ID> the entity identifier type
 */
public abstract class AbstractEntityWithImmutability<ID> implements Persistable<ID> {

  @Override
  public int hashCode() {
    return Objects.hash(getId());
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (!(obj instanceof AbstractEntityWithImmutability))
      return false;
    AbstractEntityWithImmutability<?> other = (AbstractEntityWithImmutability<?>) obj;
    return Objects.equals(getId(), other.getId());
  }

  /**
   * @see Persistable#getId()
   */
  @Override
  public abstract ID getId();

  /**
   * When true {@link EntityManager#persist(Object)} is invoked. When false
   * {@link EntityManager#merge(Object)} is invoked.
   * 
   * @see Persistable#isNew()
   */
  @Override
  public boolean isNew() {
    return isNull(getId());
  }
}
