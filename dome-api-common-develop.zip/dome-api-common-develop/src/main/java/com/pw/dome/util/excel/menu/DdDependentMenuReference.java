package com.pw.dome.util.excel.menu;

import java.util.Objects;

import com.pw.dome.util.excel.ExcelWorkbook;

import lombok.Builder;

/**
 * Provides reference to a drop-down menu group ({@link DdGroupMenuReference}) upon which to depend.
 * The menu item(s) to display within an Excel cell will depend upon the associated drop-down menu
 * group item selection. A dependent drop-down menu is also known as a cascading drop-down list,
 * cascading menu or drop-down list.
 * 
 * @see ExcelWorkbook#createDropDownMenus(boolean, java.util.List)
 */
@Builder
public record DdDependentMenuReference(DdGroupMenuReference dropDownGroupName,
    String selectedValue) {
  public DdDependentMenuReference {
	  Objects.requireNonNull(dropDownGroupName);
    // selectedValue is nullable
  }
}
