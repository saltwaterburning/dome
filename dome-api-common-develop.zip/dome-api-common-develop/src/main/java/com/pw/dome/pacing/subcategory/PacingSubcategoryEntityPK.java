package com.pw.dome.pacing.subcategory;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Embeddable
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PacingSubcategoryEntityPK implements Serializable {

	private static final long serialVersionUID = -7318219496426145689L;

	@Column(name="CATEGORY")
	private String category;

	@Column(name="SUBCATEGORY")
	private String subcategory;

	@Override
	public int hashCode() {
		return Objects.hash(category, subcategory);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof PacingSubcategoryEntityPK))
			return false;
		PacingSubcategoryEntityPK other = (PacingSubcategoryEntityPK) obj;
		return Objects.equals(category, other.category) && Objects.equals(subcategory, other.subcategory);
	}

}