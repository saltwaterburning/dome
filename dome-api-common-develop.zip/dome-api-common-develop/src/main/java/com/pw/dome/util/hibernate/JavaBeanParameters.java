package com.pw.dome.util.hibernate;

import org.apache.commons.beanutils.Converter;

public record JavaBeanParameters(int fieldIndex, String fieldName, Class<?> fieldType, Converter tupleConverter) {

	public Object convertToFieldValue(Object tupleValue) {
		return tupleConverter.convert(fieldType, tupleValue);
	}
}
