package com.pw.dome.util.excel;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.poi.ss.usermodel.Row.MissingCellPolicy.CREATE_NULL_AS_BLANK;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import jakarta.validation.UnexpectedTypeException;

import org.apache.commons.collections4.IteratorUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellAddress;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.pw.dome.util.TimeUtils;
import com.pw.dome.util.excel.CellStyle.FillPattern;
import com.pw.dome.util.excel.CellValues.BlankValue;
import com.pw.dome.util.excel.menu.DdDependentMenuReference;
import com.pw.dome.util.excel.menu.DdGroupMenuReference;
import com.pw.dome.util.excel.menu.DdMenuReference;

import lombok.extern.slf4j.Slf4j;

/**
 * Spreadsheet base implementation using Apache POI Excel. Caches spreadsheet resources for reuse
 * which are limited by POI.
 */
@Slf4j
public abstract class AbstractExcelSheet {
  private final CellStyle cellStyle;

  /** Block Sheet.autoSizeColumn(int columnIndex) when ColumnCharacterWith is set. */
  private final Map<Integer, Integer> columnCharacterWidths;
  private Row currentRow;
  /**
   * Cache drop-down list sheet resource.
   */
  private final Map<String, DataValidationConstraint> dropDownLists;

  // row.getPhysicalNumberOfCells()
  private int numberOfColumns;

  private final XSSFSheet sheet;

  private final ExcelWorkbook workbook;

  protected AbstractExcelSheet(ExcelWorkbook workbook, XSSFSheet sheet, CellStyle cellStyle) {
    this.workbook = workbook;
    this.sheet = sheet;
    this.cellStyle = cellStyle;
    dropDownLists = new HashMap<>();
    columnCharacterWidths = new HashMap<>();
    setCurrentRow(cellStyle, 0);
  }

  protected void addMergedRegion(int firstCol, int firstRow, int lastCol, int lastRow) {
    org.apache.poi.ss.util.CellRangeAddress address = new org.apache.poi.ss.util.CellRangeAddress(
        firstRow,
        lastRow,
        firstCol,
        lastCol);
    sheet.addMergedRegion(address);
  }

  protected void addNewRow() {
    addNewRow(cellStyle);
  }

  protected void addNewRow(CellStyle rowStyle) {
    setCurrentRow(rowStyle, currentRow.getRowNum() + 1);
  }

  protected void addPicture(String image, int firstCol, int firstRow, int lastCol, int lastRow) {
    workbook.addPicture(sheet, image, firstCol, firstRow, lastCol, lastRow);
  }

  protected void autoSize(int... columns) {
    Arrays.stream(columns).forEach(i -> autoSizeColumn(i));
  }

  protected void autoSizeColumnsAtRow(int rowNumber) {
	  Row row = sheet.getRow(rowNumber);
	  if (nonNull(row)) {
		  int columns = IteratorUtils.size(row.cellIterator());
		  for (int column = 0; column < columns; ++column) {
			  autoSizeColumn(column);
		  }
	  }
  }

  protected void autoSizeAll() {
	  for (int column = 0; column < numberOfColumns; ++column) {
		  autoSizeColumn(column);
	  }
  }

  private void autoSizeColumn(int column) {
	  boolean useMergedCells = true;
	  if (!columnCharacterWidths.containsKey(column)) {
		  sheet.autoSizeColumn(column, useMergedCells);
	  }
  }

  protected void autoSizeRow(int rowNumber) {
	  Row row = sheet.getRow(rowNumber);
	  if (nonNull(row)) {
		  int height = row.getHeight() * 2;
		  row.setHeight(Integer.valueOf(height).shortValue());
//		  row.setZeroHeight(false);
	  }
  }

  private void createCellComboBox(Cell cell, String[] listOfValues) {
    try {
      CellAddress address = cell.getAddress();

      DataValidationHelper dvHelper = sheet.getDataValidationHelper();
      String key = Arrays.toString(listOfValues);

      if (key.length() > 255) {
        String msg = "A valid formula or a list of values must be less than or equal to 255 characters (including separators).";
        log.warn(msg);
        return;
      }

      // Throws- A valid formula or a list of values must be less than or equal to 255
      // characters (including separators).
//			DataValidationConstraint dvConstraint = dropDownLists.computeIfAbsent(key, n->new MyXSSFDataValidationConstraint(listOfValues));
      DataValidationConstraint dvConstraint = dropDownLists.computeIfAbsent(key,
          n -> dvHelper.createExplicitListConstraint(listOfValues));
      // return new XSSFDataValidationConstraint(ValidationType.LIST, listFormula);
      CellRangeAddressList addressList = new CellRangeAddressList(address.getRow(),
          address.getRow(),
          address.getColumn(),
          address.getColumn());
      DataValidation dataValidation = dvHelper.createValidation(dvConstraint, addressList);

      dataValidation.setEmptyCellAllowed(true);
      dataValidation.setShowErrorBox(true);
      dataValidation.setSuppressDropDownArrow(true);
      sheet.addValidationData(dataValidation);
    } catch (Exception e) {
      throw new RuntimeException("Unexpected error: listOfValues: " + Arrays.toString(listOfValues),
          e);
    }
  }

  private org.apache.poi.ss.usermodel.CellStyle createCellStyle(final CellStyle cellStyle) {
    Border border;
    boolean flag = false;
    FontStyle fontStyle;
    Integer rgb;
    String fmt;
    XSSFCellStyle style = (XSSFCellStyle) sheet.getWorkbook().createCellStyle();
    if (nonNull(cellStyle.getAlignH())) {
      style.setAlignment(cellStyle.getAlignH().getAlignment());
    }
    if (nonNull(border = cellStyle.getBorder())) {
      style.setBorderBottom(border.getBottomStyle().valueOf());
      style.setBorderLeft(border.getLeftStyle().valueOf());
      style.setBorderRight(border.getRightStyle().valueOf());
      style.setBorderTop(border.getTopStyle().valueOf());
      if (nonNull(border.getBottomColor())) {
        style.setBottomBorderColor(border.getBottomColor().getIndexedColor().getIndex());
      }
      if (nonNull(border.getLeftColor())) {
        style.setLeftBorderColor(border.getLeftColor().getIndexedColor().getIndex());
      }
      if (nonNull(border.getRightColor())) {
        style.setRightBorderColor(border.getRightColor().getIndexedColor().getIndex());
      }
      if (nonNull(border.getTopColor())) {
        style.setTopBorderColor(border.getTopColor().getIndexedColor().getIndex());
      }
    }
    if (nonNull(fmt = cellStyle.getDataFormat())) {
      style.setDataFormat(getDataFormat(fmt));
    }
    if (nonNull(cellStyle.getFillBackgroundColor())) {
      style.setFillBackgroundColor(cellStyle.getFillBackgroundColor().getIndexedColor().getIndex());
    }
    if (nonNull(rgb = cellStyle.getFillBackgroundColorColor())) {
      flag = true;
      style.setFillBackgroundColor(workbook.getRGBColor(rgb));
    }
    if (nonNull(cellStyle.getFillForegroundColor())) {
      style.setFillForegroundColor(cellStyle.getFillForegroundColor().getIndexedColor().getIndex());
    }
    if (nonNull(rgb = cellStyle.getFillForegroundColorColor())) {
      flag = true;
      style.setFillForegroundColor(workbook.getRGBColor(rgb));
    }
    if (nonNull(cellStyle.getFillPattern()) || flag) {
      FillPattern fp = isNull(cellStyle.getFillPattern()) ? FillPattern.SOLID_FOREGROUND
          : cellStyle.getFillPattern();
      style.setFillPattern(fp.valueOf());
    }
    if (nonNull(fontStyle = cellStyle.getFontStyle())) {
      String key = fontStyle.toString();
      Font font = workbook.getFonts().computeIfAbsent(key, k -> createFont(fontStyle));
      style.setFont(font);
    }
    style.setHidden(cellStyle.isHidden());
    if (nonNull(cellStyle.getIndentation())) {
      style.setIndention(cellStyle.getIndentation());
    }
    style.setLocked(cellStyle.isLocked());
    style.setQuotePrefixed(cellStyle.isQuotePrefixed());
    if (nonNull(cellStyle.getRotation())) {
      style.setRotation(cellStyle.getRotation());
    }
    style.setShrinkToFit(cellStyle.isShrinkToFit());
    if (nonNull(cellStyle.getAlignV())) {
      style.setVerticalAlignment(cellStyle.getAlignV().getAlignment());
    }
    style.setWrapText(cellStyle.isWrapText());
    return style;
  }

  private Font createFont(FontStyle fontStyle) {
    Font font = sheet.getWorkbook().createFont();
    font.setBold(fontStyle.isBold());
    if (nonNull(fontStyle.getCharset())) {
      font.setCharSet(fontStyle.getCharset().getFontCharset().getNativeId());
    }
    if (nonNull(fontStyle.getColor())) {
      font.setColor(fontStyle.getColor().getIndexedColor().getIndex());
    }
    // TODO
//		if (nonNull(fontStyle.getColorColor())) {
//			int rgb = fontStyle.getColorColor();
//			workbook.getRGBColor(rgb);
//			font.setColor(fontStyle.getColor().getIndexedColor().getIndex());
//		}
    if (nonNull(fontStyle.getHeight())) {
      font.setFontHeight(fontStyle.getHeight());
    }
    if (nonNull(fontStyle.getHeightInPoints())) {
      font.setFontHeightInPoints(fontStyle.getHeightInPoints());
    }
    if (nonNull(fontStyle.getFontName())) {
      font.setFontName(fontStyle.getFontName().getName());
    }
    font.setItalic(fontStyle.isItalic());
    font.setStrikeout(fontStyle.isStrikeOut());
    if (nonNull(fontStyle.getTypeOffset())) {
      font.setTypeOffset(fontStyle.getTypeOffset().getOffset());
    }
    if (nonNull(fontStyle.getUnderline())) {
      font.setUnderline(fontStyle.getUnderline().getValue());
    }
    return font;
  }

  protected void createFreezePane(int colSplit, int rowSplit) {
    sheet.createFreezePane(colSplit, rowSplit);
  }

  protected void createFreezePane(int colSplit, int rowSplit, int leftmostColumn, int topRow) {
    sheet.createFreezePane(colSplit, rowSplit, leftmostColumn, topRow);
  }

  public boolean getBoolean(int colNum) {
    return currentRow.getCell(colNum, CREATE_NULL_AS_BLANK).getBooleanCellValue();
  }

  public boolean getBoolean(int rowNum, int colNum) {
    return sheet.getRow(rowNum).getCell(colNum, CREATE_NULL_AS_BLANK).getBooleanCellValue();
  }

  private Cell getCell(int cellNum, CellStyle cellStyle) {
    Cell cell = currentRow.getCell(cellNum);
    if (isNull(cell)) {
      cell = currentRow.createCell(cellNum);
    }
    String key = cellStyle.toString();
    org.apache.poi.ss.usermodel.CellStyle style = workbook.getCellStyles()
        .computeIfAbsent(key, k -> createCellStyle(cellStyle));
    cell.setCellStyle(style);
    return cell;
  }

  public int getColumnCount() {
    Row row = sheet.getRow(0);
    if (nonNull(row)) {
      return row.getLastCellNum();
    }

    return 0;
  }

  protected Row getCurrentRow() {
    return this.currentRow;
  }

  public int getCurrentRowNum() {
    return currentRow.getRowNum();
  }

  public short getDataFormat(String formatStr) {
	  XSSFDataFormat format = sheet.getWorkbook().createDataFormat();
	  return format.getFormat(formatStr);
  }

  public Integer getInteger(int colNum) {
    Double dbl = currentRow.getCell(colNum, CREATE_NULL_AS_BLANK).getNumericCellValue();
    return isNull(dbl) ? null : dbl.intValue();
  }

  public Integer getInteger(int rowNum, int colNum) {
    Double dbl = sheet.getRow(rowNum).getCell(colNum, CREATE_NULL_AS_BLANK).getNumericCellValue();
    return isNull(dbl) ? null : dbl.intValue();
  }

  public LocalDate getLocalDate(int colNum) {
    try {
      Date date = currentRow.getCell(colNum, CREATE_NULL_AS_BLANK).getDateCellValue();
      if (nonNull(date)) {
        return TimeUtils.toLocalDate(date);
      }
    } catch (Exception e) {
      int rowNum = currentRow.getRowNum();
      String colLetter = CellReference.convertNumToColString(colNum);
      String msg = String.format("Bad Date at row %d, column %s", rowNum + 1, colLetter);
      try {
        String header = sheet.getRow(0).getCell(colNum).getStringCellValue();
        msg = String
            .format("%s Date conversion error at row %d, column %s", header, rowNum + 1, colLetter);
      } catch (Exception ignore) {
        ; // Ignore
      }

      throw new IllegalArgumentException(msg);
    }

    return null;
  }

  public LocalDate getLocalDate(int rowNum, int colNum) {
    try {
      Date date = sheet.getRow(rowNum).getCell(colNum, CREATE_NULL_AS_BLANK).getDateCellValue();
      if (nonNull(date)) {
        return TimeUtils.toLocalDate(date);
      }
    } catch (Exception e) {
      String colLetter = CellReference.convertNumToColString(colNum);
      String msg = String.format("Bad Date at row %d, column %s", rowNum + 1, colLetter);
      try {
        String header = sheet.getRow(0).getCell(colNum).getStringCellValue();
        msg = String
            .format("%s Date conversion error at row %d, column %s", header, rowNum + 1, colLetter);
      } catch (Exception ignore) {
        ; // Ignore
      }

      throw new IllegalArgumentException(msg);
    }

    return null;
  }

  public LocalDateTime getLocalDateTime(int colNum) {
    try {
      Date date = currentRow.getCell(colNum, CREATE_NULL_AS_BLANK).getDateCellValue();
      if (nonNull(date)) {
        return TimeUtils.toLocalDateTime(date);
      }
    } catch (Exception e) {
      int rowNum = currentRow.getRowNum();
      String colLetter = CellReference.convertNumToColString(colNum);
      String msg = String.format("Bad Date at row %d, column %s", rowNum + 1, colLetter);
      try {
        String header = sheet.getRow(0).getCell(colNum).getStringCellValue();
        msg = String
            .format("%s Date conversion error at row %d, column %s", header, rowNum + 1, colLetter);
      } catch (Exception ignore) {
        ; // Ignore
      }

      throw new IllegalArgumentException(msg);
    }

    return null;
  }

  public LocalDateTime getLocalDateTime(int rowNum, int colNum) {
    try {
      Date date = sheet.getRow(rowNum).getCell(colNum, CREATE_NULL_AS_BLANK).getDateCellValue();
      if (nonNull(date)) {
        return TimeUtils.toLocalDateTime(date);
      }
    } catch (Exception e) {
      String colLetter = CellReference.convertNumToColString(colNum);
      String msg = String.format("Bad Date at row %d, column %s", rowNum + 1, colLetter);
      try {
        String header = sheet.getRow(0).getCell(colNum).getStringCellValue();
        msg = String
            .format("%s Date conversion error at row %d, column %s", header, rowNum + 1, colLetter);
      } catch (Exception ignore) {
        ; // Ignore
      }

      throw new IllegalArgumentException(msg);
    }

    return null;
  }

  public Long getLong(int colNum) {
    Double dbl = currentRow.getCell(colNum, CREATE_NULL_AS_BLANK).getNumericCellValue();
    return isNull(dbl) ? null : dbl.longValue();
  }

  public Long getLong(int rowNum, int colNum) {
    Double dbl = sheet.getRow(rowNum).getCell(colNum, CREATE_NULL_AS_BLANK).getNumericCellValue();
    return isNull(dbl) ? null : dbl.longValue();
  }

  private Cell getNewCell(CellStyle cellStyle) {
    int cellNum = currentRow.getLastCellNum();
    if (cellNum < 0) {
      cellNum = 0;
    }
    return getCell(cellNum, cellStyle);
  }

  // Less efficient than using numberOfColumns property.
  @SuppressWarnings("unused")
  private int getNumberOfColumns() {
	  int first = sheet.getFirstRowNum();
	  int last = sheet.getLastRowNum();
	  
	  int numberOfColumns = 0;
	  for (int i = first; i < last; ++i) {
		  Row row = sheet.getRow(i);
		  if (nonNull(row)) {
			  int columns = IteratorUtils.size(row.cellIterator());
			  numberOfColumns = Math.max(numberOfColumns, columns);
		  }
	  }

	  return numberOfColumns;
  }

  public Double getNumeric(int colNum) {
    return currentRow.getCell(colNum, CREATE_NULL_AS_BLANK).getNumericCellValue();
  }

  public Double getNumeric(int rowNum, int colNum) {
    return sheet.getRow(rowNum).getCell(colNum, CREATE_NULL_AS_BLANK).getNumericCellValue();
  }

  public int getPhysicalNumberOfRows() {
    return sheet.getPhysicalNumberOfRows();
  }

  public XSSFSheet getPoiSheet() {
    return this.sheet;
  }

  private Row getRow(int rowNum, CellStyle cellStyle) {
    Row row = sheet.getRow(rowNum);
    if (isNull(row)) {
      row = sheet.createRow(rowNum);
    }
    String key = cellStyle.toString();
    org.apache.poi.ss.usermodel.CellStyle style = workbook.getCellStyles()
        .computeIfAbsent(key, k -> createCellStyle(cellStyle));
    row.setRowStyle(style);
    return row;
  }

  public int getRowCount() {
    return sheet.getPhysicalNumberOfRows();
  }
  public String getSheetName() {
    return sheet.getSheetName();
  }

  public String getString(int colNum) {
    Cell cell = currentRow.getCell(colNum, CREATE_NULL_AS_BLANK);
    CellType type = cell.getCellType();
    // If user types numbers into an empty cell Excel make it numeric.
    if (CellType.NUMERIC.equals(type)) {
      Integer i = getInteger(colNum);
      return Objects.toString(i);
    }

    return currentRow.getCell(colNum, CREATE_NULL_AS_BLANK).getStringCellValue();
  }

  public String getString(int rowNum, int colNum) {
    Cell cell = sheet.getRow(rowNum).getCell(colNum, CREATE_NULL_AS_BLANK);
    CellType type = cell.getCellType();
    // If user types numbers into an empty cell Excel make it numeric.
    if (CellType.NUMERIC.equals(type)) {
      Integer i = getInteger(colNum, rowNum);
      return Objects.toString(i);
    }

    return cell.getStringCellValue();
  }

  public void protectSheet(String password) {
    sheet.protectSheet(password);
  }

  protected void setCellValues(CellStyle cellStyle, CellValues cellValues) {
    final int size = cellValues.getValues().size();

    numberOfColumns = Math.max(numberOfColumns, size);

    for (int i = 0; i < size; ++i) {
      CellStyle style = cellValues.getStyles().get(i);
      Object value = cellValues.getValues().get(i);
      Cell cell = getNewCell(isNull(style) ? cellStyle : style);

      setColumnCharacterWith(style, cell);

	  if (value instanceof BlankValue) {
        cell.setBlank();
      } else if (value instanceof Boolean) {
        cell.setCellValue(BooleanUtils.toBoolean((Boolean) value));
      } else if (value instanceof Byte) {
        cell.setCellValue((Byte) value);
      } else if (value instanceof Calendar) {
        cell.setCellValue((Calendar) value);
      }
      else if (value instanceof DdMenuReference) {
        DdMenuReference name = (DdMenuReference) value;
        CellRangeAddress cra = new CellRangeAddress(cell.getRowIndex(),
            cell.getRowIndex(),
            cell.getColumnIndex(),
            cell.getColumnIndex());

        workbook.addDropDownMenu(name, this, cra);
        cell.setCellValue(name.selectedValue());
      } else if (value instanceof DdDependentMenuReference) {
        DdDependentMenuReference name = (DdDependentMenuReference) value;
        CellRangeAddress cra = new CellRangeAddress(cell.getRowIndex(),
            cell.getRowIndex(),
            cell.getColumnIndex(),
            cell.getColumnIndex());

        workbook.addDropDownMenu(name, this, cra);
        cell.setCellValue(name.selectedValue());
      } else if (value instanceof DdGroupMenuReference) {
        DdGroupMenuReference list = (DdGroupMenuReference) value;
        CellRangeAddress cra = new CellRangeAddress(cell.getRowIndex(),
            cell.getRowIndex(),
            cell.getColumnIndex(),
            cell.getColumnIndex());

        workbook.addDropDownMenu(list, this, cra);
        cell.setCellValue(list.selectedValue());
      } else if (value instanceof ComboBoxInfo) {
        ComboBoxInfo cbInfo = (ComboBoxInfo) value;
        if (cbInfo.getValue() instanceof Boolean) {
          boolean truth = BooleanUtils.toBoolean((Boolean) cbInfo.getValue());
          cell.setCellValue(cbInfo.getItemsList()[truth ? 1 : 0]);
        } else if (cbInfo.getValue() instanceof BlankValue) {
          cell.setCellValue("");
        } else if (cbInfo.getValue() instanceof String) {
          cell.setCellValue((String) cbInfo.getValue());
        } else {
          throw new UnexpectedTypeException("Unexpcected data type: " + cbInfo.getValue());
        }

        createCellComboBox(cell, cbInfo.getItemsList());
      } else if (value instanceof Double) {
        cell.setCellValue((Double) value);
      } else if (value instanceof Integer) {
        cell.setCellValue(((Integer) value).doubleValue());
      } else if (value instanceof Long) {
        cell.setCellValue(((Long) value).doubleValue());
      } else if (value instanceof LocalDate) {
        cell.setCellValue((LocalDate) value);
      } else if (value instanceof LocalDateTime) {
        cell.setCellValue((LocalDateTime) value);
      } else if (value instanceof RichTextString) {
        cell.setCellValue((RichTextString) value);
      } else if (value instanceof String) {
    	  cell.setCellValue((String) value);
      } else {
        String msg = String.format("Unexpected argument type: %s", String.valueOf(value));
        throw new IllegalArgumentException(msg);
      }
    }
  }

  protected void setCellValues(CellValues cellValues) {
    setCellValues(cellStyle, cellValues);
  }

  private void setColumnCharacterWith(CellStyle style, Cell cell) {
      Integer width;

      if (nonNull(style) && nonNull(width = style.getColumnCharacterWith())) {
          Integer columnIdx = cell.getColumnIndex();
          Integer columnCharWidth = 256 * width;
          columnCharacterWidths.put(columnIdx, columnCharWidth);
          sheet.setColumnWidth(columnIdx, columnCharWidth);

          CellStyle cs = isNull(style) ? cellStyle : style;
          if (nonNull(cs) && !cs.isWrapText()) {
            CellRangeAddress address = new CellRangeAddress(cell.getRowIndex(),
                cell.getRowIndex(),
                cell.getColumnIndex(),
                cell.getColumnIndex());
            log.warn("ColumnCharacterWith is set but WrapText isn't at {}.",
                address.formatAsString(getSheetName(), true));
          }
        }
  }

  protected void setCurrentColumn(int columnNumber) {
    for (int i = 0; i < columnNumber - 1; ++i) {
      Cell cell = currentRow.getCell(i);
      if (isNull(cell)) {
        currentRow.createCell(i);
      }
    }
  }

  protected void setCurrentRow(CellStyle rowStyle, int rowNumber) {
    Row row = getRow(rowNumber, rowStyle);
    this.currentRow = row;
  }

  protected void setCurrentRow(int rowNumber) {
    setCurrentRow(cellStyle, rowNumber);
  }

  public void setLandscape(boolean landscape) {
    sheet.getPrintSetup().setLandscape(landscape);
  }

  /**
   * Sets a page break at the current row. Breaks occur above the current row and left of the
   * specified column inclusive.
   * 
   */
  protected void setRowBreak() {
    sheet.setRowBreak(getCurrentRowNum());
  }

  /**
   * Sets a page break at the indicated row number. Breaks occur above the specified row and left of
   * the specified column inclusive.
   * 
   * @param rowNumber the indicated row number
   */
  protected void setRowBreak(int rowNumber) {
    sheet.setRowBreak(rowNumber);
  }

  protected void setRowHeight(short lines) {
    Row row = getCurrentRow();
    if (lines == -1) {
        row.setHeight(lines);
    } else {
      float height = row.getHeightInPoints() * lines;
      row.setHeightInPoints(height);
//    	short height = (short) (row.getHeight() * lines);
//    	row.setHeight(height);
    }
  }

  public void setTabColor(int rgb) {
	  XSSFColor xssfColor = workbook.getRGBColor(rgb);
	  sheet.setTabColor(xssfColor);
  }
}
