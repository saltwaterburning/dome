package com.pw.dome.web.authorization.jwt;

import static com.pw.dome.web.authorization.jwt.Consts.EXCLUDED_ENDPOINTS;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Objects;
import java.util.stream.Collectors;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.auth0.jwt.exceptions.JWTVerificationException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pw.dome.exception.ErrorResponse;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AuthorizationTokenProcessingFilter extends OncePerRequestFilter {

	@Autowired
	private AuthorizationTokenProvider tokenProvider;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		try {
			// Use lazy instantiation since this filter can't be
			// autoWired into WebSecurityConfiguration.
			if (Objects.isNull(tokenProvider)) {
				ServletContext servletContext = request.getServletContext();
				WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
				this.tokenProvider = webApplicationContext.getBean(AuthorizationTokenProvider.class);
			}

			String jwt = tokenProvider.getBearerToken(request);

			if (tokenProvider.validateToken(jwt)) {
				Authentication userAuth = tokenProvider.getUserAuthentication(jwt);
				SecurityContextHolder.getContext().setAuthentication(userAuth);
			}

			filterChain.doFilter(request, response);
		} catch (JWTVerificationException ex) {
			log.error("Authentiction error.", ex);
			log.error(httpServletRequestToString(request));

			if (response.isCommitted()) {
				return;
			}

			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.UNAUTHORIZED,
					                                        ex.getMessage());

			response.setStatus(UNAUTHORIZED.value());
			String jsonStr = new ObjectMapper().writeValueAsString(errorResponse);
			response.getWriter().write(jsonStr);
		}
	}
	private String httpServletRequestToString(HttpServletRequest request) {
	    StringBuilder sb = new StringBuilder();

	    sb.append("Request Method = [" + request.getMethod() + "], ");
	    sb.append("Request URL Path = [" + request.getRequestURL() + "], ");

	    String headers =
	        Collections.list(request.getHeaderNames()).stream()
	            .map(headerName -> headerName + " : " + Collections.list(request.getHeaders(headerName)) )
	            .collect(Collectors.joining(", "));

	    if (headers.isEmpty()) {
	        sb.append("Request headers: NONE,");
	    } else {
	        sb.append("Request headers: ["+headers+"],");
	    }

	    String parameters =
	        Collections.list(request.getParameterNames()).stream()
	            .map(p -> p + " : " + Arrays.asList( request.getParameterValues(p)) )
	            .collect(Collectors.joining(", "));             

	    if (parameters.isEmpty()) {
	        sb.append("Request parameters: NONE.");
	    } else {
	        sb.append("Request parameters: [" + parameters + "].");
	    }

	    return sb.toString();
	}

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
		String path = request.getServletPath();

		boolean exclude = Arrays.stream(EXCLUDED_ENDPOINTS)
				.anyMatch(e -> new AntPathMatcher().match(e, request.getServletPath()));

		if (exclude) {
            log.debug("shouldNotFilter(): {}, User: {}", path, request.getRemoteUser());
		}

		return exclude;
	}

    @Override
    protected boolean shouldNotFilterAsyncDispatch() {
        return true;
    }

	@Override
    protected boolean shouldNotFilterErrorDispatch() {
        return true;
    }
}
