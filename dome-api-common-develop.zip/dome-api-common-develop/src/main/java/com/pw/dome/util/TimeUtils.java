package com.pw.dome.util;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Date;

/**
 * Utilities to handle conversion between legacy {@link java.util.Date}, {@link java.sql.Date} and
 * {@link Timestamp} classes and the new Java 8 time classes.
 * <p>
 * Conversions which result in time information being lost aren't implemented e.g. {@link Date} to
 * {@link LocalDate}.
 * </p>
 * 
 * @see <a href="https://www.oracle.com/technical-resources/articles/java/jf14-date-time.html"
 *      target="_blank">Java SE 8 Date and Time</a>
 */
final public class TimeUtils {
  public static Date toDate(final LocalDateTime date) {
    if (date != null) {
      long millis = date.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
      return new Date(millis);
    }

    return null;
  }

  public static LocalDate toLocalDate(final Date date) {
    if (date != null) {
      return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    return null;
  }

  public static LocalDate toLocalDate(final java.sql.Date date) {
    if (date != null) {
      return date.toLocalDate();
    }

    return null;
  }

  public static LocalDateTime toLocalDateTime(final Date date) {
    if (date != null) {
      return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    return null;
  }

  public static LocalDateTime toLocalDateTime(final Instant instant) {
    if (instant != null) {
      return LocalDateTime.ofInstant(instant, ZoneOffset.systemDefault());
    }

    return null;
  }

  public static LocalDateTime toLocalDateTime(final Timestamp timestamp) {
    if (timestamp != null) {
      return timestamp.toLocalDateTime();
    }

    return null;
  }

  public static java.sql.Date toSqlDate(final LocalDate localDate) {
    if (localDate != null) {
      return java.sql.Date.valueOf(localDate);
    }

    return null;
  }

  private TimeUtils() {
    throw new IllegalAccessError();
  }
}
