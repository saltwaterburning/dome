package com.pw.dome.util.excel.examples;

import com.pw.dome.report.excel.CellStyles;
import com.pw.dome.util.excel.CellStyle;
import com.pw.dome.util.excel.CellValues;
import com.pw.dome.util.excel.ExcelSheet;
import com.pw.dome.util.excel.ExcelWorkbook;

/**
 * Demonstrates fixed column width with auto-wrapping of words for long strings.
 */
public class ExampleUseOfFixedColumnCharcterWidth {

  public static void main(String[] args) throws Exception {
    int columnChacterWidth = 22;
    String notes = "0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 ";

    CellStyle blueHeader = CellStyles.HEADERS.BOLD_CENTERED_BLUE;
    CellStyle plainLeft = CellStyles.PLAIN_LEFT;
    CellStyle fixedColumnWidth = CellStyles.PLAIN_LEFT_WRAPPED.toBuilder()
        .columnCharacterWith(columnChacterWidth)
        .build();

    ExcelWorkbook workbook = new ExcelWorkbook(true);
    ExcelSheet sheet = workbook.getExcelSheet("FixedWidthExample");

    CellValues values = CellValues.builder()
        .add(blueHeader, "Header1")
        .add(blueHeader, "Auto-wrapped\nNotes\nExample")
        .add(blueHeader, "Header3")
        .build();
    sheet.withCells(values);

    values = CellValues.builder()
        .add(plainLeft, "Value 1")
        .add(fixedColumnWidth, notes)
        .add(plainLeft, "Value for column 3")
        .build();
    sheet.withNextRow().withCells(values);

    sheet.withAutoSizedColumns();
    workbook.saveAsXlsx("/tmp/fixed-column-width-example.xlsx");
  }

}
