package com.pw.dome.util.converters;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Date;

import org.apache.commons.beanutils.ConversionException;

public final class LocalDateTimeConverter extends AbstractDateTimeConverter {
	public LocalDateTimeConverter() {
		super();
		init();
	}

	public LocalDateTimeConverter(Object defaultValue) {
		super(defaultValue);
		init();
	}

	private void init() {
		DateTimeFormatter fmt =
				new DateTimeFormatterBuilder()
				.parseCaseInsensitive()
				.append(DateTimeFormatter.ISO_LOCAL_DATE)
				.appendLiteral('T')
				.append(DateTimeFormatter.ISO_LOCAL_TIME).toFormatter();
		setFormatter(fmt);
	}

    @Override
    protected <T> T convertToType(Class<T> type, Object value) throws Throwable {
    	final Class<?> sourceType = value.getClass();

    	if (sourceType.equals(Date.class)) {
    		Instant instant = ((Date)value).toInstant();
    		return type.cast(instant.atZone(ZoneId.systemDefault()).toLocalDateTime());
    	}
    	else if (sourceType.equals(java.sql.Date.class)) {
    		Instant instant = ((java.sql.Date)value).toInstant();
    		return type.cast(instant.atZone(ZoneId.systemDefault()).toLocalDateTime());
    	} else if (sourceType.equals(Timestamp.class)) {
    		Instant instant = ((Timestamp)value).toInstant();
    		return type.cast(instant.atZone(ZoneId.systemDefault()).toLocalDateTime());
    	} else if (sourceType.equals(String.class)) {
    		return type.cast(LocalDateTime.parse((String)value, getFormatter()));
    	}

    	final String msg = getClass().getName() + " does not support '" + sourceType.getName() + "' to '"
    			+ type.getName() + "' conversion.";

    	throw new ConversionException(msg);
    }

    @Override
    protected Class<?> getDefaultType() {
        return LocalDateTime.class;
    }
}
