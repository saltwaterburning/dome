package com.pw.dome.common.oas;

import com.dbds.common.rs.RESTfulResource;

/**
 * 
 * 
 * @see <a href="https://github.com/OAI/OpenAPI-Specification/blob/master/versions/3.0.3.md" target="_blank">OpenAPI Specification</a>
 */
public abstract class BaseRESTfulResource implements ApiOperations, ApiResponses, RESTfulResource {
    ; // No behavior needed yet.
}
