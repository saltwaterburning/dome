package com.pw.dome.util.excel;

import static com.pw.dome.util.excel.NameHelper.normalize;
import static java.util.Objects.isNull;
import static org.apache.poi.ss.usermodel.SheetVisibility.VERY_HIDDEN;
import static org.apache.poi.ss.usermodel.SheetVisibility.VISIBLE;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Name;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.pw.dome.util.excel.menu.DdDependentMenuReference;
import com.pw.dome.util.excel.menu.DdGroupMenuContext;
import com.pw.dome.util.excel.menu.DdGroupMenuReference;
import com.pw.dome.util.excel.menu.DdMenu;
import com.pw.dome.util.excel.menu.DdMenuReference;

import lombok.extern.slf4j.Slf4j;

/**
 * Provides a simple wrapper for Excel on top of Apache POI. Caches spreadsheet
 * resources, like fonts and cell style, for reuse which are limited by POI.
 */
@Slf4j
public final class ExcelWorkbook {

	private static record MenuDetails(String headerRange, String headerArea) {
	}

	private static byte byteOf(int integer) {
		return (byte) integer;
	};

	private final boolean landscapeMode;
	private final boolean XSSF = true;

	/**
	 * Cache to avoid POI {@link Workbook}
	 * {@link org.apache.poi.ss.usermodel.CellStyle} limits.
	 */
	private final Map<String, org.apache.poi.ss.usermodel.CellStyle> cellStyles;

	private final Map<String, MenuDetails> ddMenuDetails = new LinkedHashMap<>();

	// private final Map<String, String> ddGroupMenuAddresses = new
	// LinkedHashMap<>();
//	private final Map<String, String> ddGroupMenus = new LinkedHashMap<>();
	private final Map<String, String> ddMenuNames = new LinkedHashMap<>();

	/**
	 * Caches {@link Font} associated with
	 * {@link org.apache.poi.ss.usermodel.CellStyle}s.
	 */
	private final Map<String, Font> fonts;
	private final XSSFWorkbook poiWorkbook;

	private final Map<String, ExcelSheet> sheets;

	/**
	 * Instantiates an Excel workbook which may have many spreadsheets.
	 */
	public ExcelWorkbook() {
		try {
			cellStyles = new HashMap<>();
			fonts = new HashMap<>();
			poiWorkbook = (XSSFWorkbook) WorkbookFactory.create(XSSF);

			sheets = new LinkedHashMap<>();
			this.landscapeMode = false;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Instantiates an Excel workbook which may have many spreadsheets.
	 * 
	 * @param landscapeMode
	 */
	public ExcelWorkbook(final boolean landscapeMode) {
		try {
			cellStyles = new HashMap<>();
			fonts = new HashMap<>();
			poiWorkbook = (XSSFWorkbook) WorkbookFactory.create(XSSF);
			sheets = new HashMap<>();
			this.landscapeMode = landscapeMode;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Instantiates an Excel workbook from an {@code File}.
	 */
	public ExcelWorkbook(final File file) {
		try {
			cellStyles = new HashMap<>();
			fonts = new HashMap<>();
			poiWorkbook = (XSSFWorkbook) WorkbookFactory.create(file);
			sheets = new HashMap<>();
			this.landscapeMode = false;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Instantiates an Excel workbook from an {@code InputStream}.
	 */
	public ExcelWorkbook(final InputStream is) {
		try {
			cellStyles = new HashMap<>();
			fonts = new HashMap<>();
			poiWorkbook = (XSSFWorkbook) WorkbookFactory.create(is);
			sheets = new HashMap<>();
			this.landscapeMode = false;
			poiWorkbook.sheetIterator()
					.forEachRemaining(s -> sheets.put(s.getSheetName(), new ExcelSheet(this, (XSSFSheet) s)));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	// See
	// https://www.xelplus.com/excel-dependent-drop-down-lists-multiple-words-spaces/
	void addDropDownMenu(DdDependentMenuReference name, AbstractExcelSheet abstractSheet,
			CellRangeAddress cellAddress) {
		DdGroupMenuContext groupMenuContext = name.dropDownGroupName().groupInfo();
		String groupMenuCellAddress = groupMenuContext.getCellAddress();
		String groupMenuName = groupMenuContext.getGroupName();
		Validate.isTrue(ddMenuDetails.containsKey(groupMenuName), "The MenuDetails isn't set.");

		MenuDetails menuDetails = ddMenuDetails.get(groupMenuName);
		StringBuffer dependentListFormula = new StringBuffer("INDEX(");
		dependentListFormula.append(menuDetails.headerArea) //
				.append(", , MATCH(") //
				.append(groupMenuCellAddress) //
				.append(", ") //
				.append(menuDetails.headerRange) //
				.append(", 0))");

		log.debug("DdDependentMenuReference: {}, Formula: {}", groupMenuName, dependentListFormula.toString());

		Sheet sheet = abstractSheet.getPoiSheet();
		DataValidationHelper dvHelper = sheet.getDataValidationHelper();
		DataValidationConstraint dvConstraint = dvHelper.createFormulaListConstraint(dependentListFormula.toString());
		CellRangeAddressList addressList = new CellRangeAddressList();
		addressList.addCellRangeAddress(cellAddress);
		DataValidation validation = dvHelper.createValidation(dvConstraint, addressList);
		sheet.addValidationData(validation);

		// TODO- Delete instance name?
	}

	// See
	// https://www.xelplus.com/excel-dependent-drop-down-lists-multiple-words-spaces/
	void addDropDownMenu(DdGroupMenuReference dropDownGroupMenuRef, AbstractExcelSheet abstractSheet,
			CellRangeAddress cellAddress) {
		DdGroupMenuContext groupMenuContext = dropDownGroupMenuRef.groupInfo();
		groupMenuContext.setSheetname(abstractSheet.getSheetName());
		String groupMenuCellAddress = cellAddress.formatAsString(groupMenuContext.getSheetname(), true);
		groupMenuContext.setCellAddress(groupMenuCellAddress);
		String groupMenuName = groupMenuContext.getGroupName();
		Validate.isTrue(ddMenuDetails.containsKey(groupMenuName), "Unknown drop-down list name %s.", groupMenuName);

		log.debug("DdGroupMenuReference: {}, Formula: {}", groupMenuName, groupMenuCellAddress);

		Sheet sheet = abstractSheet.getPoiSheet();
		DataValidationHelper dvHelper = sheet.getDataValidationHelper();
		DataValidationConstraint dvConstraint = dvHelper.createFormulaListConstraint(groupMenuName);
		CellRangeAddressList addressList = new CellRangeAddressList();
		addressList.addCellRangeAddress(cellAddress);
		DataValidation validation = dvHelper.createValidation(dvConstraint, addressList);
		sheet.addValidationData(validation);
	}

	void addDropDownMenu(DdMenuReference dropDownMenuRef, AbstractExcelSheet abstractSheet,
			CellRangeAddress cellAddress) {
		String menuName = normalize(dropDownMenuRef.menuName());
		Validate.isTrue(ddMenuNames.containsKey(menuName), "Unknown drop-down list name %s. See createDropDownMenus().",
				menuName);

		String menuFormula = ddMenuNames.get(menuName);

		log.debug("DdMenuReference: {}, Formula: {}", menuName, menuFormula);

		Sheet sheet = abstractSheet.getPoiSheet();
		DataValidationHelper dvHelper = sheet.getDataValidationHelper();
		DataValidationConstraint dvConstraint = dvHelper.createFormulaListConstraint(menuName);
		CellRangeAddressList addressList = new CellRangeAddressList();
		addressList.addCellRangeAddress(cellAddress);
		DataValidation validation = dvHelper.createValidation(dvConstraint, addressList);
		sheet.addValidationData(validation);
	}

	/**
	 * Adds a picture to the workbook filling the specified rows and columns.
	 * 
	 * @param sheet
	 * @param image
	 * @param firstCol
	 * @param firstRow
	 * @param lastCol
	 * @param lastRow
	 * 
	 *                 See
	 *                 https://stackoverflow.com/questions/37182688/apache-poi-excel-sheet-resize-a-picture-while-keeping-its-ratio
	 */
	public void addPicture(Sheet sheet, String image, int firstCol, int firstRow, int lastCol, int lastRow) {
		InputStream inputStream = null;
		try {
			Resource resource = new ClassPathResource(image);
			inputStream = resource.getInputStream();
			int pictureureIdx = poiWorkbook.addPicture(inputStream.readAllBytes(), getImageType(image));
			inputStream.close();

			CreationHelper helper = poiWorkbook.getCreationHelper();
			Drawing<?> drawing = sheet.createDrawingPatriarch();
			ClientAnchor anchor = helper.createClientAnchor();
//	        anchor.setDx1(0);
//	        anchor.setDy1(0);
//	        anchor.setDx2(100);
//	        anchor.setDy2(100);
			anchor.setCol1(firstCol);
			anchor.setCol2(lastCol);
			anchor.setRow1(firstRow);
			anchor.setRow2(lastRow);
			drawing.createPicture(anchor, pictureureIdx);
//	        p.resize();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Close the underlying input resource. No further operations should be
	 * performed on the workbook.
	 */
	public void close() {
		try {
			if (poiWorkbook != null) {
				poiWorkbook.close();
			}
		} catch (IOException e) {
			;
		}
	}

	/**
	 * Returns group menu context(s) in the order of the the provided {@code menus}.
	 * The drop-down menu(s) are created within a WorkSheet tab named
	 * "DropDownMenus". The drop-down menu(s) can later be referenced and placed
	 * within cells.
	 * 
	 * @param hidden indicates if sheet tab containing menus should be visible or
	 *               not
	 * @param menus  drop-down menu items
	 * 
	 * @return group menu context(s) used to create dependent drop-down menus
	 * 
	 * @see DdGroupMenuReference
	 * @see DdDependentMenuReference
	 */
	public List<DdGroupMenuContext> createDropDownMenus(boolean hidden,
			@SuppressWarnings("unchecked") List<DdMenu>... menus) {
		List<DdGroupMenuContext> list = new ArrayList<>();
		Stream.of(menus).forEach(s -> list.add(createDropDownMenus(hidden, s)));

		return list;
	}

	/**
	 * Returns a group menu context used to create dependent drop-down menus. The
	 * drop-down menu(s) are created within a WorkSheet tab named "DropDownMenus".
	 * The drop-down menu(s) can later be referenced and placed within cells.
	 * 
	 * @param hidden indicates if sheet tab containing menus should be visible or
	 *               not
	 * @param menus  drop-down menu items
	 * 
	 * @return a group menu context used to create dependent drop-down menus
	 * 
	 * @see DdGroupMenuReference
	 * @see DdDependentMenuReference
	 * @see https://www.xelplus.com/excel-dependent-drop-down-lists-multiple-words-spaces/
	 * 
	 * 
	 *      =MATCH(LOOKUP_value, LOOKUP_range, match_type)
	 * 
	 * 
	 *      =INDEX(array, row_num, [col_num], [area_num])
	 *      https://exceljet.net/functions/index-function
	 * 
	 */
	public DdGroupMenuContext createDropDownMenus(boolean hidden, List<DdMenu> menus) {
		String listSheetName = "DropDownMenus";

		ExcelSheet sheet = getExcelSheet(listSheetName);
		sheet.getPoiSheet().protectSheet("P@ssw0rd");
		poiWorkbook.setSheetOrder(listSheetName, 0);
		poiWorkbook.setSheetVisibility(0, hidden ? VERY_HIDDEN : VISIBLE);

		StringBuilder headerSourceRange = new StringBuilder(listSheetName) //
				.append("!$");
		StringBuilder sourceMenuArea = new StringBuilder(listSheetName) //
				.append("!$");
		String formulaTextPartB = null;

		int size = ddMenuNames.size();

		String firstColLetter = null;
		String lastColLetter = null;
		StringBuilder buffy = new StringBuilder();
		int maxMenuLength = 0;

		for (DdMenu dropDownMenu : menus) {
			String listHeaderName = dropDownMenu.name();
			buffy.append(listHeaderName) //
					.append("_");

			if (maxMenuLength < dropDownMenu.items().size()) {
				maxMenuLength = dropDownMenu.items().size();
			}

			sheet.withRow(1).withColumn(size);

			int columnCnt = size++;
			sheet.withCells(CellValues.builder().add(listHeaderName).build());
			List<String> items = dropDownMenu.items();
			for (String item : items) {
				sheet.withNextRow().withColumn(size).withCells(CellValues.builder().add(item).build());
			}

			// Create formulas for the item list constraints.
			String colLetter = lastColLetter = CellReference.convertNumToColString(columnCnt);
			if (isNull(firstColLetter)) {
				firstColLetter = colLetter;
			}
			int row = sheet.getCurrentRowNum() + 1;
			String formulaTextPartA = listSheetName + "!$" + colLetter + "$2";
			formulaTextPartB = "$" + colLetter + "$" + row;

			Name namedRange = poiWorkbook.createName();
			String listHeaderName2 = normalize(listHeaderName);
			namedRange.setNameName(listHeaderName2);
			String formulaText = formulaTextPartA + ":" + formulaTextPartB;
			namedRange.setRefersToFormula(formulaText);

			ddMenuNames.put(listHeaderName2, formulaText);
			log.debug("DropDownMenuName: {}, DropDownMenuAddress: {}", dropDownMenu.name(), formulaText);
		}
		buffy.append("Group");
// TODO get 1st column- Name: Categories, Formula: ListSheet!$A$1:$C$1
		headerSourceRange.append(firstColLetter) //
				.append("$1:$") //
				.append(lastColLetter) //
				.append("$1");

		int maxMenuRow = maxMenuLength + 1;
		sourceMenuArea.append(firstColLetter) //
				.append("$2:$") //
				.append(lastColLetter) //
				.append("$") //
				.append(maxMenuRow);

		Name headerRange = poiWorkbook.createName();
		String groupMenuName = normalize(buffy.toString());
		headerRange.setNameName(groupMenuName);
		headerRange.setRefersToFormula(headerSourceRange.toString());

		MenuDetails menuDetails = new MenuDetails(headerSourceRange.toString(), sourceMenuArea.toString());
		log.debug("GroupMenuName: {}, MenuDetails: {}", groupMenuName, menuDetails);
		ddMenuDetails.put(groupMenuName, menuDetails);

		Integer maxGroupNameLength = menus.stream() //
				.map(s -> s.name()) //
				.map(String::length) //
				.max(Integer::compare) //
				.get();

		Integer maxItemNameLength = menus.stream() //
				.map(s -> s.items()) //
				.flatMap(Collection::stream) //
				.map(String::length) //
				.max(Integer::compare) //
				.get();

		return new DdGroupMenuContext(groupMenuName, maxGroupNameLength, maxItemNameLength);
	}

	private XSSFSheet createSheet(String sheetname) {
		XSSFSheet sheetWrapper = poiWorkbook.createSheet(sheetname);
		return sheetWrapper;
	}

	/**
	 * Returns the workbook {@code CellStyle} cache.
	 * 
	 * @return the workbook {@code CellStyle} cache
	 */
	Map<String, org.apache.poi.ss.usermodel.CellStyle> getCellStyles() {
		return cellStyles;
	}

	/**
	 * Returns a newly created or cached Excel sheet with the given name.
	 * 
	 * @param sheetName the Excel sheet name which will displayed in the workbook
	 *                  tab
	 * @return a newly created or cached Excel sheet with the given name
	 */
	public ExcelSheet getExcelSheet(String sheetName) {
		ExcelSheet s = sheets.computeIfAbsent(sheetName, name -> new ExcelSheet(this, createSheet(sheetName)));
		s.setLandscape(landscapeMode);
		return s;
	}

	/**
	 * Returns a newly created or cached Excel sheet with the given name.
	 * 
	 * @param sheetName the Excel sheet name which will displayed in the workbook
	 *                  tab
	 * @param cellStyle a default {@link CellStyle} to use
	 * @return a newly created or cached Excel sheet with the given name
	 */
	public ExcelSheet getExcelSheet(String sheetName, CellStyle cellStyle) {
		return sheets.computeIfAbsent(sheetName, n -> new ExcelSheet(this, createSheet(sheetName), cellStyle));
	}

	/**
	 * Returns the workbook {@code Font} cache.
	 * 
	 * @return the workbook {@code Font} cache
	 */
	Map<String, Font> getFonts() {
		return fonts;
	}

	private int getImageType(String image) {
		if (StringUtils.endsWithIgnoreCase(image, ".gif")) {
			return XSSFWorkbook.PICTURE_TYPE_GIF;
		} else if (StringUtils.endsWithIgnoreCase(image, ".jpg")) {
			return XSSFWorkbook.PICTURE_TYPE_JPEG;
		} else if (StringUtils.endsWithIgnoreCase(image, ".png")) {
			return XSSFWorkbook.PICTURE_TYPE_PNG;
		}

		throw new IllegalArgumentException("Unknown image type: " + image);
	}

	public Workbook getPoiWorkbook() {
		return poiWorkbook;
	}

	/**
	 * Creates a custom color.
	 * 
	 * @param rgb the color components
	 * @return the custom color
	 * 
	 * @see <a href="https://www.htmlcsscolor.com/hex/99CCFF" target="_blank">Color
	 *      Picker</a>
	 */
	XSSFColor getRGBColor(byte[] rgb) {
		return new XSSFColor(rgb);
	}

	/**
	 * Creates a custom color.
	 * 
	 * @param hexColor a hexadecimal color
	 * @return the custom color
	 * 
	 * @see <a href="https://www.htmlcsscolor.com/hex/99CCFF" target="_blank">Color
	 *      Picker</a>
	 */
	XSSFColor getRGBColor(int hexColor) {
		byte[] rgb = new byte[] { byteOf((hexColor >> 16) & 0xFF), byteOf((hexColor >> 8) & 0xFF),
				byteOf(hexColor & 0xFF) };
		return getRGBColor(rgb);
	}

	/**
	 * Returns the spreadsheet(s) in no particular order.
	 * 
	 * @return the spreadsheet(s) in no particular order
	 */
	public Collection<ExcelSheet> getSheets() {
		return sheets.values();
	}

	/**
	 * Returns a newly created Excel sheet with the given name. If the name was
	 * previously used it's space padded until it's unique.
	 * 
	 * @param sheetName the Excel sheet name which will displayed in the workbook
	 *                  tab
	 * @return a newly created or cached Excel sheet with the given name
	 */
	public ExcelSheet getUniqueExcelSheet(String sheetName) {
		StringBuffer buffy = new StringBuffer(sheetName);
		while (sheets.containsKey(buffy.toString())) {
			buffy.append(" ");
		}

		String key = buffy.toString();
		ExcelSheet s = sheets.computeIfAbsent(key, n -> new ExcelSheet(this, createSheet(key)));
		s.setLandscape(landscapeMode);
		return s;
	}

	/**
	 * Returns indication that the provided drop-drop menu was created.
	 * 
	 * @param menuName the drop-down menu name provided upon creation.
	 * 
	 * @return indication that the provided drop-drop menu name was created
	 * 
	 * @see DdMenu#name()
	 * @see ExcelWorkbook#createDropDownMenus(boolean, List)
	 */
	public boolean isDropDropMenuCreated(String menuName) {
		return ddMenuNames.containsKey(menuName);
	}

	/**
	 * Writes the document to the given {@code OutputStream}.
	 *
	 * @param stream the stream to write to
	 * @throws IOException upon write error
	 */
	public void saveAsXlsx(OutputStream stream) throws IOException {
		poiWorkbook.write(stream);
	}

	/**
	 * Writes the document to the given pathname.
	 * 
	 * @param pathname a pathname string
	 * @throws IOException upon write error
	 */
	public void saveAsXlsx(String pathname) throws IOException {
		try (FileOutputStream stream = new FileOutputStream(new File(pathname))) {
			saveAsXlsx(stream);
		}
	}
}
