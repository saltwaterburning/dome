package com.pw.dome.pacing.subcategory;

import lombok.Builder;

@Builder
public record PacingSubcategoryDTO(String category, String subcategory) {
	;
}
