package com.dbds.common.rs;

import jakarta.ws.rs.core.MediaType;

/**
 * Provides {@link io.swagger.v3.oas.annotations.Operation} related constants. Provides
 * {@link MediaType}s and status codes as {@code String}s to aid in documenting APIs.
 * 
 * @author <a href="mailto:art.rijos@gmail.com">Art Rijos</a>
 *
 * @see Descriptions
 * @see Status
 */
public interface RESTfulResource {
  /**
   * A {@code String} constant representing {@value #APP_JSON} media type.
   */
  String APP_JSON = MediaType.APPLICATION_JSON;
  /**
   * A {@code String} constant representing {@value #APP_XML} media type.
   */
  String APP_XML = MediaType.APPLICATION_XML;

  /**
   * A {@code String} constant representing {@value #TEXT_HTML} media type.
   */
  String TEXT_HTML = MediaType.TEXT_HTML;

  /**
   * 200 OK, see <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.1">HTTP/1.1
   * documentation</a>.
   */
  String OK = "200";
  /**
   * 201 Created, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.2">HTTP/1.1
   * documentation</a>.
   */
  String CREATED = "201";
  /**
   * 202 Accepted, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.3">HTTP/1.1
   * documentation</a>.
   */
  String ACCEPTED = "202";
  /**
   * 204 No Content, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.5">HTTP/1.1
   * documentation</a>.
   */
  String NO_CONTENT = "204";
  /**
   * 205 Reset Content, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.6">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String RESET_CONTENT = "205";
  /**
   * 206 Reset Content, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.7">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String PARTIAL_CONTENT = "206";
  /**
   * 301 Moved Permanently, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.2">HTTP/1.1
   * documentation</a>.
   */
  String MOVED_PERMANENTLY = "301";
  /**
   * 302 Found, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.3">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String FOUND = "302";
  /**
   * 303 See Other, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.4">HTTP/1.1
   * documentation</a>.
   */
  String SEE_OTHER = "303";
  /**
   * 304 Not Modified, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.5">HTTP/1.1
   * documentation</a>.
   */
  String NOT_MODIFIED = "304";
  /**
   * 305 Use Proxy, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.6">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String USE_PROXY = "305";
  /**
   * 307 Temporary Redirect, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.8">HTTP/1.1
   * documentation</a>.
   */
  String TEMPORARY_REDIRECT = "307";
  /**
   * 400 Bad Request, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.1">HTTP/1.1
   * documentation</a>.
   */
  String BAD_REQUEST = "400";
  /**
   * 401 Unauthorized, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.2">HTTP/1.1
   * documentation</a>.
   */
  String UNAUTHORIZED = "401";
  /**
   * 402 Payment Required, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.3">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String PAYMENT_REQUIRED = "402";
  /**
   * 403 Forbidden, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.4">HTTP/1.1
   * documentation</a>.
   */
  String FORBIDDEN = "403";
  /**
   * 404 Not Found, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.5">HTTP/1.1
   * documentation</a>.
   */
  String NOT_FOUND = "404";
  /**
   * 405 Method Not Allowed, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.6">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String METHOD_NOT_ALLOWED = "405";
  /**
   * 406 Not Acceptable, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.7">HTTP/1.1
   * documentation</a>.
   */
  String NOT_ACCEPTABLE = "406";
  /**
   * 407 Proxy Authentication Required, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.8">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String PROXY_AUTHENTICATION_REQUIRED = "407";
  /**
   * 408 Request Timeout, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.9">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String REQUEST_TIMEOUT = "408";
  /**
   * 409 Conflict, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.10">HTTP/1.1
   * documentation</a>.
   */
  String CONFLICT = "409";
  /**
   * 410 Gone, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.11">HTTP/1.1
   * documentation</a>.
   */
  String GONE = "410";
  /**
   * 411 Length Required, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.12">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String LENGTH_REQUIRED = "411";
  /**
   * 412 Precondition Failed, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.13">HTTP/1.1
   * documentation</a>.
   */
  String PRECONDITION_FAILED = "412";
  /**
   * 413 Request Entity Too Large, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.14">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String REQUEST_ENTITY_TOO_LARGE = "413";
  /**
   * 414 Request-URI Too Long, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.15">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String REQUEST_URI_TOO_LONG = "414";
  /**
   * 415 Unsupported Media Type, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.16">HTTP/1.1
   * documentation</a>.
   */
  String UNSUPPORTED_MEDIA_TYPE = "415";
  /**
   * 416 Requested Range Not Satisfiable, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.17">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String REQUESTED_RANGE_NOT_SATISFIABLE = "416";
  /**
   * 417 Expectation Failed, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.18">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String EXPECTATION_FAILED = "417";
  /**
   * 428 Precondition required, see <a href="https://tools.ietf.org/html/rfc6585#section-3">RFC
   * 6585: Additional HTTP Status Codes</a>.
   *
   * @since 2.1
   */
  String PRECONDITION_REQUIRED = "428";
  /**
   * 429 Too Many Requests, see <a href="https://tools.ietf.org/html/rfc6585#section-4">RFC 6585:
   * Additional HTTP Status Codes</a>.
   *
   * @since 2.1
   */
  String TOO_MANY_REQUESTS = "429";
  /**
   * 431 Request Header Fields Too Large, see
   * <a href="https://tools.ietf.org/html/rfc6585#section-5">RFC 6585: Additional HTTP Status
   * Codes</a>.
   *
   * @since 2.1
   */
  String REQUEST_HEADER_FIELDS_TOO_LARGE = "431";
  /**
   * 500 Internal Server Error, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.1">HTTP/1.1
   * documentation</a>.
   */
  String INTERNAL_SERVER_ERROR = "500";
  /**
   * 501 Not Implemented, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.2">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String NOT_IMPLEMENTED = "501";
  /**
   * 502 Bad Gateway, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.3">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String BAD_GATEWAY = "502";
  /**
   * 503 Service Unavailable, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.4">HTTP/1.1
   * documentation</a>.
   */
  String SERVICE_UNAVAILABLE = "503";
  /**
   * 504 Gateway Timeout, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.5">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String GATEWAY_TIMEOUT = "504";
  /**
   * 505 HTTP Version Not Supported, see
   * <a href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.6">HTTP/1.1
   * documentation</a>.
   *
   * @since 2.0
   */
  String HTTP_VERSION_NOT_SUPPORTED = "505";
  /**
   * 511 Network Authentication Required, see
   * <a href="https://tools.ietf.org/html/rfc6585#section-6">RFC 6585: Additional HTTP Status
   * Codes</a>.
   *
   * @since 2.1
   */
  String NETWORK_AUTHENTICATION_REQUIRED = "511";

  /**
   * Provides {@link io.swagger.v3.oas.annotations.Operation} related constants. Provides status
   * code descriptions to aid in documenting APIs.
   */
  public interface Descriptions {
    /**
     * 200 OK, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.1">HTTP/1.1
     * documentation</a>}.
     */
    String OK = "OK";
    /**
     * 201 Created, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.2">HTTP/1.1
     * documentation</a>}.
     */
    String CREATED = "Created";
    /**
     * 202 Accepted, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.3">HTTP/1.1
     * documentation</a>}.
     */
    String ACCEPTED = "Accepted";
    /**
     * 204 No Content, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.5">HTTP/1.1
     * documentation</a>}.
     */
    String NO_CONTENT = "No Content";
    /**
     * 205 Reset Content, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.6">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String RESET_CONTENT = "Reset Content";
    /**
     * 206 Reset Content, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.2.7">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String PARTIAL_CONTENT = "Partial Content";
    /**
     * 301 Moved Permanently, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.2">HTTP/1.1
     * documentation</a>}.
     */
    String MOVED_PERMANENTLY = "Moved Permanently";
    /**
     * 302 Found, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.3">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String FOUND = "Found";
    /**
     * 303 See Other, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.4">HTTP/1.1
     * documentation</a>}.
     */
    String SEE_OTHER = "See Other";
    /**
     * 304 Not Modified, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.5">HTTP/1.1
     * documentation</a>}.
     */
    String NOT_MODIFIED = "Not Modified";
    /**
     * 305 Use Proxy, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.6">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String USE_PROXY = "Use Proxy";
    /**
     * 307 Temporary Redirect, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.3.8">HTTP/1.1
     * documentation</a>}.
     */
    String TEMPORARY_REDIRECT = "Temporary Redirect";
    /**
     * 400 Bad Request, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.1">HTTP/1.1
     * documentation</a>}.
     */
    String BAD_REQUEST = "Bad Request";
    /**
     * 401 Unauthorized, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.2">HTTP/1.1
     * documentation</a>}.
     */
    String UNAUTHORIZED = "Unauthorized";
    /**
     * 402 Payment Required, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.3">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String PAYMENT_REQUIRED = "Payment Required";
    /**
     * 403 Forbidden, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.4">HTTP/1.1
     * documentation</a>}.
     */
    String FORBIDDEN = "Forbidden";
    /**
     * 404 Not Found, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.5">HTTP/1.1
     * documentation</a>}.
     */
    String NOT_FOUND = "Not Found";
    /**
     * 405 Method Not Allowed, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.6">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String METHOD_NOT_ALLOWED = "Method Not Allowed";
    /**
     * 406 Not Acceptable, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.7">HTTP/1.1
     * documentation</a>}.
     */
    String NOT_ACCEPTABLE = "Not Acceptable";
    /**
     * 407 Proxy Authentication Required, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.8">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String PROXY_AUTHENTICATION_REQUIRED = "Proxy Authentication Required";
    /**
     * 408 Request Timeout, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.9">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String REQUEST_TIMEOUT = "Request Timeout";
    /**
     * 409 Conflict, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.10">HTTP/1.1
     * documentation</a>}.
     */
    String CONFLICT = "Conflict";
    /**
     * 410 Gone, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.11">HTTP/1.1
     * documentation</a>}.
     */
    String GONE = "Gone";
    /**
     * 411 Length Required, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.12">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String LENGTH_REQUIRED = "Length Required";
    /**
     * 412 Precondition Failed, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.13">HTTP/1.1
     * documentation</a>}.
     */
    String PRECONDITION_FAILED = "Precondition Failed";
    /**
     * 413 Request Entity Too Large, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.14">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String REQUEST_ENTITY_TOO_LARGE = "Request Entity Too Large";
    /**
     * 414 Request-URI Too Long, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.15">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String REQUEST_URI_TOO_LONG = "Request-URI Too Long";
    /**
     * 415 Unsupported Media Type, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.16">HTTP/1.1
     * documentation</a>}.
     */
    String UNSUPPORTED_MEDIA_TYPE = "Unsupported Media Type";
    /**
     * 416 Requested Range Not Satisfiable, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.17">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String REQUESTED_RANGE_NOT_SATISFIABLE = "Requested Range Not Satisfiable";
    /**
     * 417 Expectation Failed, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.4.18">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String EXPECTATION_FAILED = "Expectation Failed";
    /**
     * 428 Precondition required, see
     * {@link <a href="https://tools.ietf.org/html/rfc6585#section-3">RFC 6585: Additional HTTP
     * Status Codes</a>}.
     *
     * @since 2.1
     */
    String PRECONDITION_REQUIRED = "Precondition Required";
    /**
     * 429 Too Many Requests, see {@link <a href="https://tools.ietf.org/html/rfc6585#section-4">RFC
     * 6585: Additional HTTP Status Codes</a>}.
     *
     * @since 2.1
     */
    String TOO_MANY_REQUESTS = "Too Many Requests";
    /**
     * 431 Request Header Fields Too Large, see
     * {@link <a href="https://tools.ietf.org/html/rfc6585#section-5">RFC 6585: Additional HTTP
     * Status Codes</a>}.
     *
     * @since 2.1
     */
    String REQUEST_HEADER_FIELDS_TOO_LARGE = "Request Header Fields Too Large";
    /**
     * 500 Internal Server Error, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.1">HTTP/1.1
     * documentation</a>}.
     */
    String INTERNAL_SERVER_ERROR = "Internal Server Error";
    /**
     * 501 Not Implemented, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.2">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String NOT_IMPLEMENTED = "Not Implemented";
    /**
     * 502 Bad Gateway, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.3">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String BAD_GATEWAY = "Bad Gateway";
    /**
     * 503 Service Unavailable, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.4">HTTP/1.1
     * documentation</a>}.
     */
    String SERVICE_UNAVAILABLE = "Service Unavailable";
    /**
     * 504 Gateway Timeout, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.5">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String GATEWAY_TIMEOUT = "Gateway Timeout";
    /**
     * 505 HTTP Version Not Supported, see
     * {@link <a href= "http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html#sec10.5.6">HTTP/1.1
     * documentation</a>}.
     *
     * @since 2.0
     */
    String HTTP_VERSION_NOT_SUPPORTED = "HTTP Version Not Supported";
    /**
     * 511 Network Authentication Required, see
     * {@link <a href="https://tools.ietf.org/html/rfc6585#section-6">RFC 6585: Additional HTTP
     * Status Codes</a>}.
     *
     * @since 2.1
     */
    String NETWORK_AUTHENTICATION_REQUIRED = "Network Authentication Required";
  }
}
